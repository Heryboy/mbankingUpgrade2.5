================================================== How to rebuild platform ======================================================

1) MainProjectFolder -> config.xml

2)  - xml: <widget id="io.ionic.starter" version="0.0.1" xmlns="http://www.w3.org/ns/widgets" xmlns:cdv="http://cordova.apache.org/ns/1.0">
    - change the 'io.ionic.starter to  'kh.com.ppcbank.mbanking2.sit'

3) Save the file.

4) Delete the platforms folder.

5) Open the command prompt and run 
- ionic cordova build android

6) copy MainActivity from container and overwrite MainActivity in package kh.com.ppcbank.mbanking2.sit


============================================= How to apk for enviroment SIT, UAT and PRO ==========================================

