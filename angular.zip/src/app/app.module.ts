import { HttpClient, HttpClientJsonpModule, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { BizMOBAppIron } from '@ionic-native/bizmob-plugin-appiron/ngx';
import { BizMOBApplicationExit } from '@ionic-native/bizmob-plugin-applicationexit/ngx';
import { AuthSecurity } from '@ionic-native/bizmob-plugin-authsecurity/ngx';
import { BizMOBCheckProxy } from '@ionic-native/bizmob-plugin-checkproxy/ngx';
import { BizMOBDeviceInfo } from '@ionic-native/bizmob-plugin-deviceinfo/ngx';
import { BizMOBPush } from '@ionic-native/bizmob-plugin-push/ngx';
import { BizMOBSecureKeypad } from '@ionic-native/bizmob-plugin-securekeypad/ngx';
import { BizMOBUpdate } from '@ionic-native/bizmob-plugin-update/ngx';
import { Broadcaster } from '@ionic-native/broadcaster/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Camera } from '@ionic-native/camera/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { Contact, Contacts } from '@ionic-native/contacts/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { ImagePicker } from '@ionic-native/image-picker/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Network } from '@ionic-native/network/ngx';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { TouchID } from '@ionic-native/touch-id/ngx';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BizPushService } from './bizmob/biz-push.service';
import { HomPageModule } from './hom/hom.module';
import { SBSharedModule } from './shared/shared.module';
import { HTTP } from '@ionic-native/http/ngx';
import { BizWaveSpeechToText } from '@ionic-native/bizwave-plugin-speechtotext/ngx';
import { Diagnostic } from '@ionic-native/diagnostic/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
// import { ThemeDetection } from '@ionic-native/theme-detection/ngx';
import { Badge } from '@ionic-native/badge/ngx';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    HttpClientJsonpModule,
    IonicModule.forRoot(),
    IonicStorageModule.forRoot(),
    SBSharedModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      },
    }),
    BrowserAnimationsModule,
    WindowModule,
    // ListPageModusle,
    // ShareModule,
    HomPageModule
  ],
  providers: [
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: InterceptorService,
    //   multi: true
    // },
    HTTP,
    Contacts,
    Contact,
    CallNumber,
    InAppBrowser,
    StatusBar,
    Clipboard,
    SplashScreen,
    Camera,
    File,
    FileTransfer,
    ImagePicker,
    AndroidPermissions,
    LocationAccuracy,
    Geolocation,
    SocialSharing,
    Broadcaster,
    BizPushService,
    BizMOBPush,
    Keyboard,
    BizMOBSecureKeypad,
    BizMOBAppIron,
    BizMOBCheckProxy,
    BizMOBUpdate,
    BizMOBApplicationExit,
    BizPushService,
    BizMOBPush,
    BizMOBDeviceInfo,
    Network,
    AuthSecurity,
    FingerprintAIO,
    TouchID,
    SmsRetriever,
    BizWaveSpeechToText,
    Diagnostic,
    MobileAccessibility,
    // ThemeDetection,
    Badge,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {
    console.log('AppModule Loaded!!!');
  }
}
