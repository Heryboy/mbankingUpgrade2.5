import { Component, NgZone, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Broadcaster } from '@ionic-native/broadcaster/ngx';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Platform, NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { InitializeService } from './bizmob/initialize.service';
import { InfServiceService } from './inf/services/inf-service.service';
import { MenuClick } from './shared/component/timepicker/time-picker-modal/slideIndexImp';
import { DEVICE_OS_TYPE, LANGUAGE, LOCAL_STORAGE } from './shared/constants/common.const';
import { BackService } from './shared/services/back.service';
import { BizserverService } from './shared/services/bizserver.service';
import { EncryptService } from './shared/services/encrypt.service';
import { MessageService } from './shared/services/message.service';
import { ModalService } from './shared/services/modal.service';
import { LOGINReq } from './shared/TRClass/LOGIN-req';
import { Util } from './shared/util';
import { DataCenter } from './shared/utils/data-center.static';
import { DOCUMENT } from '@angular/common';
// import { ThemeDetection, ThemeDetectionResponse } from "@ionic-native/theme-detection/ngx";

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {

  util = new Util();
  isAppInForeground = false;
  userInfo: any;
  localLangCode: any;
  i18n: any;
  deviceInfo: any;
  AESIV: string;
  errorCode: string;
  isFingerprintAvailable: boolean;
  isShortcut: boolean;
  isShortcutBackground = true;
  isRememberId: boolean;

  projectInitializeComplete = false;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private translate: TranslateService,
    private broadcast: Broadcaster,
    private router: Router,
    private zone: NgZone,
    private modalService: ModalService,
    private init: InitializeService,
    private encryptService: EncryptService,
    private backService: BackService,
    private bizServer: BizserverService,
    private androidPermissions: AndroidPermissions,
    private locationAccuracy: LocationAccuracy,
    private fingerAIO: FingerprintAIO,
    private statusBar: StatusBar,
    private mobileAccessibility: MobileAccessibility,
    private messageService: MessageService,
    private infService: InfServiceService,
    private navCtrl: NavController,
    @Inject(DOCUMENT) private document: Document,
    // private themeDetection: ThemeDetection
  ) {

    this.checkisAppInForeground();

    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      // this.isDarkModeEnabled();
      if (mobileAccessibility.isScreenReaderRunning) {
        mobileAccessibility.usePreferredTextZoom(false);
      }
      this.setInitialAppLanguage();
      this.shortcutReceiver();
      this.pushNotificationReceiver();
      this.initializeApp();
    });
  }

  initializeApp() {
    if (environment.targetType !== 'emulator') {

        this.init.initSecurity().then(
          (res) => {
            const progerssOption = {
              show: true,
              // title: 'Update',
              message: "Updating New Contents...",
              messageColor: "0770FF",        //#이 없다면 알아서 붙이도록 작업했음 (default #000000),
              progressWidthPercent: 90,      //1~100
              progressLocationYPercent: 60,  //1~100
              backgroundColor: "00000000",
              progressColor: "0770FF",      //#이 없다면 알아서 붙이도록 작업했음 (default #2196f3)
              progressBgColor: "0770FF"    //#이 없다면 알아서 붙이도록 작업했음 (default #acacac)
              // titleAlign : "center",          //center, left, right (default center)
              // titleColor : "000000",         //#이 없다면 알아서 붙이도록 작업했음 (default #000000)
              // messageAlign : "left",          //center, left, right (default left)
            };

            this.init.initUpdate(progerssOption).then(
              (res1) => {
                if (res1.header.apiName === 'APP_UPDATE') {
                  this.forceUpdate(res1.header.errorText);
                  this.splashScreen.hide();
                } else {
                  this.projectInitialize();
                }
              },
              (err) => {
                this.uploadContentFail();
                this.splashScreen.hide();
              }
            );

          },
          (err) => {
            this.securityCheckFail(err);
            this.splashScreen.hide();
          }
        );
    } else {
      this.projectInitialize();
    }
  }

  async isAvailableFingerprint() {
    await this.fingerAIO.isAvailable().then(result => {
      if (result === 'finger') {
        this.isFingerprintAvailable = true;
      } else {
        this.isFingerprintAvailable = false;
      }
    }).catch(err => {
      this.isFingerprintAvailable = false;
    });
    return this.isFingerprintAvailable;
  }

  async projectInitialize() {
    this.platform.backButton.subscribeWithPriority(0, () => {
      this.backService.fire();
    });

    await this.permisstion();
    await this.isAvailableFingerprint().then((isFingerprintAvailable) => {
      this.util.setSecureStorage(LOCAL_STORAGE.IS_AVAILABLE_BIO_AUTHENTICATION, isFingerprintAvailable);
    });

    this.legacyLogin();
  }

  legacyLogin() {
    const login = new LOGINReq();

    login.body.legacy_message.header.trcode = 'CEB0000';
    login.body.legacy_trcode = 'CEB0000';

    if ( login.body.legacy_message.header.smartPhoneVersionTypeCode === DEVICE_OS_TYPE.IOS ) {
      login.body.app_key = environment.appKey.iOS;
    } else {
      login.body.app_key = environment.appKey.Android;
    }

    this.bizServer.bizMOBPost('LOGIN', login).then( (resTr) => {
      if ( !this.bizServer.cookie ) {
        this.initNavigation(resTr.body['legacy_message']['header'], resTr);
      } else {
        this.bizServer.bizMOBPost('LOGIN', login).then( (resTrSub) => {
          this.initNavigation(resTrSub.body['legacy_message']['header'], resTrSub);
        });
      }
    });
  }

  initNavigation(legacyHeader: any, resTr: any) {
      if ( legacyHeader.result && resTr.header ) {
        const userID = resTr.body['legacy_message']['body']['dummy'];

        this.util.setSecureStorage( LOCAL_STORAGE.GUESS_USER_ID, userID );
        this.util.setSecureStorage( LOCAL_STORAGE.ALREADY_SHOW_GUIDE, false ); // ADDED: 2020-03-27
        this.util.setSecureStorage( LOCAL_STORAGE.ALREADY_SHOW_GUIDE_BILL_PAYMENT, false ); // ADDED: 2020-05-12

        if (environment.targetType !== 'emulator') {

          this.util.removeSecureStorage(LOCAL_STORAGE.USER_INFO);
          this.util.removeSecureStorage(LOCAL_STORAGE.AESIV);
          this.util.removeSecureStorage(LOCAL_STORAGE.ERROR_CODE);

          this.encryptService.storePublicKey(() => {
            this.encryptService.registerAes(() => {

              this.projectInitializeComplete = true;

              if (!this.i18n || !this.localLangCode) {
                this.backService.language();
                this.splashScreen.hide();
              } else {
                if (!this.isShortcut) { 
                  this.isRememberId = this.util.getSecureStorage(LOCAL_STORAGE.IS_REMEMBER_ID);
                  if ( this.isRememberId === true ) { 
                    this.backService.login();
                    this.splashScreen.hide();
                  } else { 
                    this.backService.home();
                    this.splashScreen.hide();
                  } 
                } else if (this.isShortcut) {
                  this.backService.login();
                  this.splashScreen.hide();
                }
              }
              this.isShortcutBackground = false;
              // this.splashScreen.hide();
          });
        });
        } else {

          this.encryptService.storePublicKey(() => {
            this.encryptService.registerAes(() => {
              if (!this.i18n || !this.localLangCode) {
                this.backService.language();
              } else if (!this.isShortcut) { 
                this.isRememberId = this.util.getSecureStorage(LOCAL_STORAGE.IS_REMEMBER_ID);
                if ( this.isRememberId === true ) {
                  this.backService.login();
                } else { 
                  this.backService.home();
                }                 
              }

            });
          });
        }
      } else {
        this.legacyLogin();
      }
  }

  shortcutReceiver() {
    this.broadcast.addEventListener('shortcutpress').subscribe((event) => {
      DataCenter.set('root', 'shortcut', event);
      if (this.isShortcutBackground === false) {
        this.isShortcut = true;
        this.backService.login();
        this.splashScreen.hide();
      } else {
        this.isShortcut = true;
      }
    });

    this.broadcast.fireNativeEvent('init', {});
  }

  checkReservationArrival(message: string, background?: boolean, messageId?: string) {

    if (message.indexOf('[Visit Reservation Notification]') >= 0) {
      const userInfo = new Util().getSecureStorage(LOCAL_STORAGE.USER_INFO);
      if (userInfo !== null) {
        this.infService.showReservationArrivalPopUp(message);
      } else {
        DataCenter.set('HomPage', 'push', true);
        DataCenter.set('HomPage', 'reservation-arrival', true);
        this.backService.login();
      }
    } else {
      if (this.platform.is('ios')) {
        console.log('isAppInForeground: ', this.isAppInForeground);
        if (background) {
          this.onNotificationTab();
        }
      } else {
        console.log('isAppInForeground: ', this.isAppInForeground);
        if (this.isAppInForeground) {
          console.log('Push Received in foreground');
          if (messageId) {
            console.log('Initial Push Received');
          } else {
            console.log('User Tab on Push Notification');
            this.onNotificationTab();
          }
        } else {
          console.log('Push Received in background');
          if (!messageId) {
            console.log('Initial Push Received');
            this.onNotificationTab();
          }
        }
      }
    }
  }

  pushNotificationReceiver() {
    /* Application is closed, user tab on notification from notification bar.
    Thus language not yet initialized.*/
    const localLangCode = this.util.getSecureStorage(LOCAL_STORAGE.LANGUAGE_CODE);
    const i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);
    if (!i18n || !localLangCode) {
      this.setInitialAppLanguage();
    }

    this.broadcast.addEventListener('push').subscribe((event) => {
      let message: string;
      let messageId: string;
      DataCenter.set('HomPage', 'push-event', event);
      this.messageService.sendNewNotification(); // Update 'N' badge at my account screen
      console.log('push event: ', JSON.stringify(event));
      if (this.platform.is('ios')) {
        message = event.message;
        console.log('[ios] push message: ', message);
        console.log('event.background: ', event.background);
        console.log('typeof event.background: ', typeof event.background);
        if (message) {
          this.checkReservationArrival(message, event.background);
        }
      } else {
        message = JSON.parse(event.data).message;
        messageId = JSON.parse(event.data).messageId;
        console.log('[android] push message: ', message);
        this.checkReservationArrival(message, this.isAppInForeground, messageId);
      }
    });
  }

  onNotificationTab() {
    this.util.setSecureStorage('IS_HAVING_NEW_PUSH', false);
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    if (this.userInfo !== null) {
      new MenuClick().clearListMenu();
      this.zone.run(() => this.router.navigate(['/acc/NOT10000000'])); // ==> go to notification screen
    } else {
      DataCenter.set('HomPage', 'push', true);
      DataCenter.set('HomPage', 'reservation-arrival', false);
      this.backService.login();
    }
  }

  forceUpdate(version) {
    this.modalService.alert({
      title: 'Application Update',
      content: 'A new version of PPCBank mobile app is now available. Please update to the version ' + version,
      callback: () => {
        if (this.platform.is('android')) {
          window.open('https://play.google.com/store/apps/details?id=kh.com.ppcbank.mbanking2p', '_system', 'location=yes');
        } else {
          window.open('itms-apps://itunes.apple.com/app/apple-store/id1499620876?mt=8', '_system', 'location=yes');
        }

        this.backService.exit();
      },
    });
  }

  uploadContentFail() {
    this.modalService.alert({
      title: 'Contents updating',
      content: '[FAIL] Update is failed. try it again later.',
      callback: () => {
        this.backService.exit();
      },
    });
  }

  securityCheckFail(err: any) {
    this.modalService.alert({
      title: 'Security',
      // content: '[FAIL] App changing detected.',
      content: err.header.errorText,
      callback: () => {
        this.backService.exit();
      },
    });
  }

  checkisAppInForeground() {
    this.platform.pause.subscribe(() => {
      this.isAppInForeground = false;
      console.log('isAppInForeground: ', this.isAppInForeground);
    });

    this.platform.resume.subscribe(() => {
      // this.isDarkModeEnabled();
      if ( this.projectInitializeComplete ) {
        this.isAppInForeground = true;

        const userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);

        if ( !userInfo ) {
          const login = new LOGINReq();

          login.body.legacy_message.header.trcode = 'CEB0000';
          login.body.legacy_trcode = 'CEB0000';

          if ( login.body.legacy_message.header.smartPhoneVersionTypeCode === DEVICE_OS_TYPE.IOS ) {
            login.body.app_key = environment.appKey.iOS;
          } else {
            login.body.app_key = environment.appKey.Android;
          }

          this.bizServer.bizMOBPost('LOGIN', login ).then( (resTr) => {
            const legacyHeader  = resTr.body['legacy_message']['header'];
            this.bizServer.checkResponse(legacyHeader) && resTr.header;

            const userID = resTr.body['legacy_message']['body']['dummy'];

            new Util().setSecureStorage( LOCAL_STORAGE.GUESS_USER_ID, userID );

            this.encryptService.storePublicKey( () => {
              this.encryptService.registerAes(() => {
              });
            });
          });
        }
      }
    });
  }

  setInitialAppLanguage() {
    this.localLangCode = this.util.getSecureStorage(LOCAL_STORAGE.LANGUAGE_CODE);
    this.i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);

    if (!this.i18n || !this.localLangCode) {
      this.translate.setDefaultLang(LANGUAGE.I18N_EN.toString());
      this.translate.use(LANGUAGE.I18N_EN.toString()).toPromise();
    } else {
      this.translate.setDefaultLang(this.i18n);
      this.translate.use(this.i18n).toPromise();
    }
    
    (document.getElementById('cssId_en') as HTMLInputElement).disabled = true;
    (document.getElementById('cssId_kh') as HTMLInputElement).disabled = true;
    if (this.localLangCode === LANGUAGE.EN) {
      (document.getElementById('cssId_en') as HTMLInputElement).disabled = false;
    } else {
      (document.getElementById('cssId_kh') as HTMLInputElement).disabled = false;
    }
    
  }


  async permisstion() {

    if (this.platform.is('cordova') && this.platform.is('android')) {
      // this.androidPermissions.PERMISSION.RECORD_AUDIO,
      this.androidPermissions.requestPermissions([
        this.androidPermissions.PERMISSION.CAMERA,
        this.androidPermissions.PERMISSION.READ_CONTACTS,
        this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE,
        this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE,
        this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION,
        this.androidPermissions.PERMISSION.READ_PHONE_NUMBERS]);

      const canRequest = await this.locationAccuracy.canRequest() as boolean;
      if (canRequest) {
        this.androidPermissions.requestPermissions([this.androidPermissions.PERMISSION.REQUEST_PRIORITY_HIGH_ACCURACY,
                                                    this.androidPermissions.PERMISSION.GET_ACCOUNTS]);
      }
    }
  }

  // async isDarkModeEnabled() {
  //   try {
  //     const isDarkModeEnabled: ThemeDetectionResponse = await this.themeDetection.isDarkModeEnabled();
  //     if(this.platform.is('ios')) {
  //       if (isDarkModeEnabled.value) {
  //         this.statusBar.backgroundColorByHexString("#333333");
  //       } else {
  //         this.statusBar.backgroundColorByHexString("#ffffff");
  //         this.statusBar.styleDefault();
  //       }
  //     }
  //     else {
  //       this.statusBar.styleDefault();
  //     }
      
  //   } catch (e) {
  //     console.log(e);
  //     this.statusBar.styleDefault();
  //   }
  // }
}
