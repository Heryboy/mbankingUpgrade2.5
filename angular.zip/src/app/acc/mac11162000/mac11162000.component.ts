import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { ShareTransactionDetailService } from '../../shared/services/share-transaction-detail-info.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { FormMode } from 'src/app/trf/qui11110000/qui11110000.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mac11162000',
  templateUrl: './mac11162000.component.html',
  styleUrls: ['./mac11162000.component.scss'],
})
export class MAC11162000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read : IonContent, static : false } ) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    name = 'Transfer';

    constructor(
        private modalService: ModalService,
        private shareTransactionDetail: ShareTransactionDetailService,
        private socialShare: SocialSharing,
        private router: Router,
    ) { }

    ngOnInit() { }

    ngAfterViewInit(): void {
        this.myContent.getScrollElement().then( (element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }

    btnBackClicked() {
        this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
    }

    btnShareClicked() {
        const shareInfo = this.shareTransactionDetail.shareDeposit(this.data as any, this.name);
        console.log('this.name', this.name);
        this.socialShare.share(shareInfo).then(function () {
            // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
        }).catch(function (error) {
            // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
        });
    }

    btnTransferAgainClicked() {
        this.setAccount();
        DataCenter.set('transactionScreen', 'transactionDetails', this.data);
        this.btnBackClicked();
        const formMode: FormMode = 'again';
        this.router.navigate(['/quick/account-transfer'], {queryParams: {mode: formMode}}); // edit mode for transfer again
        console.log('btnTransferAgainClicked');
    }

    setAccount() {
        const account = {
            accountNo : this.data.accountNo,
            accountName : this.data.accountName,
            currencyCode : this.data.currencyCode,
            depositSubjectCode : this.data.depositSubjectCode,
            availableBalance : this.data.availableBalance,
            accountNickName: this.data.accountNickName
        };
        DataCenter.set('widthDrawAbleAccount', 'account', account);
    }

}
