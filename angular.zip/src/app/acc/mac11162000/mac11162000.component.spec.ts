import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mac11162000Component } from './mac11162000.component';

describe('Mac11162000Component', () => {
  let component: Mac11162000Component;
  let fixture: ComponentFixture<Mac11162000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mac11162000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mac11162000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
