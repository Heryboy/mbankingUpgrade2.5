import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11172100Component } from './mac11172100.component';

describe('MAC11172100Component', () => {
  let component: MAC11172100Component;
  let fixture: ComponentFixture<MAC11172100Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11172100Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11172100Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
