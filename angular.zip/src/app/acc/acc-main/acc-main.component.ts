import { DataReqService } from 'src/app/shared/services/data-req.service';
import { CEB5720Res } from './../../shared/TRClass/CEB5720-res';
import { BizserverService } from './../../shared/services/bizserver.service';
import { LOAN_PRODUCT_BU_CODE } from './../../shared/constants/common.const';
import { CEB5720Req } from './../../shared/TRClass/CEB5720-req';
import { LAU40000000Component } from './../../log/lau40000000/lau40000000.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { InfServiceService } from 'src/app/inf/services/inf-service.service';
import { AppFooterMenuComponent } from 'src/app/shared/component/app-footer-menu/app-footer-menu.component';
import { MenuClick } from 'src/app/shared/component/timepicker/time-picker-modal/slideIndexImp';
import { VoiceAccessComponent } from 'src/app/shared/component/voice-access/voice-access.component';
import { BackService } from 'src/app/shared/services/back.service';
import { ChooseWithdrawalAccountService } from 'src/app/shared/services/choose-withdrawal-account.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';
import { QUI10000000Component } from 'src/app/trf/qui10000000/qui10000000.component';
import { LOCAL_STORAGE } from '../../shared/constants/common.const';
import { Util } from '../../shared/util';
import { UserProfile } from '../mac11000000/mac11000000.model';
import { SegmentValue } from './acc-main.model';
import { MAC11800000Component } from 'src/app/trf/mac11800000/mac11800000.component';
import { QUI13000000AComponent } from 'src/app/trf/qui13000000-a/qui13000000-a.component';
import * as moment from 'moment';
@Component({
    selector: 'app-acc-main',
    templateUrl: './acc-main.component.html',
    styleUrls: ['./acc-main.component.scss'],
})
export class AccMainComponent implements OnInit {

    @ViewChild(AppFooterMenuComponent, { static: true }) comp: AppFooterMenuComponent;

    changeTitle: boolean;
    isHasNotification = false;
    util = new Util();

    profile = new UserProfile();
    invalidImgUrl: boolean;
    helloWord: string;
    userInfo: any;
    isDonateAccount: boolean;

    tabValue: SegmentValue = 'tab_my';
    tabMyCache: boolean;
    tabFavCache: boolean;
    tabRecCache: boolean;
    pushRegisterAttempt = 3;

    interval: any;

    isPersonal: boolean;
    menuClick = new MenuClick();
    collateralAccount = '';     // [view]
    accountList: any[];      // [server] new trcode for request collateral account
    languageCode;
    constructor(private router: Router,
        private route: ActivatedRoute,
        private modalService: ModalService,
        private translate: TranslateService,
        private backService: BackService,
        private messageService: MessageService,
        private bizServer: BizserverService,
        private dataReqService: DataReqService,
        private choosewithdrawalAccountService: ChooseWithdrawalAccountService,
        private infService: InfServiceService
    ) { }

    async ngOnInit() {
        this.subscribePushNotification();
        this.route.params.subscribe((param) => {
            if (param.tab !== this.tabValue) {
                this.setTab(param.tab);
            }
        });

        await this.requestCollateralAccount();

        this.setProfile();
        // const donate =  DataCenter.get('hom', 'donate'); // ADDED: 2020-04-14 , Removed: 2020-05-29
        const billPayment = DataCenter.get('hom', 'billPayment'); // ADDED: 2020-05-13
        // const isLoarnAganist =  DataCenter.get('loan-against-deposit', 'isLoarnAgainstDeposit');
        const isCovidSlide = DataCenter.get('hom', 'covidDonation');
        const isLoarnAganist = DataCenter.get('loan-against-deposit', 'isLoanAgainstDeposit');
        const isMyCard = DataCenter.get('hom', 'myCard');
        this.languageCode = this.util.getSecureStorage(LOCAL_STORAGE.LANGUAGE_CODE);
        if (this.isPersonal) { // ADDE: 2020-04-14

            /* if( donate ){
                if( Utils.isDonateAccount() ){
                    this.toDonate();
                }
            } else  */
            if (isCovidSlide) {
                this.router.navigateByUrl('/quick/payment-merchant');
            } else if (billPayment) { // ADDED: 2020-05-13
                this.router.navigateByUrl('/quick/bill-payment');
            } else if (isMyCard) 
                this.router.navigateByUrl('/card/car-main');
            else {
                this.guideNotices(this.languageCode); // SIM LONGDY // Teamporary CLose form MR Chantana PPCBank Staff
            }
            if (isLoarnAganist) { // ADDED: 2020-10-20 get from home menu screen in production loarn against deposit
                if (this.collateralAccount !== '') {
                    this.router.navigateByUrl('/open/loan/intro');
                } else {
                    this.router.navigateByUrl('/loan-apply/loan-term-condition');
                }
            }
        }
        // this.guideNotices(); // SIM LONGDY // Teamporary CLose form MR Chantana PPCBank Staff
        // if ( !this.util.getSecureStorage( LOCAL_STORAGE.IS_SKIP_GUIDE ) && !this.util.getSecureStorage( LOCAL_STORAGE.ALREADY_SHOW_GUIDE ) ) {
        //     this.modalService.open({
        //       content: LAU40000000Component,
        //       modalClass: ['pop_guide'],
        //       callback: (res) => {
        //         this.util.setSecureStorage( LOCAL_STORAGE.ALREADY_SHOW_GUIDE, true );
        //       }
        //     });
        // }

    }

    async requestCollateralAccount(accountNo?: any) {
        const reqTr = new CEB5720Req();
        reqTr.body.userID = Utils.getUserInfo().userID;
        reqTr.body.loanProductCode = LOAN_PRODUCT_BU_CODE;
        reqTr.body.customerNo = Utils.getUserInfo().customerNo;

        await this.bizServer.bizMOBPost('CEB5720', reqTr).then(data => {
            const resTr = data as CEB5720Res;
            if (this.bizServer.checkResponse(resTr.header)) {
                this.accountList = resTr.body.collateralAccountInfoList;
                if (this.accountList[0]) {
                    this.collateralAccount = this.accountList[0].accountNo ? this.accountList[0].accountNo : '';
                }
            }
        });
    }

    // ADDED: 2020-05-12
    // REMOVED: 2020-05-20 Utils.isEmployeeAccount()
    isDisable = false
    guideNotices(languageCode) {
        this.dataReqService.retrieveListPromotionPopup(languageCode).then(data => {
            if (data.body.items.length > 0) {
                let date;
                date = moment(new Date()).format('YYYY/MM/DD');
                date = date.replace('/', '');
                date = this.dateWesternUnionFormat(date);
                const publishDate = data.body.items[0].publishDate;
                const isBannerPublishDate = publishDate >= date;
                if (isBannerPublishDate) {
                    if (this.util.getSecureStorage('isBannerTitle') === data.body.items[0].title 
                        && this.util.getSecureStorage('isBannerId') === data.body.items[0].id) {
                        if (!this.util.getSecureStorage(LOCAL_STORAGE.IS_DISABLE_BANNER)) {
                            DataCenter.set('banner-popup-data', 'banner-popup-display', data.body.items);
                            this.modalService.open({
                                content: QUI13000000AComponent,
                                message: { data: data.body.items },
                                modalClass: ['pop_guide'],
                                callback: (res) => {
                                    
                                }
                            });
                        }
                    } else {
                        DataCenter.set('banner-popup-data', 'banner-popup-display', data.body.items);
                        this.modalService.open({
                            content: QUI13000000AComponent,
                            message: { data: data.body.items },
                            modalClass: ['pop_guide'],
                            callback: (res) => {
                                
                            }
                        });
                    }
                }
            }

        });
        // if (
        //     !this.util.getSecureStorage( LOCAL_STORAGE.IS_SKIP_GUIDE_NOTICE )
        //     && this.util.getSecureStorage( LOCAL_STORAGE.ALREADY_SHOW_GUIDE_NOTICE)
        //     ) {
        //     this.modalService.open({
        //         content: QUI13000000AComponent,
        //         modalClass: ['pop_guide'],
        //         callback: (res) => {
        //           console.log('QUI13000000AComponent', res);
        //           this.util.setSecureStorage( LOCAL_STORAGE.ALREADY_SHOW_GUIDE_NOTICE, false );
        //         }
        //     });
        // } 
    }

    dateWesternUnionFormat(date) {
        let dateFormatted: string;
        let year: string;
        let month: string;
        let day: string;
        year = date.substr(0, 4);
        month = date.substr(4, 2);
        day = date.substr(7, 2);
        dateFormatted = year + '' + month + '' + day;
        return dateFormatted;
    }


    /*  ============================By Chhordeth ===============
     Remove Covid Feature 
     Mr.Chantara requested to remove banner covid-19.
     Date: 29/05/2020  */

    /*    toDonate() {
           const data  = {
           //   currencyCode: 'USD', // In case donation only USD
             title: this.translate.instant('COMMON.MESSAGE.DONATION'),
           };
           this.choosewithdrawalAccountService.openWithdrawAndHandle(data as SelectWidthdrawAbleAccount, (result) => {
             this.openDonateAccount(result);
           });
         }
         openDonateAccount(result) {
           if (result && result.role === BUTTON_ROLE.NEXT) {
             this.modalService.modal({
               component: PRM20040101Component,
               handler: (res) => {
                   this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
               }
             });
           }
         } */

    subscribePushNotification() {
        this.messageService.getMessage().subscribe(notification => {
            if (notification) {
                this.isHasNotification = notification;
                console.log('isHasNewNotification: ', this.isHasNotification);
            }
        });
    }

    onScrollHandler(event: any) {
        if (event.detail.scrollTop < 104) {
            this.changeTitle = false;
        } else {
            this.changeTitle = true;
        }
    }

    ionViewWillEnter() {
        this.comp.tabValue = 'my';
        this.setCache(true); // init tab view
        this.setHelloWord();
        this.setProfile();
        this.menuClick.clearListMenu();
        this.backService.subscribe(
            'logged_out',
            {
                title: this.translate.instant('COMMON.MESSAGE.LOGOUT'),
                content: this.translate.instant('COMMON.MESSAGE.DO_YOU_REALLY_WANT_TO_LOGOUT')
            }
        );

        this.isHasNotification = this.util.getSecureStorage('IS_HAVING_NEW_PUSH');
    }

    ionViewDidLeave() {
        this.setCache(false); // destroy tab view
        clearInterval(this.interval);
    }

    setTab(value: SegmentValue) {
        const test = ['tab_my', 'tab_fav', 'tab_recent'].includes(value);
        if (test) {
            this.tabValue = value;
        } else {
            console.log('setTab failed on value', value);
        }
    }

    setCache(b: boolean) {
        if (b) {
            switch (this.tabValue) {
                case 'tab_my': this.tabMyCache = true; break;
                case 'tab_fav': this.tabFavCache = true; break;
                case 'tab_recent': this.tabRecCache = true; break;
            }
        } else {
            this.tabMyCache = false;
            this.tabFavCache = false;
            this.tabRecCache = false;
        }
    }

    setHelloWord() {
        const hour = new Date().getHours();
        if (hour < 6) { // 00 --> 06
            this.helloWord = 'COMMON.LABEL.GOOD_NIGHT';
        } else if (hour < 12) { // 06 --> 12
            this.helloWord = 'COMMON.LABEL.GOOD_MORNING';
        } else if (hour < 17) { // 12 --> 17
            this.helloWord = 'COMMON.LABEL.GOOD_AFTERNOON';
        } else if (hour < 22) {  // 17 --> 22
            this.helloWord = 'COMMON.LABEL.GOOD_EVENING';
        } else { // 22 --> 00
            this.helloWord = 'COMMON.LABEL.GOOD_NIGHT';
        }
    }

    setProfile() {
        // ADDED: 2020-04-15 
        const userInfo = new Util().getSecureStorage(LOCAL_STORAGE.USER_INFO);
        this.isPersonal = Utils.personalAccount();

        // const customerTypeCode = userInfo['customerTypeCode'];
        // if (customerTypeCode === CUSTOMER_TYPE_CODE.INDIVIDUAL_BANKING) {
        //     this.isPersonal = true;
        // } else {
        //     this.isPersonal = false;
        // }
        this.profile.imageURL = userInfo.mobileUserProfileImageURL;
        this.profile.userName = userInfo.customerName;
    }

    tabChange() {
        this.setCache(true);
    }

    btnNotificationClicked() {
        this.isHasNotification = false;
        this.util.setSecureStorage('IS_HAVING_NEW_PUSH', false);
        this.router.navigate(['/acc/NOT10000000'], { replaceUrl: true });
    }

    btnLogoutClicked() {
        this.backService.fire();
    }

    viewUserInfo() {
        this.router.navigate(['/info/MYI11000000'], { replaceUrl: true });
    }

    openQuickAccessList() {
        this.modalService.open({ content: QUI10000000Component, modalClass: ['pop_bottom pop_blur bg_transparent'] });
    }

    openVoiceAccess() {
        this.modalService.open({ content: VoiceAccessComponent, modalClass: ['pop_bottom pop_blur'] });
    }
}
