export type SegmentValue = 'tab_my' | 'tab_fav' | 'tab_recent';
