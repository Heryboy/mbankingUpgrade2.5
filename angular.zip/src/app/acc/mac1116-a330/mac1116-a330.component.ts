import { Component, OnInit, Input } from '@angular/core';
import { CEB0111Req } from 'src/app/shared/TRClass/CEB0111-req';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { TranslateService } from '@ngx-translate/core';
import { DataService } from '@progress/kendo-angular-dropdowns';
import { Util } from 'src/app/shared/util';
import { LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { CEB1322Res } from 'src/app/shared/TRClass/CEB1322-res';

@Component({
  selector: 'app-mac1116-a330',
  templateUrl: './mac1116-a330.component.html',
  styleUrls: ['./mac1116-a330.component.scss'],
})
export class MAC1116A330Component implements OnInit {

  @Input() modal: any;

  authCode: string;
  timeOutMin = 2;
  timeOutSecond = 0;
  remainSecond=  60 * 2;
  phoneNumber: string;
  isDisable = true;
  isDisableAuthCode = false;
  isDisableOK = true;
  transactionDate : string;
  transactionID : string;
  buttonTextAuth : string;
  viewText: object;
  userInfo: any;
  interval: any;
  util = new Util();

  constructor(
    private bizServer: BizserverService,
    private translate: TranslateService,
    private dataService: DataService,
  ) { }

  ngOnInit() {
    this.userInfo = this.util.getSecureStorage( LOCAL_STORAGE.USER_INFO);
    
    this.phoneNumber = this.userInfo.phoneNo;

    this.translate.get('COMMON.BUTTON').subscribe((res) => {
      this.viewText = res;

      this.buttonTextAuth = this.viewText['REQUEST_THE_CODE'];
    });
  }

  onClose() {
    clearInterval(this.interval);

    this.modal.close();
  }

  maskingPhoneNumber() {
		let mobileNumber = this.phoneNumber;
				
		let fstNum = mobileNumber.substr(0,3);			
		let trdNum = mobileNumber.substr(6);
		
		return fstNum + " *** " + trdNum;
	};

  onChange() {
    if (this.authCode) {
      if (this.authCode.toString().length == 6) {
        this.isDisableOK = false;
      } else {
        this.isDisableOK = true;
      }
    } else {
      this.isDisableOK = true;
    }
  }

  onRequestAuth() {
    this.buttonTextAuth = this.viewText['RETRY'];
    this.isDisable = false;
    this.isDisableAuthCode = true;
    this.authCode = '';
    this.remainSecond = 60 * 2;
    clearInterval(this.interval);

    // const reqTr = new CEB1322Req();

    // reqTr.body.userID = this.userInfo.userID;
    // reqTr.body.customerNo = this.userInfo.customerNo;
    // reqTr.body.serviceID = this.userInfo.serviceID;

    const reqTr = new CEB0111Req();

    reqTr.body.userID = this.userInfo.userID;
    reqTr.body.customerNo = this.userInfo.customerNo;

    // this.bizServer.bizMOBPost('CEB1322', reqTr).then(data => {
    this.bizServer.bizMOBPost('CEB0111', reqTr).then(data => {
      const resTr = data as CEB1322Res;
      const resultSuccess = this.bizServer.checkResponse(resTr.header);

      if (resultSuccess) {
        this.transactionDate = resTr.body.transactionDate;
        this.transactionID = resTr.body.transactionID;

        this.interval = setInterval(() => {
          this.remainSecond--;

          this.timeOutMin = Math.floor(this.remainSecond / 60);
          this.timeOutSecond = Math.abs(this.remainSecond - (60 * this.timeOutMin));

          if (this.remainSecond <= 0) {
            clearInterval(this.interval);
          } else if (this.remainSecond <= 90) {
            this.isDisableAuthCode = false;
          }
        }, 1000);
      }
    });
  }

  onClickOK() {
    this.modal.close({
      transactionID: this.transactionID,
      transactionDate: this.transactionDate,
      authenticationCode: this.authCode
    });

    // this.dataService.scrollMessage("close");
  }

}
