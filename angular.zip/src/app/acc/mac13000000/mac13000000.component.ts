import { Component, OnInit, ViewChild } from '@angular/core';
import { IonInfiniteScroll } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { CEB2212ItemsRes } from 'src/app/shared/TRClass/CEB2212-res';
import { DEBIT_CREDIT_TYPE_CODE, TRANSACTION_FREQUENCY_CODE } from '../../shared/constants/common.const';
import { BackService } from '../../shared/services/back.service';
import { BizserverService } from '../../shared/services/bizserver.service';
import { CEB5514Req } from '../../shared/TRClass/CEB5514-req';
import { CEB5514ItemsRes, CEB5514Res } from '../../shared/TRClass/CEB5514-res';
import { Utils } from '../../shared/utils/utils.static';
import { TransactionService } from '../mac11111000/mac11111000.service';

@Component({
  selector: 'app-mac13000000',
  templateUrl: './mac13000000.component.html',
  styleUrls: ['./mac13000000.component.scss'],
})
export class MAC13000000Component implements OnInit {

  items: CEB5514ItemsRes[];
  customerNo: string;
  reqTr: CEB5514Req;
  currentPageNo = 1;
  transactionList: any = [];
  noHistory: boolean;
  debitTypeCode: string;
  creditTypeCode: string;
  once: string;
  monthly: string;
  weekly: string;
  readonly pageSize = 10;
  @ViewChild(IonInfiniteScroll, { static: true }) ionInfiniteScroll: IonInfiniteScroll;
  constructor(
    private bizServer: BizserverService,
    private transactionService: TransactionService,
    private backService: BackService,
    private translate: TranslateService
  ) {
    this.reqTr = new CEB5514Req();
    this.setRequestBody(true);
    this.onGetRecentData(false);
  }

  ngOnInit() {
    this.backService.subscribe('logged_out',
      {
        title: this.translate.instant('COMMON.MESSAGE.LOGOUT'),
        content: this.translate.instant('COMMON.MESSAGE.DO_YOU_REALLY_WANT_TO_LOGOUT')
      });
    this.once = TRANSACTION_FREQUENCY_CODE.ONCE;
    this.monthly = TRANSACTION_FREQUENCY_CODE.MONTHLY;
    this.weekly = TRANSACTION_FREQUENCY_CODE.WEEKLY;
    this.debitTypeCode = DEBIT_CREDIT_TYPE_CODE.DEBIT;
    this.creditTypeCode = DEBIT_CREDIT_TYPE_CODE.CREDIT;
  }
  recordClicked(transaction: CEB2212ItemsRes) {
    this.transactionService.viewDetail(transaction);
  }
  setRequestBody(init?: boolean) {
    this.reqTr.header.screenID = 'MAC13000000'; // your screenID
    if (init) {
      Utils.setUserInfoTo(this.reqTr.body);
      this.reqTr.body.pageSize = this.pageSize;
    } else {
      this.reqTr.body.pageNumber = this.currentPageNo;        // PAGE_NUMBER
    }
  }
  setTransactionList(list: []) {
    if (list.length === 0) {
      this.ionInfiniteScroll.disabled = true;
      if (this.transactionList.length === 0) {
        this.noHistory = true;
      }
      return;
    } else if (list.length < this.pageSize) { // last records.
      this.ionInfiniteScroll.disabled = true;
    }
    this.transactionList = [...this.transactionList, ...list] as any;
    this.currentPageNo++;
  }
  onGetRecentData(showLoading: boolean, refresh?: boolean, event?: any) {
    this.noHistory = false;
    if (refresh) {
      this.currentPageNo = 1;
      this.reqTr.body.pageNumber = this.currentPageNo;        // PAGE_NUMBER
      this.transactionList = [];
    }
    this.setRequestBody(refresh);
    this.bizServer.bizMOBPost('CEB5514', this.reqTr, showLoading).then(data => {
      const resTr = data as CEB5514Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.setTransactionList(resTr.body.items as any);
      } else {
      }
      if (!refresh) {
        this.ionInfiniteScroll.complete();
      } else {
        event.target.complete();
      }
    });
  }

  doRefresh(event) {
    this.onGetRecentData(true, true, event);
  }
  loadData() {
    this.onGetRecentData(true);
  }
}
