import { Component, OnInit } from '@angular/core';
import { MAC11168000Component } from './mac11168000/mac11168000.component';
import { MAC11168100Component } from './mac11168100/mac11168100.component';
import { MAC11166000Component } from './mac11166000/mac11166000.component';
import { ModalService } from '../shared/services/modal.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../shared/services/data.service';
import { MAC11167000Component } from './mac11167000/mac11167000.component';
import { MAC11169000Component } from './mac11169000/mac11169000.component';
import { MAC1116A000Component } from './mac1116-a000/mac1116-a000.component';

@Component({
  selector: 'app-acc',
  templateUrl: './acc.page.html',
  styleUrls: ['./acc.page.scss'],
})
export class AccPage implements OnInit {

  data;
  items:any;
  currency: string;
  constructor(
              private router: Router,
              private modal: ModalService,
              private dataService: DataService) {
              this.dataService.listData.subscribe((res) => {
                console.log('res', res);
              });

  }

  ngOnInit() {
    if ( this.data !== undefined ) {
        console.log(this.data);
    }
  }

  async presentModalPayment() {
    const restul = await this.modal.modal({
      component: MAC11166000Component,
      componentProps: {data: {id: 1}}
    });
    console.log(restul);
    // this.router.navigate(['/acc/MAC11166000']);
  }

  presentModalWing() {
    this.modal.modal({
      component: MAC11167000Component,
      componentProps: {data: {id: 1}}
    });
    // this.router.navigate(['/acc/MAC11167000']);
  }

  async presentModalWithdrawalSWIFT() {
    this.modal.modal({
      component: MAC11168000Component,
      componentProps: {data: {id: 1}}
    });
    // this.router.navigate(['/acc/MAC11168000']);
  }

  presentModalWithdrawalWU() {
    this.modal.modal({
      component: MAC11168100Component,
      componentProps: {data: {id: 1}}
    });
    // this.router.navigate(['/acc/MAC11168100']);
  }

  presentModalOverseasDeposit() {
    this.modal.modal({
      component: MAC11169000Component,
      componentProps: {data: {id: 1}}
    });
  }

  presentLoan() {
      this.modal.modal({
        component: MAC1116A000Component
      });
  }
}
