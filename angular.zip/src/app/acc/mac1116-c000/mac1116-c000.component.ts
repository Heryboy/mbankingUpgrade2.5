import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { IonContent } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { DateTimeFormatService } from 'src/app/shared/services/date-time.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataformatService } from '../../shared/services/dataformat.service';
import { ShareTransactionDetailService } from '../../shared/services/share-transaction-detail-info.service';

@Component({
    selector: 'app-mac1116-c000',
    templateUrl: './mac1116-c000.component.html',
    styleUrls: ['./mac1116-c000.component.scss'],
})
export class MAC1116C000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read: IonContent, static: false }) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    screenId: string;
    accountFormat;
    name = 'Deposit';
    constructor(
        private socialShare: SocialSharing,
        private modalService: ModalService,
        private translate: TranslateService,
        private dateTime: DateTimeFormatService,
        private dataFormat: DataformatService,
        private shareTransactionDetail: ShareTransactionDetailService
    ) { }

    ngOnInit() {
    }

    ngAfterViewInit(): void {
        this.myContent.getScrollElement().then((element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }

    btnBackClicked() {
        this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
    }

    btnShareClicked() {
        const shareInfo = this.shareTransactionDetail.shareDeposit(this.data, this.name);
        console.log('this.name', this.name);
        this.socialShare.share(shareInfo).then(function () {
            // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
        }).catch(function (error) {
            // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
        });
    }

}
