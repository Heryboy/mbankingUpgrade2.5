export type InquiryTransactionType = 'all' | 'transfer' | 'payment' | 'topup';

export class InquiryTransactionFilter {
    debitCreditTypeCode = '';
    inquiryTransactionTypeCode = '11111';
    inquiryTransferTransactionTypeCode = '111';
}

export class InquiryTransactionTypeCode {

    private readonly codes: { value: InquiryTransactionType, code: string }[];
    data: InquiryTransactionFilter; // filtered data

    constructor() {
        // meaning digit codes:(11111) all, transfer, payment , topup, cardless
        this.codes = [
            { value: 'all', code: '11111'},
            { value: 'transfer', code: '01001'},
            { value: 'payment', code: '00100'},
            { value: 'topup', code: '00010'},
        ];
        this.data = new InquiryTransactionFilter();
    }

    set(obj: InquiryTransactionFilter) {
        this.data = obj;
    }

    get(tab: InquiryTransactionType) {
        if (tab === 'all') {
            return this.data; // filtered data apply only tab all.
        }
        const obj = new InquiryTransactionFilter();
        obj.inquiryTransactionTypeCode = this.codes.find(e => e.value === tab).code;
        if (tab === 'transfer') {
            obj.debitCreditTypeCode = 'DR'; // tab transfer show only withdrawal.
        }
        return obj;
    }

}
