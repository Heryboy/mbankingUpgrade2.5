import { CEB2212ItemsRes } from 'src/app/shared/TRClass/CEB2212-res';
import { CEB2411Req } from 'src/app/shared/TRClass/CEB2411-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Type, Injectable } from '@angular/core';
import { MAC1116B000Component } from '../mac1116-b000/mac1116-b000.component';
import { MAC1116C000Component } from '../mac1116-c000/mac1116-c000.component';
import { MAC11161000Component } from '../mac11161000/mac11161000.component';
import { MAC11162000Component } from '../mac11162000/mac11162000.component';
import { MAC11163000Component } from '../mac11163000/mac11163000.component';
import { MAC11164000Component } from '../mac11164000/mac11164000.component';
import { MAC11165000Component } from '../mac11165000/mac11165000.component';
import { MAC11166000Component } from '../mac11166000/mac11166000.component';
import { MAC11167000Component } from '../mac11167000/mac11167000.component';
import { MAC11168000Component } from '../mac11168000/mac11168000.component';
import { MAC11168100Component } from '../mac11168100/mac11168100.component';
import { MAC11169000Component } from '../mac11169000/mac11169000.component';
import { MAC11171000Component } from './../mac11171000/mac11171000.component';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';

@Injectable({providedIn: 'root'})
export class TransactionService {
    transactionDetail;
    transactionName;
    constructor(private bizServer: BizserverService, private modalService: ModalService) {}

    viewDetail(transaction: CEB2212ItemsRes) {
        this.requestTransactionDetail(transaction);
    }

    private requestTransactionDetail(transaction: CEB2212ItemsRes) {
        const reqTr = new CEB2411Req();
        Utils.setUserInfoTo(reqTr.body);
        if (transaction) {
            DataCenter.set('transaction-details-name', 'transactionDetailName', transaction.transactionName);
            this.transactionDetail = transaction.transactionDetail;
            this.transactionName = transaction.transactionName;
            reqTr.body.accountNo = transaction.accountNo;
            reqTr.body.slipNo = transaction.slipNo;
            reqTr.body.transactionDate = transaction.transactionDate;
            reqTr.body.depositTransactionTypeCode = transaction.depositTransactionTypeCode;
            DataCenter.set('transaction-detail', 'transactionDetail', transaction.transactionDetail);
            DataCenter.set('deposit-transaction-type-code', 'depositTransactionTypeCode', transaction.depositTransactionTypeCode);
            DataCenter.set('transaciton-seqNo' , 'transactionSeqNo', transaction.transactionSeqNo);
            DataCenter.set('receive-Name', 'receiverName', transaction.receiverName);
        }
        this.bizServer.bizMOBPost('CEB2411', reqTr).then( (data) => {
            const resTr = data as CEB2411Res;
            if (this.bizServer.checkResponse(resTr.header)) {
                // console.log(resTr.body);
                this.viewTransactionDetail(resTr.body as any);
            }
        });
    }

    private viewTransactionDetail(detail) {
        // CR (Credit)= widthraw  = transfer
        // DR (Debit)= Deposit  = Deposit
        const map = new Map<Type<any>, string>(); // 'eBankTransactionTypeCode + debitCreditTypeCode + transactionFrequencyCode'                       : Transfer
        map.set(MAC11161000Component, '01, 02, 08, 11, 16, 21, 22, 25, 33 + DR + empty, 00'); // Intrabank & Interbank - Withdrawal                    : Transfer // BAKONG FULL FUNTRANSFER
        map.set(MAC11162000Component, '01, 03, 04, 08, 11, 17, 18, 21 , 25 + DR + 01, 02');// Intrabank & Interbank - Withdrawal - recurring           : Transfer
        // map.set(MAC11162000Component, '01, 08, 11, 21 + DR + 01, 02'); // new
        map.set(MAC11163000Component, '01, 08, 21, 25 + CR'); // Intrabank & Interbank - Deposit                                                       : Transfer
        map.set(MAC11164000Component, '06, 07, 09, 10, 28 + DR'); // Topup                                                                             : Topup
        map.set(MAC11165000Component, '05 + DR'); // Easy Cash                                                                                         : Cardless
        map.set(MAC11166000Component, '23, 26, 27, 31, 32, 35 + DR'); // Payment                                                                       : Payment
        map.set(MAC11167000Component, '19, 20 + DR'); // Wing withdrawal                                                                               : Transfer
        map.set(MAC11171000Component, '29, 30 + DR'); // AMK withdrawal                                                                                : Transfer
        map.set(MAC11168000Component, '13 + DR'); // Overseas - Withdrawal(SWIFT)                                                                      : Overseas Transfer
        map.set(MAC11168100Component, '24 + DR'); // Overseas – Withdrawal(WU)                                                                         : Overseas Transfer
        map.set(MAC11169000Component, '13 + CR'); // Overseas - Deposit                                                                                : Overseas Transfer
        map.set(MAC1116B000Component, 'empty + DR'); // Cash – withdrawal (Branch,ATM)                                                                 : Withdrawal
        map.set(MAC1116C000Component, '06, 07, 09, 10, 19, 23, 24, 25, 35, empty + CR'); // Cash - Deposit                                             : Deposit

        // detail.debitCreditTypeCode == 'DR' // Withdraw { transfer, TOp up, Pay On,  payment , Wing }
        // - if(eBankTransactionTypeCode) {
        //     01, 02, 05, 25
        //     // Transfer
        // } else {
        //     // top up
        // } else  {
        //     // Pay O
        // }
        // detail.debitCreditTypeCode == 'CR' // Deposit

        // OVERSEAS_OUTWARD_TRANSFER = '13',
        let comp: Type<any>;
        for (const [key, value] of map) {
            if ( this.test(detail, value) ) {
                comp = key;
                break;
            }
        }
        if (comp) {
            console.log('go to', comp);
            console.log(detail.eBankTransactionTypeCode, ' + ', detail.debitCreditTypeCode, ' + ', detail.transactionFrequencyCode, ' + ', detail.reversalYN);
            DataCenter.set('account-inquiry', 'transaction-detail', detail);
            this.modalService.modal(
                { component: comp, componentProps: { data: detail } }
            );
        }
    }

    private test(detail, key: string) {
        const fields = ['eBankTransactionTypeCode', 'debitCreditTypeCode', 'transactionFrequencyCode'];
        const args = key.split(' + ');
        const result = args.every( (value, index) => {
            const fieldName = fields[index];
            let fieldValue = detail[fieldName];
            if (fieldValue === '') {
                fieldValue = 'empty';
            }
            return value.split(', ').includes( fieldValue );
        });
        return result;
    }

}
