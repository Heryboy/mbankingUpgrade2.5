import { Component, OnDestroy, OnInit } from '@angular/core';
import { LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PPCB0070Req } from 'src/app/shared/TRClass/PPCB0070-req';
import { PPCB0070Res } from 'src/app/shared/TRClass/PPCB0070-res';
import { PPCB0072Req } from 'src/app/shared/TRClass/PPCB0072-req';
import { PPCB0072Res } from 'src/app/shared/TRClass/PPCB0072-res';
import { Util } from 'src/app/shared/util';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { NOT20000000Component } from '../not20000000/not20000000.component';
import { Badge } from '@ionic-native/badge/ngx';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-not10000000',
  templateUrl: './not10000000.component.html',
  styleUrls: ['./not10000000.component.scss'],
})
export class NOT10000000Component implements OnInit, OnDestroy {

  notificationList: PPCB0070Res['body']['items'];
  notificationListPerPage: any[];
  noNotification = false;
  lastTimeCheckedScreen: number;
  localStorage: Util;
  currentTime: string;
  pageNumber = 1;
  scrollEvent = false;
  isHomeNoftReq: boolean;
  constructor(
    private bizServer: BizserverService,
    private modalService: ModalService,
    private backService: BackService,
    private badge: Badge,
    private platform: Platform
  ) { }

  ngOnInit() {
    if (this.platform.is('cordova')) {
      this.badge.clear(); // Clear the badge of the app icon
    }
    const today = new Date();
    this.currentTime = this.setTimeFormat(today);
    this.localStorage = new Util();
    this.lastTimeCheckedScreen = this.localStorage.getSecureStorage(LOCAL_STORAGE.LAST_TIME_CHECK_NOTIFICATION);

    this.localStorage.setSecureStorage('IS_HAVING_NEW_PUSH', false);
    this.isHomeNoftReq = DataCenter.get('Home', 'Notification', false);
    if (this.isHomeNoftReq) {
      this.reqNonTransactionNotifications();
    }​ else {
      this.reqNotifications();
    }
  }

  ionViewWillEnter() {
    this.isHomeNoftReq = DataCenter.get('Home', 'Notification', false);
    if (this.isHomeNoftReq) {
      this.backService.subscribe('home');
    } else {
      this.backService.subscribe('my_account');
    }
  }

  ionViewDidLeave() {
    if (this.isHomeNoftReq) {
      DataCenter.clear('Home', 'Notification');
    }
  }

  onClose() {
    const isMyCard = DataCenter.get('my_card', 'my_card');
    if (isMyCard) {
      this.backService.my_card();
    } else {
      this.backService.fire();
    }
    
  }

  setTimeFormat(today: Date): string {
    const year = String(today.getFullYear());
    const month =  today.getMonth() + 1 >= 10 ? String(today.getMonth() + 1) : '0' + String(today.getMonth() + 1);
    const day = today.getDate() >= 10 ? String(today.getDate()) : '0' + String(today.getDate());
    const hour = today.getHours() >= 10 ? String(today.getHours()) : '0' + String(today.getHours());
    const minute = today.getMinutes() >= 10 ? String(today.getMinutes()) : '0' + String(today.getMinutes());
    const second = (String(today.getSeconds()).charAt(0));
    return year + month + day + hour + minute + second;
  }

  checkNewNotification(msgSendDate: string): boolean {
    if (Number(msgSendDate) < Number(this.currentTime) && Number(msgSendDate) > Number(this.lastTimeCheckedScreen)) {
      return true;
    } else {
      return false;
    }
  }

  reqNotifications() {
    const reqTr = new PPCB0070Req();
    reqTr.body.page  = this.pageNumber;
    reqTr.body.rowsPerPage  = 10;
    reqTr.body.userID  = this.localStorage.getSecureStorage(LOCAL_STORAGE.USER_INFO).userID;
    this.bizServer.bizMOBPost('PPCB0070', reqTr, true).then(data => {
      const resTr = data as PPCB0070Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        // Success To-Do
        this.notificationListPerPage = resTr.body.items;
        this.pushFullList(this.notificationListPerPage);
      }
    });
  }

  reqNonTransactionNotifications() {
    const reqTr = new PPCB0072Req();
    reqTr.body.page  = this.pageNumber;
    reqTr.body.rowsPerPage  = 10;
    reqTr.body.userID  = this.localStorage.getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
    this.bizServer.bizMOBPost('PPCB0072', reqTr, true).then(data => {
      const resTr = data as PPCB0072Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        // Success To-Do
        this.notificationListPerPage = resTr.body.items;
        this.pushFullList(this.notificationListPerPage);
      }
    });
  }

  pushFullList(listPerPage: PPCB0070Res['body']['items']) {
    if (!this.notificationList) {
      this.notificationList = [];
    }
    this.notificationList = [...this.notificationList, ...listPerPage];
    if (this.notificationList.length === 0) {
      this.noNotification = true;
    }
  }

  onClickNotificationList(notList: object) {
    this.modalService.modal({
      component: NOT20000000Component,
      componentProps: {
        data: notList
      }
    });
  }

  ngOnDestroy() {
    this.localStorage.setSecureStorage(LOCAL_STORAGE.LAST_TIME_CHECK_NOTIFICATION, this.currentTime);
  }

  scrollLoadData(event) {
    setTimeout(() => {
        if​​(this.notificationList.length >​​​0) {
          this.pageNumber = ++this.pageNumber;
          if (this.isHomeNoftReq) {
            this.reqNonTransactionNotifications();
          }​ else {
            this.reqNotifications();
          }
        }
        event.target.complete();
        if (this.notificationList.length === 0) {
          event.target.disabled = !this.scrollEvent;
       }
    }, 500);
  }

  setDateFormat(date: string): string {
    return date.substr(0, 8);
  }

  getTimeFormat(time: string): string {
    return time.substr(8, 2) + ':' + time.substr(10, 2);
  }

}
