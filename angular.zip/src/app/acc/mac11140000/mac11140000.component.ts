import { Component, OnInit, Input } from '@angular/core';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { InquiryTransactionFilter } from '../mac11111000/mac11111000.model';

@Component({
  selector: 'app-mac11140000',
  templateUrl: './mac11140000.component.html',
  styleUrls: ['./mac11140000.component.scss'],
})
export class MAC11140000Component implements OnInit {

    @Input() data: InquiryTransactionFilter;
    debitCreditTypeCode: '' | 'CR' | 'DR';
    withdrawalTypes: boolean[] = []; // 11111 : Other, Transfer, Payment, Top up, Easy Cash.
    transferTypes: boolean[] = []; // 111 : Account, Wing, Overseas
    modal: any;

    ngOnInit() {
        this.data = this.modal.message.data;
        if (this.data) {
            this.debitCreditTypeCode = this.data.debitCreditTypeCode as any;
            this.withdrawalTypes = this.toBoolArray(this.data.inquiryTransactionTypeCode);
            this.transferTypes = this.toBoolArray(this.data.inquiryTransferTransactionTypeCode);
        }
    }

    btnCloseClicked() {
        this.modal.close({ role: BUTTON_ROLE.CLOSE });
    }

    btnApplyClicked() {
        const debitCreditTypeCode = this.debitCreditTypeCode;
        const inquiryTransactionTypeCode = this.toString(this.withdrawalTypes);
        const inquiryTransferTransactionTypeCode = this.toString(this.transferTypes);
        const data: InquiryTransactionFilter = {
            debitCreditTypeCode,
            inquiryTransactionTypeCode,
            inquiryTransferTransactionTypeCode
        };
        this.modal.close({ role: BUTTON_ROLE.APPLY, data });
    }

    cateTypeChange(value: '' | 'CR' | 'DR') {
        switch (value) {
            case 'CR':  this.setAll(this.withdrawalTypes, false);
                        this.withdrawalTypes[0] = true; // keep opt other for deposit.
                        this.setAll(this.transferTypes, true);
                        this.transferTypes[1] = false; // disable wing
                        break;
            // case 'DR': this.setAll(this.withdrawalTypes, true); this.setAll(this.transferTypes, false); break;
            default: this.setAll(this.withdrawalTypes, true); this.setAll(this.transferTypes, true); break;
        }
    }

    private setAll(arr: boolean[], value: boolean) {
        for (let i = 0; i < arr.length; i++) {
            arr[i] = value;
        }
    }

    private toBoolArray(str: string) {
        const bools: boolean[] = [];
        for (let i = 0; i < str.length; i++) {
            bools[i] = str[i] === '1';
        }
        return bools;
    }

    private toString(bools: boolean[]) {
        let str = '';
        for (const b of bools) {
            str += b ? '1' : '0';
        }
        return str;
    }

}
