import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC12100000Component } from './mac12100000.component';

describe('MAC12100000Component', () => {
  let component: MAC12100000Component;
  let fixture: ComponentFixture<MAC12100000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC12100000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC12100000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
