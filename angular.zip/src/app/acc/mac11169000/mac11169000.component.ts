import { Component, OnInit } from '@angular/core';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';

@Component({
  selector: 'app-mac11169000',
  templateUrl: './mac11169000.component.html',
  styleUrls: ['./mac11169000.component.scss'],
})
export class MAC11169000Component implements OnInit {

  resBody = new CEB2411Res().body;
  data;
  result = false;
  total: number;
  constructor(
    private socialShare: SocialSharing,
    private shareTransactionDetail: ShareTransactionDetailService,
    private bizServer: BizserverService,
    private modalService: ModalService
  ) { }

  ngOnInit() {
    if (this.data) {
      this.resBody = this.data;
      this.total   = Number(this.resBody.transactionAmount) - Number(this.resBody.feeAmount);
    }
    // const transactionDetails = DataCenter.get('account-inquiry', 'transaction-detail') as InquiryTransactionDetail;
    // // console.log(transactionDetails);
    // if ( transactionDetails !== undefined) {
    //   this.result = true;
    //   this.resBody = transactionDetails;
    // }
  }

  btnBack() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

  share() {
    this.shareTransactionDetail.shareOverseasDeposit(this.data).then( res => {
      console.log(res);
      this.socialShare.share(res).then(function () {
          // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
      }).catch(function (error) {
          // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
      });
    });
  }

}
