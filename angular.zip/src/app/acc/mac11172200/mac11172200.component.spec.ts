import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11172200Component } from './mac11172200.component';

describe('MAC11172200Component', () => {
  let component: MAC11172200Component;
  let fixture: ComponentFixture<MAC11172200Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11172200Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11172200Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
