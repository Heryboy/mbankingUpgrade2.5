import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mac11165000Component } from './mac11165000.component';

describe('Mac11165000Component', () => {
  let component: Mac11165000Component;
  let fixture: ComponentFixture<Mac11165000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mac11165000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mac11165000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
