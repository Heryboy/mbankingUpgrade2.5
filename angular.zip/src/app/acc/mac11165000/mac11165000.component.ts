import { CEB0131Res } from './../../shared/TRClass/CEB0131-res';
import { CEB0131Req } from './../../shared/TRClass/CEB0131-req';
import { BizserverService } from './../../shared/services/bizserver.service';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { IonContent } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';
import { AccountCardModel } from '../mac11000000/mac11000000.model';
@Component({
  selector: 'app-mac11165000',
  templateUrl: './mac11165000.component.html',
  styleUrls: ['./mac11165000.component.scss'],
})
export class MAC11165000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read : IonContent, static : false } ) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    translateView: any;
    MAC11161000translate: any;
    displayAccountName: string;
    reverseResult = 'N';
    transactionSeqNo: any;
    depositTransactionTypeCode: any;
    receiverName: any;
    constructor(private modalService: ModalService,
                private router: Router,
                private translate: TranslateService,
                private bizServer: BizserverService,
                private shareTransactionDetail: ShareTransactionDetailService,
                private socialShare: SocialSharing) { }

    ngOnInit() {
        console.log(this.data);
        if ( this.data.accountNickName === '' || this.data.accountNickName !== '' && this.data.accountName === null) {
            this.displayAccountName = this.data.accountName;
        } else {
            this.displayAccountName = this.data.accountNickName;
        }
        this.translate.get('COMMON').subscribe((res) => {
            this.translateView = res;
            console.log();
        });
        this.translate.get('MAC11161000').subscribe((res) => {
            this.MAC11161000translate = res;
        });
        this.transactionSeqNo = DataCenter.get('transaciton-seqNo' , 'transactionSeqNo');
        this.depositTransactionTypeCode = DataCenter.get('deposit-transaction-type-code', 'depositTransactionTypeCode');
        this.receiverName = DataCenter.get('receive-Name', 'receiverName');
    }

    ngAfterViewInit(): void {
        this.myContent.getScrollElement().then( (element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }

    btnBackClicked() {
        this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
    }

    btnShareClicked() {
        this.shareTransactionDetail.shareCardLess(this.data).then(res  => {
            this.socialShare.share(res).then(function () {
                // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
            }).catch(function (error) {
                // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
            });
        });
    }

    btnTransferAgainClicked() {
        this.btnBackClicked();
        const account = {
            accountNo : this.data.accountNo,
            accountName : this.data.accountName,
            currencyCode : this.data.currencyCode,
            depositSubjectCode : this.data.depositSubjectCode,
            availableBalance : this.data.availableBalance,
            accountNickName: this.data.accountNickName
        };
        console.log('btnTransferAgainClicked');
        DataCenter.set('widthDrawAbleAccount', 'account', account);
        DataCenter.set('mac11812000', 'back', {
            currencyCode: this.data.currencyCode,
            accountName: this.data.accountName,
            amount: this.data.transactionAmount,
            phoneNumber: this.data.phoneNumber,
            scheduleDate: '',
            accountNo: this.data.customerNo,
        });
        this.router.navigate(['/quick/easy-cash']);
    }

    btnReverseAgainClicked() {
        const nBtnText = this.translate.instant('COMMON.BUTTON.NO');
        const yBtnText = this.translate.instant('COMMON.BUTTON.YES');
        const message = this.translate.instant('MAC11161000.LABEL.ARE_YOU_SURE_YOU_WANT_TO_REVERSE');
        this.modalService.confirm({
            content: message,
            lBtn: {
                btnText: nBtnText
            },
            rBtn: {
                btnText: yBtnText,
                callback: () => {
                    this.smsReceive();
                }
            }
        });
    }

    smsReceive(): Promise<boolean> {
        return new Promise((resove) => {
            const reqTr = new CEB0131Req();
            reqTr.body.accountNo = this.data.accountNo;
            Utils.setUserInfoTo(reqTr.body);
            reqTr.body.transactionAmount = this.data.transactionAmount;
            reqTr.body.transactionSeqNo = this.transactionSeqNo;
            reqTr.body.channelTypeCode	 =  '03';
            reqTr.body.depositTransactionTypeCode = this.depositTransactionTypeCode;
            reqTr.body.detailTransactionSeqNo = 0;
            reqTr.body.receiverPhoneNo = this.receiverName;
            reqTr.body.slipNo = this.data.slipNo;
            reqTr.body.transactionCurrencyCode = this.data.currencyCode;
            reqTr.body.transactionDate = this.data.transactionDate;
            this.bizServer.bizMOBPost('CEB0131', reqTr).then((res) => {
                const resTr = res as CEB0131Res;
                if (this.bizServer.checkResponse(resTr.header)) {
                    this.reverseResult = resTr.body.resultYN;
                    this.modalService.toast({
                        message: this.translate.instant('MAC11161000.LABEL.SUCCESSFULLY_REVERSED'),
                        duration: 3000,
                    });
                }
                resove(resTr.header.result);
            });
        });
    }

}
