import { DataformatService } from 'src/app/shared/services/dataformat.service';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { ShareTransactionDetailService } from '../../shared/services/share-transaction-detail-info.service';

@Component({
    selector: 'app-mac1116-b000',
    templateUrl: './mac1116-b000.component.html',
    styleUrls: ['./mac1116-b000.component.scss'],
})
export class MAC1116B000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read: IonContent, static: false }) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    name = 'Withdrawal';
    accountFormat;
    constructor(
        private modalService: ModalService,
        private socialShare: SocialSharing,
        private dataFormat: DataformatService,
        private shareTransactionDetail: ShareTransactionDetailService
    ) { }

    ngOnInit() {
    }


    ngAfterViewInit(): void {
        this.myContent.getScrollElement().then((element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }

    btnBackClicked() {
        this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
    }

    btnShareClicked() {
        const shareInfo = this.shareTransactionDetail.shareDeposit(this.data, this.name);
        console.log('this.name', this.name);
        this.socialShare.share(shareInfo).then(function () {
            // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
        }).catch(function (error) {
            // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
        });
    }

}
