import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';

@Component({
  selector: 'app-mac1116-a000',
  templateUrl: './mac1116-a000.component.html',
  styleUrls: ['./mac1116-a000.component.scss'],
})
export class MAC1116A000Component implements OnInit {
  loan;
  totalPaymentAmount: number;
  item = new T();
  data;
  constructor(
    private modalService: ModalService,
    private shareTransactionDetail: ShareTransactionDetailService,
    private socialShare: SocialSharing,
    private backService: BackService
  ) { }

  ngOnInit() {
    // this.doReq();
  }
  ionViewWillEnter() {
    if ( this.loan === undefined) {
      this.backService.my_account();
    } else {
    this.item = this.loan;
    console.log(this.loan);
    if (this.item.principalRepayMethodCode === '90') {
      this.totalPaymentAmount = this.item.transactionInterestAmount + this.item.feeAmount;
    } else {
      this.totalPaymentAmount = this.item.transactionInterestAmount +  this.item.transactionPrincipal;
    }
    this.item.totalRepayment = this.totalPaymentAmount;
    }
  }

  btnBack() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

  presentLoanShare() {
    this.shareTransactionDetail.presentLoanShare(this.item).then(res => {
      console.log(res);
      this.socialShare.share(res).then(function () {
          // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
      }).catch(function (error) {
          // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
      });

    });

  }
}

export class T {
  loanAccountNo: string;
  transactionPrincipal: number;
  feeAmount: number;
  transactionTime: string;
  loanLogTypeCode: string;
  slipNo: string;
  debitCreditTypeCode: string;
  transactionDate: string;
  principalRepayMethodCode: string;
  currencyCode: string;
  transactionInterestAmount: number;
  transactionDetail: string;
  afterBalance: number;
  totalRepayment?: number;
}