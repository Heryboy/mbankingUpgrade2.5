import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC1116A000Component } from './mac1116-a000.component';

describe('MAC1116A000Component', () => {
  let component: MAC1116A000Component;
  let fixture: ComponentFixture<MAC1116A000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC1116A000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC1116A000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
