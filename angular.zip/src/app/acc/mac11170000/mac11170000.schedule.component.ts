import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { CEB6112Req } from 'src/app/shared/TRClass/CEB6112-req';
import { CEB6112Res } from 'src/app/shared/TRClass/CEB6112-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';
import { LoanScheduleList } from './mac11170000.model';

export class MAC11170000Schedule {

  constructor(public bizServer: BizserverService) { }
  public loanScheduleList: LoanScheduleList [];
  public repaymentSelection: boolean[];
  public applyDate: string;
  public repaymentPaid: number;
  // ===========Schedule===============
  setScheduleList(list: LoanScheduleList[]) {
    if (!this.loanScheduleList) {
        this.clearLoanScheduleList();
    }
    this.loanScheduleList = [...this.loanScheduleList, ...list];
  }
  clearLoanScheduleList() {
    this.loanScheduleList = [];
  }
  setRequestBodySchedule(setDefault?: boolean): CEB6112Req {
    const reqTr = new CEB6112Req();
    if (setDefault) {
      reqTr.body.customerNo  = '0000000000018193';        // customerNo
      reqTr.body.userID  = 'sokkanha';        // userID
      reqTr.body.loanAccountNo  = '0000227000184259';        // loanAccountNo
    } else {
      const accountList = DataCenter.get('my-account', 'accountList', false);
      const accountNo = DataCenter.get('my-account', 'accountNo', false);
      const result =  accountList.find( acc => acc.accountNo === accountNo );
      Utils.setUserInfoTo(reqTr.body);
      reqTr.body.loanAccountNo = result.loanAccountNo;
    }
    return reqTr;
  }
  inquiryLoanSchedule() {
   const reqTr = this.setRequestBodySchedule(false);
   this.bizServer.bizMOBPost('CEB6112', reqTr).then(data => {
      const resTr = data as CEB6112Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        // Success To-Do
        const result =  resTr.body.items;        // items
        this.applyDate = resTr.body.applyDate;
        this.setScheduleList(result);
      }
      this.repaymentSelection = [];
      this.loanScheduleList.forEach((ele, i) => {
        if (ele.checkCollectionTypeCode === String(1) || ele.checkCollectionTypeCode === String(3)) {
          this.repaymentSelection[i] = true;
        } else {
          this.repaymentSelection[i] = false;
        }
       });
      const listSelectedPaid = this.loanScheduleList.filter( (item, i) => {
        if (item) {
          return (item.checkCollectionTypeCode === String(1) || item.checkCollectionTypeCode === String(3));
         }
       });
      this.repaymentPaid = listSelectedPaid.length ;

    });
  }
  inquirySchedule() {
    this.clearLoanScheduleList();
    this.inquiryLoanSchedule();
  }
}
