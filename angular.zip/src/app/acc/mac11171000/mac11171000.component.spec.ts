import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11171000Component } from './mac11171000.component';

describe('MAC11171000Component', () => {
  let component: MAC11171000Component;
  let fixture: ComponentFixture<MAC11171000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11171000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11171000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
