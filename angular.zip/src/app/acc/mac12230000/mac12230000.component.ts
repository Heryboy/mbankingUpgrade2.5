import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Mac12231000Component } from 'src/app/acc/mac12231000/mac12231000.component';
import { SelectFullOptionModel } from '../../shared/component/select-full-option/select-full-option.model';
import { BUTTON_ROLE, LOCAL_STORAGE } from '../../shared/constants/common.const';
import { BackService } from '../../shared/services/back.service';
import { BizserverService } from '../../shared/services/bizserver.service';
import { DataformatService } from '../../shared/services/dataformat.service';
import { FormatterService } from '../../shared/services/formatter.service';
import { ModalService } from '../../shared/services/modal.service';
import { RecipientAccountListService } from '../../shared/services/recipient-account-list.service';
import { SelectService } from '../../shared/services/select.service';
import { CEB2111Req } from '../../shared/TRClass/CEB2111-req';
import { CEB2111Res } from '../../shared/TRClass/CEB2111-res';
import { CEB3621Req } from '../../shared/TRClass/CEB3621-req';
import { CEB3621Res } from '../../shared/TRClass/CEB3621-res';
import { Util } from '../../shared/util';
import { Utils } from '../../shared/utils/utils.static';
import { BankList } from '../../trf/qui11110000/qui11110000.model';

@Component({
  selector: 'app-mac12230000',
  templateUrl: './mac12230000.component.html',
  styleUrls: ['./mac12230000.component.scss'],
})
export class MAC12230000Component implements OnInit {

  focusIndex: number;
  input = {
    receiverName: '',
    receiverAccountNo: ''
  };
  isKeyboardUp: boolean;
  isDisabledConfirm: boolean;
  isDisabledOK: boolean;
  receiverName: string;
  util = new Util();
  userInfo: object;
  viewText: object;
  successMsg: string;
  recipientBankList: SelectFullOptionModel;
  bankList: BankList[];
  recipientBank: string;
  feedBack: string;
  accountNumberType: string;
  isShowMe: boolean;
  recipientBankCode: string;
  isPpcbank: boolean;
  maxLenght: number;
  constructor(
    private modalService: ModalService,
    private translate: TranslateService,
    private bizServer: BizserverService,
    private modal: ModalService,
    private selectService: SelectService,
    private recipientAccountListService: RecipientAccountListService,
    private accountFormat: DataformatService,
    private accountFormater: FormatterService,
    private backService: BackService
  ) { }
  ngOnInit() {
    this.translate.use(this.util.getSecureStorage(LOCAL_STORAGE.I18N));
    this.feedBack = '';
    this.isKeyboardUp = false;
    this.isDisabledConfirm = true;
    this.isDisabledOK = true;
    this.setBankList();
    this.input.receiverAccountNo = '';
    this.input.receiverName = '';
    this.accountNumberType = 'number';
    this.recipientBankCode = '000';
    this.maxLenght = 20;
  }
  changeRecipientBank(event) {
    this.recipientBank = event.code;
  }
  ionViewWillEnter() {
    this.backService.subscribe('my_account');
    this.setFocus(3);
  }
  async setBankList() {
    const textTitle = this.translate.instant('QUI11110000.LABEL.SELECT_RECIPIENT_BANK');
    this.bankList = await this.recipientAccountListService.inquiryBankList(true);
    const bankList = [];
    let text;
    this.bankList.forEach((ele: any) => {
      text = '<b>' + ele.value + '</b> | ' + ele.description;
      ele.text = text;
      bankList.push(ele);
    });
    this.recipientBankList = {
      title: textTitle,
      itemValueField: 'code',
      itemTextField: 'text',
      option: bankList
    };
    this.recipientBank = '000';
  }
  async openBankList() {
    this.setFocus(0);
    this.input.receiverAccountNo = '';
    if (this.recipientBankList) {
      const result = await this.selectService.openRecipientBankList(this.recipientBankList);
      if (result) {
        this.recipientBankCode = String(result.value);
        this.recipientBank = this.recipientBankCode;
        if (this.recipientBankCode === '000') {
          this.isPpcbank = true;
        } else {
          this.isPpcbank = false;
        }
        setTimeout(() => { this.setFocus(1); }, 300);
      }
    }
  }
  onFocusAccountNo(): void {
    this.isShowMe = false;
    this.accountNumberType = 'number';
    this.isKeyboardUp = true;
    this.feedBack = '';
    this.input.receiverName = '';
  }
  onFocusName(): void {
    this.isShowMe = true;
    this.isKeyboardUp = true;
    this.feedBack = '';
  }
  onChange(e) {
    Utils.restrictEmoji(e);
    if (this.input.receiverAccountNo !== '') {
      this.isDisabledOK = false;
    } else {
      this.isDisabledOK = true;
    }
    if (this.input.receiverAccountNo !== '' && this.input.receiverName !== '') {
      this.isDisabledConfirm = false;
    } else {
      this.isDisabledConfirm = true;
    }
  }
  keyUpInput(ev) {
    if (this.recipientBank === '000') {
      const ac = this.accountFormater.toAccountNumberFormat(ev);
      this.input.receiverAccountNo = ac.text;
      this.maxLenght = 16;
    } else {
      this.maxLenght = 20;
    }
  }
  onCheckPPCBankAccount() {
    const reqTr = new CEB2111Req();
    reqTr.header.screenID = 'MAC12230000'; // your screenID
    reqTr.body.receiversAccountNo = (this.accountFormat.unFormatAccountNumber(this.input.receiverAccountNo)
      .toString()).padStart(16, '0');      // receiver's AccountNumber
    this.bizServer.bizMOBPost('CEB2111', reqTr).then(data => {
      const resTr = data as CEB2111Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.receiverName = resTr.body.accountName;        // accountName
        this.openModale();
      } else {
        this.translate.get('MAC12230000.LABEL').subscribe((res) => {
          this.viewText = res;
          this.feedBack = this.viewText['FEEDBACK'];
        });
      }
    });
  }
  async openModale() {
    const result = await this.modal.modal({
      component: Mac12231000Component,
      componentProps: { receiverName: this.receiverName }
    });
    if (result.role === BUTTON_ROLE.APPLY) {
      this.input.receiverName = this.receiverName;
      this.input.receiverAccountNo = (this.input.receiverAccountNo + '');
      this.isKeyboardUp = false;
      this.isShowMe = true;
    } else if (result.role === BUTTON_ROLE.CLOSE) {
      this.input.receiverAccountNo = '';
      this.input.receiverName = '';
    }
  }
  onClickConfirm() {
    const reqTr = new CEB3621Req();
    reqTr.header.screenID = 'MAC12230000'; // your screenID
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.receiverAccountName = this.input.receiverName;        // receiverAccountName
    reqTr.body.nickname = '';        // nickname
    if (this.recipientBank === '000') {
      reqTr.body.receiverAccountNumber = this.accountFormat.unFormatAccountNumber(this.input.receiverAccountNo.toString())
        .padStart(16, '0');        // receiverAccountNumber
    } else {
      reqTr.body.receiverAccountNumber = this.input.receiverAccountNo + '';        // receiverAccountNumber
    }
    reqTr.body.bankCode = this.recipientBank;        // bankCode
    this.bizServer.bizMOBPost('CEB3621', reqTr).then(async data => {
      const resTr = data as CEB3621Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.translate.get('MAC12230000.LABEL').subscribe((res) => {
          this.viewText = res;
          this.successMsg = this.viewText['SUCCESS_MSG'];
        });
        this.modalService.toast({
          message: this.successMsg,
          duration: 3000,
        });
        this.input.receiverAccountNo = '';
        this.input.receiverName = '';
        this.backService.my_account();
      }
    });
  }
  onBlurReceiverName() { this.isKeyboardUp = false; }
  doReceiverAccountNo() {
    if (this.recipientBank === '000') {
      this.accountNumberType = 'tel';
      this.input.receiverAccountNo = this.accountFormat.formatAccountNumber(this.input.receiverAccountNo);
      this.onCheckPPCBankAccount();
    } else {
      this.setFocus(2);
    }
  }
  onClickCancel() {
    this.backService.fire();
  }

  setFocus(index: number) {
    this.focusIndex = index;
  }

}
