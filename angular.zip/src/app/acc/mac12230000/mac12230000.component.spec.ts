import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC12230000Component } from './mac12230000.component';

describe('MAC12230000Component', () => {
  let component: MAC12230000Component;
  let fixture: ComponentFixture<MAC12230000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC12230000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC12230000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
