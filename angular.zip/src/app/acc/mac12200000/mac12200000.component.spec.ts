import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC12200000Component } from './mac12200000.component';

describe('MAC12200000Component', () => {
  let component: MAC12200000Component;
  let fixture: ComponentFixture<MAC12200000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC12200000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC12200000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
