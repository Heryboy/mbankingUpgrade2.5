import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { BizserverService } from '../../shared/services/bizserver.service';
import { ModalService } from '../../shared/services/modal.service';
import { CEB3111FavoriteAccountListRes } from '../../shared/TRClass/CEB3111-res';
import { CEB3122Req } from '../../shared/TRClass/CEB3122-req';
import { CEB3122Res } from '../../shared/TRClass/CEB3122-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { Utils } from '../../shared/utils/utils.static';

@Component({
  selector: 'app-mac12200000',
  templateUrl: './mac12200000.component.html',
  styleUrls: ['./mac12200000.component.scss'],
})

export class MAC12200000Component implements OnInit {
  @Input() modal: any;
  viewText: object;
  receiverAccountNumber: string;
  seqNo: number;
  items: CEB3111FavoriteAccountListRes[];
  constructor(
    private modalService: ModalService,
    private bizServer: BizserverService,
    private translate: TranslateService
  ) {
  }

  ngOnInit() {
    this.translate.get('MAC12200000.LABEL').subscribe((res) => {
      this.viewText = res;
    });
    const data = DataCenter.get('data', 'data');
    this.seqNo = data.seqNo;
    this.receiverAccountNumber = data.receiverAccountNumber;
    this.items = DataCenter.get('items', 'items');
  }
  async onOptionClick() {
    await this.modal.close();
    this.confirm();
  }
  async onRemoveData() {
    const reqTr = new CEB3122Req();
    reqTr.header.screenID = 'MAC12100000'; // your screenID
    reqTr.body.receiverAccountNumber = this.receiverAccountNumber;
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.sequentNo = 0;        // sequentNo
    this.bizServer.bizMOBPost('CEB3122', reqTr).then(async data => {
      const resTr = data as CEB3122Res;
      const success = this.bizServer.checkResponse(resTr.header);
      if (success) {
        if (resTr.body.resultYN === 'Y') {
          this.items.forEach((item, index) => {
            if (item.seqNo === this.seqNo) {
              this.items.splice(index, 1);
            }
          });
          this.modalService.toast({
            message: this.viewText['FAVORITE_ACCOUNT_HAVE_BEEN_REMOVED'],
            duration: 3000,
          });
        }
      }
    });
  }
  confirm() {
    this.modalService.confirm({
      title: this.viewText['CONFIRM'],
      content: this.viewText['DO_YOU_WANT_TO_REMOVE'],
      width: 300,
      modalClass: ['pop_confirm'],
      lBtn: {
        btnText: this.viewText['NO'],
        callback: () => {
          // this.modal.close('No');
        }
      },
      rBtn: {
        btnText: this.viewText['YES'],
        callback: () => {
          this.onRemoveData();
        }
      },
    });
  }
  onClosePopup(): void {
    this.modal.close();
  }
}
