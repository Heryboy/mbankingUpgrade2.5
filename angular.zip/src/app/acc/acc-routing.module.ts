import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccPage } from './acc.page';
import { MAC11000000Component } from './mac11000000/mac11000000.component';
import { MAC11161000Component } from './mac11161000/mac11161000.component';
import { MAC11166000Component } from './mac11166000/mac11166000.component';
import { MAC11167000Component } from './mac11167000/mac11167000.component';
import { MAC11168000Component } from './mac11168000/mac11168000.component';
import { MAC11172100Component } from './mac11172100/mac11172100.component';
import { MAC11172200Component } from './mac11172200/mac11172200.component';
import { NOT10000000Component } from './not10000000/not10000000.component';
import { MAC11910000Component } from '../pay/mac11910000/mac11910000.component';
import { MAC12100000Component } from './mac12100000/mac12100000.component';
import { MAC12110000Component } from './mac12110000/mac12110000.component';
import { AccMainComponent } from './acc-main/acc-main.component';
import { MAC11111000Component } from './mac11111000/mac11111000.component';
import { MAC11120000Component } from './mac11120000/mac11120000.component';
import { MAC11170000Component } from './mac11170000/mac11170000.component';
import { MAC13000000Component } from './mac13000000/mac13000000.component';
import { MAC12230000Component } from './mac12230000/mac12230000.component';
import { MAC11920000Component } from '../pay/mac11920000/mac11920000.component';

const routes: Routes = [
  {
    path: 'acc',
    children: [
      { path: '', component: AccPage, pathMatch: 'full' },
      { path: 'main/:tab', component: AccMainComponent },
      // {
      //   path: 'main', component: AccMainComponent, children: [
        //   { path: '', redirectTo: 'my-account', pathMatch: 'full' },
          // { path: 'my-account', component: MAC11000000Component },
        //   { path: 'fav-account', component: MAC12100000Component },
        //   { path: 'recent-account', component: MAC13000000Component },
      //   ]
      // },
      {
        path: 'account-inquiry', children: [
          { path: 'saving', component: MAC11111000Component },
          { path: 'deposit', component: MAC11120000Component },
          { path: 'loan', component: MAC11170000Component },
        ]
      },
      { path: 'account-inquiry', component: MAC11111000Component },
      { path: 'account-inquiry/:tab', component: MAC11111000Component },
      { path: 'account-inquiry-deposit', component: MAC11120000Component },
    //   { path: 'transaction-detail', component: MAC11161000Component },

    //   { path: 'acc-trans-detail-payment', comp?onent: MAC11166000Component }, // 23
    //   { path: 'acc-trans-detail-wing', component: MAC11167000Component }, // 19 , 20
    //   { path: 'acc-trans-detail-ov-wdsWIFT', component: MAC11168000Component }, // 13 DR
    //   { path: 'acc-trans-detail-ov–wdwU', component: MAC11168100Component }, // 24
    //   { path: 'acc-trans-detail-ov-deposit', component: MAC11169000Component }, // 13 CR

      // { path: 'account-inquiry/loan', component: MAC11170000Component },
      // { path: 'loan-confirm', component: MAC11172100Component },
      // { path: 'loan-complete', component: MAC11172200Component },
    //   { path: 'MAC11167000', component: MAC11167000Component },
    //   { path: 'MAC11166000', component: MAC11166000Component },
    //   { path: 'MAC11168000', component: MAC11168000Component },
    //   { path: 'MAC11161000', component: MAC11161000Component },
      { path: 'MAC11910000', component: MAC11910000Component },
      { path: 'MAC11920000', component: MAC11920000Component },
      { path: 'MAC12100000', component: MAC12100000Component },
      { path: 'MAC12230000', component: MAC12230000Component },
      { path: 'MAC12110000', component: MAC12110000Component },
      { path: 'NOT10000000', component: NOT10000000Component },
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
})
export class AccRoutingPageModule { }
