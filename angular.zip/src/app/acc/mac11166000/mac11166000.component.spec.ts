import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11166000Component } from './mac11166000.component';

describe('MAC11166000Component', () => {
  let component: MAC11166000Component;
  let fixture: ComponentFixture<MAC11166000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11166000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11166000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
