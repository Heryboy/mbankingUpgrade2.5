import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs1-a510000',
  templateUrl: './bfs1-a510000.component.html',
  styleUrls: ['./bfs1-a510000.component.scss'],
})
export class BFS1A510000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
