import { Component, OnInit } from '@angular/core';
import { InfServiceService } from 'src/app/inf/services/inf-service.service';
import { BackService } from 'src/app/shared/services/back.service';
import { Product } from 'src/app/shared/TRClass/PPCB0130-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { LoanApplyService } from '../bfs19100000/loan-apply.service';
import { OccupationalInfo } from '../bfs19300000/bfs19300000.model';

@Component({
  selector: 'app-bfs19600000',
  templateUrl: './bfs19600000.component.html',
  styleUrls: ['./bfs19600000.component.scss'],
})
export class Bfs19600000Component implements OnInit {

  occupationInfo: OccupationalInfo;
  selectedLoan: Product;
  selectedBranch: any;
  currencyCode: string;
  branchName: string;
  constructor(
    private loanApply: LoanApplyService,
    private backService: BackService,
    private infService: InfServiceService
  ) {
    this.currencyCode = DataCenter.get('loan-apply', 'transactionCurrencyCode', false);
    this.selectedBranch = DataCenter.get('loan-apply', 'selectedBranch', false);
    this.selectedLoan = DataCenter.get('loan-apply', 'selectedLoan', false);
    this.occupationInfo = DataCenter.get('loan-apply', 'occupationInfo', false);
    this.branchName = this.infService.getBranchName(this.selectedBranch);
  }

  ngOnInit() {}

  ionViewWillEnter() {
    this.backService.subscribe();
  }

  onBtnCancelClick() {
    this.backService.fire();
  }

  onBtnConfirmClick() {
    this.loanApply.onConfirm();
  }
}
