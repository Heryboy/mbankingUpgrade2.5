import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS14200000Component } from './bfs14200000.component';

describe('BFS14200000Component', () => {
  let component: BFS14200000Component;
  let fixture: ComponentFixture<BFS14200000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS14200000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS14200000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
