import { Component, OnInit, ViewChild } from '@angular/core';
import { MapsService } from 'src/app/shared/services/maps.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { InitMapsModel, DestinationObject } from 'src/app/shared/component/maps/maps.model';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { MapsComponent } from 'src/app/shared/component/maps/maps.component';
import { TranslateService } from '@ngx-translate/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BFS12300000Component } from '../bfs12300000/bfs12300000.component';
import { PopoverController, IonSlides } from '@ionic/angular';
import { BFS12400000Component } from '../bfs12400000/bfs12400000.component';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { FACILITY_CODE, LANGUAGE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { Util } from 'src/app/shared/util';
import { BackService } from 'src/app/shared/services/back.service';
import { Utils } from 'src/app/shared/utils/utils.static';
import { ActivatedRoute } from '@angular/router';

export type ButtonCardRole = 'btn_call' | 'btn_share' | 'btn_directions';

@Component({
  selector: 'app-bfs12100000',
  templateUrl: './bfs12100000.component.html',
  styleUrls: ['./bfs12100000.component.scss'],
})
export class BFS12100000Component implements OnInit {

  @ViewChild(MapsComponent, { static: true })
  mapsComponent: MapsComponent;

  @ViewChild(IonSlides, { static: false }) ionSlides: IonSlides;

  branchList: any[];
  initMapsData: InitMapsModel;
  mapsType = 'all';
  default = '0';
  sortSelected: SelectBoxOptionModel;
  dataBranchId = 0;

  branchCategory: string;
  userLatitude: number;
  userLongitude: number;
  hideList = true;

  radioFilter = 'all';
  radioFilterText = '';
  defaultFacility: any[];
  markerSetAble = true;

  isCardButtonClick: boolean;

  facilityCode =  FACILITY_CODE;
  appLanguageModel = {
    en: LANGUAGE.I18N_EN,
    ja: LANGUAGE.I18N_JA,
    km: LANGUAGE.I18N_KM,
    ko: LANGUAGE.I18N_KO,
    zh: LANGUAGE.I18N_ZH
  };
  appLanguage: string;

  durations: Array<any>;
  constructor(
    public mapService: MapsService,
    public bizServer: BizserverService,
    private translate: TranslateService,
    private modalService: ModalService,
    public popoverController: PopoverController,
    public callNumber: CallNumber,
    public socialShare: SocialSharing,
    private backService: BackService,
    private routeState: ActivatedRoute
  ) {}

  ngOnInit() {}

  ionViewWillEnter() {
    if (Utils.getUserInfo()) {
      this.routeState.queryParams.subscribe(e => {
        if (e && e.from === 'my_account') {
          this.backService.subscribe('my_account');
        } else if (e && e.from === 'menu') {
          this.backService.subscribe('menu');
        }
      });
    } else {
      this.backService.subscribe('home');
    }
    this.appLanguage = (new Util()).getSecureStorage(LOCAL_STORAGE.I18N);
    this.translate.get('BFS12100000').subscribe((res) => {
      this.sortSelected = {
        title: res.TITLE.SORT,
        selectedTab: 1,
        selectedTabValue: res.LABEL.BY_DISTANCE,
        items: [
          {
            title: res.TITLE.SORT,
            itemValueField: 'value',
            itemTextField: 'text',
            seletedOpt: '0',
            option: [
              {
                text: res.LABEL.BY_DISTANCE,
                value: '0'
              },
              {
                text: res.LABEL.BY_NAME,
                value: '1'
              }
            ]
          },
        ]
      };

      this.radioFilterText = res.LABEL.ALL;
    });

    this.translate.get('BFS12100000.LABEL').subscribe((res) => {
      this.defaultFacility = [
        { name: res.SOCIAL_COFFEE_HUMANITY, code: FACILITY_CODE.SOCIAL_COFFEE_HUMANITY, checked: false },
        { name: res.GOLD_CLUB, code: FACILITY_CODE.GOLD_CLUB, checked: false },
        { name: res.KOREAN_DESK, code: FACILITY_CODE.KOREAN_DESK, checked: false },
        { name: res.CHINESE_DESK, code: FACILITY_CODE.CHINESE_DESK, checked: false },
        { name: res.JAPANESE_DESK, code: FACILITY_CODE.JAPANESE_DESK, checked: false },
        { name: res.SME_CENTER, code: FACILITY_CODE.SME_CENTER, checked: false }
      ];
    });

  }

  onClose() {
    this.backService.fire();
  }

  loadData(event: any) {
    if (event.length > 0) {
      this.branchList = event;
      console.log(this.branchList, "Brand_list");
      const branchListLength = this.branchList.length;
      this.durations = new Array(branchListLength);
      this.mapsComponent.setListMarkerOnMap(this.branchList, 'All');
      DataCenter.set('BFS12100000', 'branchList', event);
      this.sortBy('0');
    }
  }

  async markerClicked(branch: any ) {
    this.mapsComponent.clearMapRoute();
    this.markerSetAble = false;
    const index = this.branchList.findIndex( b => b.branchCode === branch.code && b.branchCategory === branch.category );
    const currentBranch = this.branchList.find( b => b.branchCode === branch.code && b.branchCategory === branch.category );
    this.ionSlides.slideTo(index);
    if (index >= 2) {
      const duration = await this.mapService.calculateRouteDistanceFromUser(currentBranch, currentBranch.userLocation);
      this.durations[index - 3] = duration;
    }
  }


  async ionSlideDidChange() {
    this.mapsComponent.clearMapRoute();
    if (!this.markerSetAble) {
        this.markerSetAble = true;
        return;
    }
    const index = await this.ionSlides.getActiveIndex();
    const branch = this.branchList[index];
    this.mapsComponent.setMarker(branch.latitude, branch.longitude, branch.branchCode);
    if (index >= 2) {
      const duration = await this.mapService.calculateRouteDistanceFromUser(branch, branch.userLocation);
      this.durations[index - 2] = duration;
    }
  }

  openBranchFilter() {
    this.mapsComponent.clearMapRoute();
    this.modalService.open({
      content: BFS12400000Component,
      message: { branchList: this.branchList, filterValue: this.radioFilter, facility: this.defaultFacility },
      callback: (data) => {
        console.log(data);

        // category
        if (data) {
          let branchList = DataCenter.get('BFS12100000', 'branchList', false);
          if (data.filterValue) {
            this.radioFilter = data.filterValue;
            this.mapsComponent.setMapOnAll(null);
            this.translate.get('BFS12100000.LABEL').subscribe((res) => {
              switch (this.radioFilter) {
                case 'branch':
                  branchList = branchList.filter( branch => branch.branchCategory === '01');
                  this.radioFilterText = res.BRANCH;
                  break;
                case 'atm':
                  branchList = branchList.filter( branch => branch.branchCategory === '02');
                  this.radioFilterText = res.ATM;
                  break;
                case 'all':
                  this.radioFilterText = res.ALL;
                  break;
              }
            });
          }

          this.defaultFacility = data.checkedFacility;
          const checkedFacility = data.checkedFacility.filter((facility: any) => facility.checked); // checked facility

          // facility 
          let filterBranchList = [];
          if ( checkedFacility && ( checkedFacility.length === 6 || checkedFacility.length > 0 ) ) { // Get only facilities  
            for (const branch of branchList) {   
              if ( this.radioFilter === 'atm' ) { // branchCategory 02 : ATM 
                if ( branch.facility.length === 0 || branch.facility.length === 1 && 
                    ( branch.facility[0].code === null || branch.facility[0].code === '' ) ) { // Case: Selected only ATM
                      filterBranchList.push(branch);
                }
              }
              for (const facility of branch.facility) { 
                let facilityCodeEqual = false; 
                for (const checked of checkedFacility) {   
                  if ( facility.code === checked.code && checked.checked ) {
                    filterBranchList.push(branch);
                    facilityCodeEqual = true;
                    break;
                  }
                }
                if (facilityCodeEqual) {
                  break;
                }
              } 
            } 
          } else if ( checkedFacility && checkedFacility.length === 0 ) { // not selected : Get all facilities and non-facilities 
            filterBranchList = branchList; 
          } else {  
            branchList.forEach( branch => {
              if (branch.facility.length === 0
                || (branch.facility.length === 1
                // && branch.facility[0].description === null
                && (branch.facility[0].code === ''
                || branch.facility[0].code === null))) {
                filterBranchList.push(branch);
              }
            });
          }
          this.branchList = filterBranchList;
          switch (this.radioFilter) {
            case 'branch':
              this.mapsComponent.setListMarkerOnMap(this.branchList, '01');
              break;
            case 'atm':
              this.mapsComponent.setListMarkerOnMap(this.branchList, '02');
              break;
            case 'all':
              this.mapsComponent.setListMarkerOnMap(this.branchList, 'All');
              break;
            }
        }
      },
      modalClass: ['pop_top']
    });
  }

  openDetail(data: any) {
    if (this.isCardButtonClick !== true) {
      this.mapsComponent.clearMapRoute();
      this.modalService.modal({
        component: BFS12300000Component,
        componentProps: {
          data
        },
        handler: (res) => {
          if (res.data === 'onDirections') {
            this.onShowMap();
          }
        }
      });
    }
    this.isCardButtonClick = false;
  }

  onClickBtnOnCard(role: ButtonCardRole, data?: any) {

    this.isCardButtonClick = true;
    switch (role) {
      case 'btn_call':
        const num = data;
        if (num && num.trim().length > 0) {
          this.callNumber.callNumber(num, false);
        }
        break;
      case 'btn_share':
        this.translate.get('BFS12100000.LABEL').subscribe(translate => {
          if (translate) {
            const shareData = `${translate.BRANCH_NAME} : ${this.appLanguage === this.appLanguageModel.en ? data.branchNameEn :
              this.appLanguage === this.appLanguageModel.ja ? data.branchNameJp :
              this.appLanguage === this.appLanguageModel.ko ? data.branchNameKr :
              this.appLanguage === this.appLanguageModel.km ? data.branchNameKh :
              this.appLanguage === this.appLanguageModel.zh ? data.branchNameCn :
              data.branchNameEn}
              ${translate.BRANCH_ADDRESS} : ${this.appLanguage === this.appLanguageModel.en ? data.branchAddressEn :
              this.appLanguage === this.appLanguageModel.ja ? data.branchAddressJp :
              this.appLanguage === this.appLanguageModel.ko ? data.branchAddressKr :
              this.appLanguage === this.appLanguageModel.km ? data.branchAddressKh :
              this.appLanguage === this.appLanguageModel.zh ? data.branchAddressCn :
              data.branchNameEn}`;
            this.socialShare.share(shareData);
          }
        });
        break;
      case 'btn_directions':
        const latLngObject: DestinationObject = {lat: data.latitude, lng: data.longitude, code: data.branchCode};
        this.mapService.calculateAndDisplayRoute(latLngObject);
        break;
    }
  }

  onClickSortBy() {
    this.mapsComponent.clearMapRoute();
    switch (this.default) {
      case '0':
        this.sortBy('0');
        break;
      case '1':
        this.sortBy('1');
        break;
    }
  }

  sortBy(type: string) {
    switch (type) {
      case '0':
        if (this.branchList.length > 0) {
          this.branchList = this.branchList.sort((a: any, b: any) => a.distance - b.distance);
        }
        break;
      case '1':
        if (this.branchList.length > 0) {
          this.branchList.sort((a: any, b: any) => ((
            this.appLanguage === this.appLanguageModel.en ? a.branchNameEn :
            this.appLanguage === this.appLanguageModel.ja ? a.branchNameJp :
            this.appLanguage === this.appLanguageModel.ko ? a.branchNameKr :
            this.appLanguage === this.appLanguageModel.km ? a.branchNameKh :
            this.appLanguage === this.appLanguageModel.zh ? a.branchNameCn :
            a.branchNameEn) >
            (this.appLanguage === this.appLanguageModel.en ? b.branchNameEn :
            this.appLanguage === this.appLanguageModel.ja ? b.branchNameJp :
            this.appLanguage === this.appLanguageModel.ko ? b.branchNameKr :
            this.appLanguage === this.appLanguageModel.km ? b.branchNameKh :
            this.appLanguage === this.appLanguageModel.zh ? b.branchNameCn :
            b.branchNameEn
            )) ? 1 : (((
              this.appLanguage === this.appLanguageModel.en ? b.branchNameEn :
              this.appLanguage === this.appLanguageModel.ja ? b.branchNameJp :
              this.appLanguage === this.appLanguageModel.ko ? b.branchNameKr :
              this.appLanguage === this.appLanguageModel.km ? b.branchNameKh :
              this.appLanguage === this.appLanguageModel.zh ? b.branchNameCn :
              b.branchNameEn) >
              (this.appLanguage === this.appLanguageModel.en ? a.branchNameEn :
              this.appLanguage === this.appLanguageModel.ja ? a.branchNameJp :
              this.appLanguage === this.appLanguageModel.ko ? a.branchNameKr :
              this.appLanguage === this.appLanguageModel.km ? a.branchNameKh :
              this.appLanguage === this.appLanguageModel.zh ? a.branchNameCn :
              a.branchNameEn
              )) ? -1 : 0));
        }
        break;
    }
  }

  onShowList(): void {
    this.mapsComponent.clearMapRoute();
    this.hideList = false;
  }

  onShowMap(): void {
    this.mapsComponent.clearMapRoute();
    this.hideList = true;
  }

}
