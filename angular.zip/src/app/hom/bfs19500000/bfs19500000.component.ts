import { Component, OnInit } from '@angular/core';
import { BackService } from 'src/app/shared/services/back.service';
import { Product } from 'src/app/shared/TRClass/PPCB0130-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { PersonalInfo } from '../bfs19200000/bfs19200000.model';

@Component({
  selector: 'app-bfs19500000',
  templateUrl: './bfs19500000.component.html',
  styleUrls: ['./bfs19500000.component.scss'],
})
export class BFS19500000Component implements OnInit {

  selectedLoan: Product;
  personalInfo: PersonalInfo;
  constructor(
    private backService: BackService
  ) {
    this.selectedLoan = DataCenter.get('loan-apply', 'selectedLoan', false);
    this.personalInfo = DataCenter.get('loan-apply', 'personalInfo', false);
  }

  ngOnInit() {}

  ionViewWillEnter() {
    this.subscribeBackButton();
  }

  subscribeBackButton() {
    const isSignedIn = DataCenter.get('loan-apply', 'isSignedIn', false);
    if (isSignedIn) {
      this.backService.subscribe('select_loan');
    } else {
      this.backService.subscribe('home');
    }
  }

  onBtnCofirmClick() {
    this.backService.fire();
  }
}
