import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { DateTimeFormatService } from 'src/app/shared/services/date-time.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { SelectService } from 'src/app/shared/services/select.service';
import { CEB4611Req } from 'src/app/shared/TRClass/CEB4611-req';
import { CEB4611Res } from 'src/app/shared/TRClass/CEB4611-res';
import { MaskedTextBoxComponent } from '@progress/kendo-angular-inputs';
import { BackService } from 'src/app/shared/services/back.service';
@Component({
  selector: 'app-bfs16000000',
  templateUrl: './bfs16000000.component.html',
  styleUrls: ['./bfs16000000.component.scss'],
})
export class BFS16000000Component implements OnInit {
  @ViewChild('setFocus', {static: true}) myInput: MaskedTextBoxComponent;
  items: any[];
  itemsRender: any[];
  exchangeRateList: any[];
  exchangeRateListTmp: any[];



  overseasExchangeRateList: any[];
  overseasExchangeRateListTmp: any[];
  selectRate1: SelectBoxOptionModel;
  selectRate2: SelectBoxOptionModel;
  optionSelectChange1: any[];
  optionSelectChange2: any[];
  now = moment();
  date: string;
  note = 'sell';
  rate1 = 1;
  rate1Str: string;
  rate2 = 0.00;
  rate2Str: string;
  selectChange1: string;
  selectChange2: string;
  changeLanguageRate1: string;
  changeLanguageRate2: string;
  final: number;
  test = '';

  cssRate1 = '';
  cssRate2 = '';
  setFocus1 = false;
  setFocus2 = false;
  viewText: any;
  constructor(
    private bizServer: BizserverService,
    private pipeDate: DateTimeFormatService,
    private translate: TranslateService,
    private selectService: SelectService,
    private formatterService: FormatterService,
    private backService: BackService
  ) {
  }

  ionViewWillEnter() {
    this.translate.get('COMMON.LABEL').subscribe((res) => {
      this.viewText = res;
    });
    this.doReq();
    this.backService.subscribe();
  }
  ngOnInit() {
    this.date = this.pipeDate.getDateTimeFormat(this.now.format('YYYYMMDD'));
    // this.doReq();
  }

  back() {
    this.backService.fire();
  }

  doReq() {
    const reqTr = new CEB4611Req();
    this.bizServer.bizMOBPost('CEB4611', reqTr).then(data => {
      const resTr = data as CEB4611Res;
      console.log(resTr);
      this.items = [];
      if (this.bizServer.checkResponse(resTr.header)) {
        this.exchangeRateListTmp = resTr.body.exchangeRateList;
        this.overseasExchangeRateListTmp = resTr.body.overseasExchangeRateList;
        console.log(this.overseasExchangeRateListTmp);
        this.pushExchangeRateList();
        this.pushOverseExchangeRateList();
        this.Sort();
        this.exchangeRateListTmp   = this.items;
        this.setSelectRate1(this.items);
        this.setSelectRate2(this.items);
        this.btnBuy();
        this.rate1Str = '1.00';
      }
    });
  }

  setSelectRate1(exChangeRateList) {
    this.optionSelectChange1 = [];
    const length =  exChangeRateList.length;
    for ( let i = 0; i < length; i++) {
        if ( exChangeRateList[i].currencyCode === 'USD') {
            this.selectChange1 = exChangeRateList[i].currencyCode;
            this.cssRate1      = exChangeRateList[i].ngClass;
            this.changeLanguageRate1 = 'USD';
        }
        this.optionSelectChange1.push({
          text: exChangeRateList[i].currencyCode,
          value: exChangeRateList[i].currencyCode,
          ngClass: exChangeRateList[i].ngClass
        });
    }
    // this.selectRate1 = this.objSelect;

    this.selectRate1 = {
      title: this.viewText.CHOOSE_CURRENCY, // sort text
      selectedTab: 0,
      selectedTabValue: 'USD',
      ngClass: 'rate1',
      items: [
        {
          title: 'titleTab',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.selectChange1,
          option: this.optionSelectChange1
        }
      ]
    };
  }

  setSelectRate2(exChangeRateListKHR) {
    this.optionSelectChange2 = [];
    const length =  exChangeRateListKHR.length;
    for ( let i = 0; i < length; i++) {
        if ( exChangeRateListKHR[i].currencyCode === 'KHR') {
            this.selectChange2 = exChangeRateListKHR[i].currencyCode;
            this.cssRate2      = exChangeRateListKHR[i].ngClass;
            this.changeLanguageRate2 = 'KHR';
        }
        this.optionSelectChange2.push({
          text: exChangeRateListKHR[i].currencyCode,
          value: exChangeRateListKHR[i].currencyCode,
          ngClass: exChangeRateListKHR[i].ngClass
        });
    }

    this.selectRate2 = {
      title: this.viewText.CHOOSE_CURRENCY, // sort text
      selectedTab: 0,
      selectedTabValue: '',
      ngClass: 'rate2',
      items: [
        {
          title: 'titleTab',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.selectChange2,
          option: this.optionSelectChange2
        }
      ]
    };
  }

  toFixed( value: string, returnFormate: 0 | 2 | 4): string {
    const split = String(value).split('.');
    const b = split[0];
    let a = '';
    if ( split[0]) {
      if ( returnFormate === 0) {
        return b;
      }
      if (returnFormate === 2) {
        if ( split[1] ) {
          a = split[1].substr(0, 2);
          return b + '.' + a;
        }
        return b;
      }
      if ( returnFormate === 4) {
        if ( split[1] ) {
          a = split[1].substr(0, 4);
          return b + '.' + a;
        }
        return b;
      }
    }
  }

  btnBuy() {
    this.note = 'buy';
    // this.setFocus1 = true;
    this.calculateRate();
  }

  btnSell() {
    this.note = 'sell';
    // this.setFocus1 = true;
    this.calculateRate();
  }

  calculateRate() {
      if ( this.note === 'buy') {                         // 1) When Buy button is clicked
        if ( this.selectChange1 === 'USD' ) {             // 1-1) First Currency is USD (USD => other currency)
        // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < this.items.length; i++) {
              if ( this.items[i].currencyCode === this.selectChange2 ) {
                const value = Math.round( this.rate1 * this.items[i].buying * 100) / 100;
                if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
                  const data = this.formatterService.formatAmount(value, 0);

                  this.rate2Str = data.text;
                  this.rate2    = data.value;

                } else if ( this.selectChange2 === 'EUR') {
                  const value1 = this.rate1 * this.items[i].buying;
                  const data    = this.formatterService.formatAmount(value1, 4);
                  this.rate2    = data.value;
                  this.rate2Str = data.text;

                } else {
                  // this.rate2 = +this.toFixed(String(value), 2);
                  const data    = this.formatterService.formatAmount(value, 2);
                  this.rate2    = data.value;
                  this.rate2Str = data.text;
                }
              }
          }

        } else if (this.selectChange2 === 'USD') {        // 1-2) Second Currency is USD ( Other currency to USD )
          // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < this.items.length; i++) {
            if ( this.items[i].currencyCode === this.selectChange1 ) {
              let value     = Math.round( this.rate1 / this.items[i].buying * 100) / 100;
              const data    = this.formatterService.formatAmount(value, 2);
              this.rate2    = data.value;
              this.rate2Str = data.text;
              // this.rate2 = +this.toFixed(String(value), 2);
            }
        }

        } else if ( this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD' ) {
          let sellRate = 0;
          let baseRate = 0;
          // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange1) {
                sellRate = this.items[i].selling;
              }
          }
          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange2) {
               baseRate = this.items[i].baseRate;
            }
          }
          // console.log(sellRate, baseRate, this.rate1, 'dddddddddddddddddddd');
          if ( sellRate !== 0 && baseRate !== 0 ) {
            const value = Math.round( ( this.rate1 / sellRate * baseRate ) * 100 ) / 100;
            if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
              // this.rate2 = +this.toFixed(String(value), 0);
              const data    = this.formatterService.formatAmount(value, 0);
              this.rate2    = data.value;
              this.rate2Str = data.text;
            } else if ( this.selectChange2 === 'EUR') {
              const value1  =  this.rate1 / sellRate * baseRate;
              // this.rate2 = +this.toFixed(String(value1), 4);
              const data    = this.formatterService.formatAmount(value1, 4);
              this.rate2    = data.value;
              this.rate2Str = data.text;
            } else {
              // this.rate2 = +this.toFixed(String(value), 2);
              const data    = this.formatterService.formatAmount(value , 2);
              this.rate2    = data.value;
              this.rate2Str = data.text;
            }
          }
        }
      }

      if ( this.note === 'sell') {              // 2) When Sell Button is clicked
        if ( this.selectChange1 === 'USD' ) {   // 2-1) First Currency is USD
        // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange2 ) {
              const value = Math.round( ( this.rate1 * this.items[i].selling ) * 100) / 100;

              if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
                // this.rate2 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate2    = data.value;
                this.rate2Str = data.text;

              } else if ( this.selectChange2 === 'EUR') {
                const value1  = this.rate1 * this.items[i].selling;
                console.log('value1', value1);
                
                // this.rate2 = +this.toFixed(String(value1), 4);
                const data    = this.formatterService.formatAmount(value1, 4);
                
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else {
                // this.rate2 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              }

            }
          }
        }  else if (this.selectChange2 === 'USD') { // 2-2) Second Currency is USD
          for ( let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange1 ) {
                  // this.rate2 = Math.round( (this.rate1 / this.items[i].selling) * 100) / 100;
                let value = Math.round( (this.rate1 / this.items[i].selling) * 100) / 100;
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              }
          }

        } else if ( this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD' ) { // 2-3) When both currencies are not USD

          let buyRate = 0;
          let baseRate = 0;
          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange1 ) {
              buyRate = this.items[i].buying;
            }
          }

          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++) {
            if ( this.items[i].currencyCode === this.selectChange2 ) {
              baseRate = this.items[i].baseRate;
            }
          }

          if ( buyRate !== 0 && baseRate !== 0 ) {
              const value = Math.round( this.rate1 / buyRate * baseRate * 100 ) / 100 ;
              if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
                // this.rate2 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else if ( this.selectChange2 === 'EUR') {
                const value1  =  this.rate1 / buyRate * baseRate;
                // this.rate2 = +this.toFixed(String(value1), 4);
                const data    = this.formatterService.formatAmount(value1, 4);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else {
                // this.rate2 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              }
          }
      }
      }
  }

  changeRate1() {
    this.setFocus1 = false;
    this.setFocus2 = false;
  // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.items.length; i++) {
      if ( this.items[i].currencyCode === this.selectChange1) {
        this.cssRate1 = this.items[i].currencyCode;
        this.cssRate1 = this.items[i].ngClass;
        this.changeLanguageRate1 = this.items[i].currencyCode;
      }
    }
    if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
        // this.rate1 = +this.toFixed(String(this.rate1), 0);
        const data    = this.formatterService.formatAmount(this.rate1Str, 0);
        this.rate1    = data.value;
        this.rate1Str = data.text;
    } else if ( this.selectChange1 === 'EUR') {
        // this.rate1 = +this.toFixed(String(this.rate1), 4);
        const data    = this.formatterService.formatAmount(this.rate1Str, 4);
        this.rate1    = data.value;
        this.rate1Str = data.text;
    } else {
        // this.rate1 = +this.toFixed(String(this.rate1), 2);
        const data    = this.formatterService.formatAmount(this.rate1Str, 2);
        this.rate1    = data.value;
        this.rate1Str = data.text;
    }

    if ( this.note === 'buy') {
        if ( this.selectChange2 === 'USD')  {  // 1-1) First Currency is USD

            // tslint:disable-next-line: prefer-for-of
            for ( let i = 0; i < this.items.length; i++) {
              if ( this.items[i].currencyCode === this.selectChange1) {
                const value = Math.round( ( this.rate2 * this.items[i].buying ) * 100) / 100;
                if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                  // this.rate1 = +this.toFixed(String(value), 0);
                  const data    = this.formatterService.formatAmount(value, 0);
                  this.rate1    = data.value;
                  this.rate1Str = data.text;
                } else if ( this.selectChange1 === 'EUR') {
                  const value1  = this.rate2 * this.items[i].buying;
                  // this.rate1 = +this.toFixed(String(value1), 4);
                  const data    = this.formatterService.formatAmount(value1, 4);
                  this.rate1    = data.value;
                  this.rate1Str = data.text;
                } else {
                  // this.rate1 = +this.toFixed(String(value), 2);
                  const data    = this.formatterService.formatAmount(value, 2);
                  this.rate1    = data.value;
                  this.rate1Str = data.text;
                }
              }
            }

        } else if ( this.selectChange1 === 'USD' ) { // 1-2) Second Currency is USD

        // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange2) {
                // this.rate1 = Math.round( this.rate2 / this.items[i].buying * 100 ) / 100;
                let value     = Math.round( this.rate2 / this.items[i].buying * 100 ) / 100;
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              }
          }

        } else if ( this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD') { // 1-3) When both currencies are not USD
          // console.log('1-3) When both currencies are not USD');
          let sellRate = 0;
          let baseRate = 0;

        // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
              if (this.items[i].currencyCode === this.selectChange2) {
                sellRate = this.items[i].selling;
              }
          }

        // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange1) {
              baseRate = this.items[i].baseRate;
            }
          }
          // console.log(sellRate, baseRate, this.selectChange1, this.selectChange2);
          if ( sellRate !== 0 && baseRate !== 0 ) {

            const value = Math.round( this.rate2 / sellRate * baseRate  * 100) / 100;

            if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                // this.rate1 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              } else if ( this.selectChange1 === 'EUR') {
                // console.log(this.rate2, Number(sellRate), baseRate);
                const value1  =  this.rate2 / Number(sellRate) * baseRate;
                // this.rate1 = +this.toFixed(String(value1), 4);

                const data    = this.formatterService.formatAmount(value1, 4);
                this.rate1    = data.value;
                this.rate1Str = data.text;

              } else {
                // this.rate1 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              }

          }
        }
    }

    if ( this.note === 'sell' ) {
      if ( this.selectChange2 === 'USD') { // 2-1) First Currency is USD
          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange1 ) {
                  const value = Math.round( this.rate2 * this.items[i].selling * 100) / 100;

                  if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                    // this.rate1 = +this.toFixed(String(value), 0);
                    const data    = this.formatterService.formatAmount(value, 0);
                    this.rate1    = data.value;
                    this.rate1Str = data.text;
                  } else if ( this.selectChange1 === 'EUR') {
                    const value1 =  this.rate2 * this.items[i].selling;
                    // this.rate1 = +this.toFixed(String(value1), 4);
                    const data    = this.formatterService.formatAmount(value1, 4);
                    this.rate1    = data.value;
                    this.rate1Str = data.text;
                  } else {
                    // this.rate1 = +this.toFixed(String(value), 2);
                    const data    = this.formatterService.formatAmount(value, 2);
                    this.rate1    = data.value;
                    this.rate1Str = data.text;
                  }
              }
          }
      } else if (this.selectChange1 === 'USD') { // 2-2) Second Currency is USD

          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange2) {
                // this.rate1 = Math.round( this.rate2 / this.items[i].selling * 100) / 100;
                let value = Math.round( this.rate2 / this.items[i].selling * 100) / 100;
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              }
          }
      } else if (this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD' ) { // 2-3) When both currencies are not USD
        let buyRate  = 0;
        let baseRate = 0;
        // tslint:disable-next-line: prefer-for-of
        for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange2) {
              buyRate = this.items[i].buying;
            }
        }
        // tslint:disable-next-line: prefer-for-of
        for ( let i = 0; i < this.items.length; i++) {
            if ( this.items[i].currencyCode === this.selectChange1 ) {
              baseRate = this.items[i].baseRate;
            }
        }
        if ( buyRate !== 0 && baseRate !== 0 ) {
          const value = Math.round( this.rate2 / buyRate * baseRate * 100) / 100;

          if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
            // this.rate1 = +this.toFixed(String(value), 0);
            const data    = this.formatterService.formatAmount(value, 0);
            this.rate1    = data.value;
            this.rate1Str = data.text;
          } else if ( this.selectChange1 === 'EUR') {
            const value1  =  this.rate2 / buyRate * baseRate;
            // this.rate1 = +this.toFixed(String(value1), 4);
            const data    = this.formatterService.formatAmount(value1, 4);
            this.rate1    = data.value;
            this.rate1Str = data.text;
          } else {
            // this.rate1 = +this.toFixed(String(value), 2);
            const data    = this.formatterService.formatAmount(value, 2);
            this.rate1    = data.value;
            this.rate1Str = data.text;
          }
        }

      }
    }
  }

  changeRate2() {

  // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.items.length; i++) {
      if ( this.items[i].currencyCode === this.selectChange2) {
        this.cssRate2 = this.items[i].currencyCode;
        this.cssRate2 = this.items[i].ngClass;
        this.changeLanguageRate2 = this.items[i].currencyCode;
      }
    }
    if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
      // this.rate2 = +this.toFixed(String(this.rate2), 0);
      const data    = this.formatterService.formatAmount(this.rate2Str, 0);
      this.rate2    = data.value;
      this.rate2Str = data.text;
    } else if ( this.selectChange1 === 'EUR') {
        // this.rate2 = +this.toFixed(String(this.rate2), 4);
        const data    = this.formatterService.formatAmount(this.rate2Str, 4);
        this.rate2    = data.value;
        this.rate2Str = data.text;
    } else {
        // this.rate2 = +this.toFixed(String(this.rate2), 2);
        const data    = this.formatterService.formatAmount(this.rate2Str, 2);
        this.rate2    = data.value;
        this.rate2Str = data.text;
    }
    this.setFocus1 = false;
    this.setFocus2 = false;

    if ( this.note === 'buy') {
      if ( this.selectChange1 === 'USD' ) { // 1-1) First Currency is USD

          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange2 ) {
                  const value = Math.round( this.rate1 * this.items[i].buying * 100 ) / 100;
                  if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
                    // this.rate2 = +this.toFixed(String(value), 0);
                    const data    = this.formatterService.formatAmount(value, 0);
                    this.rate2    = data.value;
                    this.rate2Str = data.text;
                  } else if ( this.selectChange2 === 'EUR') {
                    const value1 =  this.rate1 * this.items[i].buying;
                    // this.rate2 = +this.toFixed(String(value1), 4);
                    const data    = this.formatterService.formatAmount(value1, 4);
                    this.rate2    = data.value;
                    this.rate2Str = data.text;
                    console.log(this.rate2Str);
                  } else {
                    // this.rate2 = +this.toFixed(String(value), 2);
                    const data    = this.formatterService.formatAmount(value, 2);
                    this.rate2    = data.value;
                    this.rate2Str = data.text;
                  }
              }
          }
      } else if ( this.selectChange2 === 'USD' ) { // 1-2) Second Currency is USD

          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange1) {
              // this.rate2 = Math.round ( this.rate1 / this.items[i].buying * 100 ) / 100;
              let value     = Math.round ( this.rate1 / this.items[i].buying * 100 ) / 100;
              const data    = this.formatterService.formatAmount(value, 2);
              this.rate2    = data.value;
              this.rate2Str = data.text;
            }

          }
      } else if ( this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD' ) {
        let sellRate = 0;
        let baseRate = 0;
        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange1) {
              sellRate = this.items[i].selling;
            }
        }
        // tslint:disable-next-line: prefer-for-of
        for ( let i = 0; i < this.items.length; i++ ) {
          if ( this.items[i].currencyCode === this.selectChange2) {
             baseRate = this.items[i].baseRate;
          }
        }
        // console.log(sellRate, baseRate, this.rate1, 'dddddddddddddddddddd');
        if ( sellRate !== 0 && baseRate !== 0 ) {
          const value = Math.round( ( this.rate1 / sellRate * baseRate ) * 100 ) / 100;
          if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
            // this.rate2 = +this.toFixed(String(value), 0);
            const data    = this.formatterService.formatAmount(value, 0);
            this.rate2    = data.value;
            this.rate2Str = data.text;
          } else if ( this.selectChange2 === 'EUR') {
            const value1  =  this.rate1 / sellRate * baseRate;
            // this.rate2 = +this.toFixed(String(value1), 4);
            const data    = this.formatterService.formatAmount(value1, 4);
            this.rate2    = data.value;
            this.rate2Str = data.text;
          } else {
            // this.rate2 = +this.toFixed(String(value), 2);
            const data    = this.formatterService.formatAmount(value , 2);
            this.rate2    = data.value;
            this.rate2Str = data.text;
          }
        }
      }
    }

    if ( this.note === 'sell') {
      if ( this.selectChange1 === 'USD') { // 2-1) First Currency is USD

        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < this.items.length; i++) {
            if (this.items[i].currencyCode === this.selectChange2 ) {
              const value = Math.round( this.rate1 * this.items[i].selling * 100) / 100;
              if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
                // this.rate2 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else if ( this.selectChange2 === 'EUR') {
                const value1  =  this.rate1 * this.items[i].selling;
                // this.rate2 = +this.toFixed(String(value1), 4);
                const data    =  this.formatterService.formatAmount(value1, 4);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else {
                // this.rate2 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              }
            }
        }
      } else if ( this.selectChange2 === 'USD') { // 2-2) Second Currency is USD

        // tslint:disable-next-line: prefer-for-of
        for ( let i = 0; i < this.items.length; i++) {
            if ( this.items[i].currencyCode === this.selectChange1) {
              const value = Math.round ( this.rate1 / this.items[i].selling * 100) / 100;

              if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                // this.rate2 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else if ( this.selectChange1 === 'EUR') {
                const value1 =  this.rate1 / this.items[i].selling;
                // this.rate2 = +this.toFixed(String(value1), 4);
                const data    = this.formatterService.formatAmount(value1, 4);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else {
                // this.rate2 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              }
            }

        }
      } else if ( this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD' ) { // 2-3) When both currencies are not USD

          let buyRate = 0;
          let baseRate = 0;
          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange1 ) {
              buyRate = this.items[i].buying;
            }
          }

          // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++) {
            if ( this.items[i].currencyCode === this.selectChange2 ) {
              baseRate = this.items[i].baseRate;
            }
          }

          if ( buyRate !== 0 && baseRate !== 0 ) {
              const value = Math.round( this.rate1 / buyRate * baseRate * 100 ) / 100 ;
              if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
                // this.rate2 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else if ( this.selectChange2 === 'EUR') {
                const value1  =  this.rate1 / buyRate * baseRate;
                // this.rate2 = +this.toFixed(String(value1), 4);
                const data    = this.formatterService.formatAmount(value1, 4);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              } else {
                // this.rate2 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate2    = data.value;
                this.rate2Str = data.text;
              }
          }
      }

    }
  }

  onTypeChangeRate1(event) {
    if ( this.setFocus1 === true ) {
      this.rate1         = Number(event.target.value);
      this.calculateRate();
    }
  }

  onTypeChangeRate2(e) {
      this.rate2 = Number(e.target.value);
      if ( this.note === 'buy' ) {
          if ( this.selectChange2 === 'USD' ) {             // 1-1) First Currency is USD (USD => other currency)
            for (let i = 0; i < this.items.length; i++) {
                if ( this.items[i].currencyCode === this.selectChange1 ) {
                  const value = Math.round( this.rate2 * this.items[i].buying * 100) / 100;

                  if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                    // this.rate1 = +this.toFixed(String(value), 0);
                    const data    = this.formatterService.formatAmount(value, 0);
                    this.rate1    = data.value;
                    this.rate1Str = data.value;
                  } else if ( this.selectChange1 === 'EUR') {
                    const value1 = e.target.value * this.items[i].buying;
                    // this.rate1 = +this.toFixed(String(value1), 4);
                    const data    = this.formatterService.formatAmount(value1, 4);
                    this.rate1    = data.value;
                    this.rate1Str = data.text;
                  } else {
                    // this.rate1 = +this.toFixed(String(value), 2);
                    const data    = this.formatterService.formatAmount(value, 2);
                    this.rate1    = data.value;
                    this.rate1Str = data.text;
                  }
                }
            }
          } else if (this.selectChange1 === 'USD') {        // 1-2) Second Currency is USD ( Other currency to USD )
          // tslint:disable-next-line: prefer-for-of
            for (let i = 0; i < this.items.length; i++) {
              if ( this.items[i].currencyCode === this.selectChange2 ) {
                // this.rate1 = Math.round( this.rate2 / this.items[i].buying * 100) / 100;
                let value     = Math.round( this.rate2 / this.items[i].buying * 100) / 100;
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              }
            }
          } else if (this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD') { // 1-3) When both currencies are not USD
            let sellRateFromCurrency = 0;
            let baseRateToCurrency   = 0;
          // tslint:disable-next-line: prefer-for-of
            for (let i = 0; i < this.items.length; i++) {
              if ( this.items[i].currencyCode === this.selectChange2 ) {
                sellRateFromCurrency = this.items[i].selling;
              }
            }
          // tslint:disable-next-line: prefer-for-of
            for ( let i = 0; i < this.items.length; i++ ) {
              if ( this.items[i].currencyCode === this.selectChange1 ) {
                baseRateToCurrency = this.items[i].baseRate;
              }
            }
            if ( sellRateFromCurrency !== 0 && baseRateToCurrency !== 0 ) {
              const value = Math.round( (this.rate2 / sellRateFromCurrency * baseRateToCurrency) * 100) / 100;

              if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                // this.rate1 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate1    =  data.value;
                this.rate1Str = data.text;
              } else if ( this.selectChange1 === 'EUR') {
                const value1  = this.rate2 / sellRateFromCurrency * baseRateToCurrency;
                // this.rate1 = +this.toFixed(String(value1), 4);
                const data    = this.formatterService.formatAmount(value1, 4);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              } else {
                // this.rate1 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              }
            }
      }
      } else if ( this.note === 'sell' ) {
        if ( this.selectChange2 === 'USD' ) {   // 2-1) First Currency is USD
          // this.rate1 = this.rate2;
        // tslint:disable-next-line: prefer-for-of
          for ( let i = 0; i < this.items.length; i++ ) {
            if ( this.items[i].currencyCode === this.selectChange1 ) {
              const value = Math.round( ( this.rate2 * this.items[i].selling ) * 100) / 100;

              if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
                // this.rate1 = +this.toFixed(String(value), 0);
                const data    = this.formatterService.formatAmount(value, 0);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              } else if ( this.selectChange1 === 'EUR') {
                const value1 = this.rate2 * this.items[i].selling;
                // this.rate1 = +this.toFixed(String(value1), 4);
                const data    = this.formatterService.formatAmount(value1, 4);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              } else {
                // this.rate1 = +this.toFixed(String(value), 2);
                const data    = this.formatterService.formatAmount(value, 2);
                this.rate1    = data.value;
                this.rate1Str = data.text;
              }
            }
          }
      } else if (this.selectChange1 === 'USD') { // 2-2) Second Currency is USD
        for (let i = 0; i < this.items.length; i++) {
          if ( this.items[i].currencyCode === this.selectChange2) {
            // this.rate1 = Math.round( this.rate2 / this.items[i].selling * 100) / 100;
            let value     = Math.round( this.rate2 / this.items[i].selling * 100) / 100;
            const data    = this.formatterService.formatAmount(value, 2);
            this.rate1    = data.value;
            this.rate1Str = data.text;
          }
        }
      } else if (this.selectChange1 !== 'USD' && this.selectChange2 !== 'USD') { // 2-3) When both currencies are not USD
        let buyRateFromCurrency = 0;
        let baseRateToCurrency   = 0;

      // tslint:disable-next-line: prefer-for-of
        for ( let i = 0; i < this.items.length; i++) {
          if ( this.items[i].currencyCode === this.selectChange2 ) {
            buyRateFromCurrency = this.items[i].buying;
          }
        }
      // tslint:disable-next-line: prefer-for-of
        for ( let i = 0; i < this.items.length; i++ ) {
          if ( this.items[i].currencyCode === this.selectChange1 ) {
            baseRateToCurrency = this.items[i].baseRate;
          }
        }

        if ( buyRateFromCurrency !== 0 && baseRateToCurrency !== 0 ) {
            const value = Math.round( this.rate2 / buyRateFromCurrency * baseRateToCurrency  * 100) / 100;
            if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
              // this.rate1 = +this.toFixed(String(value), 0);
              const data    = this.formatterService.formatAmount(value, 0);
              this.rate1    = data.value;
              this.rate1Str = data.text;
            } else if ( this.selectChange1 === 'EUR') {
              const value1  = this.rate2 / buyRateFromCurrency * baseRateToCurrency;
              // this.rate1 = +this.toFixed(String(value1), 4);
              const data    = this.formatterService.formatAmount(value1, 4);
              this.rate1    = data.value;
              this.rate1Str = data.text;
            } else {
              // this.rate1 = +this.toFixed(String(value), 2);
              const data    = this.formatterService.formatAmount(value, 2);
              this.rate1    = data.value;
              this.rate1Str = data.text;
            }
        }
      }
      }
  // }
  }

  setFocusRate1(event) {
    this.setFocus1 = true;
    this.setFocus2 = false;
    if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
      // this.rate1 = +this.toFixed(String(this.rate1), 0);
      const data    = this.formatterService.formatAmount(event.target.value, 0);
      this.rate1    = data.value;
      this.rate1Str = String(data.value);
    } else if ( this.selectChange1 === 'EUR') {
      // this.rate1 = +this.toFixed(String(this.rate1), 4);
      const data    = this.formatterService.formatAmount(event.target.value, 4);
      this.rate1    = data.value;
      this.rate1Str = data.text;
    } else {
      // this.rate1 = +this.toFixed(String(this.rate1), 2);
      const data    = this.formatterService.formatAmount(event.target.value, 2);
      this.rate1    = data.value;
      this.rate1Str = String(data.value);
    }
    console.log(this.rate1Str);
    event.target.value = this.rate1Str;
  }

  setFocusOutRate1(event) {
    if ( this.selectChange1 === 'KHR' || this.selectChange1 === 'VND') {
      // this.rate1 = +this.toFixed(String(this.rate1), 0);
      const data    = this.formatterService.formatAmount(event.target.value, 0);
      this.rate1    = data.value;
      this.rate1Str = data.text;
    } else if ( this.selectChange1 === 'EUR') {
      // this.rate1 = +this.toFixed(String(this.rate1), 4);
      const data    = this.formatterService.formatAmount(event.target.value, 4);
      this.rate1    = data.value;
      this.rate1Str = data.text;
    } else {
      // this.rate1 = +this.toFixed(String(this.rate1), 2);
      const data    = this.formatterService.formatAmount(event.target.value, 2);
      this.rate1    = data.value;
      this.rate1Str = data.text;
    }
    console.log(this.rate1Str);
    event.target.value = this.rate1Str;
  }

  setFocusRate2(event) {
    this.setFocus2 = true;
    this.setFocus1 = false;
    if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
      // this.rate2 = +this.toFixed(String(this.rate2), 0);
      const data    = this.formatterService.formatAmount(event.target.value, 0);
      this.rate2    = data.value;
      this.rate2Str = String(data.value);
    } else if ( this.selectChange2 === 'EUR') {
        // this.rate2 = +this.toFixed(String(this.rate2), 4);
        const data    = this.formatterService.formatAmount(event.target.value, 4);
        this.rate2    = data.value;
        this.rate2Str = String(data.value);
        // alert(this.rate2Str);
    } else {
        // this.rate2 = +this.toFixed(String(this.rate2), 2);
        const data    = this.formatterService.formatAmount(event.target.value, 2);
        this.rate2    = data.value;
        this.rate2Str = String(data.value);
    }
  }

  setFocusOutRate2(event) {
    if ( this.selectChange2 === 'KHR' || this.selectChange2 === 'VND') {
      // this.rate2 = +this.toFixed(String(this.rate2), 0);
      const data    = this.formatterService.formatAmount(event.target.value, 0);
      this.rate2    = data.value;
      this.rate2Str = data.text;
    } else if ( this.selectChange2 === 'EUR') {
        // this.rate2 = +this.toFixed(String(this.rate2), 4);
        const data    = this.formatterService.formatAmount(event.target.value, 4);
        this.rate2    = data.value;
        this.rate2Str = data.text;
    } else {
        // this.rate2 = +this.toFixed(String(this.rate2), 2);
        const data    = this.formatterService.formatAmount(event.target.value, 2);
        this.rate2    = data.value;
        this.rate2Str = data.text;
    }
  }

  async ionchangeRate1() {
    // console.log(this.changeLanguageRate1, this.changeLanguageRate2);
    this.optionSelectChange1 = [];
    const length =  this.items.length;

    this.items.forEach(element => {
      if ( element.currencyCode !== this.changeLanguageRate2) {
        this.optionSelectChange1.push({
          text: element.currencyCode,
          value: element.currencyCode,
          ngClass: element.ngClass,
          buying: element.buying,
          selling: element.selling,
          baseRate: element.baseRate,
        });
      }
    });

    const selectBoxOption: SelectBoxOptionModel = {
        title:  this.viewText.CHOOSE_CURRENCY,
        items: [{ title: 'Select',
                  itemTextField: 'text',
                  itemValueField: 'value',
                  seletedOpt: this.selectChange1,
                  option: this.optionSelectChange1
        }]
    };
    const result = await this.selectService.present(selectBoxOption);
    if (result && result.value) {
      this.changeLanguageRate1 = result.text;
      this.cssRate1 = result.ngClass;
      this.selectChange1 = result.text;
      this.changeRate1();
    //  console.log(result);
    }
  }

  async ionchangeRate2() {
    this.optionSelectChange2 = [];
    const length =  this.items.length;

    this.items.forEach(element => {
      if ( element.currencyCode !== this.changeLanguageRate1) {
        this.optionSelectChange2.push({
          text: element.currencyCode,
          value: element.currencyCode,
          ngClass: element.ngClass,
          buying: element.buying,
          selling: element.selling,
          baseRate: element.baseRate,
        });
      }
    });

    const selectBoxOption: SelectBoxOptionModel = {
        title:  this.viewText.CHOOSE_CURRENCY,
        items: [{ title: 'Select',
                  itemTextField: 'text',
                  itemValueField: 'value',
                  seletedOpt: this.selectChange2,
                  option: this.optionSelectChange2
        }]
    };
    const result = await this.selectService.present(selectBoxOption);
    if (result && result.value) {
      this.changeLanguageRate2 = result.text;
      this.cssRate2 = result.ngClass;
      this.selectChange2 = result.text;
      this.changeRate2();
    //  console.log(result);
    }
  }
  Sort() {
    const orders = ['USD', 'KHR', 'KRW', 'EUR', 'THB', 'CNY', 'VND', 'JPY'];
    this.itemsRender = this.itemsRender.sort( (a, b) => {
      const index1 = orders.indexOf(a.currencyCode);
      const index2 = orders.indexOf(b.currencyCode);
      if ( index1 === -1) {
        return 1;
      }
      if (index2 === -1) {
        return -1;
      }
      return index1 - index2;
    } );
    // console.log(this.items);
  }

  onClickCurrencyExchange() {
   this.itemsRender =  this.exchangeRateList;
   this.Sort();
  }

  onClickOverseaTransfer() {
    this.itemsRender = this.overseasExchangeRateList;
    this.Sort();
  }
  pushExchangeRateList() {
    const length = this.exchangeRateListTmp.length;
    this.items = [];
    let p ;
    let itemClass;
    for ( let i = 0; i < length; i++) {
        switch ( this.exchangeRateListTmp[i].currencyCode) {
          case 'KHR': // 1 KHR
            itemClass = 'curreny_khr';
            break;
          case 'EUR': // 2 EUR
            itemClass = 'curreny_eur';
            break;
          case 'JPY': // 3 JPY
            itemClass = 'curreny_jyp';
            break;
          case 'THB': // 4 THB
            itemClass = 'curreny_thb';
            break;
          case 'SGD': // 5 SGD
            itemClass = 'curreny_sgd';
            break;
          case 'KRW': // 6 KRW
            itemClass = 'curreny_krw';
            break;
          case 'CNY':
            itemClass = 'curreny_cny';
            break;
          case 'VND':
              itemClass = 'curreny_vnd';
              break;
          case 'USD': // 7 USD
            itemClass = 'curreny_usd';
            break;
          default:
            itemClass = 'noCss';
            break;
        }
        p = {
          buying: +this.exchangeRateListTmp[i].buying,
          currencyCode: this.exchangeRateListTmp[i].currencyCode,
          selling: +this.exchangeRateListTmp[i].selling,
          baseRate: +this.exchangeRateListTmp[i].baseRate,
          ngClass: itemClass
        };
        this.items.push(p);
        this.exchangeRateList = this.items;
        this.itemsRender      = this.items;
    }
  }

  pushOverseExchangeRateList() {
    const length = this.overseasExchangeRateListTmp.length;
    this.overseasExchangeRateList = [];
    let itemClass ;
    let overseasExchangeRate;
    for ( let i = 0; i < length; i++) {
        switch ( this.overseasExchangeRateListTmp[i].currencyCode) {
          case 'KHR': // 1 KHR
            itemClass = 'curreny_khr';
            break;
          case 'EUR': // 2 EUR
            itemClass = 'curreny_eur';
            break;
          case 'JPY': // 3 JPY
            itemClass = 'curreny_jyp';
            break;
          case 'THB': // 4 THB
            itemClass = 'curreny_thb';
            break;
          case 'SGD': // 5 SGD
            itemClass = 'curreny_sgd';
            break;
          case 'KRW': // 6 KRW
            itemClass = 'curreny_krw';
            break;
          case 'CNY':
            itemClass = 'curreny_cny';
            break;
          case 'VND':
              itemClass = 'curreny_vnd';
              break;
          case 'USD': // 7 USD
            itemClass = 'curreny_usd';
            break;
          default:
            itemClass = 'noCss';
            break;
        }
        overseasExchangeRate = {
          buying: +this.overseasExchangeRateListTmp[i].buying,
          currencyCode: this.overseasExchangeRateListTmp[i].currencyCode,
          selling: +this.overseasExchangeRateListTmp[i].selling,
          ngClass: itemClass
        };
        this.overseasExchangeRateList.push(overseasExchangeRate);
    }
  }

}
