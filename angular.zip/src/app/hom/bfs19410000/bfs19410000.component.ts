import { Component, OnInit } from '@angular/core';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Router } from '@angular/router';
import { LoanApplyService } from '../bfs19100000/loan-apply.service';

@Component({
  selector: 'app-bfs19410000',
  templateUrl: './bfs19410000.component.html',
  styleUrls: ['./bfs19410000.component.scss'],
})
export class BFS19410000Component implements OnInit {

  constructor(
    private router: Router,
    private loanApply: LoanApplyService
  ) { }

  ngOnInit() {}

  handler(e) {
    console.log(e);
    if (e.type === 'next' || e.type === 'list_item') {
      DataCenter.set('bfs19410000', 'selectedBranch', e.detail.data);
      this.router.navigateByUrl('/loan-apply/confirm');
    } else if (e.type === 'skip') {
      DataCenter.set('bfs19410000', 'selectedBranch', undefined);
      this.router.navigateByUrl('/loan-apply/confirm');
    } else if (e.type === 'cancel') {
      this.loanApply.onCancel();
    }
  }
}

