import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs1-a440000',
  templateUrl: './bfs1-a440000.component.html',
  styleUrls: ['./bfs1-a440000.component.scss'],
})
export class BFS1A440000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
