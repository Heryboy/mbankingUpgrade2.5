import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS13000000aComponent } from './bfs13000000a.component';

describe('BFS13000000aComponent', () => {
  let component: BFS13000000aComponent;
  let fixture: ComponentFixture<BFS13000000aComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS13000000aComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS13000000aComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
