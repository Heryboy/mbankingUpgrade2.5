import { CEB5720Res } from 'src/app/shared/TRClass/CEB5720-res';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB5720Req } from 'src/app/shared/TRClass/CEB5720-req';
import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BUTTON_ROLE, CATEGORY, OPEN_ACCOUNT, OPEN_ACCOUNT_Deposit_KHR, OPEN_ACCOUNT_Deposit_USD, APPLY_LOAN, INSTALLMENT_ACCOUNT, FIXED_DEPOSIT_ACCOUNT, SAVING_DEPOSIT_ACCOUNT, LOAN_AGAINST_DEPOSIT, LOCAL_STORAGE, LOAN_PRODUCT_BU_CODE } from 'src/app/shared/constants/common.const';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PPCB0140Req } from 'src/app/shared/TRClass/PPCB0140-req';
import { PPCB0140Res } from 'src/app/shared/TRClass/PPCB0140-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { environment } from 'src/environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { Util } from 'src/app/shared/util';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-bfs18100000',
  templateUrl: './bfs18100000.component.html',
  styleUrls: ['./bfs18100000.component.scss'],
})
export class BFS18100000Component implements OnInit {

  i18n;

  product;
  productId: number;
  resultSuccess = false;
  isOpenAcc = false;
  categoryAcc = '';
  bizMOBServer = environment.bizMOBServer;
  items: any;
  viewText: any;
  url = '';
  displayButtonName: string;
  languageCode: string;
  categoryName: string;
  dateTime: string;
  util = new Util();
  title: string;
  collateralAccount = '';     // [view]
  accountList: any [];      // [server] new trcode for request collateral account
  noLoginLoanAgainstDeposit = false;
  constructor(
    private bizServer: BizserverService,
    private modal: ModalService,
    private router: Router,
    private zone: NgZone,
    private translate: TranslateService,
    private backService: BackService
  ) {
  }

  async ngOnInit() {
    this.languageCode = this.util.getSecureStorage( LOCAL_STORAGE.LANGUAGE_CODE );
    console.log( this.languageCode
      );
    this.translate.get('COMMON.BUTTON').subscribe((res) => {
      this.viewText = res;
    });
    const isProduct =  DataCenter.get('product', 'isProductTrue');
    if (Utils.getUserInfo()) {
      await this.requestCollateralAccount();
    }
    await this.doReq();
    this.backService.subscribe();

    this.i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);

  }

// 007005	007	Deposits
// 007006	007	Loans
// 007020	007	Card Service
// 007007	007	e-Banking Service
// 007008	007	Trade Finance
// 007009	007	Fund Transfer
// 007010	007	Cash Management Services

async doReq() {
    // console.log(this.product, 'dafmsdk');
    const reqTr = new PPCB0140Req();
    reqTr.body.productID = + this.product.id;
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
     // PPCB0140
    this.bizServer.bizMOBPost('PPCB0140', reqTr).then(data => {
      this.productId = this.product.id;
      const resTr = data as  PPCB0140Res;
      this.items = resTr.body;
      this.categoryName = resTr.body.categoryName;
      this.dateTime     = resTr.body.dateTime;
      this.resultSuccess = this.bizServer.checkResponse(resTr.header);
      if ( this.resultSuccess ) {
        this.items = resTr.body;
        if (this.items) {
          this.title = this.items.title;
        }
        // if ( this.isSavingDepositAccount( this.items.productCode ) ) {
        //   this.url = '/open/saving/intro';
        //   this.isOpenAcc = true;
        //   this.displayButtonName = this.viewText.REQUEST_TO_OPEN_ACCOUNT;
        // } else if ( this.isFixedDepositAccount( this.items.productCode ) ) {
        //   this.url = '/open/fixed/intro';
        //   this.isOpenAcc = true;
        //   this.displayButtonName = this.viewText.REQUEST_TO_OPEN_ACCOUNT;
        // } else if ( this.isInstallmentAccount( this.items.productCode ) ) {
        //   this.url = '/open/installment/intro';
        //   this.isOpenAcc = true;
        //   this.displayButtonName = this.viewText.REQUEST_TO_OPEN_ACCOUNT;
        // }
        // else if ( this.isLoanAgainstDeposit( this.items.productCode ) ) {
        //   this.url = '/open/loan/intro';
        //   this.isOpenAcc = true;
        //   this.displayButtonName = this.viewText.APPLY_LOAN;
        // }
        if ( this.isLoanAgainstDeposit( this.items.productCode ) ) {
          if (this.collateralAccount !== '') {
            this.url = '/open/loan/intro';
            this.isOpenAcc = true;
             this.displayButtonName = this.viewText.GET_LOAN_AGAINST_DEPOSIT;
          } else {
            if (Utils.getUserInfo()) {
              this.url = '/loan-apply/loan-term-condition';
              this.isOpenAcc = true;
              this.displayButtonName = this.viewText.APPLY_LOAN;
            } else {
              DataCenter.set('loan-against-deposit', 'isLoanAgainstDeposit', true);
              this.noLoginLoanAgainstDeposit = true;
              this.isOpenAcc = true;
              this.displayButtonName = this.viewText.APPLY_LOAN;
            }
          }
        } else if ( this.isApplyLoan( this.items.productCode ) ) {
          this.url = '/loan-apply/loan-term-condition';
          this.isOpenAcc = true;
          this.displayButtonName = this.viewText.APPLY_LOAN;
        } else {
          // not open account
        }
    }

    });
}

async requestCollateralAccount(accountNo?: any) {
  const reqTr = new CEB5720Req();
  reqTr.body.userID          = Utils.getUserInfo().userID;
  reqTr.body.loanProductCode = LOAN_PRODUCT_BU_CODE;
  reqTr.body.customerNo      = Utils.getUserInfo().customerNo;

  await this.bizServer.bizMOBPost('CEB5720', reqTr).then(data => {
    const resTr = data as CEB5720Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      this.accountList = resTr.body.collateralAccountInfoList;
      if (this.accountList[0]) {
        this.collateralAccount = this.accountList[0].accountNo ? this.accountList[0].accountNo : '';
        console.log("get data", this.collateralAccount);
      }
    }
  });
}

  btnClose() {
    this.modal.dismiss({role: BUTTON_ROLE.CLOSE});
  }

  btnRequestOpenAcc() {
    this.modal.dismiss({role: BUTTON_ROLE.CLOSE});
    DataCenter.set('loan-apply', 'selectedLoan', this.items);
    DataCenter.set('loan-apply', 'isSignedIn', true); // to set 'back route' when user cancel loanApply
    this.categoryAcc = this.items.categoryCode;
    // Go to Login without login Screen
    if (this.noLoginLoanAgainstDeposit) {
      this.backService.login();
      return;
    }
    this.zone.run(() => {
      // const navigationExtras: NavigationExtras = {
      //   queryParams: {
      //     productId: JSON.stringify(this.product)
      //   }
      // };
      this.router.navigate([this.url]);
    });
  }


 
  private isSavingDepositAccount( productCode ) {
    return SAVING_DEPOSIT_ACCOUNT.some( ( value ) => { return ( value == productCode ) } );
  }

  private isFixedDepositAccount( productCode ) {
    return FIXED_DEPOSIT_ACCOUNT.some( ( value ) => { return ( value == productCode ) } );
  }

  private isInstallmentAccount( productCode ) {
    return INSTALLMENT_ACCOUNT.some( ( value ) => { return ( value == productCode ) } );    
  }

  private isApplyLoan( productCode ) {
   return APPLY_LOAN.some( ( value ) => { return ( value == productCode ) } );    
  }
  
  private isLoanAgainstDeposit( productCode ) {
   return LOAN_AGAINST_DEPOSIT.some( ( value ) => { return ( value == productCode ) } );    
  }

}
