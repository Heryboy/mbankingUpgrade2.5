import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS18100000Component } from './bfs18100000.component';

describe('BFS18100000Component', () => {
  let component: BFS18100000Component;
  let fixture: ComponentFixture<BFS18100000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS18100000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS18100000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
