import { Component, OnInit } from '@angular/core';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { TitleModel } from 'src/app/shared/component/title/title.model';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { PPCB01F0Req } from 'src/app/shared/TRClass/PPCB01F0-req';
import { BackService } from 'src/app/shared/services/back.service';
import { Util } from 'src/app/shared/util';

@Component({
  selector: 'app-bfs11110000-a',
  templateUrl: './bfs11110000-a.component.html',
  styleUrls: ['./bfs11110000-a.component.scss'],
})
export class Bfs11110000AComponent implements OnInit {
  title: TitleModel;
  data;
  faqIdIndex;
  test: string;
  template: string;
  titleTemplate: string;
  categoryName: string;
  index: number;
  length: number;
  countData: number;

constructor(  private bizServer: BizserverService,
              private backService: BackService,
              private modalService: ModalService) { }

ngOnInit() {
    this.title = {
      class: 'headerTermCondition',
      closeBtn: {
        icon: {
          icon: '',
          class: 'btn_close',
        },
        class: 'closeBtnTermCondition',
        handler: () => {
          this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
        }
      }
    };
    this.index = this.faqIdIndex;
    this.countData = this.data.length - 1;
    this.requestData();
    this.backService.subscribe();
  }

  private requestData() {
    const reqTr = new PPCB01F0Req();
    const faqId =   + this.data[this.index].faqId;
    this.categoryName = this.data[this.index].categoryName;
    reqTr.body.faqId = faqId;
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
    this.bizServer.bizMOBPost('PPCB01F0', reqTr).then(data => {
      this.template = data.body.content;
      this.titleTemplate = data.body.title;
    });

  }

  btnPre() {
    if (this.index > 0) {
      --this.index;
      this.requestData();
    }
  }

  btnNext() {
    if (this.countData > this.index) {
      ++this.index;
      this.requestData();
    }
  }
  btnConfrim() {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }

  btnClose() {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }
}
