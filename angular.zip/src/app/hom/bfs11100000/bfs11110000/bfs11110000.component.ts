import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { ContentModel } from 'src/app/shared/component/pre-next/pre-next.model';
import { TermConditionModel } from 'src/app/shared/component/term-and-condition/term-and-condition.model';
import { TitleModel } from 'src/app/shared/component/title/title.model';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Bfs11110000AComponent } from '../bfs11110000-a/bfs11110000-a.component';

@Component({
  selector: 'app-bfs11110000',
  templateUrl: './bfs11110000.component.html',
  styleUrls: ['./bfs11110000.component.scss'],
})
export class Bfs11110000Component implements OnInit {

  termConditionModel: TermConditionModel;
  content: ContentModel[];
  header: TitleModel;
  data;
  constructor(
    private modalCtr: ModalController,
    private translate: TranslateService,
    private bizServer: BizserverService,
    private modalService: ModalService) {
  }

  ngOnInit() {
    console.log('test data', this.data);
    this.setTermCondition();
  }

 private setTitle() {
    this.header = {
      text: 'Term and Condition',
      class: 'string',
      closeBtn: {
         icon: {
           icon: 'md-close'
         },
        class: 'Close',
        handler: () => {
          this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
        }
      },
      backBtn: {
        icon: {
          icon: 'Close'
        },
        class: 'Back',
        handler: () => {
        }
      }
    };
  }

 private setTermCondition() {
    this.setTitle();
    this.setContentModel();

    this.termConditionModel = {
      header: this.header,
      content: this.content,
      callback: () => { console.log('confirm'); }
    };
  }

 private setContentModel() {
    this.content = [];
    this.content.push({
      component: Bfs11110000AComponent,
      componentProps: { data: this.data, jhbguhuh: 0 }
    });
  }

  test() {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }
}
