import { Component, OnInit } from '@angular/core';
import { TermConditionModel, EventModel } from 'src/app/shared/component/term-and-condition/term-and-condition.model';
import { TitleModel } from 'src/app/shared/component/title/title.model';
import { Bfs11110000AComponent } from '../bfs11110000-a/bfs11110000-a.component';
import { BFS1A000000Component } from '../../bfs1-a000000/bfs1-a000000.component';

@Component({
  selector: 'app-bfs11200000',
  templateUrl: './bfs11200000.component.html',
  styleUrls: ['./bfs11200000.component.scss'],
})
export class BFS11200000Component implements OnInit {
  text: string;

  termcondition: TermConditionModel;
  title: TitleModel;
  event: EventModel;
  constructor() { }

  ngOnInit() {
    this.title = {
      text: 'FAQ',
      class: 'string',
      backBtn: {
        icon: {
          icon: 'Close'
        },
        class: 'Back',
        defaultHref: '/home/before-sign',
        handler: () => {
          // console.log('backAction');
        }
      }
    };
  }

}
