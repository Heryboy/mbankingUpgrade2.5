import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { SelectFullOptionModel } from 'src/app/shared/component/select-full-option/select-full-option.model';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { COUNTRY_CODE_APPLY_LOAN, LANGUAGE, LOAN_PURPOSE_CODE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { RetrieveCountryCodeListService } from 'src/app/shared/services/retrieve-country-code-list.service';
import { RetrieveProvinceCodeListService } from 'src/app/shared/services/retrieve-province-code-list.service';
import { CEB0311CodeListRes } from 'src/app/shared/TRClass/CEB0311-res';
import { UserInfo } from 'src/app/shared/TRClass/CEB5621-req';
import { Product } from 'src/app/shared/TRClass/PPCB0130-res';
import { Util } from 'src/app/shared/util';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { LoanApplyService } from '../bfs19100000/loan-apply.service';
import { OccupationalInfo } from '../bfs19300000/bfs19300000.model';
import { PersonalInfo } from './bfs19200000.model';
import { Utils } from 'src/app/shared/utils/utils.static';
import { Keyboard } from '@ionic-native/keyboard/ngx';

@Component({
  selector: 'app-bfs19200000',
  templateUrl: './bfs19200000.component.html',
  styleUrls: ['./bfs19200000.component.scss'],
})
export class BFS19200000Component implements OnInit {

  @ViewChild('firstNameID', {static: false}) firstNameID: any;
  @ViewChild('stateOrProvinceID', {static: false}) stateOrProvinceID: any;
  @ViewChild('residenceAddressID', {static: false}) residenceAddressID: any;
  @ViewChild('personalAddressCityID', {static: false}) personalAddressCityID: any;
  @ViewChild('companyAddressID', {static: false}) companyAddressID: any;
   personalInfo: PersonalInfo = {
    familyName: '',
    firstName: '',
    nationalID: 0,
    phoneNo: '',
    gender: '',
    maritalStatusCode: '',
    birthCountryCode: 0,
    birthProvince: ''
  };
   occupationInfo: OccupationalInfo = {
    personalAddressCityCode: '',
    personalAddress: '',
    occupationTypeCode: '',
    companyName: '',
    companyCityCode: '',
    companyAddress: '',
    lengthOfService: 0,
    monthlyIncome: 0,
    requestedAmount: 0,
  };
   gender = 'M';
   birthCountry: string;
   maritalStatus: string;
   nationalID: number;
   selectedLoan: Product;
   countryList: SelectFullOptionModel;
   maritalStatusList: SelectBoxOptionModel;
   provinceList: SelectFullOptionModel;
   userInfo: UserInfo;
   util = new Util();
   provinceCodeList: Array<CEB0311CodeListRes>;

   isPersonalInfoInputDone = false;

   isLoanInfoInputDone = false;
   isOccupationInputDone = false;
   isResidenceInfoInputDone = false;
   isLoanRequestInfoDone = false;
   companyLocationList: SelectFullOptionModel;
   residanceList: SelectFullOptionModel;
   loanPurposeList: SelectBoxOptionModel;
   RecommendLoan = [];
   personalAddressCity: string;

   rdbOccupationType = '01';
   companyAddressCity: string;

   isBtnConfirmPersonalEnabled = false;
   isBtnConfirmBirthEnabled = false;
   isBtnConfirmContactEnabled = false;
   isBtnConfirmAllInfoEnabled = false;

   isBtnConfirmResidenceEnabled = false;
   isBtnConfirmOccupationEnabled = false;

   transactionCurrencyCode = 'USD';

   selectedBranchName: string;
   isFocus: boolean;
   indexFocus: number;
   isKeyboardUp = false;

  // These country shouldn't select or search
  private countryCodeUnderBlackList = [
    COUNTRY_CODE_APPLY_LOAN.AFGHANISTAN,
    // COUNTRY_CODE_APPLY_LOAN.CONGO_KINSHASA, // MISSING
    COUNTRY_CODE_APPLY_LOAN.UKRAINE,
    COUNTRY_CODE_APPLY_LOAN.CUBA,
    COUNTRY_CODE_APPLY_LOAN.ISLAMIC_REPUBLIC_OF_IRAN,
    COUNTRY_CODE_APPLY_LOAN.IRAQ,
    COUNTRY_CODE_APPLY_LOAN.LEBANON,
    COUNTRY_CODE_APPLY_LOAN.LIBYA,
    COUNTRY_CODE_APPLY_LOAN.KOREA_NORTH,
    COUNTRY_CODE_APPLY_LOAN.SOMALIA,
    // COUNTRY_CODE_APPLY_LOAN.SOUTH_SUDAN, // MISSING
    COUNTRY_CODE_APPLY_LOAN.SUDAN,
    COUNTRY_CODE_APPLY_LOAN.SYRIAN_ARAB_REPUBLIC // MISSING
  ];

  constructor(
    private router: Router,
    private province: RetrieveProvinceCodeListService,
    private country: RetrieveCountryCodeListService,
    private translate: TranslateService,
    private loanApply: LoanApplyService,
    private formatterService: FormatterService,
    private backService: BackService,
    private keyboard: Keyboard
  ) {
    this.occupationInfo.lengthOfService = undefined;
    this.occupationInfo.monthlyIncome = undefined;
    this.occupationInfo.requestedAmount = undefined;
    this.defaultRecommendLoan();
    this.personalInfo.nationalID = undefined;
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    this.getSelectedBranch();
  }

  async ngOnInit() {
    this.getSelectMaritalStatus();
    await this.getSelectAvailableCountry();
    await this.getSelectProvince();
    await this.getSelectCompanyLocationList();
    await this.getSelectResidanceList();
    this.getSelectLoanPurposeList();
    this.setFocus();
  }

  ionViewWillEnter() {
    this.backService.subscribe('loan_apply');
  }

  setFocus(): void {
    setTimeout(() => {
      this.firstNameID.setFocus();
    }, 500);
  }
  // Static data because server haven't defined trCode yet.
  defaultRecommendLoan(): void {
    this.translate.get('BFS19000000.TS.LOAN_LIST').subscribe(tran => {
      this.RecommendLoan = [
        {
          name: 'Business',
          loanPurposeCode: LOAN_PURPOSE_CODE.BUSINESS
        },
        {
          name: 'Purchase Cars',
          loanPurposeCode: LOAN_PURPOSE_CODE.PURCHASE_CARS
        },
        {
          name: 'Purchase House',
          loanPurposeCode: LOAN_PURPOSE_CODE.PURCHASE_HOUSE
        },
        {
          name: 'Renovate House',
          loanPurposeCode: LOAN_PURPOSE_CODE.RENOVATE_HOUSE
        },
        {
          name: 'Other',
          loanPurposeCode: LOAN_PURPOSE_CODE.OTHER
        }
      ];
    });
  }

  getSelectedBranch(): void {
    const appLanguage = this.util.getSecureStorage(LOCAL_STORAGE.I18N);
    const selectedBranch = DataCenter.get('loan-apply', 'selectedBranch', false);
    if (selectedBranch) {
      if (appLanguage === LANGUAGE.I18N_KM) {
        this.selectedBranchName = selectedBranch.branchNameKh;
      } else {
        this.selectedBranchName = selectedBranch.branchNameEn;
      }
    }
  }

  getSelectMaritalStatus(): void {
    this.maritalStatusList = {
      title: this.translate.instant('BFS19200000.LABEL.PLEASE_SELECT_MARITAL_STATUS'),
      selectedTabValue: '',
      items: [{
        title: '',
        seletedOpt: '',
        itemValueField: 'value',
        itemTextField: 'text',
        option: [
          {
            value : '1',
            text: this.translate.instant('BFS19200000.TS.MARITAL_STATUS.SINGLE')
          },
          {
            value : '2',
            text: this.translate.instant('BFS19200000.TS.MARITAL_STATUS.MARRIED')
          },
        ]
      }]
    };
  }

  async getSelectProvince() {
    await this.province.getRequestCodeList().then(codeList => {
      this.provinceCodeList = codeList;
    });
    this.provinceCodeList = this.moveItemInListToTop(this.provinceCodeList, 'province');
    this.provinceList = {
      title: this.translate.instant('BFS19200000.LABEL.SELECT_BIRTH_PROVINCE_OR_CITY'),
      itemTextField: 'value',
      itemValueField: 'code',
      option: this.provinceCodeList
    };
  }

  moveItemInListToTop(list: any[], countryOrProvince: string) {
    let code: string;
    if (countryOrProvince === 'country') {
      code = '105'; // Cambodia country code
    } else if (countryOrProvince === 'province') {
      code = '012'; // PhnomPenh province code
    }
    if (code) {
      for (let i = 0; i < list.length; i++) {
        if (list[i].code === code as string) {
          const itemFound = list[i];
          list.splice(i, 1);
          const temp = [itemFound, ...list];
          list = temp;
          break;
        }
      }
    }
    return list;
  }

  async getSelectAvailableCountry() {
    let countryCodeList;
    await this.country.getRequestCodeList().then(codeList => {
      countryCodeList = codeList;
      for (const i of this.countryCodeUnderBlackList) {
        for (let j = 0; j < countryCodeList.length; j++) {
          if (countryCodeList[j].code === i) {
            countryCodeList.splice(j, 1);
          }
        }
      }
    });
    countryCodeList = this.moveItemInListToTop(countryCodeList, 'country');
    this.countryList = {
      title: this.translate.instant('BFS19200000.LABEL.SELECT_COUNTRY'),
      itemTextField: 'value',
      itemValueField: 'code',
      option: countryCodeList
    };
  }

  async getSelectCompanyLocationList() {
    await this.province.getRequestCodeList().then(codeList => {
      codeList = this.moveItemInListToTop(codeList, 'province');
      this.companyLocationList = {
        title: this.translate.instant('BFS19200000.LABEL.PLEASE_SELECT_PROVINCE'),
        itemTextField: 'value',
        itemValueField: 'code',
        option: codeList
      };

    });
  }

  async getSelectResidanceList() {
    await this.province.getRequestCodeList().then(codeList => {
      codeList = this.moveItemInListToTop(codeList, 'province');
      this.residanceList = {
        title: this.translate.instant('BFS19200000.LABEL.PLEASE_SELECT_PROVINCE'),
        itemTextField: 'value',
        itemValueField: 'code',
        option: codeList
      };
    });
  }

  getSelectLoanPurposeList(): void {
    const loanOption = [];
    for ( const i of this.RecommendLoan) {
      loanOption.push({value: i.loanPurposeCode, text: i.name});
    }
    this.loanPurposeList = {
      title: this.translate.instant('BFS19200000.TS.SELECT'),
      selectedTabValue: '',
      items: [{
        title: '',
        seletedOpt: '',
        itemValueField: 'value',
        itemTextField: 'text',
        option: loanOption
      }]
    };
  }

  async onSelectBranch() {
    await this.loanApply.onSelectBranch();
    this.getSelectedBranch();
  }

  isInputFocusSkip() {
    if (this.indexFocus === 0 && this.personalInfo.firstName !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 1 && this.personalInfo.familyName !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 2 && this.nationalID) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 3 && this.formatterService.isValid(this.personalInfo.phoneNo, 'PHONE_NUM')) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 4 && this.birthCountry) {
      if (this.personalInfo.birthCountryCode !== 0 && this.personalInfo.birthCountryCode !== 105) {
        this.indexFocus += 2;
      } else {
        this.indexFocus++;
      }
      return true;
    } else if (this.indexFocus === 5 && this.personalInfo.birthProvince !== '') {
      this.indexFocus += 2;
      return true;
    } else if (this.indexFocus === 6 && this.personalInfo.birthProvince !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 7 && this.personalInfo.maritalStatusCode !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 9 && this.occupationInfo.personalAddressCityCode !== '' && this.personalAddressCity) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 10 && this.occupationInfo.personalAddress !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 12 && this.occupationInfo.companyName !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 13 && this.companyAddressCity) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 14 && this.occupationInfo.companyAddress !== '') {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 15 && this.occupationInfo.lengthOfService && this.occupationInfo.lengthOfService !== 0) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 16 && this.occupationInfo.monthlyIncome && this.occupationInfo.monthlyIncome !== 0) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 18 && this.selectedLoan) {
      this.indexFocus++;
      return true;
    } else if (this.indexFocus === 19 && this.occupationInfo.requestedAmount && this.occupationInfo.requestedAmount !== 0) {
      this.indexFocus++;
      return true;
    } else {
      return false;
    }
  }

  async onBtnNextClickAndFocusHandler() {
    if (this.indexFocus === 3) {
      if (this.gender !== 'M') {
        this.indexFocus++;
      }
    } else {
      this.indexFocus++;
      while (this.isInputFocusSkip()) {
        this.isInputFocusSkip();
      }
    }

    if (this.indexFocus === 8) { // last focusIndex of personal information form detected, go to focus blank input of this form.
      this.indexFocus = 0;
      while (this.isInputFocusSkip()) {
        this.isInputFocusSkip();
      }
    } else if (this.indexFocus > 8 && this.indexFocus < 11) {
      if (this.indexFocus === 9) {
        setTimeout(() => {
          this.isKeyboardUp = true;
          this.personalAddressCityID.setFocus();
        }, 200);
      } else if (this.indexFocus === 10) {
        if (!this.personalAddressCity) {
          setTimeout(() => {
            this.residenceAddressID.setFocus();
          }, 200);
        } else {
          this.indexFocus = 9;
        }
      }
    } else if (this.indexFocus === 11) { // last focusIndex of residence information form detected, go to focus blank input of this form.
      this.indexFocus = 9;
    } else if (this.indexFocus === 17) { // last focusIndex of occupation information form detected, go to focus blank input of this form.
      this.indexFocus = 12;
      while (this.isInputFocusSkip()) {
        this.isInputFocusSkip();
      }
    } else if (this.indexFocus === 20) { // last focusIndex of loan information form detected, go to focus blank input of this form.
      this.indexFocus = 18;
      while (this.isInputFocusSkip()) {
        this.isInputFocusSkip();
      }
    }
    this.onCheckValidation();
  }

  onBtnConfirmPersonalInputInfo(): void {
    this.indexFocus = 9;
    this.isPersonalInfoInputDone = true;
    this.personalInfo.gender = this.gender;
    this.onCheckValidation();
  }

  onBtnConfirmResidenceInfo(): void {
    this.indexFocus = 11;
    this.isResidenceInfoInputDone = true;
    this.onCheckValidation();
  }

  onBtnConfirmOccupationInfo(): void {
    this.indexFocus = 18;
    this.isOccupationInputDone = true;
    this.onCheckValidation();
  }

  onChangePhone(event): void {
    if ( event.target ) {
      const value = this.formatterService.toPhoneNumber(event.target.value);
      event.target.value = value.text;
      this.personalInfo.phoneNo = value.value;
    }
    this.onCheckValidation();
  }

  onCheckValidation(): void {
    // Personal Information
    if (this.personalInfo.firstName === '' ||
        this.personalInfo.familyName === '' ||
        !this.nationalID ||
        !this.formatterService.isValid(this.personalInfo.phoneNo, 'PHONE_NUM') ||
        !this.gender ||
        !this.birthCountry ||
        this.personalInfo.birthProvince === '' ||
        this.personalInfo.maritalStatusCode === '' ||
        !this.maritalStatus) {
      this.isBtnConfirmPersonalEnabled = false;
    } else {
      this.isBtnConfirmPersonalEnabled = true;
    }
    // Residence Information
    if (!this.personalAddressCity ||
        this.occupationInfo.personalAddress === '') {
      this.isBtnConfirmResidenceEnabled = false;
    } else {
      this.isBtnConfirmResidenceEnabled = true;
    }
    // Occupation Information
    if (this.occupationInfo.companyAddress === '' ||
        this.occupationInfo.companyName === '' ||
        this.occupationInfo.companyCityCode === '' ||
        !this.occupationInfo.lengthOfService ||
        !this.occupationInfo.monthlyIncome) {
        this.isBtnConfirmOccupationEnabled = false;
    } else {
        this.isBtnConfirmOccupationEnabled = true;
    }
    // Loan Information
    if (!this.occupationInfo.requestedAmount ||
      !this.selectedLoan ||
      !this.transactionCurrencyCode) {
      this.isBtnConfirmAllInfoEnabled = false;
    } else {
      this.isBtnConfirmAllInfoEnabled = true;
    }
  }

  onMaritalStatusChange(ev): void {
    if (ev.value === '2') {
      this.personalInfo.maritalStatusCode = '02';
    } else {
      this.personalInfo.maritalStatusCode = '01';
    }
    this.maritalStatus = ev.text;
    this.onCheckValidation();
  }

  onCountryChange(ev): void {
    this.indexFocus = 4;
    this.birthCountry = ev.value;
    this.personalInfo.birthCountryCode = Number(ev.code);
    this.onCheckValidation();
    if (this.personalInfo.birthCountryCode !== 0 && this.personalInfo.birthCountryCode !== 105) {
      this.indexFocus = 6;
      setTimeout(() => {
        this.stateOrProvinceID.setFocus();
      }, 300);
    } else {
      this.indexFocus = 5;
    }
  }

  onProvinceChange(ev): void {
    this.personalInfo.birthProvince = ev.value;
    if (this.indexFocus === 5) {
      this.indexFocus = 7;
    }
    this.onCheckValidation();
  }

  onBtnCancelClick(): void {
    this.loanApply.onCancel();
  }

  onCompanyLocationChange(ev): void {
    this.companyAddressCity = ev.value;
    this.occupationInfo.companyCityCode = ev.code;
    setTimeout(() => {
      this.companyAddressID.setFocus();
    }, 200);
    this.onCheckValidation();
  }

  onResidanceChange(ev): void {
    this.indexFocus = 9;
    this.personalAddressCity = ev.value;
    this.occupationInfo.personalAddressCityCode = ev.code;
    if (this.occupationInfo.personalAddressCityCode !== '') {
      this.indexFocus = 10;
      setTimeout(() => {
        this.residenceAddressID.setFocus();
      }, 300);
    }
    this.onCheckValidation();
  }

  onLoanPurposeChange(ev): void {
    for (const i of this.RecommendLoan) {
      if (i.loanPurposeCode === ev.value) {
        this.selectedLoan = i;
        break;
      }
    }
    this.onCheckValidation();
  }

  onGenderChange(): void {
    this.indexFocus = 4;
    while (this.isInputFocusSkip()) {
      this.isInputFocusSkip();
    }
    this.onCheckValidation();
  }
  onOccupationTypeClicked(): void {
    this.indexFocus = 12;
    while (this.isInputFocusSkip()) {
      this.isInputFocusSkip();
    }
    this.onCheckValidation();
  }
  onTransactionCurrencyCodeClicked(): void {
    this.indexFocus = 19;
    while (this.isInputFocusSkip()) {
      this.isInputFocusSkip();
    }
    this.onCheckValidation();
  }

  onBtnPrevious(): void {
    if (this.isPersonalInfoInputDone && !this.isResidenceInfoInputDone) {
      this.isPersonalInfoInputDone = false;
      this.isResidenceInfoInputDone = false;
      this.isOccupationInputDone = false;
    } else if (this.isPersonalInfoInputDone && this.isResidenceInfoInputDone && !this.isOccupationInputDone) {
      this.isResidenceInfoInputDone = false;
      this.isOccupationInputDone = false;
    } else if (this.isPersonalInfoInputDone && this.isOccupationInputDone && !this.isLoanRequestInfoDone) {
      this.isOccupationInputDone = false;
    }
    this.onCheckValidation();
  }

  onInputInfoEdit(section: string): void {
    switch (section) {
      case 'personalInfo': this.isPersonalInfoInputDone = false; break;
      case 'residenceInfo': this.isResidenceInfoInputDone = false; break;
      case 'occupationInfo': this.isOccupationInputDone = false; break;
      default: break;
    }
  }

  onBtnConfirmAllInfo(): void {
    this.occupationInfo.occupationTypeCode = this.rdbOccupationType;
    DataCenter.set('loan-apply', 'personalInfo', this.personalInfo);
    DataCenter.set('loan-apply', 'occupationInfo', this.occupationInfo);
    DataCenter.set('loan-apply', 'selectedLoan', this.selectedLoan);
    DataCenter.set('loan-apply', 'transactionCurrencyCode', this.transactionCurrencyCode);
    this.router.navigateByUrl('/loan-apply/confirm');
  }

  // removeInvalidChars(e) {
  //   // Utils.restrictEmoji(e);
  //   this.onCheckValidation();
  // }

}
