export interface PersonalInfo {
    familyName: string;
    firstName: string;
    nationalID: number;
    phoneNo: string;
    gender: string;
    maritalStatusCode: string;
    birthCountryCode: number;
    birthProvince: string;
}
