import { Component, OnInit, Input } from '@angular/core'; 

export class Facility {
  name?: string;
  code?: string;
  checked?: boolean;
}
@Component({
  selector: 'app-bfs12400000',
  templateUrl: './bfs12400000.component.html',
  styleUrls: ['./bfs12400000.component.scss'],
})
export class BFS12400000Component implements OnInit {

  @Input() modal;
  filterValue: string;
  branchList: any[];
  branchFacility: Facility[];
  checkedFacility: any[];
  checkedLength: any;
  isValid: boolean;  
  isIndeterminate: boolean;
  masterCheck:boolean;

  constructor() { }

  ngOnInit() {  
    this.branchList = this.modal.message.branchList;
    this.filterValue = this.modal.message.filterValue;
    this.checkedFacility = this.modal.message.facility;
    if (this.checkedFacility && this.checkedFacility.length > 0) {    
      this.branchFacility = this.checkedFacility;
    } else { 
      this.branchFacility = this.branchFacility.map((facility: any) => {
        return { name: facility.name, code: facility.code, checked: true };
      });
    }
  }

  onCheck() {
    this.checkedFacility = this.branchFacility;
  }

  filterValueChange() {
    this.branchFacility = this.branchFacility.map((facility: any) => {
      return { name: facility.name, code: facility.code, checked: false };
    });
    this.masterCheck = false;
    this.checkedFacility = this.branchFacility;
  }

  checkMaster() {
    setTimeout(()=>{
      this.branchFacility.forEach(obj => {
        obj.checked = this.masterCheck;
      });
    });
  }
 
  onTermsChecked() {    
    const totalItems = this.branchFacility.length;
    let checked = 0;
    this.branchFacility.map(obj => {
      if (obj.checked) checked++;
    });
    if (checked > 0 && checked < totalItems) { 
      //If even one item is checked but not all
      // this.isIndeterminate = true;
      this.masterCheck = false;
    } else if ( checked == totalItems ) { 
      //If all are checked
      this.masterCheck = true;
      this.isIndeterminate = false;
    } else { 
      //If none is checked
      this.isIndeterminate = false;
      this.masterCheck = false;
    }  
  }

  onApply() {
    this.onClose();
    this.modal.callback({
      checkedFacility: this.checkedFacility, 
      filterValue: this.filterValue
    }); 
  }

  onClose() {
    this.modal.close();
  }
 
}
