import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs19420000',
  templateUrl: './bfs19420000.component.html',
  styleUrls: ['./bfs19420000.component.scss'],
})
export class BFS19420000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
