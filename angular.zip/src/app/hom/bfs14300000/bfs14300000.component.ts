import { Component, OnInit, Input, Renderer2 } from '@angular/core';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { TranslateService } from '@ngx-translate/core';
import { Util } from 'src/app/shared/util';
declare let document: any;

export type SortByType = 'name' | 'distance' | 'discount' | 'merchant' | 'mobile';

@Component({
  selector: 'app-bfs14300000',
  templateUrl: './bfs14300000.component.html',
  styleUrls: ['./bfs14300000.component.scss'],
})
export class BFS14300000Component implements OnInit {
  @Input() modal;
  filterValue: string;
  default = '0';
  filterSelected: SelectBoxOptionModel;
  merchantCategory: any[];
  merchantList: any[];
  distanceRange: any;
  sortingByValue: SortByType;
  util = new Util();
  sortList = [];
  discountType = [];
  discountTypeValue;
  maximumRange = 500;
  constructor(
    private translate: TranslateService,
    private renderer: Renderer2
  ) { }

  ngOnInit() {
    this.default = this.modal.message.defaultFilterSelected;
    this.merchantCategory = this.modal.message.merchantCategory;
    this.merchantList = DataCenter.get('BFS14100000', 'merchantList', false);
    if (this.merchantList) {
      this.maximumRange = this.setMaximumRange();
    }
    this.translate.get('BFS14100000.LABEL').subscribe((res) => {
      this.discountType = [
        { name: res.MERCHANT, value: 'merchant', checked: false },
        { name: res.MOBILE_PAYMENT, value: 'mobile', checked: false },
      ];
      const sortingDiscountTypeByValue = this.modal.message.discountType;
      this.onDiscountTypeChange(sortingDiscountTypeByValue, true);
    });
    this.translate.get('BFS14300000.LABEL').subscribe((res) => {
      this.sortList = [
        { name: res.BY_NAME, value: 'name', checked: false },
        { name: res.BY_DISTANCE, value: 'distance', checked: false },
        { name: res.BY_DISCOUNT, value: 'discount', checked: false }
      ];

      const option = [
        {
          text: res.ALL,
          value: '0'
        }
      ];

      if (this.merchantCategory) {
        for (const category of this.merchantCategory) {
          option.push({
            text: category.categoryName,
            value: category.categoryCode
          });
        }
      }

      this.filterSelected = {
        title: res.CATEGORY,
        selectedTab: 1,
        selectedTabValue: res.ALL,
        items: [
          {
            title: res.CATEGORY,
            itemValueField: 'value',
            itemTextField: 'text',
            seletedOpt: this.default,
            option
          },
        ]
      };
      this.sortingByValue = this.modal.message.sortDefault;
      this.onSortChange(this.sortingByValue, true);
      // const sortingDiscountTypeByValue = this.modal.message.discountType;
      // this.onDiscountTypeChange(sortingDiscountTypeByValue, true);
      this.distanceRange = this.modal.message.distanceRange;
    });
  }

  onClick() {
    const kendo = document.querySelector('.pop_select_option');
    this.renderer.removeClass(kendo, 'pop_select_option');
  }
  onSortChange(value: SortByType, initValue?: boolean) {
    const newList = [];
    let lastIndex = this.sortList.length;
    this.sortList.forEach( item => {
      if (item.value === value && item.checked) {
        newList.push(item);
        this.sortingByValue = item.value;
      } else {
        if (item.value === value && initValue) {
          item.checked = true;
        } else {
          item.checked = false;
        }
        newList.push(item);
        lastIndex--;
        // if (lastIndex === 0) {
        //   this.sortingByValue = undefined;
        // }
      }
    });

    this.sortList = newList;
  }

  onDiscountTypeChange(value: SortByType, initValue?: boolean) {
    const newList = [];
    let lastIndex = this.discountType.length;
    this.discountType.forEach( item => {
      if (item.value === value && item.checked) {
        newList.push(item);
        this.discountTypeValue = item.value;
      } else {
        if (item.value === value && initValue) {
          item.checked = true;
        } else {
          item.checked = false;
        }
        newList.push(item);
        lastIndex--;
      }
    });

    this.discountType = newList;
  }

  onApply() {
    if (this.merchantList) {
      if (this.distanceRange) {
        this.merchantList = this.merchantList.filter((merchant) => (this.distanceRange.lower <= merchant.distance / 1000)
                                                                && (this.distanceRange.upper >= merchant.distance / 1000));
      }
      let merchantList = [];
      if (this.merchantList.length > 0) {
        switch (this.sortingByValue) {
          case 'name':
            merchantList = this.util.sortByTextField(this.merchantList, 'name');
            break;
          case 'distance':
            merchantList = this.util.sortByNumberField(this.merchantList, 'distance');
            break;
          // case 'popularity':
          //   break;
          case 'discount':
            merchantList = this.util.sortByNumberField(this.merchantList, 'discountRateEnd', 'DESC');
            break;
          default:
            merchantList = this.merchantList;
            break;
        }
      } else {
        merchantList = this.merchantList;
      }
      if (this.default !== '0' && this.merchantList.length > 0) {
        merchantList = this.merchantList.filter((merchant) => this.default === merchant.categoryCode);
        this.modal.callback({
          merchantList,
          sortingByValue: this.sortingByValue,
          defaultFilterSelected: this.default,
          distanceRange: this.distanceRange,
          discountType: this.discountTypeValue
        });
      } else {
        this.modal.callback({
          merchantList,
          sortingByValue: this.sortingByValue,
          defaultFilterSelected: this.default,
          distanceRange: this.distanceRange,
          discountType: this.discountTypeValue
        });
      }
    }
    this.onClose();
  }

  setMaximumRange(): number {
    return Number((this.util.sortByNumberField(this.merchantList, 'distance', 'DESC')[0].distance / 1000).toFixed()) + 1;
  }

  onClose() {
    this.modal.close();
  }
}
