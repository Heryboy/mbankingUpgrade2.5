import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS13100000Component } from './bfs13100000.component';

describe('BFS13100000Component', () => {
  let component: BFS13100000Component;
  let fixture: ComponentFixture<BFS13100000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS13100000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS13100000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
