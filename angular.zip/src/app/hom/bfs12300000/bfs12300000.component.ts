import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE, FACILITY_CODE, LANGUAGE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { PPCB0170Req } from 'src/app/shared/TRClass/PPCB0170-req';
import { PPCB0170Res, PPCB0170BranchDetailsRes } from 'src/app/shared/TRClass/PPCB0170-res';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { MapsService } from 'src/app/shared/services/maps.service';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Util } from 'src/app/shared/util';
import { TranslateService } from '@ngx-translate/core';
import { DestinationObject } from 'src/app/shared/component/maps/maps.model';

@Component({
  selector: 'app-bfs12300000',
  templateUrl: './bfs12300000.component.html',
  styleUrls: ['./bfs12300000.component.scss'],
})
export class BFS12300000Component implements OnInit {

  data: any;
  detail: PPCB0170BranchDetailsRes;
  facilityCode = FACILITY_CODE;
  appLanguageModel = {
    en: LANGUAGE.I18N_EN,
    ja: LANGUAGE.I18N_JA,
    km: LANGUAGE.I18N_KM,
    ko: LANGUAGE.I18N_KO,
    zh: LANGUAGE.I18N_ZH
  };
  appLanguage: string;
  constructor(
    private modalService: ModalService,
    private bizServer: BizserverService,
    private mapService: MapsService,
    private callNumber: CallNumber,
    private socialShare: SocialSharing,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.appLanguage = (new Util()).getSecureStorage(LOCAL_STORAGE.I18N);
    this.reqDetail();
  }

  reqDetail() {
    const reqTr = new PPCB0170Req();

    reqTr.body.branchCategory = this.data.branchCategory;
    reqTr.body.branchCode = this.data.branchCode;
    reqTr.body.userLatitude = this.data.userLongitude;
    reqTr.body.userLongitude = this.data.userLongitude;
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
    
    this.bizServer.bizMOBPost('PPCB0170', reqTr).then( data => {
      const resTr = data as PPCB0170Res;
      const resultSuccess = this.bizServer.checkResponse(resTr.header);
      if (resultSuccess) {
       this.detail = resTr.body;
      }
    });
  }

  onCall(tel: string) {
    const num = tel;
    if (num && num.trim().length > 0) {
      this.callNumber.callNumber(num, false);
    }
  }

  onShare(data) {
    this.translate.get('BFS12300000.LABEL').subscribe(translate => {
      if (translate) {
        const shareData = `${translate.BRANCH_NAME} : ${this.appLanguage === this.appLanguageModel.en ? data.branchNameEn :
          this.appLanguage === this.appLanguageModel.ja ? data.branchNameJp :
          this.appLanguage === this.appLanguageModel.ko ? data.branchNameKr :
          this.appLanguage === this.appLanguageModel.km ? data.branchNameKh :
          this.appLanguage === this.appLanguageModel.zh ? data.branchNameCn :
          data.branchNameEn}
          ${translate.BRANCH_ADDRESS} : ${this.appLanguage === this.appLanguageModel.en ? data.branchAddressEn :
          this.appLanguage === this.appLanguageModel.ja ? data.branchAddressJp :
          this.appLanguage === this.appLanguageModel.ko ? data.branchAddressKr :
          this.appLanguage === this.appLanguageModel.km ? data.branchAddressKh :
          this.appLanguage === this.appLanguageModel.zh ? data.branchAddressCn :
          data.branchNameEn}`;
        this.socialShare.share(shareData);
      }
    });
  }

  onDirections() {
    const destination: DestinationObject = { lat: this.data.latitude, lng: this.data.longitude, code: this.data.branchCode };
    this.mapService.calculateAndDisplayRoute(destination);
    this.dismiss('onDirections');
  }

  dismiss(data?: any) {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE, data });
  }

}
