import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS1A330000Component } from './bfs1-a330000.component';

describe('BFS1A330000Component', () => {
  let component: BFS1A330000Component;
  let fixture: ComponentFixture<BFS1A330000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS1A330000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS1A330000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
