import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs1-a421000',
  templateUrl: './bfs1-a421000.component.html',
  styleUrls: ['./bfs1-a421000.component.scss'],
})
export class BFS1A421000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
