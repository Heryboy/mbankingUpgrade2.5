import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs1-a322000',
  templateUrl: './bfs1-a322000.component.html',
  styleUrls: ['./bfs1-a322000.component.scss'],
})
export class BFS1A322000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
