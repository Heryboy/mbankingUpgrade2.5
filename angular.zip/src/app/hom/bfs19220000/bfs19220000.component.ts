import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs19220000',
  templateUrl: './bfs19220000.component.html',
  styleUrls: ['./bfs19220000.component.scss'],
})
export class BFS19220000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
