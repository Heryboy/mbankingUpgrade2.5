import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS19220000Component } from './bfs19220000.component';

describe('BFS19220000Component', () => {
  let component: BFS19220000Component;
  let fixture: ComponentFixture<BFS19220000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS19220000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS19220000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
