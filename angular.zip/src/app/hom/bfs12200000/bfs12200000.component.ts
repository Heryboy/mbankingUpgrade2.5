import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/shared/services/data.service';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';

@Component({
  selector: 'app-bfs12200000',
  templateUrl: './bfs12200000.component.html',
  styleUrls: ['./bfs12200000.component.scss'],
})
export class BFS12200000Component implements OnInit {
  branchList: any[];
  default = '';
  sortSelected: SelectBoxOptionModel;
  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.getSelectTabData();
    this.dataService.listData.subscribe(branchList => this.branchList = branchList);
  }


  getSelectTabData() {
    this.sortSelected = {
      title: 'Sort',
      selectedTab: 1,
      selectedTabValue: 'By Distance',
      items: [
        {
          title: 'Sort',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: '0',
          option: [
            {
              text: 'By Distance',
              value: '0'
            },
            {
              text: 'By Name',
              value: '1'
            }
          ]
        },
      ]
    };
  }

  onClickSortBy() {
    switch (this.default) {
      case '0':
        this.sortBy('0');
        break;
      case '1':
        this.sortBy('1');
        break;
    }
  }

  sortBy(type: string) {
    switch (type) {
      case '0':
        this.branchList = this.branchList.sort((a: any, b: any) => a.distance - b.distance);
        break;
      case '1':
        this.branchList.sort((a: any, b: any) => (a.branchNameEn > b.branchNameEn) ? 1 : ((b.branchNameEn > a.branchNameEn) ? -1 : 0));
    }
  }
}
