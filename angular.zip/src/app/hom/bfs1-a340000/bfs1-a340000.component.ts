import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs1-a340000',
  templateUrl: './bfs1-a340000.component.html',
  styleUrls: ['./bfs1-a340000.component.scss'],
})
export class BFS1A340000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
