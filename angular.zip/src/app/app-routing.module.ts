import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '',
    children: [
      { path: 'home', loadChildren: './hom/hom.module#HomPageModule'},
    ]
  },
  { path: '',
    children: [
      {
        path: '', loadChildren: './inf/inf.module#InfPageModule'
      },
    ]
  },
  { path: '',
    children: [
      {
        path: '', loadChildren: './acc/acc.module#AccPageModule'
      },
    ]
  },
  { path: '',
    children: [
      {
        path: '', loadChildren: './opn/opn.module#OpnPageModule'
      },
    ]
  },
  { path: '',
    children: [
      {
         path: '', loadChildren: './trf/trf.module#TrfPageModule'
      },
    ]
  },
  { path: '',
    children: [
      {
        path: '', loadChildren: './log/log.module#LogPageModule'
      },
    ]
  },
  { path: '',
    children: [
      {
        path: '', loadChildren: './car/car.module#CarModule'
      },
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
