import { Platform } from '@ionic/angular';
import { PushRegistParam } from './classes/push-regist-param';
import { BizMOBPush } from '@ionic-native/bizmob-plugin-push/ngx';
import { Injectable } from '@angular/core';
import { BizserverService } from '../shared/services/bizserver.service';
import { LOCAL_STORAGE } from '../shared/constants/common.const';
import { Util } from '../shared/util';
import { DeviceInfoParam } from './classes/device-info-param';
import { BizMOBDeviceInfo } from '@ionic-native/bizmob-plugin-deviceinfo/ngx';


@Injectable({
  providedIn: 'root'
})
export class BizPushService {

  util = new Util();
  private responseObj = {
    body : {},
    header : {
      result : true,
      apiName : 'REGIST_USER',
      language : '',
      osType : '',
      displayType : '',
      errorCode : '',
      errorText : ''
    }
  };

  constructor(
    private bizserver: BizserverService,
    private bizpush: BizMOBPush,
    private platform: Platform,
    private deviceInfo: BizMOBDeviceInfo
  ) { }

  registUser(userID: string): Promise<any> {

    const promiseReturn = new Promise((resolve, reject) => {

        const isPushRegistration = JSON.parse(localStorage.getItem("BIZMOB_PUSH_REGISTRAION"));
        if ( isPushRegistration ) {
          // const pushKeyParam =  new PushRegistParam(userID);
          // this.bizpush.updatePushAgreementInfo(pushKeyParam).then((res)=>{
          //   console.log(res);
          // });

          resolve(this.responseObj);

        } else {

          if (!this.platform.is('mobile')) {
            resolve(this.responseObj);
          } else {
            const param = new DeviceInfoParam();

            this.deviceInfo.getDeviceInfo(param).then(
              res => {
                const deviceId = res.body.deviceId;
                const pushKeyParam =  new PushRegistParam(userID, deviceId);
                console.log('pushKeyParam', JSON.stringify(pushKeyParam));

                this.bizpush.pushRegistration(pushKeyParam).then(
                  res1 => {
                    console.log('push registration is success : ' + JSON.stringify(res) );
                    localStorage.setItem('BIZMOB_PUSH_REGISTRAION', JSON.stringify(true));
                    localStorage.setItem('PUSH_REGISTER_USER', JSON.stringify(userID));
                    resolve(this.responseObj);
                  },
                  err => {
                    console.log('push registration is fail : ' + JSON.stringify(err) );
                    reject(err);
                  }
                );
              },
              err => {
                console.log('Error deviceInfo: ' + JSON.stringify(err));
                reject(err);
              });
          }
        }
    });

    return promiseReturn;
  }

}
