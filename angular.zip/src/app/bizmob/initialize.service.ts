import { Injectable } from '@angular/core';
import { BizMOBAppIron } from '@ionic-native/bizmob-plugin-appiron/ngx';
import { BizMOBCheckProxy } from '@ionic-native/bizmob-plugin-checkproxy/ngx';
import { BizMOBDeviceInfo } from '@ionic-native/bizmob-plugin-deviceinfo/ngx';
import { Platform } from '@ionic/angular';
import { environment } from 'src/environments/environment';
import { LOCAL_STORAGE } from '../shared/constants/common.const';
import { BizserverService } from '../shared/services/bizserver.service';
import { Util } from '../shared/util';
import { AppIronParam } from './classes/app-iron-param';
import { AppPatchParam } from './classes/app-patch-param';
import { ChkProxyParam } from './classes/chk-proxy-param';
import { DeviceInfoParam } from './classes/device-info-param';
import { UpdateParam } from './classes/update-param';
import { BizMOBUpdate } from '@ionic-native/bizmob-plugin-update/ngx';

@Injectable({
  providedIn: 'root'
})
export class InitializeService {

  private responseObj = {
    "body" : {},
    "header" : {
      "result" : false,
      "apiName" : "",
      "language" : "",
      "osType" : "",
      "displayType" : "",
      "errorCode" : "",
      "errorText" : ""
    }
  };

  constructor(
    private platform: Platform,
    private appIron: BizMOBAppIron,
    private deviceInfo: BizMOBDeviceInfo,
    private checkProxy: BizMOBCheckProxy,
    private bizServer: BizserverService,
    private updateManager: BizMOBUpdate
  ) { }

  util = new Util();

  initUpdate(progressOption:any): Promise<any> {

    let promiseReturn = new Promise((resolve, reject) => {
      if (!this.platform.is('mobile' )) {
        this.responseObj.header.apiName = "APPLICATION_UPDATE";
        this.responseObj.header.result = true;
        this.responseObj.body["isLatest"] = true;
        resolve(this.responseObj);
      }else {
        let param = new DeviceInfoParam();

        this.deviceInfo.getDeviceInfo(param).then(
        (res) => {
          localStorage.setItem( LOCAL_STORAGE.DEVICE_INFO, res.body);
          this.util.setSecureStorage( LOCAL_STORAGE.DEVICE_INFO, res.body );

          const appVersion = this.stringToNumberArray(res.body.appVersion); // '1.0.0'
          const contentsVersion = this.stringToNumberArray(res.body.contentsVersion);
          const lastVersion = this.stringToNumberArray(res.body.lastVersion);
          const osType =  res.body.osType;
          const osVersion =  res.body.osVersion;
          const displayType = 'PHONE';
          // NOTED: check app version updated 2020-03-05
          const appMajorVersion = Number(appVersion[0]);
          const appMinorVersion = Number(appVersion[1]);
          const appBuildVersion = Number(appVersion[2]);

          if ( lastVersion[0] > appMajorVersion ) {
            this.responseObj.header.apiName = 'APP_UPDATE';
            this.responseObj.header.errorText = res.body.lastVersion;
            this.responseObj.header.result = true;
            resolve(this.responseObj);
          } else {
            if ( lastVersion[1] > appMinorVersion ) {
              this.responseObj.header.apiName = 'APP_UPDATE';
              this.responseObj.header.errorText = res.body.lastVersion;
              this.responseObj.header.result = true;
              resolve(this.responseObj);
            } else {
              if ( lastVersion[2] > appBuildVersion ) {
                this.responseObj.header.apiName = 'APP_UPDATE';
                this.responseObj.header.errorText = res.body.lastVersion;
                this.responseObj.header.result = true;
                resolve(this.responseObj);
              } else {
                const ZZ0006Req = new UpdateParam( environment.appKey[osType], osType, osVersion,  appVersion, contentsVersion, displayType );

                this.getCurrentInfo(ZZ0006Req).then((ZZ0006Res) => {

                  if ( ZZ0006Res.header.result ) {

                    const currentAppVersion = [ZZ0006Res.body.app_major_version, ZZ0006Res.body.app_minor_version, ZZ0006Res.body.app_build_version];
                    const currentContentsVersion = [ZZ0006Res.body.content_major_version, ZZ0006Res.body.content_minor_version];
                    const strCurrentContentsVersion = ZZ0006Res.body.content_major_version + '.' + ZZ0006Res.body.content_minor_version;

                    const existNewApp = this.checkVersion(appVersion, currentAppVersion);
                    const existNewContents = this.checkVersion(contentsVersion, currentContentsVersion);

                    if (ZZ0006Res.body.app_result) {
                      // App update
                      // resolve(ZZ0006Res);
                    } else {
                      // check contents update
                      if (ZZ0006Res.body.content_result) {
                        // update contents
                        const serverUrl = this.bizServer.getServerURI();
                        const patchParam = new AppPatchParam("contents", serverUrl, strCurrentContentsVersion, ZZ0006Res.body.app_filename, ZZ0006Res.body.content_major_filename, ZZ0006Res.body.content_minor_filename , progressOption);

                        this.updateManager.update(patchParam).then( (res) => {

                            resolve(this.responseObj);
                          }, (err) => {

                            reject(err);
                          }
                        );

                      } else {
                        this.responseObj.header.apiName = "APPLICATION_UPDATE";
                        this.responseObj.header.result = true;
                        this.responseObj.body["isLatest"] = true;
                        resolve(this.responseObj);
                      }
                    }
                  } else {
                     reject(ZZ0006Res);
                  }
                },
                (ZZ0006Err) => {
                  reject(ZZ0006Err);
                });
              }
            }
          }

        },
        (err) => {

          this.responseObj.header.apiName = "DEVICE_INFO";
          this.responseObj.header.result = false;
          this.responseObj.header.errorCode = err.header.errorCode;
          this.responseObj.header.errorText = err.body.errorText;

          reject(this.responseObj);

        });

      }

    });

    return promiseReturn;
  }

  checkVersion(deviceVer: Array<number>, currentVer: Array<number> ){

    let floatStrDeviceVer: string = "";
    let floatStrCurrentVer: string = "";

    deviceVer.forEach((val,idx) => {
      if( idx == 1 ) {
        floatStrDeviceVer += "." +deviceVer[idx];
      }else{
        floatStrDeviceVer += deviceVer[idx];
      }
    });

    currentVer.forEach((val,idx) => {
      if( idx == 1 ) {
        floatStrCurrentVer += "." +currentVer[idx];
      }else{
        floatStrCurrentVer += currentVer[idx];
      }
    });
    
    let checkResult: boolean = false;
    // alert(parseFloat(floatStrCurrentVer));
    // alert(parseFloat(floatStrDeviceVer));

    if(parseFloat(floatStrCurrentVer) > parseFloat(floatStrDeviceVer)){
      checkResult = true;
    }
   
    return checkResult;

  }

  stringToNumberArray(version:string){

    let retArray :Array<number> = new Array();

    const version_strArr = version.split(".");
    
    version_strArr.forEach(function (value) {
      retArray.push(Number(value));
    }); 
    
    return retArray;

  }

  getCurrentInfo(param): Promise<any> {
    
    return this.bizServer.bizMOBContent(param).toPromise();
  }

  getDeviceInfo(): Promise<any> {

    let promiseReturn = new Promise((resolve, reject) => {
    
      let param = new DeviceInfoParam();

      this.deviceInfo.getDeviceInfo(param).then(
      (res) => {
        resolve(res);
      },
      (err) => {
        
        this.responseObj.header.apiName = "DEVICE_INFO";
        this.responseObj.header.result = false;
        this.responseObj.header.errorCode = err.header.errorCode;
        this.responseObj.header.errorText = err.body.errorText;

        reject(this.responseObj);

      });

    });

    return promiseReturn;
  }


  initSecurity(): Promise<any> {

    const promiseReturn = new Promise((resolve, reject) => {

      const param = new AppIronParam();

      if (!this.platform.is("mobile") || !environment.checkAppIron) {

        this.responseObj.header.apiName = "SECURITY_CHECK";
        this.responseObj.header.result = true;
        resolve(this.responseObj);

      } else {

        this.appIron.checkAppIron(param).then(
          (res) => {

            if ( res.header.result ) {
              const param = new ChkProxyParam();

              this.checkProxy.isConnectedProxy(param).then( (res) => {
                    if (!res.body.isProxy) {
                      this.responseObj.header.apiName = "SECURITY_CHECK";
                      this.responseObj.header.result = true;

                      resolve(this.responseObj);
                    } else {
                      this.responseObj.header.apiName = "CHECK_PROXY";
                      this.responseObj.header.result = false;
                      this.responseObj.header.errorCode = "CP0000";
                      this.responseObj.header.errorText = 'Connected through proxy server detected.',

                      reject(this.responseObj);
                    }

              }, (err) => {

                    this.responseObj.header.apiName = "CHECK_PROXY";
                    this.responseObj.header.result = false;
                    this.responseObj.header.errorCode = err.header.errorCode;
                    this.responseObj.header.errorText = err.body.errorText;

                    reject(this.responseObj);
                  }
              );
            } else {

              this.responseObj.header.apiName = "APP_IRON";
              this.responseObj.header.result = false;
              this.responseObj.header.errorCode = res.body.appIronCode;
              this.responseObj.header.errorText = res.body.appIronErrorMsg;

              reject(this.responseObj);

            }

          },
          (err) => {
            this.responseObj.header.apiName = "APP_IRON";
            this.responseObj.header.result = false;
            this.responseObj.header.errorCode = err.header.errorCode;
            // this.responseObj.header.errorText = err.header.errorText;
            this.responseObj.header.errorText = 'Network problem occured.';

            reject(this.responseObj);
          }
        );
      }

    });

    return promiseReturn;
  }

}
