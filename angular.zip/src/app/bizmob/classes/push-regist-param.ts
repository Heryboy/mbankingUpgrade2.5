import { environment } from 'src/environments/environment';

export class PushRegistBody {

    public pushUrl: string = environment.bizPushServer.URL;
    public pushKey = '';
    public userId = '';
    public deviceId = '';
    public appName: string = environment.appName;
    public channelId = '';
    public channelName = '';
    public channelDescription = '';
    public notiImportance = 'high';

    constructor(userID: string, deviceID: string) {
        this.userId = userID;
        this.deviceId = deviceID;
    }

}

export class BaseNativeHeader {

    public result = false;
    public apiName = 'PUSH_REGISTRATION';
    public language = '';
    public osType = '';
    public displayType = '';
    public errorCode = '';
    public errorText = '';

}

export class PushRegistParam {
    body: PushRegistBody;
    header: BaseNativeHeader;

    constructor(userID: string, deviceId: string) {
        this.header = new BaseNativeHeader();
        this.body = new PushRegistBody(userID, deviceId);
    }
}
