import { environment } from 'src/environments/environment';

export class AppIronBody {
   
    public url:string = environment.AppIronServer.URL;
}

export class BaseNativeHeader {
   
    public result:boolean = false;
    public apiName:string = "checkAppIron";
    public language:string = "";
    public osType:string = "";
    public displayType:string = "";
    public errorCode:string = "";
    public errorText:string = "";
  
}
export class AppIronParam {

    body : AppIronBody;
    header : BaseNativeHeader;

    constructor() {
        this.header = new BaseNativeHeader();
        this.body = new AppIronBody();
    }
}
