export class UpdateBody {

    public app_build_version: number = 0;
    public app_key: string = "";
    public app_major_version: number = 1;
    public app_minor_version: number = 0;
    public app_tester: boolean = false;
    public content_major_version: number = 0;
    public content_minor_version: number = 0;
    public display_type: string =  "";
    public os_type: string =  "";
    public os_version: string =  "";

    constructor(app_key: string, os_type: string, os_version: string, app_version: Array<number>, contents_version: Array<number>,  display_type?: string) {

        this.app_key = app_key;
        this.os_type = os_type;
        this.os_version = os_version;
        this.display_type = display_type;
        
        this.app_major_version = app_version[0];
        this.app_minor_version = app_version[1];
        this.app_build_version = app_version[2];

        this.content_major_version = contents_version[0];
        this.content_minor_version = contents_version[1];
        
        
    }

}


export class BaseHeader {

    public result: boolean = true;
    public trcode: string = "ZZ0006";
    public error_code: string = "";
    public error_text: string = "";
    public info_text: string = "";
    public login_session_id: string = "";
    public message_version: string = "1.0.1";
  
}

export class UpdateParam {

    header : BaseHeader;
    body: UpdateBody;

    constructor(app_key: string, os_type: string, os_version: string, app_version: Array<number>, contents_version: Array<number>, display_type?: string) {
        this.header = new BaseHeader();
        this.body = new UpdateBody(app_key, os_type, os_version, app_version, contents_version, display_type);
    }

}
