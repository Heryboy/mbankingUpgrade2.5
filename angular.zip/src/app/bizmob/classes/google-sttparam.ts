import { environment } from 'src/environments/environment';


export class GoogleSTTBody {
   
    public apiKey: string = environment.googleapiKey;
    public langCode: string = "";
    public recordTime: string = "3";
   

    constructor(langCd: string, recodingSeconds? : string) {
        this.langCode = langCd;
        this.recordTime = recodingSeconds;
    }

}


export class BaseNativeHeader {
   
    public result:boolean = false;
    public apiName:string = "recordAudio";
    public language:string = "";
    public osType:string = "";
    public displayType:string = "";
    public errorCode:string = "";
    public errorText:string = "";
  
}

export class GoogleSTTParam {

    body : GoogleSTTBody;
    header : BaseNativeHeader;

    constructor(langCd: string, recodingSeconds?: string) {
        this.header = new BaseNativeHeader();
        this.body = new GoogleSTTBody(langCd, recodingSeconds );
    }

}
