import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BizMOBPush } from '@ionic-native/bizmob-plugin-push/ngx';


@NgModule({
  declarations: [],
  providers : [
    BizMOBPush
  ],
  imports: [
    CommonModule
  ]
})
export class BizmobModule { }
