import { Component, OnInit } from '@angular/core';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-car12340000',
  templateUrl: './car12340000.component.html',
  styleUrls: ['./car12340000.component.scss'],
})
export class CAR12340000Component implements OnInit {

  constructor(
    private backservice: BackService
  ) { }

  ngOnInit() {}

  ionViewDidEnter() {
    this.backservice.subscribe('my_card');
  }

  onClickOk() {
    this.backservice.fire();
  }
}
