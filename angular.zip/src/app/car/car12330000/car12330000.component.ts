import { CardService } from 'src/app/shared/services/card.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { BUTTON_ROLE, CHANNEL } from 'src/app/shared/constants/common.const';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB8121Req } from 'src/app/shared/TRClass/CEB8121-req';
import { CEB8121Res } from 'src/app/shared/TRClass/CEB8121-res'; 
import { BackService } from 'src/app/shared/services/back.service';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { TranslateService } from '@ngx-translate/core';
import { FormatterService } from 'src/app/shared/services/formatter.service';

@Component({
  selector: 'app-car12330000',
  templateUrl: './car12330000.component.html',
  styleUrls: ['./car12330000.component.scss'],
})
export class CAR12330000Component implements OnInit {
  data = new CEB8121Req().confirmData;
  currentDate = moment().format('YYYYMMDD');
  requestAmount: number;
  interestRate: number;
  repaymentDate: string;
  depositAccountNumber: string;
  depositAccountNickName: string;
  // fee = new CEB8019Res().body;
  fee: number;
  expectedInterestAmount: number;
  totalRepaymentAmount: number;
  currencyCode: string;
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  chargeFee: number;  
  constructor(
    private router: Router,
    private modealService: ModalService,
    private authTranService: AuthTransactionService,
    private bizServer: BizserverService,
    private backService: BackService,
    private cardService: CardService,
    private translate: TranslateService,
    private formatterService: FormatterService,
  ) {

  }

  async ngOnInit() {
    this.requestAmount = this.data.requestAmount;
    // Change to correct repayment date
    let date: any;
    date = moment(new Date()).format('YYYY-MM-DD');
    date = await this.cardService.dateValidationFormat(date, 25); // validation datef format for settlementDate
    this.repaymentDate = date; // This day for settlementDate : this.data.fee.settlementDate;
    this.interestRate = this.data.interest.interestRate;
    this.depositAccountNumber = this.data.card.accountNo;
    this.depositAccountNickName = this.data.card.cardNickName;
    this.fee = this.data.fee;
    this.currencyCode = this.data.card.currencyCode;
    this.calculate();
    this.chargeAmount(); 
  }

  async calculate() {
    /* NOTE */
    // interest amount = actualDays / 360
    // actualDays = cash advance amount (request amount) * interestRate * days / 360 
    // days = repaymentDate - requestdate (today)
    const days = await this.cardService.getCountTotalDifferenceDays(this.repaymentDate);
    const actualDays = (this.requestAmount * this.interestRate * days) / 360;
    // if devide by 360 follows rule of loan
    // if devide by 365 follows rule of deposit
    this.expectedInterestAmount = actualDays / 360;
    this.totalRepaymentAmount = this.requestAmount + this.chargeFee + this.expectedInterestAmount;
  }

  async onClickYes() {
    if ( this.data.accountBalance < this.data.requestAmount ) { 
      let accountBalance;
      await this.translate.get(
        'CAR12330000.LABEL.NOT_ENOUGH_AVAILABLE_CREDIT_LIMIT',
        {
          accountBalance: this.formatterService.formatCurrency(this.data.accountBalance, 'blur', 'USD').text,
          currencyCode: this.data.card.currencyCode
        }
      ).subscribe((res) => {
        accountBalance = res;
        this.modealService.alert({
          content: accountBalance,
          btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
          callback: (res: any) => {
            if (res) {
              console.log(res);
            }
          }
        });
      });
    } else if ( this.data.requestAmount > 50 ) { 
      this.backService.modalService.modal({
        component: SmsAuthenticationComponent,
        componentProps: {
          callback: (res) => {
            if (res) {
              this.transactionID = res.transactionID;
              this.authenticationCode = res.authenticationCode;
              this.transactionDate = res.transactionDate;
              this.checkAuthentication();
            }
          }
        }
      });
    } else {  
      this.doReqestCashAdvance();
    }
  } 

  async checkAuthentication() {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID = this.transactionID;       
    reqTr.body.authenticationCode = this.authenticationCode; 
    reqTr.body.authTransactionDate = this.transactionDate;   
    reqTr.body.channelTypeCode = CHANNEL.MOB;                
    reqTr.body.customerNo = Utils.getUserInfo().customerNo;  
    reqTr.body.userID = Utils.getUserInfo().userID;          
    await this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.doReqestCashAdvance();
      }
    });
  }

  chargeAmount() { 
    this.chargeFee = this.data.requestAmount * 2 / 100;
    if ( this.chargeFee > 5 ) { 
      return this.chargeFee;
    } else { 
      this.chargeFee = this.data.fee;
      return this.chargeFee;
    }
  }

  async doReqestCashAdvance() {
    const reqTr = new CEB8121Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.authTransactionID = this.transactionID;
    reqTr.body.authenticationCode = this.authenticationCode;
    reqTr.body.authTransactionDate = this.transactionDate;
    reqTr.body.cardId = this.data.card.cardIDSvfe;
    reqTr.body.requestAmount = Number(this.data.requestAmount); 
    reqTr.body.currencyCode = this.data.card.currencyCode; 
    reqTr.body.accountNo = this.cardService.addFormatAccNumber(this.data.card.accountNo, 16); 
    await this.bizServer.bizMOBPost('CEB8121', reqTr).then(data => {
      const resTr = data as CEB8121Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.toCompleteScreen();
      }
    });
  }

  toCompleteScreen() {
    // close all pop up
    this.modealService.dismissAll({
      role: BUTTON_ROLE.APPLY
    });
    this.router.navigate(['/card/complete-cash-adv']);
  }

  onClickNo() {
    this.modealService.dismiss({
      role: BUTTON_ROLE.NO
    });
  }

}
