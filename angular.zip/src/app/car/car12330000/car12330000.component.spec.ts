import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12330000Component } from './car12330000.component';

describe('CAR12330000Component', () => {
  let component: CAR12330000Component;
  let fixture: ComponentFixture<CAR12330000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12330000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12330000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
