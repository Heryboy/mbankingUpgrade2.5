import { Component, OnInit } from '@angular/core';
import { BUTTON_ROLE, CHANNEL, CARD_PRODUCT_NAME } from 'src/app/shared/constants/common.const';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CAR12320000Component } from '../car12320000/car12320000.component';  
import { CEB8111Req } from 'src/app/shared/TRClass/CEB8111-req';
import { CEB8111Res } from 'src/app/shared/TRClass/CEB8111-res';
import { CEB8014Req } from 'src/app/shared/TRClass/CEB8014-req';
import { CEB8014Res } from 'src/app/shared/TRClass/CEB8014-res';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { CEB8121Req } from 'src/app/shared/TRClass/CEB8121-req';
import { CEB8013Req } from 'src/app/shared/TRClass/CEB8013-req';
import { CEB8013Res, CEB8013LimitAmount } from 'src/app/shared/TRClass/CEB8013-res';

@Component({
  selector: 'app-car12310000',
  templateUrl: './car12310000.component.html',
  styleUrls: ['./car12310000.component.scss'],
})
export class CAR12310000Component implements OnInit {
  card: CEB8012ItemsRes;
  interestRate: number; 
  minFee: number;
  minFeeTxt: string;
  minFeeRate: number;
  minFeeRateTxt: string; 
  myInterestRate = new CEB8111Res().body;
  creditLimit = new CEB8014Res().body;   
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT; 
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS; 
  dailyTransactionLimit = new CEB8013Res().body; 
  withdrawalDailyLimit  = new CEB8013LimitAmount();   
  dailyCashAdvanceTransaction: number; 
  constructor(
    private modealService: ModalService,
    private bizServer: BizserverService 
  ) {
    this.dailyCashAdvanceTransaction = 0;
   }

  async ngOnInit() {
    this.card = this.card;
    this.minFee = 5;
    this.minFeeRate = 2; 
    await this.getCashAdvanceInterestRate();
    await this.getCreditCardLimit();
    this.getDailyTransactionLimits();
  }

  onClickRequest() {
    if (this.card) {
      let data = new CEB8121Req().confirmData;
      data = {
        availableAmount: this.dailyCashAdvanceTransaction, 
        accountBalance: this.creditLimit.availableAmount,
        card: this.card,
        fee: this.minFee,
        interest: this.myInterestRate,
        requestAmount: null
      };
      this.modealService.modal({
        component: CAR12320000Component,
        componentProps: {
          data
        }
      }).then((result) => { });
    }
  } 

  async getCashAdvanceInterestRate() {
    const reqTr = new CEB8111Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.productNo = this.card.productNum;
    reqTr.body.feeAttributeCode = "RATP0001";
    await this.bizServer.bizMOBPost('CEB8111', reqTr).then(data => {
      const resTr = data as CEB8111Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.myInterestRate = resTr.body;
        this.interestRate = this.myInterestRate.interestRate; 
      }
    });
  }

  async getDailyTransactionLimits() {
    const reqTr = new CEB8013Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.cardNumber = this.card.cardNumber;
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    await this.bizServer.bizMOBPost('CEB8013', reqTr).then(data => {
      const resTr = data as CEB8013Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.dailyTransactionLimit = resTr.body;  
        this.withdrawalDailyLimit  = this.dailyTransactionLimit.withdrawalLimitAmount; 
        this.dailyCashAdvanceTransaction =  this.withdrawalDailyLimit.amount - this.creditLimit.sumTransactionAmountFee; 
      }
    });
  }

  async getCreditCardLimit() {
    const reqTr = new CEB8014Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.cardNumber = this.card.cardNumber;
    await this.bizServer.bizMOBPost('CEB8014', reqTr).then(data => {
      const resTr = data as CEB8014Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.creditLimit = resTr.body;  
      }
    });
  }

  btnCancel() {
    this.modealService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

}
