import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { MONTH_KEY_VALUE } from 'src/app/shared/common/data.common';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CAR12730000Component } from '../car12730000/car12730000.component';
import { SelectService } from 'src/app/shared/services/select.service';
import { WithdrawAbleAccount } from 'src/app/shared/services/withdraw-able-account.service';
import { CurrencyCode } from 'src/app/shared/constants/common.type';
import { AcountList } from 'src/app/acc/mac11170000/mac11170000.model';
import { BUTTON_ROLE, CARD_SCHEME_TYPE_CODE, CARD_SUBJECT_TYPE_CODE } from 'src/app/shared/constants/common.const';
import { CardService } from 'src/app/shared/services/card.service';
import { DataCardReqService } from 'src/app/shared/services/data-card-req.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-car12720000',
  templateUrl: './car12720000.component.html',
  styleUrls: ['./car12720000.component.scss'],
})
export class CAR12720000Component implements OnInit {

  @ViewChild('cardNickName', {static: true}) cardNickName;
  done1: string;
  done2: string;
  done3: string;
  done4: string;
  btnNext: string;
  keyboardup: string;
  disabled: boolean;
  disabledToNext: boolean;
  cardNicknameFeedback: string;
  settlementAccClass: string;
  cardProduct: string;
  cardProductText: string;
  cardProductId: string;
  settlementAccount: string;
  mMtext: string;
  mMvalue: string;
  yYtext: string;
  accountNo: string;
  accountName: string;
  accountNickName: string;
  cardNickname: string;
  currencyCode: string;
  cardProductType = '66'; // Test
  MMObj: SelectBoxOptionModel;
  YYObj: SelectBoxOptionModel;
  data;
  settlementAccountSelect: SelectBoxOptionModel;

  optMMList: any[];
  optYYList: any[];
  optSettlementAccountList: any[];

  public acountList: AcountList[];
  constructor(
    private translate: TranslateService,
    private modalService: ModalService,
    private selectService: SelectService,
    private cardService: CardService,
    private withdrawAccountService: WithdrawAbleAccount,
    private cardReqService: DataCardReqService,
    private backService: BackService
  ) { }

  ngOnInit() {
    this.settlementAccClass = 'done_cont';
    this.disabledToNext = false;
    this.done1 = '';
    this.done2 = '';
    this.done3 = '';
    this.done4 = '';
    this.keyboardup = '';
    this.btnNext = this.translate.instant('CARD_COMMON.BUTTON.NEXT');
    const dataInfo = DataCenter.get('cardAddVirtual', 'cardAddVirtual', true);
    if (dataInfo) {
      this.data = dataInfo;
    }
    this.disabled = true;
    this.optionMMList();
    this.optionYYList();
    this.SettlementAccountReqest();
  }

  ionViewWillEnter() {
    this.backService.subscribe('intro_virtual_card');
  }

  optionMMList() {
    this.optMMList = [];
    MONTH_KEY_VALUE.forEach(element => {
      this.optMMList.push({
        text: this.translate.instant(element.key),
        key: this.translate.instant(element.text),
        value: element.value
      });
    });
  }

  optionYYList() {
    const yy = Number(moment().format('YYYY'));
    this.optYYList = [];
    for (let i = 0; i <= 5; i++) {
      this.optYYList.push({
        text: String(yy + i),
        value: String(yy + i)
      });
    }
  }

  async SettlementAccountReqest() {
    const data = {
      currencyCode: 'USD' as CurrencyCode,
    };
    this.acountList = await this.withdrawAccountService.getWithdrawAccountByFilter(data);
    console.log(this.acountList);
  }

  onClickMM() {
    this.MMObj = {
      title: 'Month', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      items: [
        {
          title: 'titleTab',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.mMvalue,
          option: this.optMMList
        }
      ]
    };
    this.selectService.present(this.MMObj).then( rest => {
      if (rest) {
        this.mMtext = rest.text;
        this.mMvalue = rest.value;
        if (this.yYtext) {
          this.disabled = false;
        }
      }
    });
  }

  onClickYY() {
    this.YYObj = {
      title: 'Year', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      items: [
        {
          title: 'titleTab',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.yYtext,
          option: this.optYYList
        }
      ]
    };
    this.selectService.present(this.YYObj).then( rest => {
      if (rest) {
        this.yYtext = rest.text;
        if (this.mMvalue) {
          this.disabled = false;
        }
      }
    });
  }

  onClickNext() {
    this.nextRole();
  }

  onClickCardProduct() {
    DataCenter.set('screen', 'screen', 'screen01');
    this.cardService.selectCardProduct(CARD_SUBJECT_TYPE_CODE.ALL, CARD_SCHEME_TYPE_CODE.ALL, this.cardProduct, this.translate.instant('CAR12720000.LABEL.CHOOSE_CARD_PRODUCT')).then(res => {
      this.cardProduct      = res.code;
      this.cardProductText  = res.name;
      this.cardProductId    = res.productID;
      this.disabled = false;
    });
  }

  async onClickSettlementAccount() {
    this.withdrawAccountService.cardSettlementAccountSelectService(this.acountList, this.accountNo, this.translate.instant('CAR12720000.LABEL.CHOOSE_SETTLEMENT_ACCOUNT'), ).then(result => {
      if (result) {
        console.log(result);
        this.accountNo    = result.accountNo;
        this.accountName  = result.accountName;
        this.accountNickName = result.accountNickName;
        this.currencyCode   = result.currencyCode;
        this.disabled     = false;
      }
  });
  }

  ionChangeCardNickname(event) {
    if (event.target.value) {
      this.disabled = false;
      this.disabledToNext = true;
    } else {
      this.disabled = true;
      this.disabledToNext = false;
    }
  }

  onClickCancel() {
    this.backService.fire();
  }

  onClickDone(note: string) {
    this.btnNext = this.translate.instant('CARD_COMMON.BUTTON.CONFIRM');
    switch (note) {
      case 'Card_Product':
        this.done1 = '';
        this.done2 = '';
        this.done3 = '';
        this.done4 = '';
        this.onClickCardProduct();
        break;
      case 'Settlement_Account':
        this.done1 = 'done';
        this.done2 = '';
        this.done3 = '';
        this.done4 = '';
        this.onClickSettlementAccount();
        break;
      case 'Select_Vaild_Thru_MM':
        this.done1 = 'done';
        this.done2 = 'done';
        this.done3 = '';
        this.done4 = '';
        this.onClickMM();
        break;
      case 'Select_Vaild_Thru_YY':
        this.done1 = 'done';
        this.done2 = 'done';
        this.done3 = '';
        this.done4 = '';
        this.onClickYY();
        break;
      case 'Card_Nickname':
        this.done1 = 'done';
        this.done2 = 'done';
        this.done3 = 'done';
        this.done4 = 'done';
        this.cardNickName.setFocus();
        break;
    }
    this.disabled = false;
    this.disabledToNext   = false;
    console.log(note);
  }

  toNextStep() {
    this.doRequestCheckCardNickName().then( res => {
      if (res === true) {
        let data = {
          cardProductId: this.cardProductId,
          cardProductValue: this.cardProduct,
          cardProductText: this.cardProductText,
          cardNickname: this.cardNickname,
          monthText: this.mMtext,
          validThruMM: this.mMvalue,
          validThruYY: this.yYtext,
          accNumber: this.accountNo,
          accountName: this.accountName,
          accountNickName: this.accountNickName,
          fee: this.data.fee,
          currencyCode: this.currencyCode,
          cardProductType: this.cardProductType
        };
        this.modalService.modal({
          component: CAR12730000Component,
          componentProps: {
            data
          }
      }).then((result) => {});
      }
    });
  }

  nextRole() {
    this.btnNext = this.translate.instant('CAR12511000.BUTTON.NEXT');
    if (this.cardProduct) {
      this.done1 = 'done';
      this.disabled = true;
      if (this.accountNo) {
        this.done2 = 'done';
        this.disabled = true;
        if (this.mMvalue && this.yYtext) {
          this.done3 = 'done';
          this.disabled = true;
          this.cardNickName.setFocus();
          this.keyboardup = 'keyboardup';
          if (this.cardNickname) {
            this.disabledToNext = true;
            this.done4 = 'done';
          }
        }
      }
    }
  }

  doRequestCheckCardNickName(): Promise<boolean> {
    return new Promise( (resolve) => {
      this.cardReqService.checkCardNickName(String(this.cardNickname.trim())).then(res => {
        if (res.resultYN === 'Y') {
          this.cardNicknameFeedback = this.translate.instant('CAR12511000.LABEL.NICKNAME_ALREADY');
          resolve(false);
        } else {
          this.cardNicknameFeedback = undefined;
          resolve(true);
        }
      });
    });
  }

}
