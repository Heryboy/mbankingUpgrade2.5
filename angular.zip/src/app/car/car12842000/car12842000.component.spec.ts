import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12842000Component } from './car12842000.component';

describe('CAR12842000Component', () => {
  let component: CAR12842000Component;
  let fixture: ComponentFixture<CAR12842000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12842000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12842000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
