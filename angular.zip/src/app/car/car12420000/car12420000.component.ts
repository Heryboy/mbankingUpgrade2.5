import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car12420000',
  templateUrl: './car12420000.component.html',
  styleUrls: ['./car12420000.component.scss'],
})
export class CAR12420000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
