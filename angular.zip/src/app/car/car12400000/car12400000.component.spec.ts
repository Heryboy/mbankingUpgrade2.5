import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12400000Component } from './car12400000.component';

describe('CAR12400000Component', () => {
  let component: CAR12400000Component;
  let fixture: ComponentFixture<CAR12400000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12400000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12400000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
