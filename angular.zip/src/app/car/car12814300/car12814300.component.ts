import { Component, OnInit } from '@angular/core';
import { BackService } from 'src/app/shared/services/back.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

@Component({
  selector: 'app-car12814300',
  templateUrl: './car12814300.component.html',
  styleUrls: ['./car12814300.component.scss'],
})
export class CAR12814300Component implements OnInit {
  data;
  constructor(
    private backService: BackService
  ) { }

  ngOnInit() {
    this.backService.subscribe('debit_card_information');
    const data = DataCenter.get('CAR12814200', 'CAR12814200');
  }

  onClickOk() {
    DataCenter.set('my_card', 'my_card', true);
    this.backService.fire();
  }

}
