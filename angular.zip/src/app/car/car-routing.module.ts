import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CarMainComponent } from './car-main/car-main.component';
import { CAR11100000Component } from './car11100000/car11100000.component';
import { CAR11200000Component } from './car11200000/car11200000.component';
import { CAR11210000Component } from './car11210000/car11210000.component';
import { CAR11300000Component } from './car11300000/car11300000.component';
import { CAR12000000Component } from './car12000000/car12000000.component';
import { CAR12000000aComponent } from './car12000000a/car12000000a.component';
import { CAR12100000Component } from './car12100000/car12100000.component';
import { CAR12200000Component } from './car12200000/car12200000.component';
import { CAR12310000Component } from './car12310000/car12310000.component';
import { CAR12320000Component } from './car12320000/car12320000.component';
import { CAR12330000Component } from './car12330000/car12330000.component';
import { CAR12340000Component } from './car12340000/car12340000.component';
import { CAR12400000Component } from './car12400000/car12400000.component';
import { CAR12410000Component } from './car12410000/car12410000.component';
import { CAR12420000Component } from './car12420000/car12420000.component';
import { CAR12431000Component } from './car12431000/car12431000.component';
import { CAR12432000Component } from './car12432000/car12432000.component';
import { CAR12433000Component } from './car12433000/car12433000.component';
import { CAR12511000Component } from './car12511000/car12511000.component';
import { CAR12512000Component } from './car12512000/car12512000.component';
import { CAR12520000Component } from './car12520000/car12520000.component';
import { CAR12530000Component } from './car12530000/car12530000.component';
import { CAR12710000Component } from './car12710000/car12710000.component';
import { CAR12720000Component } from './car12720000/car12720000.component';
import { CAR12812000Component } from './car12812000/car12812000.component';
import { CAR12813000Component } from './car12813000/car12813000.component';
import { CAR12821000Component } from './car12821000/car12821000.component';
import { CAR12822000Component } from './car12822000/car12822000.component';
import { CAR12841000Component } from './car12841000/car12841000.component';
import { CAR13000000Component } from './car13000000/car13000000.component';
import { CAR12811000Component } from './car12811000/car12811000.component';
import { CAR12842000Component } from './car12842000/car12842000.component';
import { CAR12815100Component } from './car12815100/car12815100.component';
import { CAR12814100Component } from './car12814100/car12814100.component';
import { CAR12843000Component } from './car12843000/car12843000.component';
import { CAR12841100Component } from './car12841100/car12841100.component';
import { CAR12740000Component } from './car12740000/car12740000.component';
import { CAR12814300Component } from './car12814300/car12814300.component';
import { CAR12814200Component } from './car12814200/car12814200.component';
import { CAR12815200Component } from './car12815200/car12815200.component';
import { CAR12815300Component } from './car12815300/car12815300.component';
import { CAR12816100Component } from './car12816100/car12816100.component';
import { CAR12816200Component } from './car12816200/car12816200.component';
import { CAR12816300Component } from './car12816300/car12816300.component';

const routes: Routes = [
  {
    path: 'card',
    children: [
      { path: 'car-main',                   component: CarMainComponent },
      { path: 'activation-card',            component: CAR12511000Component },
      { path: 'activation-pre-pay',         component: CAR12512000Component },
      { path: 'my-card',                    component: CAR12000000Component },
      { path: 'overflow',                   component: CAR12000000aComponent },
      { path: 'complete-cash-adv',          component: CAR12340000Component },
      { path: 'complete-activation',        component: CAR12530000Component },
      { path: 'comfirm-cash-adv',           component: CAR12330000Component },
      { path: 'form-cash-adv',              component: CAR12320000Component },
      { path: 'check-balance',              component: CAR12200000Component },
      { path: 'view-transaction',           component: CAR12420000Component },
      { path: 'pre-pay',                    component: CAR12431000Component },
      { path: 'intro-cash-adv',             component: CAR12310000Component },
      { path: 'intro-virtual-card',         component: CAR12710000Component },
      { path: 'add-virtual-card',           component: CAR12720000Component },
      { path: 'statement',                  component: CAR12410000Component },
      { path: 'select-card',                component: CAR11210000Component },
      { path: 'transaction-detail',         component: CAR11300000Component },
      { path: 'transaction',                component: CAR12100000Component },
      { path: 'billing',                    component: CAR12400000Component },
      { path: 'debit-card',                 component: CAR11100000Component },
      { path: 'credit-card',                component: CAR11200000Component },
      { path: 'complete-pre-pay',           component: CAR12433000Component },
      { path: 'comfirm-activation-card',    component: CAR12520000Component },
      { path: 'comfirm-pre-pay',            component: CAR12432000Component },
      { path: 're-issue-card',              component: CAR12841000Component },
      { path: 're-issue-card',
        children: [
          { path: '',                       component: CAR12841000Component },
          { path: 'select-branch',          component: CAR12841100Component },
          { path: 'confirm',                component: CAR12842000Component },
          { path: 'result',                 component: CAR12843000Component },
        ],
      },
      { path: 'view-benefits',              component: CAR12813000Component },
      { path: 'my-point',                   component: CAR13000000Component },
      { path: 'block-card-confirm',         component: CAR12821000Component },
      { path: 'block-card-result',          component: CAR12822000Component },
      { path: 'credit-card-information',    component: CAR12812000Component },
      { path: 'debit-card-information',     component: CAR12811000Component},
      { path: 'application-form',           component: CAR12815100Component},
      { path: 'change-transaction-limit',   component: CAR12814100Component},
      {path: 'complete-add-virtual-card',   component: CAR12740000Component},
      { path: 'result-change-transaction-limit', component: CAR12814300Component},
      { path: 'confirm-change-transaction-limit', component: CAR12814200Component},
      { path: 'confirm-change-PIN',         component: CAR12815200Component},
      { path: 'result-change-PIN',          component: CAR12815300Component},
      { path: 'reset-PIN',                  component: CAR12816100Component},
      { path: 'confirm-reset-PIN',          component: CAR12816200Component},
      { path: 'result-reset-PIN',           component: CAR12816300Component}
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
})
export class CardRoutingModule { }
