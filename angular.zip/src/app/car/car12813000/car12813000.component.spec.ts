import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12813000Component } from './car12813000.component';

describe('CAR12813000Component', () => {
  let component: CAR12813000Component;
  let fixture: ComponentFixture<CAR12813000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12813000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12813000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
