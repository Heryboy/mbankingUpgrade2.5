import { Component, OnInit, Renderer2 } from '@angular/core';
import { DateRange, FromDateToDate } from '../../shared/component/filter/filter.model';
import { SelectBoxOptionModel } from '../../shared/component/select-option/select-option.model';
import { BUTTON_ROLE, CARD_SUBJECT_TYPE_CODE, REGION_CODE, CARD_SCHEME, CARD_SCHEME_TYPE_CODE } from '../../shared/constants/common.const';
import { DataCenter } from '../../shared/utils/data-center.static';
import { Utils } from '../../shared/utils/utils.static';
import { CardFilter } from './car11210000.model';
import { TranslateService } from '@ngx-translate/core';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res';

@Component({
  selector    : 'app-car11210000',
  templateUrl : './car11210000.component.html',
  styleUrls   : ['./car11210000.component.scss'],
})
/* the filter screen for card */
export class CAR11210000Component implements OnInit {
  modal: any;
  regionTypeCode: REGION_CODE.ALL | REGION_CODE.CAMBODIA | REGION_CODE.OVERSEAS;
  cardTransactionType: boolean[] = [, , , ];
  isValidCardTransactionType: boolean;
  dateRange: any;
  search: string;
  dataCardFilter =  new CardFilter();
  all       = REGION_CODE.ALL;
  cambodia  = REGION_CODE.CAMBODIA;
  overseas  = REGION_CODE.OVERSEAS;
  isTransactionType: boolean;
  setDate: FromDateToDate;
  cardList: CEB8012ItemsRes[];
  cardListAfterFilter: CEB8012ItemsRes[];
  list: SelectBoxOptionModel;
  placeHoder: string;
  selectedAll: any;
  selectedValue: string;
  constructor(
    private translate: TranslateService,
    private renderer: Renderer2
      ) { }

  ngOnInit() {
    this.search   = '';
    this.dataCardFilter     = this.modal.message.data;
    this.addSelectAllElementToCardList();
    this.setFilter();
    this.cardList = DataCenter.get('CAR12000000', 'cardList', false);
    const cloned = this.cardList.map(x => Object.assign({}, x));
    this.cardListAfterFilter = this.filterByCardType(cloned as any);
    this.getSelectData();
  }
  // set filter when init filter
  setFilter() {
    if (this.dataCardFilter.regionTypeCode === undefined) {
      this.regionTypeCode = REGION_CODE.ALL;
      if (this.dataCardFilter.isCreditCard) {
        this.setAll(this.cardTransactionType, true);
      }
      this.selectedValue  = this.selectedAll.cardNo;
      this.dataCardFilter.card      = this.selectedAll;
    } else {
      // this.setDate = {
      //   fromDate  : this.dataCardFilter.dateRange.fromDate, // 2020-03-04
      //   toDate    : this.dataCardFilter.dateRange.toDate  // 2020-03-04
      // };
      this.cardTransactionType  = this.dataCardFilter.cardTransactionType;
      this.regionTypeCode       = this.dataCardFilter.regionTypeCode;
      // this.search               = this.dataCardFilter.search;
      this.selectedValue        = this.dataCardFilter.card.cardNo;
    }
  }
  // set nickname and add select all of each card to cards
  filterByCardType(list: CEB8012ItemsRes[]) {
    let filterBy: string;
    if (this.dataCardFilter.isCreditCard) {
      filterBy      = CARD_SUBJECT_TYPE_CODE.CREDIT;
    } else {
      filterBy      = CARD_SUBJECT_TYPE_CODE.DEBIT;
    }
    const cardList = [];
    list.filter(item => {
      if (item.cardTypeFeature as any === filterBy) {
        const i = {
          remainDate          : item.endDate,
          threeMonthNotedYN   : item.amendAvailableYN,
          cardSubjectTypeCode : item.cardTypeFeature ,
          // vitualYN            : item.isVirtual,
          cardNickname        : this.getItemTextField(item),
          cardProductName     : item.productName,
          cardHolder          : item.cardholderName,
          cardNo              : item.cardNumber,
          expireDate          : item.expireDateSvfe,
          cardScheme          : item.cardNetName,
          cardStatusCode      : item.cardStatusCodeSvfe
        };
        cardList.push(i);
        return i;
      }
    });
    cardList.unshift(this.selectedAll);
    return cardList;
  }
  // for the select all of each card data
  addSelectAllElementToCardList() {
    let allCardNickname   = '';
    if (this.dataCardFilter.isCreditCard) {
      allCardNickname     = this.translate.instant('CAR11210000.LABEL.ALL_CREDIT_CARDS');
    } else {
      allCardNickname     = this.translate.instant('CAR11210000.LABEL.ALL_DEBIT_CARDS');
    }
    this.selectedAll      = {
      remainDate          : 800,
      threeMonthNotedYN   : 'all',
      cardSubjectTypeCode : 'all' ,
      vitualYN            : 'all',
      cardNickname        : allCardNickname,
      cardProductName     : allCardNickname,
      cardHolder          : 'all',
      cardNo              : 'all',
      expireDate          : 'all',
      cardScheme          : 'all',
      cardStatusCode      : 'all'
    };
  }

  getSelectData() {
    this.list = {
      title: this.translate.instant('CAR11210000.LABEL.PLEASE_SELECT_CARD'),
      items: [
        {
          title         : 'Select',
          itemValueField: 'cardNo',
          itemTextField : 'cardNickname',
          seletedOpt    : this.selectedValue,
          option        : this.cardListAfterFilter
        },
      ]
    };
  }

  // make nickanme + last 4 digits from UX/UI design
  getItemTextField(item: CEB8012ItemsRes) {
    let name: any;
    let cardScheme: any;
    if (item.cardNickName !== '') {
      name = item.cardNickName;
    } else {
      name = item.cardholderName;
    }
    if (item.cardNetName as any === CARD_SCHEME_TYPE_CODE.VISA) {
      cardScheme = CARD_SCHEME.VISA;
    } else if (item.cardNetName as any === CARD_SCHEME_TYPE_CODE.MASTER) {
      cardScheme = CARD_SCHEME.MASTER;
    } else if (item.cardNetName as any === CARD_SCHEME_TYPE_CODE.CSS) {
      cardScheme = CARD_SCHEME.CSS;
    } else if (item.cardNetName as any === CARD_SCHEME_TYPE_CODE.DINERS_CLUB) {
      cardScheme = CARD_SCHEME.DINERS_CLUB;
    } else if (item.cardNetName as any === CARD_SCHEME_TYPE_CODE.LOCAL_NETWORK) {
      cardScheme = CARD_SCHEME.LOCAL_NETWORK;
    } else {
      cardScheme = 'Unknown Card Type';
    }
    const cardNo = Utils.getLast4Digits(item.cardNumber);
    let returnValue = cardScheme + ' ' + cardNo + ' | ' + name;
    if (item.cardNumber as any === 'all') {
      return returnValue = this.selectedAll.cardNickname;
    }
    return returnValue;
  }

  btnCloseClicked() {
    this.modal.close({ role: BUTTON_ROLE.CLOSE });
  }
// btn click apply and close modal
  btnApplyClicked() {
    const data: CardFilter = {
      regionTypeCode        : this.regionTypeCode,
      dateRange             : this.dateRange,
      search                : this.search,
      cardTransactionType   : this.cardTransactionType,
      isShowAccountCard     : this.dataCardFilter.isShowAccountCard,
      isCreditCard          : this.dataCardFilter.isCreditCard,
      card                  : this.dataCardFilter.card
    };
    this.modal.close({ role: BUTTON_ROLE.APPLY, data });
  }
  // get date filter
  dateFilterChanged(dateRange: DateRange) {
    this.dateRange = dateRange;
  }
  // set all array boolean value
  setAll(arr: boolean[], value: boolean) {
      for (let i = 0; i < arr.length; i++) {
          arr[i] = value;
      }
  }
  // to get after click change card filter
  onChangeCard(event) {
    this.dataCardFilter.card = event;
  }
  // to check is valid card transaction type
  // if there is no check of each transaction type set the botton apply to disabled
  onTermsChecked() {
    const resultCardTransactionType = this.cardTransactionType.filter((item) => {
      if (item === true) {
        return item;
      }
    });
    if (resultCardTransactionType.length === 0) {
      this.isValidCardTransactionType = true;
    } else {
      this.isValidCardTransactionType = false;
    }
  }

  onClick() {
    const kendo = document.querySelector('.pop_select_option');
    this.renderer.removeClass(kendo, 'pop_select_option');
  }
  
}
