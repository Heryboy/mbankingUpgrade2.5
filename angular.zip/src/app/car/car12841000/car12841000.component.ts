import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ADDRESS_TYPE_CODE, BUTTON_ROLE, CARD_SCHEME_TYPE_CODE, CARD_SUBJECT_TYPE_CODE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { CardService } from 'src/app/shared/services/card.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { RECEIVE_TYPE } from '../../shared/constants/common.const';
import { cardBenifitInfoList } from '../car11100000/data';
import { CAR12813000Component } from '../car12813000/car12813000.component';
import { CAR12841100Component } from '../car12841100/car12841100.component';
import { CAR12842000Component } from '../car12842000/car12842000.component';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { CEB8222Req } from 'src/app/shared/TRClass/CEB8222-req';
import { CEB8222AddressListRes, CEB8222Res } from 'src/app/shared/TRClass/CEB8222-res';
import { PPCB0160BranchListRes } from 'src/app/shared/TRClass/PPCB0160-res';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB0311Req } from 'src/app/shared/TRClass/CEB0311-req';
import { CEB0311Res } from 'src/app/shared/TRClass/CEB0311-res';

@Component({
  selector: 'app-car12841000',
  templateUrl: './car12841000.component.html',
  styleUrls: ['./car12841000.component.scss'],
})
export class CAR12841000Component implements OnInit { 
  card = new  CEB8012ItemsRes();
  enableBtnNext = false;   
  cardSubjectType: string;
  cardBenifitInfo = {
    productTypeCode: '',
    benefit: ''
  };
  reissueCardInfo = {
    deliverAddress: new CEB8222AddressListRes(),
    receiveOptionCode: RECEIVE_TYPE.DELIVERY,
    selectedBranch: new PPCB0160BranchListRes(),
    card: {
      cardNumber: ''
    },
    product: {
            productNum: '',
            productName: ''
    },
    productReIssue: {
            productNum: '',
            productName: ''
    }
  };
  // User Prefer delivery address
  ADDRESS_CODE_USER_CHOICE: any = ADDRESS_TYPE_CODE.HOME_ADDRESS ; // ADDRESS_CODE_USER_CHOICE: its type can be array or string
  RECEIVE_TYPE_CODE_USER_CHOICE = RECEIVE_TYPE.DELIVERY;
  // addressDescriptionUserChoice, shown on input screen, and for final result to next screen
  addressDescriptionUserChoice: CEB8222AddressListRes = new CEB8222AddressListRes();
  addressHomeUserChoice: CEB8222AddressListRes = new CEB8222AddressListRes();
  addressBusinessUserChoice: CEB8222AddressListRes = new CEB8222AddressListRes();
  addressOtherUserChoice: CEB8222AddressListRes = new CEB8222AddressListRes();
  initHomeAddress = true;
  initBusinessAddress = true;
  initOtherAddress = true; 
  rdbDelivery: any = RECEIVE_TYPE.DELIVERY;
  rdbBranchPickup: any;
  enableOtherAddress = true;
  // placeholder, used in input textview in html
  deliverPlaceHolder: string = this.translate.instant('CAR12841000.LABEL.ENTER_DELIVER_ADDRESS_HERE');
  // Address list of Customer from Server
  customerAddressList: Array<CEB8222AddressListRes>;
  // Constant Type, declared for using in View (HTML)
  BUSINESS_ADDRESS = ADDRESS_TYPE_CODE.BUSINESS_ADDRESS;
  HOME_ADDRESS = ADDRESS_TYPE_CODE.HOME_ADDRESS;
  OTHER_ADDRESS: string[]; // array code of other addresses from ADDRESS_TYPE_CODE enum
  RECEIVE_TYPE_DELIVERY = RECEIVE_TYPE.DELIVERY;
  RECEIVE_TYPE_BRANCH = RECEIVE_TYPE.BRANCH;
  translateCardTypeFeature: string;
  translateTitle: string;
  reissueReasonsList: any; 
  constructor(
    private backService: BackService,
    private modalService: ModalService,
    private cardService: CardService,
    private translate: TranslateService,
    private element: ElementRef,
    private bizServer: BizserverService
  ) {
    this.setCardbenefitByProductTypeCode('01');
  }

  @ViewChild('pickUpAddressInput', {static: true}) pickUpAddressInput;

  async ngOnInit() { 
    await this.initData (); 
    this.checkCardTypeFeature();
    // this.checkCardProductYN(); 
  }

  onRdbCardReceiveCheck(rdb) {
    if (rdb === RECEIVE_TYPE.DELIVERY) {
      this.rdbBranchPickup = '';
      this.reissueCardInfo.receiveOptionCode = this.rdbDelivery;
    } else {
      this.rdbDelivery = '';
      this.reissueCardInfo.receiveOptionCode = this.rdbBranchPickup;
    }
  }

  async initData() {
    this.card = DataCenter.get('card', 'card', false);
    this.reissueYN();
    this.OTHER_ADDRESS = this.getOtherAddressEnumValues();
    this.customerAddressList = await this.getCustomerAddressListByCustomerNo();
    await this.onAddressChange(true);
    this.reissueCardInfo.product.productName = this.card.productName;
    this.reissueCardInfo.product.productNum = this.card.productNum; 
    this.reissueCardInfo.card.cardNumber = this.card.cardNumber;
    if ( this.card.amendAvailableYN === 'Y' as any || this.card.amendAvailableYN === 'B1' as any ) { 
      this.getRenewalReason(); 
    }
    this.reissueCardInfo.deliverAddress = this.addressDescriptionUserChoice;
    this.addressHomeUserChoice.code = ADDRESS_TYPE_CODE.HOME_ADDRESS as any;
    this.addressBusinessUserChoice.code = ADDRESS_TYPE_CODE.BUSINESS_ADDRESS as any;
    this.addressOtherUserChoice.code = ADDRESS_TYPE_CODE.STATEMENT_DELIVERY_ADDRESS as any;
    await this.onCheckValidation();
  }

  // Disable or Enble Button Next
  async onCheckValidation() {
    await this.adjust();
    if (!this.reissueCardInfo) {
      this.enableBtnNext = false;
      return;
    }

    if (this.productChoosedYN() && this.card) {
      if (this.deliveryYN()) {
        const deliveryAddressChoosedYN = (this.addressDescriptionUserChoice
                                          &&  this.addressDescriptionUserChoice.street
                                          && this.addressDescriptionUserChoice.code) ? true : false;
        this.enableBtnNext = deliveryAddressChoosedYN;
        if (this.addressDescriptionUserChoice) {
          this.assignAddressFirstInitIfAddressTypeNoDataInServer(this.addressDescriptionUserChoice.code);
        }
      } else if (this.picupFromBranchYN()) {
        const pickupFromBranchChoosedYN = (this.reissueCardInfo.selectedBranch
                                          && this.reissueCardInfo.selectedBranch.branchCode) ? true : false;
        this.enableBtnNext = pickupFromBranchChoosedYN;
      } else {
        this.enableBtnNext = false;
      }
    }
  }

  // Check whether product has value or not
  productChoosedYN() {
    const productChoosedYN = (this.reissueCardInfo.product
                            && this.reissueCardInfo.product.productName
                            && this.reissueCardInfo.product.productNum) ? true : false;
    return productChoosedYN;
  }

  // Check whether user final decision is Delivery or not
  deliveryYN() {
    return this.reissueCardInfo
          && this.reissueCardInfo.receiveOptionCode === RECEIVE_TYPE.DELIVERY;
  }

  // Check whether user final decision is Pickup from branch or not
  picupFromBranchYN() {
    return this.reissueCardInfo
          && this.reissueCardInfo.receiveOptionCode === RECEIVE_TYPE.BRANCH;
  }

  onClickCancel() {
    this.backService.back();
  }

  onClickNext() {
    if ( this.reissueCardInfo.productReIssue.productNum === '' || this.reissueCardInfo.productReIssue.productNum === undefined
          &&  this.reissueCardInfo.productReIssue.productName === '' || this.reissueCardInfo.productReIssue.productName === undefined ) { 
      this.modalService.alert({
        content: this.translate.instant('CAR12841000.LABEL.PLEASE_SELECT_REISSUE_REASON'),
        btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
        callback: (res: any) => {
          if (res) {
            console.log(res);
          }
        }
      });
    } else { 
      this.reissueCardInfo.deliverAddress = this.addressDescriptionUserChoice;
      this.modalService.modal({
        component         : CAR12842000Component,
        componentProps : { 
          reissueCardInfo : this.reissueCardInfo, 
          amendAvailableYN: this.card.amendAvailableYN
        }
      });
    }
  }

  async onSelectBranch() {
    const result = await this.modalService.modal({
      component: CAR12841100Component
    });
    if (result.role === BUTTON_ROLE.OK) {
      this.reissueCardInfo.selectedBranch = result.data;
      this.onCheckValidation();
    }
  }

  // when user change:
  // ex: from Home to Office, or Office to home ...
  segmentChanged(event) {
    if (event) {
      this.onAddressChange(false); 
      this.pickUpAddressInput.setFocus(); 
    }
  }

  toViewBenefit() {
    // Currently we use static benifit data
    this.setCardbenefitByProductTypeCode(this.reissueCardInfo.product.productNum);
    if (this.card) {
      const dataBenefit = {
        benefits        : this.cardBenifitInfo.benefit,
        cardProductName : this.reissueCardInfo.product.productName
      };
      this.modalService.modal({
       component       : CAR12813000Component,
       componentProps  : { card: dataBenefit }
     });
    }
  }

  async getCustomerAddressListByCustomerNo(): Promise<Array<CEB8222AddressListRes>> {
    const reqTr = new CEB8222Req();
    reqTr.body.cardNumber = this.card.cardNumber; 
    let customerAddressList: Array<CEB8222AddressListRes>;
    await this.bizServer.bizMOBPost('CEB8222', reqTr).then(data => {
      const resTr = data as CEB8222Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        customerAddressList = resTr.body.addressList;
      }
    });

    return Promise.resolve(customerAddressList);
  }

  async onAddressChange(inti: boolean) {
    await this.resetChoice();
    if (!this.alreadyInitAssignAddress(this.ADDRESS_CODE_USER_CHOICE)) {
      this.setAddressWhenInit();
    } else {
      this.setAddressDescriptionUserChoice(this.ADDRESS_CODE_USER_CHOICE);
    }
    if (!inti) {
      this.onCheckValidation();
    }
  }

  // assign value, when user click on each buttons of address type for the first time
  setAddressWhenInit() {
    const otherAddressYN      = this.isOtherAddress(this.ADDRESS_CODE_USER_CHOICE);
    // tslint:disable-next-line: no-unused-expression
    // tslint:disable-next-line: max-line-length
    this.addressDescriptionUserChoice = this.customerAddressList.find(address => {
      if (otherAddressYN) {
        this.initOtherAddress = false;
        // this.ADDRESS_CODE_USER_CHOICE: is the array of other addresses (address beside home and business)
        // value is type string, value is the code of other address
        // Return true when one of other address in array this.ADDRESS_CODE_USER_CHOICE
        // matches the code of address from list customerAddressList
        if (this.ADDRESS_CODE_USER_CHOICE.find(value => address.code === value)) {
          this.addressOtherUserChoice = address;
          return true;
        } else {
          this.enableOtherAddress     = false;
          this.disableEnableOtherAddress();
          return false;
        }
      } else if (address.code as ADDRESS_TYPE_CODE === this.ADDRESS_CODE_USER_CHOICE) {
        if (address.code as ADDRESS_TYPE_CODE === ADDRESS_TYPE_CODE.HOME_ADDRESS) {
          this.addressHomeUserChoice = address;
        } else {
          this.addressBusinessUserChoice = address;
        }
        return true;
      } else {
        return false;
      }
    });

    if (!otherAddressYN) {
      if (this.ADDRESS_CODE_USER_CHOICE as ADDRESS_TYPE_CODE === ADDRESS_TYPE_CODE.HOME_ADDRESS) {
        this.initHomeAddress = false;
      } else {
        this.initBusinessAddress = false;
      }
    }

    // tslint:disable-next-line: max-line-length
    // Prevent undefine data
    if (!this.addressDescriptionUserChoice) {
      this.addressDescriptionUserChoice =  new CEB8222AddressListRes();
      // tslint:disable-next-line: max-line-length
      this.addressDescriptionUserChoice.code = !otherAddressYN ? this.ADDRESS_CODE_USER_CHOICE : ADDRESS_TYPE_CODE.STATEMENT_DELIVERY_ADDRESS;
    }
  }

  // check whether each address types are already assigned from server address or not
  // return true, already get assigned data from server
  alreadyInitAssignAddress(addressCode): boolean {
    const otherOtherYN = this.isOtherAddress(addressCode);
    const homeAddressAlreadyInted = ((addressCode as ADDRESS_TYPE_CODE === ADDRESS_TYPE_CODE.HOME_ADDRESS) && !this.initHomeAddress);
    // tslint:disable-next-line: max-line-length
    const businessAddressAlreadyInted = ((addressCode as ADDRESS_TYPE_CODE === ADDRESS_TYPE_CODE.BUSINESS_ADDRESS) && !this.initBusinessAddress);
    const otherAddressAlreadyInted = (otherOtherYN && !this.initOtherAddress);

    return homeAddressAlreadyInted || businessAddressAlreadyInted || otherAddressAlreadyInted;
  }

  // we use this function when
  // choice address type already assigned before
  setAddressDescriptionUserChoice(addressCode) {
    if (this.isOtherAddress(addressCode)) {
      this.addressDescriptionUserChoice = this.addressOtherUserChoice;
    } else if (addressCode === ADDRESS_TYPE_CODE.HOME_ADDRESS) {
      this.addressDescriptionUserChoice = this.addressHomeUserChoice;
    } else if (addressCode === ADDRESS_TYPE_CODE.BUSINESS_ADDRESS) {
      this.addressDescriptionUserChoice = this.addressBusinessUserChoice;
    }
  }

  // used when:
  // type of address no data from server and user input data
  // so he need to assign data from user input to that address type
  // Ex: Office: no data, and user input data ==>
  // office address type have to be equal data user input
  assignAddressFirstInitIfAddressTypeNoDataInServer(addressCode) {
    if (!this.isOtherAddress(addressCode)) {
      if (addressCode === ADDRESS_TYPE_CODE.HOME_ADDRESS) {
        this.addressHomeUserChoice = this.addressDescriptionUserChoice;
      } else if (addressCode === ADDRESS_TYPE_CODE.BUSINESS_ADDRESS) {
        this.addressBusinessUserChoice = this.addressDescriptionUserChoice;
      }
    }
  }
  // Reset the choice that user choosed before
  async resetChoice() {
    // tslint:disable-next-line: max-line-length
    this.reissueCardInfo.deliverAddress = new CEB8222AddressListRes();
    this.onRdbCardReceiveCheck(RECEIVE_TYPE.DELIVERY);
    this.addressDescriptionUserChoice = new CEB8222AddressListRes();
    this.deliverPlaceHolder = this.translate.instant('CAR12841000.LABEL.ENTER_DELIVER_ADDRESS_HERE');
    this.pickUpAddressInput.readonly = false;
    await this.adjust();
  }

  // onClickCardProduct() {
  //   this.cardService.selectCardProduct(CARD_SUBJECT_TYPE_CODE.ALL,
  //     CARD_SCHEME_TYPE_CODE.ALL, this.reissueCardInfo.product.productNum,
  //     this.translate.instant('CAR12720000.LABEL.SELECT_CARD_PRODUCT')).then(res => {
  //       this.reissueCardInfo.product.productNum  = res.code;
  //       this.reissueCardInfo.product.productName = res.name;
  //   }).catch( err => {
  //     // handle error here
  //   });
  // }

  onClickReIssueReason(){
    DataCenter.set('screen', 'screen', 'screen02');
    const reIssueReasonCode = 0;
    this.cardService.selectCardProduct(CARD_SUBJECT_TYPE_CODE.ALL,
      CARD_SCHEME_TYPE_CODE.ALL, this.reissueCardInfo.productReIssue.productNum,
      this.translate.instant('CAR12720000.LABEL.SELECT_RE_ISSUE_REASON'), reIssueReasonCode).then(res => {
        this.reissueCardInfo.productReIssue.productNum = res.code;
        this.reissueCardInfo.productReIssue.productName = res.name;
    }).catch( err => {
      // handle error here
    });
  }

  

  setCardbenefitByProductTypeCode(code: string) {
    // Test
    // Currently, we use static data for view benifit
    // So we use code 01
    code = '01';
    //
    if ( this.cardBenifitInfo.productTypeCode === this.reissueCardInfo.product.productNum ) {
      return;
    }
    this.cardBenifitInfo = cardBenifitInfoList.find(cardBenfitInfo => cardBenfitInfo.productTypeCode === code);
  }

  async adjust(): Promise<boolean> {
    const textArea = this.element.nativeElement.getElementsByTagName('textarea')[0];
    let textAreaHeigh = '';
    if (textArea) {
      if (textArea.style.height) {
        // delete word px
          textAreaHeigh = textArea.style.height.substr(0, textArea.style.height.length - 2);
      }
      if ( !textArea.style.height || textAreaHeigh < textArea.scrollHeight) {
         textArea.style.overflow = 'hidden';
        // textArea.style.height = 'auto';
         textArea.style.height = textArea.scrollHeight + 'px';
         textArea.parentNode.style.overflow = 'hidden';
         textArea.parentNode.style.height = textArea.style.height;
      }
    }
    return Promise.resolve(true);
  }

  // becuase Other Address Enum is more than one, and we put it as Array
  // addressCode: is this.ADDRESS_CODE_USER_CHOICE, it can be string or array
  isOtherAddress(addressCode) {
    if (typeof addressCode !== 'string') {
      this.disableEnableOtherAddress();
      return true;
    } else {
      return false;
    }
  }

  disableEnableOtherAddress() {
    if (!this.enableOtherAddress) {
      this.deliverPlaceHolder = this.translate.instant('CAR12841000.LABEL.THERE_IS_NO_SAVE_OTHERS_ADDRESS'); 
      this.pickUpAddressInput.readonly = true;
    } else {
      this.deliverPlaceHolder = this.translate.instant('CAR12841000.LABEL.ENTER_DELIVER_ADDRESS_HERE');  
      this.pickUpAddressInput.readonly = false;
    }
  }

  // Get other addresses type which is not home or business type,
  // And put those other addresses in array
  // This function return array of other addresses
  getOtherAddressEnumValues() {
    // tslint:disable-next-line: no-use-before-declare
    // tslint:disable-next-line: max-line-length
    const values: string[] = Object.keys(ADDRESS_TYPE_CODE).map(key => ADDRESS_TYPE_CODE[key]).filter(
      // tslint:disable-next-line: radix
      k => {
        if (!(parseInt(k) >= 0) && k !== this.HOME_ADDRESS && k !== this.BUSINESS_ADDRESS) {
          return k;
        }
      });
    return values;
  }

  checkexpDate(card: CEB8012ItemsRes): boolean {  
    if ( card.amendAvailableYN === 'Y' as any || card.amendAvailableYN === 'B1' as any ) { 
      return true;
    } else { 
      return false;
    } 
  }

  checkCardTypeFeature() { 
    if ( this.card.cardTypeFeature === 'CreditNobless' as any || this.card.cardTypeFeature == 'CreditPrestigePlus' as any ) { 
      return this.translateCardTypeFeature = this.translate.instant('CAR12000000.LABEL.CREDIT');
    } else if ( this.card.cardTypeFeature != 'CreditNobless' as any && this.card.cardTypeFeature != 'CreditPrestigePlus' as any ) { 
      return this.translateCardTypeFeature =  this.card.cardTypeFeature;
    }
  }

  checkImage() : boolean { 
    if ( this.card.cardTypeFeature == 'CreditPrestigePlus' as any ) { 
      return true;
    } else if ( this.card.cardTypeFeature != 'CreditNobless' as any && this.card.cardTypeFeature != 'CreditPrestigePlus' as any ) { 
      return false;
    }
  }

  // checkCardProductYN() : boolean {
  //   if ( this.card.statusYn === 'Y' as any ) {  
  //     return true;
  //   } else { 
  //     return false;
  //   }
  // }

  reissueYN() { 
    if ( this.card.amendAvailableYN === 'Y' as any || this.card.amendAvailableYN === 'B1' as any ) {  
      this.translateTitle = this.translate.instant('CAR12841000.LABEL.RENEWAL_CARD'); 
    } else { 
      this.translateTitle = this.translate.instant('CAR12841000.LABEL.RE_ISSUE_CARD'); 
    }
  }

  getRenewalReason() {  
    const reqTr = new CEB0311Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.searchKeyword = 'RISSUC_RSCD';
    this.bizServer.bizMOBPost('CEB0311', reqTr).then(data => {
      const resTr = data as CEB0311Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.reissueReasonsList = resTr.body.codeList;   
        this.reissueReasonsList.forEach(element => { 
          if ( element.code === '04' as any ) { 
            this.reissueCardInfo.productReIssue.productNum = element.code;
            this.reissueCardInfo.productReIssue.productName = element.value;
          }    
        }); 
      }
    }); 
  }

}
