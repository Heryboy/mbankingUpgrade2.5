import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car12200000',
  templateUrl: './car12200000.component.html',
  styleUrls: ['./car12200000.component.scss'],
})
export class CAR12200000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
