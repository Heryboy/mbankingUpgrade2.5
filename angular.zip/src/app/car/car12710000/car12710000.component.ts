import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MONTH_KEY_VALUE } from 'src/app/shared/common/data.common';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { SelectService } from 'src/app/shared/services/select.service';
import { CEB7026Req } from 'src/app/shared/TRClass/CEB7026-req';
import { CEB7026Res } from 'src/app/shared/TRClass/CEB7026-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';

@Component({
  selector: 'app-car12710000',
  templateUrl: './car12710000.component.html',
  styleUrls: ['./car12710000.component.scss'],
})

export class CAR12710000Component implements OnInit {
  fee: number;
  currentyCode: string;
  mMvalue: string;
  mMtext: string;
  constructor(
    private bizServer: BizserverService,
    private selectService: SelectService,
    private translate: TranslateService,
    private router: Router,
    private backService: BackService
  ) { }

  ngOnInit() {
    this.doRequestFee();
  }

  ionViewWillEnter() {
    this.backService.subscribe('my_card');
  }

  onClickCancel() {
    this.backService.fire();
  }

  onClickRequest() {
    const data = {
      fee: this.fee,
      currentyCode: this.currentyCode
    };
    DataCenter.set('cardAddVirtual', 'cardAddVirtual', data);
    this.router.navigate(['/card/add-virtual-card']);
  }

  doRequestFee() {
    const reqTr = new CEB7026Req();
    const userInfo                  = Utils.getUserInfo();
    reqTr.body.customerNo           = userInfo.customerNo;
    reqTr.body.userID               = userInfo.userID;

    console.log(reqTr);
    this.fee = 0;
    this.currentyCode = 'USD';
    return;
    //
    this.bizServer.bizMOBPost('CEB7026', reqTr).then(data => {
      const resTr = data as CEB7026Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.fee  = resTr.body.fee;
        this.currentyCode = resTr.body.currencyCode;
      }
    });
  }

  async onClickMM() {
    let optMMList:any[] = [];
    MONTH_KEY_VALUE.forEach(element => {
      optMMList.push({
        text: this.translate.instant(element.key),
        key: this.translate.instant(element.text),
        value: element.value
      });
    });

    const MMObj: SelectBoxOptionModel = {
      title: 'Month', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      ngClass: 'holder',
      items: [
        {
          title: '',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.mMvalue,
          option: optMMList
        }
      ]
    };
    const result = await this.selectService.present(MMObj);
    if (result) {
      this.mMtext = result.text;
      this.mMvalue = result.value;
    }
  }
  
}