import { Component, OnInit, ViewChild } from '@angular/core'; 
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { SelectService } from 'src/app/shared/services/select.service';
import { MONTH_KEY_VALUE } from 'src/app/shared/common/data.common';
import { TranslateService } from '@ngx-translate/core'; 
import { ModalService } from '../../shared/services/modal.service';
import { CAR12816200Component } from '../car12816200/car12816200.component';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { BUTTON_ROLE, CARD_SUBJECT_TYPE_CODE, CARD_PRODUCT_NAME } from 'src/app/shared/constants/common.const';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { CardService } from 'src/app/shared/services/card.service';

export enum DoneClass {
  DONE    = 'done'
}

@Component({
  selector: 'app-car12816100',
  templateUrl: './car12816100.component.html',
  styleUrls: ['./car12816100.component.scss'],
})

export class CAR12816100Component implements OnInit {
  doneExpDate: string; 
  doneCvvCode: string;
  doneNewPIN: string;
  doneConfirmNewPIN: string;
  disabled: boolean;
  disabledCvv = true;
  disabledNewPIN = true;
  disabledConfirmNewPIN = true;
  appAutoFocusCvv: boolean;
  appAutoFocusNewPIN: boolean;
  appAutoFocusConfirmNewPIN: boolean;
  disabledToNext: boolean;
  MMObj: SelectBoxOptionModel;
  YYObj: SelectBoxOptionModel;
  mMvalue: string;
  mMtext: string;
  yYtext: string; 
  cVVCode: string;
  PIN: string;
  confirmPIN: string; 
  cVVCodeFeedback: string;
  PINFeedback: string;
  confirmPINFeedback: string;
  btnNext: string; 
  card = new CEB8012ItemsRes();
  isKeyboardUp: boolean;
  data; 
  creditCard = CARD_SUBJECT_TYPE_CODE.CREDIT;
  debitCard = CARD_SUBJECT_TYPE_CODE.DEBIT; 
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS;
  translateCardTypeFeature: string;
  readonly: boolean;
  @ViewChild('cVVCodeInput'     , {static: true}) cVVCodeInput;
  @ViewChild('confirmCurrentPIN', {static: true}) confirmCurrentPIN;
  @ViewChild('currentPIN'       , {static: true}) currentPIN; 

  constructor( 
    private selectService: SelectService,
    private translate: TranslateService,
    private modalService: ModalService,
    private cardService: CardService
  ) { }

  ngOnInit() {
    this.card = DataCenter.get('card', 'card', false);
    this.btnNext = this.translate.instant('CAR12816100.BUTTON.NEXT');
    this.disabledToNext = false;
    this.doneExpDate = '';
    this.doneCvvCode = '';
    this.doneNewPIN = '';
    this.doneConfirmNewPIN = '';
    this.disabled = true;
    this.disabledCvv = false;
    this.disabledNewPIN = false;
    this.disabledConfirmNewPIN = false;
    this.readonly = true;   
    this.appAutoFocusCvv = true;
    // set button to full screen
    // this.isKeyboardUp = true;
    this.checkCardTypeFeature();
  }

  // set button to full screen when users put cursor in textfields
  onFocus(): void {
    this.isKeyboardUp = true;
  }

  // set button to not full screen when users do not put cursor in textfields
  onBlur(): void {
    this.isKeyboardUp = false;
  }

  onClickCancel() {
    // this.backService.fire();
    this.modalService.dismiss({
      role: BUTTON_ROLE.CANCEL
    });
  }

  async onClickMM() {
    let optMMList:any[] = [];
    MONTH_KEY_VALUE.forEach(element => {
      optMMList.push({
        text: this.translate.instant(element.key),
        key: this.translate.instant(element.text),
        value: element.value
      });
    });
    const MMObj: SelectBoxOptionModel = {
      title: 'Month', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      ngClass: 'holder',
      items: [
        {
          title: '',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.mMvalue,
          option: optMMList
        }
      ]
    };
    const result = await this.selectService.present(MMObj);
    console.log(result);
    if (result) {
      this.mMtext = result.text;
      this.mMvalue = result.value;
      if (this.yYtext) {
        this.disabled = false;
      }
    }
  }

  async onClickYY() {
    const yy  = this.cardService.formatDateYYYY();
    let optYYList: any[] = [];
    for (let i = 0; i <= 10; i++) {
      optYYList.push({
        text: String(yy + i),
        value: String(yy + i)
      });
    }
    const YYObj: SelectBoxOptionModel = {
      title: 'Year', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      ngClass: 'holder',
      items: [
        {
          title: '',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.yYtext,
          option: optYYList
        }
      ]
    };
    const result = await this.selectService.present(YYObj);
    console.log(result);
    if (result) {
        this.yYtext = result.text;
        if (this.mMvalue) {
          this.disabled = false;
        }
    }
  }

  checkNumber(str: string) {
    let code: number, i: number, len: number;
    for (i = 0, len = str.toString().length; i < len; i++) {
      code = str.charCodeAt(i);
      if (!(code > 47 && code < 58)) {
        return false;
      }
    } // numeric (0-9)
    return true;
    // this.formatterService.isNumeric(char);
  }

  ionChangeCVVCode(event) {
    // this.disabled = true;
    // if (this.checkNumber(this.cVVCode)) {
    //   if (this.cVVCode.length === 3) {
    //     this.disabled = false;
    //   }
    // } else {
    //   this.cVVCodeFeedback = this.translate.instant('CAR12816100.LABEL.LAST_THREE_DIGITS_ON_THE_BACK_OF_THE_CARD');
    // }
    if (event) {
      event.target.value = String(event.target.value).substr(0, 3);
      if (String(event.target.value).length === 3) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    }
  }

  ionChangePIN() {
    this.disabled = true;
    if (this.checkNumber(this.PIN)) {
      if (this.PIN.length === 6) {
        this.disabled = false;
      }
    } else {
      this.PINFeedback = this.translate.instant('CAR12816100.LABEL.ENTER_FOUR_DIGITS_PIN_CODE');
    }
  }

  ionChangeConfirmPIN(event) {
    if (event) {
      event.target.value = String(event.target.value).substr(0, 6);
      if (String(event.target.value).length === 6) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    }
  }

  onClickDone(note: string) {
    switch (note) {
      case 'Select_Vaild_Thru_MM':
        this.doneExpDate = '';
        this.doneCvvCode = '';
        this.doneNewPIN = '';
        this.doneConfirmNewPIN = '';
        this.onClickMM();
        break;
      case 'Select_Vaild_Thru_YY':
        this.doneExpDate = '';
        this.doneCvvCode = '';
        this.doneNewPIN = '';
        this.doneConfirmNewPIN = '';
        this.onClickYY();
        break;
      case 'CVV_Code':
        this.doneExpDate = DoneClass.DONE;
        this.doneCvvCode = '';
        this.doneNewPIN = '';
        this.doneConfirmNewPIN = '';
        this.appAutoFocusCvv = true;
        this.appAutoFocusNewPIN = false; 
        this.appAutoFocusConfirmNewPIN = false; 
        break;
      case 'PIN':
        this.doneExpDate = DoneClass.DONE;
        this.doneCvvCode = DoneClass.DONE;
        this.doneNewPIN = '';
        this.doneConfirmNewPIN = '';
        this.appAutoFocusNewPIN = true; 
        this.appAutoFocusCvv = false;
        this.appAutoFocusConfirmNewPIN = false; 
        break;
      case 'Confirm_PIN':
        this.doneExpDate = DoneClass.DONE;
        this.doneCvvCode = DoneClass.DONE;
        this.doneNewPIN = DoneClass.DONE;
        this.doneConfirmNewPIN = '';
        this.appAutoFocusConfirmNewPIN = true; 
        this.appAutoFocusCvv = false;
        this.appAutoFocusNewPIN = false; 
        break;
    }
    this.disabled = false;
    this.disabledToNext = false;
    this.btnNext = this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'); 
  }

  onClickNext() {
    this.nextRole();
  }

  nextRole() {
    this.btnNext = this.translate.instant('CAR12816100.BUTTON.NEXT');
    if (this.yYtext && this.mMvalue) {  
      this.disabled = true; 
      this.doneExpDate = DoneClass.DONE;   
      this.disabledCvv = true;   
      this.readonly = false;   
      this.appAutoFocusNewPIN = false;
      this.appAutoFocusConfirmNewPIN = false; 
      this.appAutoFocusCvv = true;
      if (this.cVVCode) { 
        this.cVVCodeFeedback = undefined;
        this.doneCvvCode = DoneClass.DONE;
        this.disabled = false;
        this.disabledNewPIN = true;  
        this.appAutoFocusCvv = false;
        this.appAutoFocusConfirmNewPIN = false; 
        this.appAutoFocusNewPIN = true;
        if (this.PIN) {
          this.doneNewPIN = DoneClass.DONE;
          this.disabled = true;
          this.appAutoFocusCvv = false;
          this.appAutoFocusNewPIN = false;
          this.disabledConfirmNewPIN = true; 
          this.appAutoFocusConfirmNewPIN = true; 
          if (this.confirmPIN) {
            if (this.checkCurrntPIN() === true ) {
              this.doneConfirmNewPIN = DoneClass.DONE;
              this.disabled = false;
              this.disabledToNext = true;
            }  
          }
        } 
      }
    }
  }

  // Checking on PIN & Confirm-PIN whether they match together or not
  // if the passwords match with each other : let user to next step
  checkCurrntPIN(): boolean {
    if (this.PIN === this.confirmPIN) {
      this.confirmPINFeedback = undefined;
      return true;
    }
    // Show the result of Confirm-PIN whenever it does not match with PIN
    // Result : PIN code does not match. Please try again.
    this.confirmPINFeedback = this.translate.instant('CAR12816100.LABEL.PIN_CODE_INVALID');
    this.disabled = true; 
    return false;
  }

  toNextStep() {
    let data = {
      month      : this.mMvalue,
      year       : this.yYtext.substr(2),
      cVVCode    : this.cVVCode,
      PIN        : this.PIN,
      cardNumber : this.card.cardNumber
    };
    this.modalService.modal({
      component: CAR12816200Component,
      componentProps: { 
        data
      }
    }).then((result) => {});
  }  

  checkCardTypeFeature() { 
    if ( this.card.productNum === '10' as any || this.card.productNum === '20' as any) { 
      return this.translateCardTypeFeature = this.translate.instant('CAR12000000.LABEL.CREDIT');
    } else if ( this.card.productNum != '10' as any && this.card.productNum != '20' as any ) { 
      return this.translateCardTypeFeature = this.card.cardTypeFeature;
    }
  }

  checkHansuang() : boolean { 
    if ( this.card.cardProductName == 'VisaHansarang' as any ) { 
      return true;
    } else { 
      return false;
    }
  }

}
