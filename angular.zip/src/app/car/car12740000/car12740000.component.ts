import { Component, OnInit } from '@angular/core';
import { BackService } from 'src/app/shared/services/back.service';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-car12740000',
  templateUrl: './car12740000.component.html',
  styleUrls: ['./car12740000.component.scss'],
})
export class CAR12740000Component implements OnInit {

  constructor(
    private backSerive: BackService,
    private modalService: ModalService
  ) { }

  ngOnInit() {}
  ionViewWillEnter() {
    this.backSerive.subscribe('my_card');
  }

  onClickOk() {
    this.backSerive.fire();
  }

}
