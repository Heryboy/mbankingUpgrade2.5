import { Component, OnInit } from '@angular/core';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { BUTTON_ROLE, CARD_SUBJECT_TYPE_CODE, CARD_PRODUCT_NAME, CHANNEL } from '../../shared/constants/common.const';
import { BackService } from '../../shared/services/back.service';
import { ModalService } from '../../shared/services/modal.service';
import { DataCenter } from '../../shared/utils/data-center.static';
import { CAR12813000Component } from '../car12813000/car12813000.component';
import { CAR12815100Component } from '../car12815100/car12815100.component';
import { CAR12816100Component } from '../car12816100/car12816100.component';
import { MAC1163A000Component } from 'src/app/opn/mac1163-a000/mac1163-a000.component';
import { Utils } from 'src/app/shared/utils/utils.static';
import * as moment from 'moment';  
import { CEB8113Req } from 'src/app/shared/TRClass/CEB8113-req';
import { CEB8113Res } from 'src/app/shared/TRClass/CEB8113-res';
import { CardService } from 'src/app/shared/services/card.service'; 
import { TranslateService } from '@ngx-translate/core'; 
import { CEB8013Res, CEB8013LimitAmount } from 'src/app/shared/TRClass/CEB8013-res';
import { CEB8013Req } from 'src/app/shared/TRClass/CEB8013-req'; 

@Component({
  selector    : 'app-car12812000',
  templateUrl : './car12812000.component.html',
  styleUrls   : ['./car12812000.component.scss']
})

export class CAR12812000Component implements OnInit { 
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  card = new CEB8012ItemsRes();
  dailyTransactionLimit = new CEB8013Res().body; 
  withdrawalDailyLimit = new CEB8013LimitAmount();  
  listBillingInfo: any[];   
  listInfo: any[];   
  translateCardTypeFeature: string;
  annualFee: string; 
  creditCard = CARD_SUBJECT_TYPE_CODE.CREDIT; 
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS;  
  constructor(
    private modalService: ModalService,
    private backService: BackService,
    private bizServer: BizserverService, 
    private translate: TranslateService,
    private cardService: CardService,
  ) { }

  ngOnInit() {
    this.card = DataCenter.get('card', 'card');  
    // this.dateAfterConverted = this.cardService.formatDateYYYYMM( this.card.expireDateSvfe );
    this.annualFee = this.translate.instant('CAR12811000.LABEL.FREETC');    
    this.paymentInformation();  
    this.getDailyTransactionLimits();
    this.checkCardTypeFeature();
    this.disabledCashAdvance();
  }

  ionViewWillEnter() { 
    const isMyCard = DataCenter.get('my_card', 'my_card');
    const isTransaction = DataCenter.get('card_transaction', 'card_transaction');
    const isBilling = DataCenter.get('card_billing', 'card_billing');
    if ( isMyCard ) { // click from card list  
      this.backService.subscribe('my_card'); 
    } else if ( isTransaction ) { // click from transaction by card
      DataCenter.set('card', 'card', this.card);
      this.backService.subscribe('card_transaction');  
    } else if ( isBilling ) { // click from billing
      DataCenter.set('card', 'card', this.card);
      this.backService.subscribe('card_billing');  
    }
  }

  paymentInformation() {
    const reqTr            = new CEB8113Req();
    const userInfo         = Utils.getUserInfo(); 
    reqTr.body.userID      = userInfo.userID;
    reqTr.body.customerNo  = userInfo.customerNo;
    reqTr.body.accountID   = this.card.accountID;
    reqTr.body.cardNumber  = this.card.cardNumber;  
    this.bizServer.bizMOBPost('CEB8113', reqTr).then(data => {
      const resTr = data as CEB8113Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.listBillingInfo = resTr.body.items;   
        // this.listInfo = this.listBillingInfo.slice(-2); 
        this.listBillingInfo.filter(
          billingInfo => {
            billingInfo.dueDate     = moment(billingInfo.dueDate, 'YYYYMMDD').format('DD');
            billingInfo.invoiceDate = moment(billingInfo.invoiceDate, 'YYYYMMDD').format('DD');
            billingInfo.startDate   = moment(billingInfo.startDate, 'YYYYMMDD').format('DD');
            billingInfo.endDate     = moment(billingInfo.endDate, 'YYYYMMDD').format('DD');
        });    
      }
    });
  }

  async getDailyTransactionLimits() {
    const reqTr = new CEB8013Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.cardNumber = this.card.cardNumber;
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    await this.bizServer.bizMOBPost('CEB8013', reqTr).then(data => {
      const resTr = data as CEB8013Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.dailyTransactionLimit = resTr.body;  
        this.withdrawalDailyLimit  = this.dailyTransactionLimit.withdrawalLimitAmount;   
      }
    });
  } 

  clickBack() { 
    this.backService.fire();
  }

  async doChangeNickname() {
    const myAccount = {
      cardId          : this.card.cardIDSvfe,
      cardNickName    : this.card.cardNickName,
      mode            : 'card',
      cardProductID   : this.card.productId
    };
    const result = await this.modalService.modal({
      component: MAC1163A000Component,
      componentProps: { data: myAccount }
    });
    if (result.role === BUTTON_ROLE.APPLY) {
      this.card.cardNickName = result.data; 
    }
  }

  toChangePin() {
    if ( this.card.cardStatusCodeSvfe === 0 || this.card.cardStatusCodeSvfe === 14 ) { 
      DataCenter.set('card', 'card', this.card);
      this.modalService.modal({
        component: CAR12815100Component,
        componentProps: {
          data: this.card
        }
      }).then((result) => {
      });
    } else { 
      this.cardService.disabledGeneratePIN();
    }
  }

  toViewBenefit() {
    const dataBenefit = { 
      cardProductName : this.card.productName,
      cardTypeCode    : this.card.cardTypeCode
    };
    this.modalService.modal({
     component       : CAR12813000Component,
     componentProps  : { card: dataBenefit }
   });
  }

  onClickToResetPIN() { 
    if ( this.card.cardStatusCodeSvfe === 0 || this.card.cardStatusCodeSvfe === 14 ) { 
      this.toCompleteScreen();
    } else  {
      this.cardService.disabledGeneratePIN();
    }
  }

  toCompleteScreen() { 
    DataCenter.set('card', 'card', this.card);
    this.modalService.modal({
      component: CAR12816100Component,
      componentProps: {
        data: this.card
      }
    }).then((result) => {
    });
  }

  disabledCashAdvance() : boolean {  
    if ( this.card.productNum === 'P0110201000001' as any || this.card.productNum === 'P0110201000201' as any ) { 
      return true;
    }
  }

  checkCardTypeFeature() { 
    if ( this.card.productNum === '10' as any || this.card.productNum === '20' as any) { 
      return this.translateCardTypeFeature = this.translate.instant('CAR12000000.LABEL.CREDIT');
    } else if ( this.card.productNum != '10' as any && this.card.productNum != '20' as any ) { 
      return this.translateCardTypeFeature = this.card.cardTypeFeature;
    }
  } 

}
