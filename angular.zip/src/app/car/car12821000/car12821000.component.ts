import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { BUTTON_ROLE, CHANNEL } from 'src/app/shared/constants/common.const';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { BlockUnblockCardData, CEB8131Req } from 'src/app/shared/TRClass/CEB8131-req';
import { CEB8131Res } from 'src/app/shared/TRClass/CEB8131-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';

@Component({
  selector: 'app-car12821000',
  templateUrl: './car12821000.component.html',
  styleUrls: ['./car12821000.component.scss'],
})
export class CAR12821000Component implements OnInit {
  card = new  CEB8012ItemsRes();
  data = new BlockUnblockCardData();
  content = '';
  completeScreenContent = '';
  blockYN: boolean;
  cVVCode: string;
  readonly: boolean; 
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  focusIndex: number;
  disabledBtn: boolean;
  constructor(
    private translate: TranslateService,
    private modalService: ModalService,
    private authTranService: AuthTransactionService,
    private bizServer: BizserverService,
    private backService: BackService,
    private route: Router,
    ) { }

  ngOnInit() {
    this.initData();
  }

  initData() {
    this.data     = DataCenter.get('CAR12810000', 'blockUnblockCardData', true);
    this.card     = this.data.card;
    this.blockYN  = this.data.blockYN;
    this.setContent();
    if ( this.card.cardBlockYN === 'Y' as any  ) { 
      this.disabledBtn = true;
    } else { 
      this.disabledBtn = false;
    }
  }

  ionViewWillEnter() {
    this.setFocus(1);
    const isMyCard = DataCenter.get('my_card', 'my_card');
    const isTransaction = DataCenter.get('card_transaction', 'card_transaction');
    const isBilling = DataCenter.get('card_billing', 'card_billing');
    if ( isMyCard ) {
      this.backService.subscribe('my_card'); 
    } else if ( isTransaction )  {  
      DataCenter.set('card', 'card', this.card);
      this.backService.subscribe('card_transaction');  
    } else if ( isBilling )  {  
      DataCenter.set('card', 'card', this.card);
      this.backService.subscribe('card_billing');  
    } else if ( this.data ) { 
      this.backService.subscribe('my_card'); 
    }
  } 

  validate() {  
    if ( this.cVVCode.length === 3 ) { 
      this.disabledBtn = false;
    } else { 
      this.disabledBtn = true;
    }
  }
  
  onClickYes() {
    this.requetAuthentication();
  }

  async requetAuthentication() {
    await this.backService.modalService.modal({
      component: SmsAuthenticationComponent,
      componentProps: {
        callback: (res) => {
          if (res) {
            this.transactionID      = res.transactionID;
            this.authenticationCode = res.authenticationCode;
            this.transactionDate    = res.transactionDate;
            this.checkAuthentication();
          }
        }
      }
    });
  }

  checkAuthentication() {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID   = this.transactionID;               // authTransactionID
    reqTr.body.authenticationCode  = this.authenticationCode;          // authenticationCode
    reqTr.body.authTransactionDate = this.transactionDate;             // authTransactionDate
    reqTr.body.channelTypeCode     = CHANNEL.MOB;                      // channelTypeCode
    reqTr.body.customerNo          = Utils.getUserInfo().customerNo;   // customerNo
    reqTr.body.userID              = Utils.getUserInfo().userID;       // userID
    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        if(this.blockYN) {
          this.doRequestForBlockCard();
        } else {
          this.doRequestForUnBlockCard();
        }
      }
    });
  } 

  doRequestForBlockCard() {
    const blockCardRequestData = new CEB8131Req();
    blockCardRequestData.body.authTransactionID = this.transactionID;
    blockCardRequestData.body.authenticationCode = this.authenticationCode;
    blockCardRequestData.body.authTransactionDate = this.transactionDate;
    blockCardRequestData.body.cardId = this.card.cardIDSvfe;
    blockCardRequestData.body.blockPossibleYN = 'Y'; // Y = Block card
    this.doRequestToServer(blockCardRequestData);
  }
  
  doRequestForUnBlockCard() {
    const unblockCardRequestData = new CEB8131Req();
    unblockCardRequestData.body.authTransactionID = this.transactionID;
    unblockCardRequestData.body.authenticationCode = this.authenticationCode;
    unblockCardRequestData.body.authTransactionDate = this.transactionDate;
    unblockCardRequestData.body.cardId = this.card.cardIDSvfe;
    unblockCardRequestData.body.cvv = this.cVVCode;
    unblockCardRequestData.body.validThru = this.data.card.expireDateSvfe;
    unblockCardRequestData.body.blockPossibleYN = 'N'; // N = UnBlock card
    this.doRequestToServer(unblockCardRequestData);
  }

  doRequestToServer(reqTr: CEB8131Req) {
    this.bizServer.bizMOBPost('CEB8131', reqTr).then(data => {
      const resTr = data as CEB8131Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.toCompleteScreen();
      }
    });
  }

  async toCompleteScreen() {
    this.modalService.dismissAll({
      role: BUTTON_ROLE.CLOSE
    });
    this.data.completeScreenContent = this.completeScreenContent;
    DataCenter.set('data', 'data', this.data.completeScreenContent);
    this.route.navigate(['/card/block-card-result']);
    // const res = await this.modalService.modal({
    //   component       : CAR12822000Component,
    //   componentProps  : { data: this.data }
    // });
    // if (res.role === BUTTON_ROLE.OK) {
    //   this.route.navigateByUrl(this.data.previouScreen);
    // } 
  }

  setContent() {
    if(this.blockYN) {
      this.content = this.translate.instant('CAR12821000.LABEL.DO_YOU_WANT_TO_BLOCK_THIS_CARD');
      this.completeScreenContent = this.translate.instant('CAR12822000.LABEL.BLOCK_CARD');
    } else {
      this.content = this.translate.instant('CAR12821000.LABEL.DO_YOU_WANT_TO_UNBLOCK_THIS_CARD');
      this.completeScreenContent = this.translate.instant('CAR12822000.LABEL.UNBLOCK_CARD');
    }
  }

  setFocus(index: number) {
    this.focusIndex = index;
  }

  cardBlockYN (card: CEB8012ItemsRes): boolean {
    return card.cardBlockYN === 'Y' as any;
  }

  onClickNo() { 
    // this.modalService.dismiss({  
    //   role: BUTTON_ROLE.CLOSE 
    // });
    this.backService.fire();
  }
  
}
