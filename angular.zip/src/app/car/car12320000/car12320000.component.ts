import { Component, OnInit, ViewChild } from '@angular/core';
import { DataCommon } from 'src/app/shared/common/data.common';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { CardTransactionLimitAmountServices } from 'src/app/shared/services/check-card-transfer-limit.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB8121Req } from 'src/app/shared/TRClass/CEB8121-req';
import { CAR12330000Component } from '../car12330000/car12330000.component';
import { TranslateService } from '@ngx-translate/core'; 

@Component({
  selector: 'app-car12320000',
  templateUrl: './car12320000.component.html',
  styleUrls: ['./car12320000.component.scss'],
})
export class CAR12320000Component implements OnInit {
  requestAmount: number;
  data = new CEB8121Req().confirmData; 
  availableAmount: number;
  currencyCode: string;
  interestRate: number;
  fee = 0;
  keyboardup: string;
  exceedAvailableAmountYN = false;
  diableBtnNext = true;
  accountTransferLimit: any;
  joinAccountYN: any; 
  dailyCashAdvanceTransaction: number;
  minimumAmount: number;
  @ViewChild('inputAmount', { static: true }) inputAmount;
  constructor(
    private modealService: ModalService,
    private formatterService: FormatterService,
    private cardTransaction: CardTransactionLimitAmountServices,
    private translate: TranslateService,
    private modalService: ModalService,
  ) { }

  async ngOnInit() {
    this.minimumAmount = 5;
    this.availableAmount = this.data.availableAmount;
    this.currencyCode = this.data.card.currencyCode; 
    this.focusInputAmount();   
  }

  async ionViewWillEnter() {
    setTimeout(() => {
      this.inputAmount.setFocus();
    }, 200);
  }

  focusInputAmount() {
    this.keyboardup = 'keyboardup';
  }

  async onNext() {
    this.data.requestAmount = this.requestAmount ? DataCommon.unFormatNumber(this.requestAmount.toString()) : this.requestAmount;
    const exceedCashAdvaceLimitYN = await this.cardTransaction.checkCashAdvanceLimitAmount(this.data.requestAmount, this.getCashAdvanceLimitTransaction());

    if (!exceedCashAdvaceLimitYN) {
      this.modealService.modal({
        component: CAR12330000Component,
        componentProps: {
          data: this.data
        }
      });
    }

    // if ( this.data.requestAmount <= 5 ) { 
    //   let amountMinimum;
    //   await this.translate.get(
    //     'CAR12320000.LABEL.CASH_ADVANCE_AMOUNT_MINIMUM',
    //     {
    //       minimumAmount: this.formatterService.formatCurrency(5, 'blur', 'USD').text,
    //       currencyCode: this.data.card.currencyCode
    //     }
    //   ).subscribe((res) => {
    //     amountMinimum = res;
    //     this.modalService.alert({
    //       content: amountMinimum,
    //       btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
    //       callback: (res: any) => {
    //         if (res) {
    //           console.log(res);
    //         }
    //       }
    //     });
    //   });
    // } else { 
    //   if (!exceedCashAdvaceLimitYN) {
    //     this.modealService.modal({
    //       component: CAR12330000Component,
    //       componentProps: {
    //         data: this.data
    //       }
    //     });
    //   }
    // }
  }

  ionChangeAmount(event, even: 'blur' | 'focus' | 'keyup') {
    this.formateAmount(event, even);
    this.validate();
  }

  validate() {
    const amount = this.requestAmount ? DataCommon.unFormatNumber(this.requestAmount.toString()) : this.requestAmount;
    this.exceedAvailableAmountYN = amount > this.availableAmount ? true : false;  // if ExceedAvailableAmount -> True , else -> false
    console.log("TRUE OR FALSE", this.exceedAvailableAmountYN);
    this.diableBtnNext = this.exceedAvailableAmountYN || amount <= 0;
  }

  formateAmount(event, even: 'blur' | 'focus' | 'keyup') {
    this.formatterService.formatCurrency(event, even, this.currencyCode as any);
  }

  onClickCancel() {
    this.modealService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

  // TODO
  getCashAdvanceLimitTransaction() {
    //     if ( this.requestAmount > this.availableAmount ) {
    //       this.modealService.alert({
    //         content: this.translate.instant('CARD_COMMON.MESSAGE.EXCEEDED_AVAILABLE_AMOUNT_LIMIT',
    //                   {availableAmount: this.availableAmount}),
    //         });
    //       } else {
    //         return this.requestAmount;
    //       // return 10000;
    //     }
    return this.requestAmount;
  }

}