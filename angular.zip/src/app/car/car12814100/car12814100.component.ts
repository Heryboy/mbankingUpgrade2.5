import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DataCommon } from 'src/app/shared/common/data.common';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB3311ItemsRes } from 'src/app/shared/TRClass/CEB3311-res';
import { CEB8013LimitAmount, CEB8013Res } from 'src/app/shared/TRClass/CEB8013-res';
import { DataformatService } from '../../shared/services/dataformat.service';
import { CAR12814200Component } from '../car12814200/car12814200.component';

export enum LimitType {
  PURCHASE    = 'purchase',
  WITHDRAWAL  = 'withdrawal',
  TRANSFER    = 'transfer'
}

export enum LimitHTMLClass {
  DONE    = 'done'
}

@Component({
  selector: 'app-car12814100',
  templateUrl: './car12814100.component.html',
  styleUrls: ['./car12814100.component.scss'],
})

export class CAR12814100Component implements OnInit {
  donePurchaseLimit: string;
  doneWithdrawalLimit: string;
  doneTransferLimit: string;
  purchaseDailyLimit    = new CEB8013LimitAmount();
  transferDailyLimit    = new CEB8013LimitAmount();
  withdrawalDailyLimit  = new CEB8013LimitAmount();
  purchaseLimitMaxTranslate: string;
  withdrawalLimitMaxTranslate: string;
  transferLimitMaxTranslate: string;
  buttonTranslate: 'CARD_COMMON.BUTTON.NEXT';
  LimitType = LimitType;
  showNextButtonYN: boolean;
  purchaseExceededError: string;
  withdrawalExceededError: string;
  transferExceededError: string;
  errorYN: boolean;
  overMax: boolean;
  data = new CEB8013Res().body;
  card: any;
  purchaseDailyLimitMax    = new CEB8013LimitAmount();
  transferDailyLimitMax    = new CEB8013LimitAmount();
  withdrawalDailyLimitMax  = new CEB8013LimitAmount();
  item: CEB3311ItemsRes;
  itemOriginal: CEB3311ItemsRes;
  isKeyboardUp: boolean;
  input = {
    transactionLimitAmount: ''
  };
  focusIndex: number;
  @ViewChild('purchaseLimitInput'  ,   {static: true}) purchaseLimitInput;
  @ViewChild('withdrawalLimitInput',   {static: true}) withdrawalLimitInput;
  @ViewChild('transferLimitInput'  ,   {static: true}) transferLimitInput;

  constructor(
    private modalService: ModalService,
    private translate: TranslateService,
    private dataformatService: DataformatService,
    private formatterService: FormatterService,
  ) { }

  ngOnInit() {
    this.getData();
    // view all fields
    this.resetHTMLClass();

    // set button to full screen
    this.isKeyboardUp = true;    
  }

  getData() {
    this.purchaseDailyLimit   = this.data.purchaseLimitAmount;
    this.withdrawalDailyLimit = this.data.withdrawalLimitAmount;
    this.transferDailyLimit   = this.data.transferLimitAmount;

    // this.purchaseDailyLimit     = this.dataformatService.formatMoney(this.data.purchaseLimitAmount.amount, 
    //                       this.data.purchaseLimitAmount.currencyCode) as any;
    // this.withdrawalDailyLimit   = this.dataformatService.formatMoney(this.data.withdrawalLimitAmount.amount,
    //                       this.data.withdrawalLimitAmount.currencyCode) as any;
    // this.transferDailyLimit     = this.dataformatService.formatMoney(this.data.transferLimitAmount.amount, 
    //                       this.data.transferLimitAmount.currencyCode) as any;

    this.purchaseDailyLimitMax   = Object.assign([], this.data.purchaseLimitAmount);
    this.withdrawalDailyLimitMax =  Object.assign([], this.data.withdrawalLimitAmount);
    this.transferDailyLimitMax   =  Object.assign([], this.data.transferLimitAmount);
    this.setLimitMaxTranslation();
  }

  setLimitMaxTranslation() {
    // translate & format from en file in each label
    this.purchaseLimitMaxTranslate = this.translateLimitAmount('CAR12814100.LABEL.PURCHASE_LIMIT', 
                                  this.purchaseDailyLimitMax.allowMaxLimit, 
                                  this.purchaseDailyLimitMax.currencyCode ? this.purchaseDailyLimitMax.currencyCode : 'USD' );

    this.withdrawalLimitMaxTranslate = this.translateLimitAmount('CAR12814100.LABEL.WITHDRAWAL_LIMIT',
                                  this.withdrawalDailyLimitMax.allowMaxLimit,
                                  this.withdrawalDailyLimitMax.currencyCode ? this.withdrawalDailyLimitMax.currencyCode : 'USD' );

    this.transferLimitMaxTranslate = this.translateLimitAmount('CAR12814100.LABEL.TRANSFER_LIMIT',
                                  this.transferDailyLimitMax.allowMaxLimit,
                                  this.transferDailyLimitMax.currencyCode ? this.transferDailyLimitMax.currencyCode : 'USD' );
  }

  translateLimitAmount(translateKey: string, limitAmount: number, currencyCode: string): string | any{
    return this.translate.instant(translateKey, {
        LimitAmount: this.dataformatService.formatMoney(limitAmount, currencyCode),
        currencyCode: currencyCode
    });
  }

  exceededLimitErrorYN(limitType: LimitType): boolean {
    this.purchaseExceededError   = '';
    this.withdrawalExceededError = '';
    this.transferExceededError   = '';
    let amount = 0;
    this.showNextButtonYN        = false;
    switch (limitType) {
      case LimitType.PURCHASE:{
        amount = this.purchaseDailyLimit.amount ? DataCommon.unFormatNumber(this.purchaseDailyLimit.amount) : this.purchaseDailyLimit.amount;
        this.setErrorAndOverMaxAndShowNexButton(amount, this.purchaseDailyLimitMax.allowMaxLimit);
        this.purchaseExceededError = this.overMax ? 'CAR12814100.LABEL.EXCEEDED_PURCHASE_LIMIT' : '';
        break;
      }        
      case LimitType.WITHDRAWAL:{
        amount = this.withdrawalDailyLimit.amount ? DataCommon.unFormatNumber(this.withdrawalDailyLimit.amount) : this.withdrawalDailyLimit.amount;
        this.setErrorAndOverMaxAndShowNexButton(amount, this.withdrawalDailyLimitMax.allowMaxLimit);
        this.withdrawalExceededError = this.overMax ? 'CAR12814100.LABEL.EXCEEDED_WITHDRAWAL_LIMIT' : '';
        break;
      }
      case LimitType.TRANSFER:{
        amount = this.transferDailyLimit.amount ? DataCommon.unFormatNumber(this.transferDailyLimit.amount) : this.transferDailyLimit.amount;
        this.setErrorAndOverMaxAndShowNexButton(amount, this.transferDailyLimitMax.allowMaxLimit);
        this.transferExceededError = this.overMax ? 'CAR12814100.LABEL.EXCEEDED_TRANSFER_LIMIT' : '';
        this.showNextButtonYN = !(this.overMax || this.errorYN);
        break;
      }
    }
    return this.errorYN;
  }

  setErrorAndOverMaxAndShowNexButton(amount, maxAmount) {
    this.overMax = amount > maxAmount;
    this.errorYN = (!amount && amount !== 0) || this.overMax;
  }

  // whenever users focus on selected field 
  // it will delete the last two numbers from the amount of any user *,***.00
  // but whenever *,***.10 : it will not delete the last two numbers
  onFocus(event, dailyLimit: CEB8013LimitAmount, limitType: LimitType) :void {
    this.exceededLimitErrorYN(limitType);
    // this.focusIndex = 1;
    // this.isKeyboardUp = true;
    // this.formatterService.formatCurrency(event, 'focus', dailyLimit.currencyCode as any);
  }

  // whenever users take out the cursor from selected field
  // it will add the last two numbers from the amount of any user *,***.00
  onBlur(event, dailyLimit: CEB8013LimitAmount) {
    this.isKeyboardUp = false;
    const data = this.formatterService.formatCurrency(event, 'blur', dailyLimit.currencyCode as any);
    if (data) {
      this.input.transactionLimitAmount = this.dataformatService.formatMoney(data.value, dailyLimit.currencyCode);
    }
  }

  onKeyUp(event, dailyLimit: CEB8013LimitAmount) {
    this.formatterService.formatCurrency(event, 'keyup', dailyLimit.currencyCode as any);
  }

  onClickLimitInput(limitType: LimitType) {    
    switch (limitType) {
      case LimitType.PURCHASE:
        this.donePurchaseLimit = '';
        this.doneWithdrawalLimit = '';
        this.doneTransferLimit = '';
        this.purchaseLimitInput.setFocus();
        break;
      case LimitType.WITHDRAWAL:
        this.donePurchaseLimit = LimitHTMLClass.DONE;;
        this.doneWithdrawalLimit = '';
        this.doneTransferLimit = '';
        this.withdrawalLimitInput.setFocus();
        break;
      case LimitType.TRANSFER:
        this.donePurchaseLimit = LimitHTMLClass.DONE;;
        this.doneWithdrawalLimit = LimitHTMLClass.DONE;;
        this.doneTransferLimit = '';
        this.transferLimitInput.setFocus();
        break;
    }
    this.errorYN = false;
    this.showNextButtonYN = false;
    // this.btnNext = this.translate.instant('CARD_COMMON.BUTTON.CONFIRM');
  }

  onClickConfirmToNextLimit() {
    this.checkDonePurchaseLimitYN();
    this.checkDoneWithdrawalLimitYN();
    this.checkDoneTransferLimitYN();
  }

  checkDonePurchaseLimitYN(): boolean {
    if (this.purchaseDailyLimit.amount) {
      this.donePurchaseLimit = LimitHTMLClass.DONE;
      this.withdrawalLimitInput.setFocus();
      return true;
    }
    return false;
  }

  checkDoneWithdrawalLimitYN(): boolean{
    if (this.purchaseDailyLimit.amount && this.withdrawalDailyLimit.amount) {
      this.doneWithdrawalLimit = LimitHTMLClass.DONE;
      this.transferLimitInput.setFocus();
      return true;
    }
    return false;
  }

  // we show button next when the last input (TransferLimit) have valid data
  checkDoneTransferLimitYN(){
    this.errorYN = true;
    this.showNextButtonYN = false;
    if (this.purchaseDailyLimit.amount && this.withdrawalDailyLimit.amount && this.transferDailyLimit.amount) {
      this.errorYN = false; // set this to false for enable next button, so that can request to next screen
      this.showNextButtonYN = true;
    }
    return this.showNextButtonYN;
  }

  // view all inputs
  resetHTMLClass() {
    this.donePurchaseLimit = LimitHTMLClass.DONE;
    this.doneWithdrawalLimit = LimitHTMLClass.DONE;
    this.doneTransferLimit = LimitHTMLClass.DONE;
  }

  onNextScreen() { 
    // check for not allowing using go to next screen if over limit 
    if ( this.exceededLimitErrorYN(LimitType.PURCHASE) ) {  
      this.donePurchaseLimit = '';
      this.doneWithdrawalLimit = '';
      this.doneTransferLimit = '';
      this.purchaseLimitInput.setFocus();
      return; 
    } else if ( this.exceededLimitErrorYN(LimitType.WITHDRAWAL) ) { 
      this.doneWithdrawalLimit = '';
      this.doneTransferLimit = ''; 
      this.withdrawalLimitInput.setFocus();
      return; 
    } else if ( this.exceededLimitErrorYN(LimitType.TRANSFER) ) { 
      this.doneTransferLimit = '';
      this.transferLimitInput.setFocus();
      return; 
    }
    let data = {
      purchaseLimit           : DataCommon.unFormatNumber(this.purchaseDailyLimit.amount as any),
      withdrawalLimit         : DataCommon.unFormatNumber(this.withdrawalDailyLimit.amount as any),
      transferLimit           : DataCommon.unFormatNumber(this.transferDailyLimit.amount as any),
      purchaseLimitTypeCode   : this.purchaseDailyLimit.limitTypeCode,
      withdrawalLimitCode     : this.withdrawalDailyLimit.limitTypeCode,
      transferLimitTypeCode   : this.transferDailyLimit.limitTypeCode,
      currencyCode            : this.card.currencyCode,
      cardIDSvfe              : this.card.cardIDSvfe,
      expDate                 : this.card.expireDateSvfe
    };

    this.modalService.modal({
      component: CAR12814200Component,
      componentProps: {
        data
      }
    }).then((result) => {
      if (result) {
        console.log('data: ' + result);
      }
    });
  }

  onClickCancel() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CANCEL
    });
  }

}
