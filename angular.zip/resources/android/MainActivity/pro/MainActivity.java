package kh.com.ppcbank.mbanking2p;

 
//implementation "com.google.firebase:firebase-analytics:15.0.0"
/* 

       Licensed to the Apache Software Foundation (ASF) under one 

       or more contributor license agreements.  See the NOTICE file 

       distributed with this work for additional information 

       regarding copyright ownership.  The ASF licenses this file 

       to you under the Apache License, Version 2.0 (the 

       "License"); you may not use this file except in compliance 

       with the License.  You may obtain a copy of the License at 

 
 

         http://www.apache.org/licenses/LICENSE-2.0 

 
 

       Unless required by applicable law or agreed to in writing, 

       software distributed under the License is distributed on an 

       "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY 

       KIND, either express or implied.  See the License for the 

       specific language governing permissions and limitations 

       under the License. 

 */










import android.app.Application;

import android.content.BroadcastReceiver;

import android.content.Context;

import android.content.DialogInterface;

import android.content.Intent;

import android.content.IntentFilter;

import android.content.res.AssetManager;

import android.net.Uri;

import android.os.Bundle;

import android.support.v4.content.LocalBroadcastManager;

import android.text.TextUtils;

import android.util.Log;




import com.google.android.gms.common.GoogleApiAvailability;

import com.google.android.gms.security.ProviderInstaller;




import org.apache.cordova.CordovaActivity;

import org.json.JSONException;

import org.json.JSONObject;




import java.io.File;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.io.OutputStream;

import com.google.firebase.analytics.FirebaseAnalytics;


public class MainActivity extends CordovaActivity implements ProviderInstaller.ProviderInstallListener {

    private BroadcastReceiver receiver;




    private static final int ERROR_DIALOG_REQUEST_CODE = 1;




    private boolean retryProviderInstall;




    private String assetFolderPath = "www";

    private String assetBackPath = "";




    private String copyFolderPath = "";

    private String copyBackPath = "";

    private FirebaseAnalytics mFirebaseAnalytics;


    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        ProviderInstaller.installIfNeededAsync(this, this);




        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver, new IntentFilter("refresh_activity"));


        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        // enable Cordova apps to be started in the background 

        Bundle extras = getIntent().getExtras();

        if (extras != null && extras.getBoolean("cdvStartInBackground", false)) {

            moveTaskToBack(true);

        }




        // Set by <content src="index.html" /> in config.xml 

//        loadUrl(launchUrl); 




        if (launchUrl.startsWith("http://localhost:8100")) {

            loadUrl(launchUrl);

        } else {

            runOnUiThread(new Runnable() {

                @Override

                public void run() {

                    String externalUrl = getFilesDir().getParent() + "/www/index.html";

                    Log.e("externalUrl", externalUrl);

                    File file = new File(externalUrl);

                    Log.e("file exist", String.valueOf(file.exists()));

                    if (file.exists()) {

                        loadUrl("file://" + externalUrl);

                    } else {

                        String copyPath = getFilesDir().getParent() + "/www";

                        copyFolderPath = copyPath;

                        copyAssets(copyFolderPath, assetFolderPath);

                        loadUrl("file://" + externalUrl);

                    }

                }

            });

        }

        onJSMessage();




    }




    private void upgradeSecurityProvider() {

        ProviderInstaller.installIfNeededAsync(this, new ProviderInstaller.ProviderInstallListener() {

            @Override

            public void onProviderInstalled() {

                Log.i("ProviderInstalled","onProviderInstalled");

            }




            @Override

            public void onProviderInstallFailed(int errorCode, Intent recoveryIntent) {

                Log.i("ProviderInstallFailed", "onProviderInstallFailed");

                GoogleApiAvailability.getInstance().showErrorNotification(getApplicationContext(),errorCode);

            }

        });

    }




    // Subcribe 

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {

        @Override

        public void onReceive(Context context, Intent intent) {




            if(appView != null) {

                appView.clearCache();

                appView.clearHistory();

            }




            runOnUiThread(new Runnable() {

                @Override

                public void run() {

                    String externalUrl = getFilesDir().getParent() + "/www/index.html";

                    Log.e("externalUrl", externalUrl);

                    File file = new File(externalUrl);

                    Log.e("file exist", String.valueOf(file.exists()));

                    if (file.exists()) {

                        loadUrl("file://" + externalUrl);

                    }

                }

            });

        }

    };







    public void copyAssets(String copyPath, String copyAssetListName) {

        AssetManager assetManager = getAssets();

        String[] files = null;

        try {




            files = assetManager.list(copyAssetListName);

            //assetFolderPath = copyAssetListName; 

            Log.e(TAG, "copyAssetListName : " + copyAssetListName);

            Log.e(TAG, "copyPath : " + copyPath);




        } catch (IOException e) {

            Log.e("tag", "Failed to get asset file list.", e);

        }




        for(String filename : files) {

            InputStream in = null;

            OutputStream out = null;

            try {




                File dir = new File(copyPath);

                if (!dir.exists()) {

                    dir.mkdir();

                }




                in = assetManager.open(copyAssetListName + "/" + filename);

                File outFile = new File(copyPath +"/", filename);

                out = new FileOutputStream(outFile);

                copyFile(in, out);

                in.close();

                in = null;

                out.flush();

                out.close();

                out = null;

            } catch (FileNotFoundException e) {

                assetFolderPath = copyAssetListName;

                copyFolderPath = copyPath;




                assetBackPath = assetFolderPath;

                copyBackPath = copyFolderPath;




                String folder = assetFolderPath + "/" + filename;

                String path = copyFolderPath + "/" + filename;

                copyAssets(path, folder);

                assetFolderPath = assetBackPath;

                copyFolderPath = copyBackPath;

            } catch(IOException e) {

                Log.e("tag", "Failed to copy asset file: " + filename, e);

            }

        }

    }




    public void copyFile(InputStream in, OutputStream out) throws IOException {

        byte[] buffer = new byte[1024];

        int read;

        while((read = in.read(buffer)) != -1){

            out.write(buffer, 0, read);

        }

    }




    public void onJSMessage() {

        receiver = new BroadcastReceiver() {

            @Override

            public void onReceive(Context context, Intent intent) {

                final Bundle extras = intent.getExtras();




                Log.d("CDVBroadcaster", String.format("Native event [%s] received with data [%s]", intent.getAction(), String.valueOf(extras)));




                JSONObject externalData = getExternalData();

                if (externalData != null) {

                    Log.e("MainActivity", "externalData : " + externalData);

                    try {

                        sendJSMessage(externalData);

                    } catch (JSONException e) {

                        e.printStackTrace();

                    }

                }




            }

        };




        LocalBroadcastManager.getInstance(this)

                .registerReceiver(receiver, new IntentFilter("init"));



    }



    public void sendJSMessage(JSONObject externalData) throws JSONException {

        final String eventName = externalData.getString("eventName");

        final Intent intent = new Intent(eventName);




        Bundle b = new Bundle();

        b.putString( "data", externalData.toString());

        intent.putExtras( b);




        LocalBroadcastManager.getInstance(this).sendBroadcastSync(intent);

    }




    public JSONObject getExternalData() {

        JSONObject callbackData = null;

        Intent intent = getIntent();

        try {

            if (intent != null) {

                if (!TextUtils.isEmpty(intent.getAction()) && intent.getAction().equals(Intent.ACTION_VIEW)) {

                    // 숏컷을 통해서 들어온 경우 

                    Uri uri = intent.getData();

                    String uriString = uri.toString();




                    if (uriString.startsWith("shortcuts://")) {

                        String param = uri.getQueryParameter("shortcut_data");

                        callbackData = new JSONObject(param);

                        callbackData.put("eventName","shortcutpress");

                    }

                } else if (intent.hasExtra("external_data")) {

                    // 푸시를 통해 들어온 경우 

                    callbackData = new JSONObject(intent.getStringExtra("external_data"));

                    callbackData.put("eventName","push");

                }

            }

        } catch (Exception e) {

            e.printStackTrace();

        }




        return callbackData;

    }




    @Override

    public void onDestroy() {

        super.onDestroy();

        if (null != this.receiver){

            LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);

        }

        if (null != this.mMessageReceiver) {

            LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);

        }

    }




    // Missing Google Play Services Updated Security Provider 

    @Override

    public void onProviderInstalled() {

        // Provider is up-to-date, app can make secure network calls. 

    }




    @Override

    public void onProviderInstallFailed(int i, Intent intent) {

        GoogleApiAvailability availability = GoogleApiAvailability.getInstance();

        if (availability.isUserResolvableError(i)) {

            // Recoverable error. Show a dialog prompting the user to 

            // install/update/enable Google Play services. 

            availability.showErrorDialogFragment(

                    this,

                    i,

                    ERROR_DIALOG_REQUEST_CODE,

                    new DialogInterface.OnCancelListener() {

                        @Override

                        public void onCancel(DialogInterface dialog) {

                            // The user chose not to take the recovery action 

                            onProviderInstallerNotAvailable();

                        }

                    });

        } else {

            // Google Play services is not available. 

            onProviderInstallerNotAvailable();

        }

    }




    @Override

    protected void onActivityResult(int requestCode, int resultCode,

                                    Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ERROR_DIALOG_REQUEST_CODE) {

            // Adding a fragment via GoogleApiAvailability.showErrorDialogFragment 

            // before the instance state is restored throws an error. So instead, 

            // set a flag here, which will cause the fragment to delay until 

            // onPostResume. 

            retryProviderInstall = true;

        }

    }




    /**

     * On resume, check to see if we flagged that we need to reinstall the 

     * provider. 

     */

    @Override

    protected void onPostResume() {

        super.onPostResume();

        if (retryProviderInstall) {

            // We can now safely retry installation. 

            ProviderInstaller.installIfNeededAsync(this, this);

        }

        retryProviderInstall = false;

    }




    private void onProviderInstallerNotAvailable() {

        // This is reached if the provider cannot be updated for some reason. 

        // App should consider all HTTP communication to be vulnerable, and take 

        // appropriate action. 

    }

} 

 