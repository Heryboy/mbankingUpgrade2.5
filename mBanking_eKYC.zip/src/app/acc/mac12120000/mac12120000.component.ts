import { Component, Input, OnInit } from '@angular/core';
import { BUTTON_ROLE } from '../../shared/constants/common.const';

@Component({
  selector: 'app-mac12120000',
  templateUrl: './mac12120000.component.html',
  styleUrls: ['./mac12120000.component.scss'],
})
export class MAC12120000Component implements OnInit {
  @Input() data: any;
  @Input() modal: any;
  debitCreditTypeCode: '' | 'CR' | 'DR';

  constructor(
  ) { }

  ngOnInit() {
    this.data = this.modal.message.data;
    if (this.data) {
      this.debitCreditTypeCode = this.data.debitCreditTypeCode as any;
    }
  }
  btnCloseClicked() {
    this.modal.close({ role: BUTTON_ROLE.CLOSE });
  }

  btnApplyClicked() {
    const debitCreditTypeCode = this.debitCreditTypeCode;
    const data: any = {
      debitCreditTypeCode
    };
    this.modal.close({ role: BUTTON_ROLE.APPLY, data });
  }
}
