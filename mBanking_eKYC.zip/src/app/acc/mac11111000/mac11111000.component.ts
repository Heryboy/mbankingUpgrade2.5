import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonInfiniteScroll } from '@ionic/angular';
import { AccountCardModel } from 'src/app/acc/mac11000000/mac11000000.model';
import { DateRange } from 'src/app/shared/component/filter/filter.model';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB2212Req } from 'src/app/shared/TRClass/CEB2212-req';
import { CEB2212ItemsRes, CEB2212Res } from 'src/app/shared/TRClass/CEB2212-res';
import { Utils } from 'src/app/shared/utils/utils.static';
import { FormatterPipe } from '../../shared/pipes/formatter.pipe';
import { SearchService } from '../../shared/services/search.service';
import { Util } from '../../shared/util';
import { MAC11140000Component } from '../mac11140000/mac11140000.component';
import { InquiryTransactionType, InquiryTransactionTypeCode } from './mac11111000.model';
import { TransactionService } from './mac11111000.service';

@Component({
  selector: 'app-mac11111000',
  templateUrl: './mac11111000.component.html',
  styleUrls: ['./mac11111000.component.scss'],
})
export class MAC11111000Component implements OnInit {

    @ViewChild(IonInfiniteScroll, {static: true}) ionInfiniteScroll: IonInfiniteScroll;


    changeTitle = false;
    util = new Util();
    segmentCategoryTab: InquiryTransactionType;
    transactionList: CEB2212ItemsRes[] = []; // default transactionList
    displayTransactionList: CEB2212ItemsRes[]; // transactionList after search
    narResultStatus = 'R';
    noHistory: boolean;
    account: AccountCardModel;
    totalTransactionAmount: number;
    // totalTransactionCurrency = 'USD';
    reqTr: CEB2212Req;
    fromDate: string;
    toDate: string;
    filter: InquiryTransactionTypeCode;
    currentPageNo = 1;
    readonly pageSize = 10;
    readonly searchFields = ['branchName', 'transactionReasonDesc', 'phoneNumber', 'payonCardNo'];
    searchKey = '';
    currencyUSD = 'USD';
    // avoid dub req
    ongoingRequest: boolean;
    pendingRequest: boolean;
    isPersonal: boolean;

    constructor(private transactionService: TransactionService,
                private bizServer: BizserverService,
                private router: Router,
                private formatterPipe: FormatterPipe,
                private modalService: ModalService,
                private searchService: SearchService,
                private backService: BackService,
    ) {
        this.setCategoryTab('all');
        this.filter = new InquiryTransactionTypeCode();
        this.setRequestBody(true);
        this.transactionService.setModal(this.modalService);
    }

    ngOnInit() {
        this.isPersonal = Utils.personalAccount();
    }

    ionViewWillEnter() {
        this.backService.subscribe('my_account');
    }

    onScrollHandler(event: any) {
        // console.log(event.detail.scrollTop);
        if (event.detail.scrollTop < 88 ) {
            this.changeTitle = false;
        } else {
            this.changeTitle = true;
        }
    }

    setSelectedAccount(account: AccountCardModel) {
        this.account = account;
        if (this.fromDate && this.toDate) { // sync init request with dateFilterChanged event.
            this.renewRequest();
        }
    }

    setRequestBody(init?: boolean) { // set request transaction list
        if (init) {
            this.reqTr = new CEB2212Req();
            Utils.setUserInfoTo(this.reqTr.body);
            this.reqTr.body.businessCode = 'PDP';
            this.reqTr.body.pageSize = this.pageSize;
        } else {
            this.reqTr.body.accountNo = this.account.accountNo;
            const filter = this.filter.get(this.segmentCategoryTab);
            this.reqTr.body.debitCreditTypeCode = filter.debitCreditTypeCode;
            this.reqTr.body.inquiryTransactionTypeCode = filter.inquiryTransactionTypeCode;
            this.reqTr.body.inquiryTransferTransactionTypeCode = filter.inquiryTransferTransactionTypeCode;
            this.reqTr.body.pageNumber = this.currentPageNo;
            this.reqTr.body.fromDate = this.fromDate;
            this.reqTr.body.toDate = this.toDate;
        }
    }

    setCategoryTab(value: InquiryTransactionType) {
        const test = ['all', 'transfer', 'payment', 'topup'].includes(value);
        if (test) {
            this.segmentCategoryTab = value;
        } else {
            console.log('setCategoryTab failed on value', value);
        }
    }

    setTransactionList(list: CEB2212ItemsRes[]) {
        if (list.length === 0) { // no records.
            this.ionInfiniteScroll.disabled = true;
            if (this.transactionList.length === 0) {
                this.noHistory = true;
            }
            return;
        } else if (list.length < this.pageSize) { // last records.
            this.ionInfiniteScroll.disabled = true;
        }
        this.preFormatTextTransactions(list); // spp search function.
        this.transactionList = [...this.transactionList, ...list];
        this.refreshDisplayTransactionList();
        this.currentPageNo++;
    }

    setTotalAmount(value: number) {
        if (value !== null) {
            this.totalTransactionAmount = value;
        }
    }

    get hightlightText() { // spp search function.
        if (this.segmentCategoryTab === 'all') {
            return this.searchKey;
        } else {
            return '';
        }
    }

    preFormatTextTransactions(list: CEB2212ItemsRes[]) { // spp search function.
        list.forEach( (t) => {
            switch (t.eBankTransactionTypeCode as any) {
                case '06': case '07': t.phoneNumber = this.formatterPipe.transform(t.phoneNumber, 'PHONE_NUM') as any; break;
                case '09': case '10': t.payonCardNo = this.formatterPipe.transform(t.payonCardNo, 'PAYON_NUMBER') as any; break;
                default: return; // skip clear branchName field.
            }
        });
    }

    refreshDisplayTransactionList() {
        let list: any[];
        if (this.segmentCategoryTab === 'all') {
            list = this.searchService.search(this.transactionList, this.searchFields, this.searchKey);
        } else {
            list = this.transactionList;
        }
        this.displayTransactionList = list;
    }

    clearTransactionList() {
        this.transactionList = [];
        this.displayTransactionList = [];
        this.setTotalAmount(0);
        this.currentPageNo = 1;
        this.ionInfiniteScroll.disabled = false;
    }

    requestData(showLoading: boolean) { // request transaction list
        if (this.ongoingRequest) { // avoid dub req
            this.pendingRequest = true;
            return;
        } else {
            this.ongoingRequest = true;
            this.noHistory = false;
        }
        this.setRequestBody();
        this.bizServer.bizMOBPost('CEB2212', this.reqTr, !showLoading).then( (data) => {
            const resTr = data as CEB2212Res;
            console.log('================111111', data);
            if (this.bizServer.checkResponse(resTr.header as any)) {
                this.setTotalAmount(resTr.body.totalTransactionAmount as any);
                this.setTransactionList(resTr.body.items);
            }
            this.ionInfiniteScroll.complete();
            this.finishRequest(); // avoid dub req
        });
    }

    finishRequest() {
        this.ongoingRequest = false;
        if (this.pendingRequest) {
            this.pendingRequest = false;
            this.renewRequest();
        }
    }

    renewRequest() { // renew transaction list
        this.clearTransactionList();
        this.requestData(true);
    }

    segmentCategoryTabChanged(value: InquiryTransactionType) {
        this.renewRequest();
        // console.log('segmentCategoryTabChanged', value);
    }

    loadData(event) {
        this.requestData(false);
    }

    recordClicked(transaction: CEB2212ItemsRes) {
        console.log(transaction);
        this.transactionService.viewDetail(transaction);
    }

    async filterClicked(ev) {
        this.modalService.open({
            content: MAC11140000Component,
            message: { data: this.filter.data },
            modalClass: ['pop_top'],
            callback: (result) => {
                // console.log('filterChanged', result.data);
                if (result.role === BUTTON_ROLE.APPLY) {
                    this.filter.set(result.data);
                    this.renewRequest();
                }
            }
        });
    }

    dateFilterChanged(dateRange: DateRange) {
        // console.log('dateFilterChanged', dateRange);
        this.fromDate = dateRange.fromDateAsServerFormat;
        this.toDate = dateRange.toDateAsServerFormat;
        this.renewRequest();
    }

    searchChanged(key: string) {
        this.searchKey = key;
        this.refreshDisplayTransactionList();
    }

    btnSetRecurringTransferClicked() {
        this.router.navigateByUrl('open/overflow/rec-sche-transfer/transfer/create');
    }

    btnSetRecurringTopupClicked() {
        this.router.navigateByUrl('open/overflow/rec-sche-transfer/topup/create');
    }

}
