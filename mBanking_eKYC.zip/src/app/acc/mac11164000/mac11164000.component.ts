import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { Router } from '@angular/router';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { AccountCardModel } from '../mac11000000/mac11000000.model';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { ShareTransactionDetailService } from '../../shared/services/share-transaction-detail-info.service';
import { DateTimeFormatService } from 'src/app/shared/services/date-time.service';
import { DateUtils } from 'src/app/shared/utils/date-utils.static';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-mac11164000',
  templateUrl: './mac11164000.component.html',
  styleUrls: ['./mac11164000.component.scss'],
})
export class MAC11164000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read : IonContent, static : false } ) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    name = 'Topup';
    isTranDataFromPush: boolean;
    constructor(
        private modalService: ModalService,
        private router: Router,
        private dateTime: DateTimeFormatService,
        private shareTransactionDetail: ShareTransactionDetailService,
        private socialShare: SocialSharing,
        private backService: BackService
    ) { }

    ngOnInit() { }

    ngAfterViewInit(): void {
        console.log(this.data);
        this.myContent.getScrollElement().then( (element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }
    ionViewWillEnter() {
        this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
        console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
        if ( this.isTranDataFromPush ) {
            this.backService.subscribe('my_account');
        }
     }
    btnBackClicked() {
        if ( this.isTranDataFromPush ) {
            this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
            this.backService.fire();
        } else {

            this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
        }
    }

    btnShareClicked() {
        const shareInfo = this.shareTransactionDetail.shareDeposit(this.data as any, this.name);
        console.log('this.name', this.name);
        this.socialShare.share(shareInfo).then(function () {
            // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
        }).catch(function (error) {
            // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
        });
    }


    btnTopupAgain() {
        let uri = '';
        let data;
        console.log(this.data);
        switch ( this.data.eBankTransactionTypeCode ) {
            case '06':

                uri = '/quick/popup';
                data  = {
                    currencyCode: this.data.currencyCode,
                    accountName: this.data.accountName,
                    amount: this.data.transactionAmount,
                    phoneNumber: this.data.phoneNumber,
                    scheduleDate: '',
                    accountNo: this.data.customerNo,
                    };
                break;
            case '07':
                uri = '/quick/popup-scheduled';
                const time = DateUtils.getTimeFormat(this.data.transactionTime);
                data  = {
                    currencyCode: this.data.currencyCode,
                    amount: this.data.transactionAmount,
                    phoneNumber: this.data.phoneNumber,
                    scheduleDate: this.dateTime.getDateTimeFormat(this.data.transactionDate, 'yyyy-mm-dd'),
                    scheduleStartTime: time.value,
                    scheduleStartTimeShow: time.text
                    };
                break;
            case '09':
                uri = '/quick/payon_topup';
                data  = {
                    currencyCode: this.data.currencyCode,
                    accountName: this.data.accountName,
                    amount: this.data.transactionAmount,
                    payOnCardNo: this.data.payonCardNo,
                    accountNo: this.data.accountNo,
                };
                break;
            case '10':
                uri = '/quick/payon_scheduled';
                data  = {
                    currencyCode: this.data.currencyCode,
                    amount: this.data.transactionAmount,
                    phoneNumber: this.data.phoneNumber,
                    scheduleDate: this.dateTime.getDateTimeFormat(this.data.transactionDate, 'yyyy-mm-dd'),
                    scheduleStartTime: time.value,
                    scheduleStartTimeShow: time.text
                    };
                break;
            case '28':
                uri = '/quick/bongloy_topup';
                data  = {
                    currencyCode: this.data.currencyCode,
                    accountName: this.data.accountName,
                    amount: this.data.transactionAmount,
                    payOnCardNo: this.data.payonCardNo,
                    accountNo: this.data.accountNo,
                };
                break;
        }
        if ( uri !== '') {
            const account = {
                accountNo : this.data.accountNo,
                accountName : this.data.accountName,
                currencyCode : this.data.currencyCode,
                depositSubjectCode: this.data.depositSubjectCode,
                availableBalance : this.data.availableBalance,
                accountNickName: this.data.accountNickName
            };

            this.btnBackClicked();
            DataCenter.set('mac11812000', 'back', data);
            DataCenter.set('widthDrawAbleAccount', 'account', account);
            DataCenter.set('transactionScreen', 'transactionDetails', this.data);
            this.router.navigate([uri]);
        }
    }

}
