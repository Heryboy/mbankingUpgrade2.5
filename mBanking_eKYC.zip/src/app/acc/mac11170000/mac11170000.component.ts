import { AfterContentChecked, Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MAC11710000Component } from 'src/app/opn/mac11710000/mac11710000.component';
import { BUTTON_ROLE, CHANNEL, TOTAL_REPAY_REASON_CODE } from 'src/app/shared/constants/common.const';
import { CurrencyCode, SegmentPeriodOptionValue } from 'src/app/shared/constants/common.type';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { WithdrawAbleAccount } from 'src/app/shared/services/withdraw-able-account.service';
import { CEB2214Req } from 'src/app/shared/TRClass/CEB2214-req';
import { CEB2214Res } from 'src/app/shared/TRClass/CEB2214-res';
import { CEB6111Req } from 'src/app/shared/TRClass/CEB6111-req';
import { CEB6111Res } from 'src/app/shared/TRClass/CEB6111-res';
import { CEB6112Req } from 'src/app/shared/TRClass/CEB6112-req';
import { CEB6112Res } from 'src/app/shared/TRClass/CEB6112-res';
import { CEB6211Req } from 'src/app/shared/TRClass/CEB6211-req';
import { CEB6211Res, CEB6211ResBody } from 'src/app/shared/TRClass/CEB6211-res';
import { CEB6221Req } from 'src/app/shared/TRClass/CEB6221-req';
import { CEB6221Res } from 'src/app/shared/TRClass/CEB6221-res';
import { CEB6311Req } from 'src/app/shared/TRClass/CEB6311-req';
import { CEB6311Res } from 'src/app/shared/TRClass/CEB6311-res';
import { CEB6321Req } from 'src/app/shared/TRClass/CEB6321-req';
import { CEB6321Res } from 'src/app/shared/TRClass/CEB6321-res';
import { Util } from 'src/app/shared/util';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { DateUtils } from 'src/app/shared/utils/date-utils.static';
import { Utils } from 'src/app/shared/utils/utils.static';
import { AccountCardModel } from '../mac11000000/mac11000000.model';
import { MAC1116A000Component } from '../mac1116-a000/mac1116-a000.component';
import { MAC11172100Component } from '../mac11172100/mac11172100.component';
import { MAC11172200Component } from '../mac11172200/mac11172200.component';
import { AcountList, DataRegister, GridRigisterScheduleRepay, GridScheduleRepay, InquiryTransactionLoan, LoanDetails, LoanScheduleList, LoanType, RepaymentDetails } from './mac11170000.model';



@Component({
  selector: 'app-mac11170000',
  templateUrl: './mac11170000.component.html',
  styleUrls: ['./mac11170000.component.scss'],
})
export class MAC11170000Component implements OnInit, AfterContentChecked {

  public repayPrincipal: number;
// ======================Schedule=================
  public loanScheduleList: LoanScheduleList [];
  public repaymentSelection: boolean[];
  public applyDate: string;
  public repaymentPaid: number;
  // ================================
  segmentPeriodOption: SegmentPeriodOptionValue;
  currentPageNo: number;
  fromDate: string;
  toDate: string;
  pageNumber = 1;
  transactionList: InquiryTransactionLoan[];
  reqTr: CEB6111Req;
  remainingRepayLoanScheduleList: LoanScheduleList[] ;

  public changeTitle = false;
  public tabLoanType: LoanType;
  public typeLoan = 'LOAN_TERM';

  public repaymentSelectedCount =  0;
  public loanDetails: LoanDetails;
  public acountList: AcountList[];
  public gridScheduleRepay: GridScheduleRepay [];
  private gridRigisterScheduleRepay: GridRigisterScheduleRepay[];
  public repayInfoBySchedule: CEB6211ResBody;
  public retrieveLoanRepayAllInfo: CEB6311Res['body'];
  public checkNumberOFData = [];
  public checkBoxReypay: boolean;
  private scrolEvent = false;
  private repaymentAmountBySchedule: number;
  private repaymentAmountByRepayAll: number;
  public repaymentAccountNumber: string;
  public btnDisable: boolean;

  public transactionID: number;
  public authenticationCode: string;
  public transactionDate: string;
  public curDate: string;
  private narration: string;
  private feeDescription: string;
  public noHistory: boolean;
  public outStandingBanlance: number;
  disabledInput = true; // for close input amount text;
  disabledTab: boolean;
  public loan = {
    loanOD: 'LOAN_OD',
    loanTerm: 'LOAN_TERM',
  };

  public account: AccountCardModel;
  public repaymentAmount: number ;
  public accountName: string;

  public repaymentDetails: RepaymentDetails;
  private totalRepayment: DataRegister;
  accountNumber: string;
  firstRequest = 1;
  isPersonal: boolean;
  util = new Util();
  constructor(
    private translate: TranslateService,
    private bizServer: BizserverService,
    private withdrawAccountService: WithdrawAbleAccount,
    private authTranService: AuthTransactionService,
    private backService: BackService,
    private dialog: ModalService
  ) {
    this.narration = 'EM';
    this.feeDescription = 'Fee Description from mobile banking';
    this.segmentPeriodOption = 'tab_1w';
    this.tabLoanType = 'tab_histories';
    this.setDateRange(this.segmentPeriodOption);
    this.reqTr = new CEB6111Req();
  }

  ngOnInit() {
    this.backService.subscribe();
    this.account = DataCenter.get('my-account', 'account', false);
    this.curDate = DateUtils.getDateAsServerFormat();
    this.checkLoanType(this.account.principalRepayMethodCode.toString(), this.tabLoanType);
    this.outStandingBanlance = Number(this.account.loanBalance);
    if (this.outStandingBanlance === 0) {
      this.disabledTab = true;
    } else {
      this.disabledTab = false;
    }
    this.isPersonal = Utils.personalAccount();
    // const userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    // const customerTypeCode = userInfo['customerTypeCode'];
    // if (customerTypeCode === CUSTOMER_TYPE_CODE.INDIVIDUAL_BANKING) {
    //     this.isPersonal = true;
    // } else {
    //   this.isPersonal = false;
    // }
  }
  ngAfterContentChecked() {
    if (this.tabLoanType === 'tab_repay') {
      if (this.repaymentAmount && this.repaymentAmount !== 0 && this.repaymentAccountNumber ) {
        this.btnDisable = false;
      } else {
        this.btnDisable = true;
      }
    }
  }
  checkLoanType(value: string, tabSegment) {
    if ( value === '90') {
      this.typeLoan =  this.loan.loanOD;
      if (tabSegment === 'tab_repay' || tabSegment === 'tab_schedule') {
        this.tabLoanType = 'tab_histories';
      }
    } else {
      this.typeLoan =  this.loan.loanTerm;
    }
  }
  async segmentOptionChanged(value: LoanType ) {
    switch (value) {
      case 'tab_details':
          this.inquiryLoanDetails();
          break;
      case 'tab_histories':
          this.clearTransactionList();
          this.inquiryTransaction();
          break;
      case 'tab_repay':
          this.clearRepaymentData();
          this.inquirySchedule();
          const data = {
            currencyCode: this.account.currencyCode as CurrencyCode,
          };
          this.acountList = await this.withdrawAccountService.getWithdrawAccountByFilter(data);
          if (this.acountList && this.acountList.length > 1) {
            this.accountNumber = this.acountList[0].accountNo;
          }
          break;
      case 'tab_schedule':
          this.inquirySchedule();
          break;
      default: this.tabLoanType = 'tab_histories';
    }
    this.tabLoanType = value;
  }
  async requestAuthentication() {
    this.authTranService.reqestAuthCode({ callback:  (auth) => {
      this.transactionID      = Number(auth.transactionID);
      this.authenticationCode = auth.authenticationCode;
      this.transactionDate    = auth.transactionDate;
      this.checkBoxReypay ? this.registerRegisterRepayLoanEarly() : this.registerRepayLoanIndividual();
    }});
  }
  clearRepaymentData() {
    this.repayInfoBySchedule = undefined;
    this.retrieveLoanRepayAllInfo = undefined;
    this.repaymentAmount = undefined;
    this.checkBoxReypay = false;
    this.repaymentAccountNumber = undefined;
  }
  // Next Repay Click Repay
  async onRepay() {
  let interestAmount, principalAmount, otherAmount;
  if (this.checkBoxReypay) {
      this.repaymentAmount =  this.repaymentAmountByRepayAll;
      interestAmount = this.retrieveLoanRepayAllInfo.repayInterest;
      principalAmount = this.retrieveLoanRepayAllInfo.repayPrincipal;
      otherAmount = this.retrieveLoanRepayAllInfo.feeAmount +  this.retrieveLoanRepayAllInfo.overdueAmount;
  } else {
    this.repaymentAmount = this.repaymentAmountBySchedule;
    interestAmount = this.repayInfoBySchedule.repayInterest;
    principalAmount = this.repayPrincipal;
    otherAmount = this.repayInfoBySchedule.overdueAmount;
  }
  const details: RepaymentDetails = {
    totalAmount: this.repaymentAmount,
    currencyCode: this.account.currencyCode,
    interestAmount,
    principalAmount,
    otherAmount,
    repaymentAccountNumber: this.repaymentAccountNumber,
    nickName: this.accountName
  };

  this.repaymentDetails  = details;
  const result = await this.dialog.modal({
    component: MAC11172100Component, // Checked translate finished
    componentProps: { repaymentDetails : details}
  });
  if (result.role === BUTTON_ROLE.YES) {
    this.requestAuthentication();
  }
}
async repayCompoleted() {
  const result = await this.dialog.modal({
    component: MAC11172200Component, // Already finished translate 
    componentProps: { repaymentDetails:  this.repaymentDetails}
  });
  if (result.role === BUTTON_ROLE.OK) {
    this.tabLoanType = 'tab_histories';
    this.inquiryLoanDetails();
  }
}

  async registerRegisterRepayLoanEarly() {
    const reqTr = new CEB6321Req();
    const registerEarly = this.retrieveLoanRepayAllInfo;
    reqTr.body.repayInterest  = registerEarly.repayInterest;        //
    reqTr.body.paymentApplyDate  = this.curDate;        //
    reqTr.body.commissionRate  = registerEarly.commissionRate;        // commissionRate
    reqTr.body.totalRepayReasonCode  = TOTAL_REPAY_REASON_CODE.OWN_MONEY;        //
    reqTr.body.overdueAmount  = registerEarly.overdueAmount;        //
    reqTr.body.feeDescription  = this.feeDescription;        // feeDescription
    reqTr.body.earlyRepayApplyFeeTypeCode  = registerEarly.earlyRepayApplyFeeTypeCode;        // earlyRepayApplyFeeTypeCode
    reqTr.body.feeAmount  = registerEarly.feeAmount;        // feeAmount
    reqTr.body.repayPrincipal  = registerEarly.repayPrincipal;        //
    reqTr.body.narration  = this.narration;
    reqTr.body.loanAccountNo  = registerEarly.loanAccountNo;        // 샘플
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    reqTr.body.authenticationCode = this.authenticationCode;
    reqTr.body.authTransactionDate = this.transactionDate;
    reqTr.body.authTransactionID = this.transactionID;
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.alternativeTransferAccountNo  = this.repaymentAccountNumber;        // alternativeTransferAccountNo
    this.bizServer.bizMOBPost('CEB6321', reqTr).then(data => {
      const resTr = data as CEB6321Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.repayCompoleted();
      }
      this.authTranService.transactionResult( resTr.header );
    });

}
  async registerRepayLoanIndividual() {

    const amountPayList = this.totalRepayment;
    const reqTr = new CEB6221Req();
    const repayInfoBySchedule = this.repayInfoBySchedule;
    reqTr.body.totalRepayReasonCode  = TOTAL_REPAY_REASON_CODE.OWN_MONEY;        //
    reqTr.body.loanAccountNo  = this.account.loanAccountNo;        // 샘플
    reqTr.body.paymentApplyDate  = this.curDate;        //
    reqTr.body.narration  = this.narration;        //
    reqTr.body.alternativeTransferAccountNo  = this.repaymentAccountNumber;        // alternativeTransferAccountNo
    reqTr.body.grid01  = this.gridRigisterScheduleRepay;        // 목록
    reqTr.body.totalBalance  = amountPayList.totalBalance;        //
    reqTr.body.payTotalAmount  = amountPayList.payTotalAmount;        //
    reqTr.body.totalAmount  = this.repaymentAmount;        //
    reqTr.body.repayInterest  = amountPayList.repayInterest;        //
    reqTr.body.repayPrincipal  = amountPayList.repayPrincipal;        //
    reqTr.body.overdueDays  = repayInfoBySchedule.overdueDays;        //
    reqTr.body.overdueAmount  = repayInfoBySchedule.overdueAmount;        //
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    reqTr.body.authenticationCode = this.authenticationCode;
    reqTr.body.authTransactionDate = this.transactionDate;
    reqTr.body.authTransactionID = this.transactionID;
    Utils.setUserInfoTo(reqTr.body);

    this.bizServer.bizMOBPost('CEB6221', reqTr).then(data => {
      const resTr = data as CEB6221Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.repayCompoleted();
      }
      this.authTranService.transactionResult( resTr.header );
    });

}

setBody(obj: object): void {
  Utils.setUserInfoTo(obj);
  Utils.setProperty(obj, 'loanAccountNo', this.account.loanAccountNo);
}
// =======================Repay=========================
  async inquiryRepayAllInfo() {
    const reqTr = new CEB6311Req();
    reqTr.body.loanAccountNo  = this.account.loanAccountNo;        // loanAccountNo
    reqTr.body.repayPrincipal  = Number(this.account.loanBalance);        // repayPrincipal
    reqTr.body.paymentApplyDate  = this.curDate;       // paymentApplyDate
    Utils.setUserInfoTo(reqTr.body);

    const resTr = await this.bizServer.bizMOBPost('CEB6311', reqTr) as CEB6311Res;
    if (this.bizServer.checkResponse(resTr.header)) {
     this.retrieveLoanRepayAllInfo = resTr.body;
     const details = resTr.body;
    //  this.repaymentAmountByRepayAll = details.feeAmount + details.overdueAmount + details.repayInterest + details.repayPrincipal;
     this.repaymentAmountByRepayAll = details.totalAmount;
    }
    return resTr.header.result;
  }
  async inquiryRepayInfoBySchedule() {
    const reqTr = new CEB6211Req();
    this.setBody(reqTr.body);
    reqTr.body.grid01  = this.gridScheduleRepay;        // grid01
    reqTr.body.paymentApplyDate  = this.curDate;        // baseDate (today)

    const resTr = await this.bizServer.bizMOBPost('CEB6211', reqTr) as CEB6211Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      this.repayInfoBySchedule = resTr.body;
      const details = resTr.body;
      this.repaymentAmountBySchedule = details.overdueAmount + details.repayInterest + this.repayPrincipal;
    }
    return resTr.header.result;
}
 async onClickRepayCheck() {
  if (this.checkBoxReypay) {
   /*  this.repayInfoBySchedule = undefined;
    this.repaymentAmount = undefined; */
    const result = await this.inquiryRepayAllInfo();
    if (result) {
      this.repaymentAmount = result ? this.repaymentAmountByRepayAll : 0;
    }
    
  } else {
    this.repaymentAmount = this.repaymentAmountBySchedule;
  }
}
async withdrawAccount() {
    this.withdrawAccountService.withdrawAccountSelectService(this.acountList, this.accountNumber).then(result => {
      if (result) {
        this.repaymentAccountNumber = result.accountNo;
        this.accountName = (result.accountNickName === null || result.accountName === '') ? result.accountName : result.accountNickName;
        this.accountNumber = result.accountNo;
      }
  });
}
// ==================LOAN DETAILS=================

setRequestBodyLoanDetails(): CEB2214Req {
  const reqTr = new CEB2214Req();
  this.setBody(reqTr.body);
  reqTr.body.businessCode = this.account.businessCode;
  return reqTr;
}
inquiryLoanDetails() {
  const reqTr =  this.setRequestBodyLoanDetails();
  this.bizServer.bizMOBPost('CEB2214', reqTr).then(data => {
    const resTr = data as CEB2214Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      this.loanDetails = resTr.body;
      this.account.loanBalance = this.loanDetails.loanBalance as any;
      this.outStandingBanlance = this.loanDetails.loanBalance;
    }
  });
}

  // ================= HISTORY =============
  onClickViewDetails(val: InquiryTransactionLoan) {
    if (val.debitCreditTypeCode !== 'CR') {
      this.dialog.modal({
        component: MAC1116A000Component,
        componentProps: { loan: val }
      });
    }
  }
  setDateRange(option: SegmentPeriodOptionValue) {
    this.fromDate = DateUtils.getStartDatePeriodAsString(option);
    this.toDate = DateUtils.getCurrentDateTime();
  }
  clearTransactionList() {
    this.transactionList = [];
    this.pageNumber = 1;
  }
  setRequestBody(setDefault?: boolean) {
    this.setBody(this.reqTr.body);
    this.reqTr.body.pageSize = 10;     // pageSize
    this.reqTr.body.pageNumber =  this.pageNumber;     // pageNumber
    this.reqTr.body.inquiryLoanTypeCode = this.account.businessCode;     // inquiryLoanTypeCode
    this.reqTr.body.loanAccountNo = this.account.loanAccountNo;
    this.reqTr.body.fromDate = DateUtils.getDateAsServerFormat(this.fromDate);
    this.reqTr.body.toDate = DateUtils.getDateAsServerFormat(this.toDate);
  }
  setTransactionLoanList(list: InquiryTransactionLoan[]) {
    if (list.length === 0) {
        if (this.transactionList.length === 0) {
            this.noHistory = true;
        }
        return;
    }
    if (!this.transactionList) {
        this.clearTransactionList();
    }
    this.transactionList = [...this.transactionList, ...list];
  }
  inquiryTransaction() {
    this.setRequestBody( );
    this.bizServer.bizMOBPost('CEB6111', this.reqTr).then(data => {
      const resTr = data as CEB6111Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.checkNumberOFData = resTr.body.items;
        this.setTransactionLoanList(resTr.body.items);
        this.firstRequest++;
      } else {
        this.noHistory = false;
      }
    });
  }
  scrollLoadData(event) {
    setTimeout(() => {
        if​​(this.checkNumberOFData.length >​​​0) {
          this.pageNumber++;
          this.inquiryTransaction();
        }
        event.target.complete();
        if (this.checkNumberOFData.length === 0) {
          event.target.disabled = !this.scrolEvent;
       }
    }, 500);
  }
// ===========Scroll Event Fixed ========

onScrollHandler(event) {
  if (event.detail.scrollTop < 88 ) {
    this.changeTitle = false;
  } else {
    this.changeTitle = true;
  }
}

setSelectedAccount(account: AccountCardModel): void {
  this.account = account;
  this.outStandingBanlance = Number(this.account.loanBalance);
  this.checkLoanType(this.account.principalRepayMethodCode.toString(), this.tabLoanType);
  this.segmentOptionChanged(this.tabLoanType);
}


filterChanged(ev) {
  this.fromDate = ev.fromDate;
  this.toDate = ev.toDate;
  this.clearTransactionList();
  if (this.firstRequest !== 1) {
    this.inquiryTransaction();
  }
}

getRemainingRepaymentLoan() {
  this.remainingRepayLoanScheduleList = [];
  const remainningLoan = [];
  const currentDate = this.applyDate;
  const futuerRepayment = [];
  for (const ele of this.loanScheduleList) {
    if (ele.checkCollectionTypeCode === String(0)) {
      if ( ele.paymentApplyDate <=  currentDate ) {
        remainningLoan.push(ele);
      }
     /*  else {  // In mobile banking not allow to pay in the futuer
        if (ele.paymentApplyDate >= currentDate) {
          futuerRepayment.push(ele);
          break;
        }
      } */
    }
  }
  this.remainingRepayLoanScheduleList = [...remainningLoan, ...futuerRepayment];
  if (this.remainingRepayLoanScheduleList.length === 0) {
    this.disabledInput = true;
  } else {
    this.disabledInput = false;
  }
}
  async onClickRepaySchedule() {
    if (this.remainingRepayLoanScheduleList.length > 0) {
      const result = await this.dialog.modal({
        component: MAC11710000Component, // Finished translate
        componentProps: {
          loanSchedule: this.remainingRepayLoanScheduleList,
          currencyCode: this.account.currencyCode
        }
      });

      if (result.role === BUTTON_ROLE.APPLY) {
        this.gridRigisterScheduleRepay = result.data.repaymentByScheduleList;
        this.gridScheduleRepay = result.data.gridDetails;
        this.repayPrincipal = 0;
        this.repayPrincipal = result.data.registerData.repayPrincipal;

        this.totalRepayment = result.data.registerData;
        this.gridRigisterScheduleRepay = result.data.gridRegister;
        await this.inquiryRepayInfoBySchedule();
        this.repaymentAmount = this.repaymentAmountBySchedule;
        this.checkBoxReypay = false;
      }
    }
}
//  ====================== Loan Schedule ==============

setScheduleList(list: LoanScheduleList[]) {
  if (!this.loanScheduleList) {
      this.clearLoanScheduleList();
  }
  this.loanScheduleList = [...this.loanScheduleList, ...list];
}
clearLoanScheduleList() {
  this.loanScheduleList = [];
}
setRequestBodySchedule(): CEB6112Req {
  const reqTr = new CEB6112Req();
  Utils.setUserInfoTo(reqTr.body);
  reqTr.body.loanAccountNo = this.account.loanAccountNo;
  return reqTr;
}
inquiryLoanSchedule() {
 const reqTr = this.setRequestBodySchedule();
 this.bizServer.bizMOBPost('CEB6112', reqTr).then(data => {
    const resTr = data as CEB6112Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      // Success To-Do
      const result =  resTr.body.items;        // items
      this.applyDate = resTr.body.applyDate;
      this.setScheduleList(result);
      this.getRemainingRepaymentLoan();
    }
    this.repaymentSelection = [];
    this.loanScheduleList.forEach((ele, i) => {
      if (ele.checkCollectionTypeCode === String(1) || ele.checkCollectionTypeCode === String(3)) {
        this.repaymentSelection[i] = true;
      } else {
        this.repaymentSelection[i] = false;
      }
     });
    const listSelectedPaid = this.loanScheduleList.filter( (item, i) => {
      if (item) {
        return (item.checkCollectionTypeCode === String(1) || item.checkCollectionTypeCode === String(3));
       }
     });
    this.repaymentPaid = listSelectedPaid.length ;

  });
}
inquirySchedule() {
  this.clearLoanScheduleList();
  this.inquiryLoanSchedule();
}
}

