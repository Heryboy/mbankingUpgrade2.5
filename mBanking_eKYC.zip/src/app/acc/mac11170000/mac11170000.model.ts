import { CEB2011Res, CEB2011ItemsRes } from 'src/app/shared/TRClass/CEB2011-res';
import { CEB2214AccountListRes, CEB2214Res } from 'src/app/shared/TRClass/CEB2214-res';
import { CEB6111ItemsRes } from 'src/app/shared/TRClass/CEB6111-res';
import { CEB6112ItemsRes } from 'src/app/shared/TRClass/CEB6112-res';
import { CEB6211Grid01Req } from 'src/app/shared/TRClass/CEB6211-req';
import { CEB6221Grid01Req } from 'src/app/shared/TRClass/CEB6221-req';

export type InquiryTransactionLoan = CEB6111ItemsRes;
export type LoanScheduleList = CEB6112ItemsRes;
export type LoanDetails = CEB2214Res['body'];
export type AccountList = CEB2214AccountListRes;
export type GridScheduleRepay = CEB6211Grid01Req;
export type GridRigisterScheduleRepay = CEB6221Grid01Req;
export type AcountList = CEB2011ItemsRes;
export type LoanType = 'tab_schedule'  | 'tab_repay' | 'tab_histories' | 'tab_details';
export class RepaymentDetails {
    totalAmount: number;
    currencyCode: string;
    interestAmount: number;
    principalAmount: number;
    otherAmount: number;
    repaymentAccountNumber: string;
    nickName: string;
}

export class DataRegister {
    payTotalAmount: number; // 	 =  Sum(  Principle amount)
    repayInterest: number; // 	 =  Sum(  Interest amount)
    repayPrincipal: number; // 	 =  Sum(  Principle amount)
    totalBalance: number; //          =  Sum(  Principle )  that overdule loan
}
