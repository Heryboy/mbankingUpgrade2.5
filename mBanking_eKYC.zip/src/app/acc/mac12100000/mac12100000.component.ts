import { Component, OnInit, NgZone } from '@angular/core';
import { ModalService } from '../../shared/services/modal.service';
import { MAC12200000Component } from '../mac12200000/mac12200000.component';
import { Router } from '@angular/router';
import { DataCenter } from '../../shared/utils/data-center.static';
import { CEB3111Req } from '../../shared/TRClass/CEB3111-req';
import { CEB3111Res, CEB3111FavoriteAccountListRes } from '../../shared/TRClass/CEB3111-res';
import { BizserverService } from '../../shared/services/bizserver.service';
import { Util } from '../../shared/util';
import { LOCAL_STORAGE } from '../../shared/constants/common.const';
import { ChooseWithdrawalAccountService } from '../../shared/services/choose-withdrawal-account.service';
import { SelectWidthdrawAbleAccount } from '../../shared/component/withdraw-able-ccount/withdraw-able-account.model';
import { TranslateService } from '@ngx-translate/core';
import { Utils } from '../../shared/utils/utils.static';
import { BackService } from '../../shared/services/back.service';

@Component({
  selector: 'app-mac12100000',
  templateUrl: './mac12100000.component.html',
  styleUrls: ['./mac12100000.component.scss'],
})
export class MAC12100000Component implements OnInit {
  public changeTitle = false;
  isFavoriteFriend: boolean;
  bankName: string;
  accountName: string;
  accountNo: string;
  imageURL: string;
  checkImage: Array<boolean> = [];
  userInfo: object;
  util = new Util();
  items: CEB3111FavoriteAccountListRes[];
  public data: SelectWidthdrawAbleAccount;
  resultYN: string;
  seqNo: any;
  receiverAccountNumber: string;
  viewText: object;
  constructor(
    private modal: ModalService,
    private route: Router,
    private bizServer: BizserverService,
    private chooseWithdrawalAccountService: ChooseWithdrawalAccountService,
    private translate: TranslateService,
    private zone: NgZone,
    private backService: BackService
  ) { }

  ngOnInit() {
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    this.isFavoriteFriend = false;
    this.getData();
    this.translate.get('MAC12200000.LABEL').subscribe((res) => {
      this.viewText = res;
    });
    this.backService.subscribe('logged_out',
      {
        title: this.translate.instant('COMMON.MESSAGE.LOGOUT'),
        content: this.translate.instant('COMMON.MESSAGE.DO_YOU_REALLY_WANT_TO_LOGOUT')
      });
  }
  onSetting(item: any) {
    this.seqNo = item.item.seqNo;
    this.receiverAccountNumber = item.item.receiverAccountNumber;
    let data: any;
    data = {
      seqNo: item.item.seqNo,
      receiverAccountNumber: item.item.receiverAccountNumber,
    };
    DataCenter.set('data', 'data', data);
    DataCenter.set('isFavoriteFriend', 'isFavoriteFriend', this.isFavoriteFriend);
    DataCenter.set('items', 'items', this.items);
    this.modal.open({
      content: MAC12200000Component, modalClass: ['pop_bottom'],
      callback: (res) => {
        this.resultYN = res;
      }
    });
  }
  extractFirstCharacter(text: string): string {
    if (text !== undefined) {
      const oneLetter = text.charAt(0).toUpperCase();
      return oneLetter || '';
    }
  }
  public getColorByFirstCharacter(str: string): string {
    const aToG = '^[a-gA-G]*$';
    const hToN = '^[h-nH-N]*$';
    const oToT = '^[o-tO-T]*$';
    const uToZ = '^[u-zU-Z]*$';

    if (str.match(aToG)) {
      return '';
    } else if (str.match(hToN)) {
      return 'bg02';
    } else if (str.match(oToT)) {
      return 'bg03';
    } else if (str.match(uToZ)) {
      return 'bg04';
    }
  }
  toDetail(item) {
    if (DataCenter.get('card', 'card') !== 'card') {
      DataCenter.set('item', 'item', item);
      this.zone.run(() => {
        this.route.navigateByUrl('/acc/MAC12110000');
      });
    }
  }
  onTransfer(item: CEB3111FavoriteAccountListRes) {
    this.data = {
      title: 'QUI11000000.BUTTON.ACCOUNT_TRANSFER',
    };
    DataCenter.set('transactionScreen', 'transactionDetails', item); // Don't change screenID and Key
    const accountTransfer = '/quick/account-transfer';
    this.chooseWithdrawalAccountService.openWidthdrawAbleAccount(this.data, accountTransfer, 'update');
  }
  checkLoadImage(i: string | number) {
    return this.checkImage[i] = true;
  }
  checkCondIf() {
    return this.checkImage;
  }
  getData() {
    const reqTr = new CEB3111Req();
    reqTr.header.screenID = 'MAC12100000'; // your screenID
    Utils.setUserInfoTo(reqTr.body);
    this.bizServer.bizMOBPost('CEB3111', reqTr).then(data => {
      const resTr = data as CEB3111Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.items = resTr.body.favoriteAccountList;        // favoriteAccountList
        if (this.items.length === 0) {
          this.isFavoriteFriend = true;
        }
      }
    });
  }
  onScrollHandler(event) {
    if (event.detail.scrollTop < 104) {
      this.changeTitle = false;
    } else {
      this.changeTitle = true;
    }
  }
}
