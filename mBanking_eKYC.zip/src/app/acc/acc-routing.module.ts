import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccMainComponent } from './acc-main/acc-main.component';
import { AccPage } from './acc.page';
import { MAC11111000Component } from './mac11111000/mac11111000.component';
import { MAC11120000Component } from './mac11120000/mac11120000.component';
import { MAC11170000Component } from './mac11170000/mac11170000.component';
import { MAC12100000Component } from './mac12100000/mac12100000.component';
import { MAC12110000Component } from './mac12110000/mac12110000.component';
import { MAC12230000Component } from './mac12230000/mac12230000.component';
import { NOT10000000Component } from './not10000000/not10000000.component';

const routes: Routes = [
  {
    path: 'acc',
    children: [
      { path: '', component: AccPage, pathMatch: 'full' },
      { path: 'main/:tab', component: AccMainComponent },
      {
        path: 'account-inquiry', children: [
          { path: 'saving', component: MAC11111000Component },
          { path: 'deposit', component: MAC11120000Component },
          { path: 'loan', component: MAC11170000Component },
        ]
      },
      { path: 'account-inquiry', component: MAC11111000Component },
      { path: 'account-inquiry/:tab', component: MAC11111000Component },
      { path: 'account-inquiry-deposit', component: MAC11120000Component },
      { path: 'MAC12100000', component: MAC12100000Component },
      { path: 'MAC12230000', component: MAC12230000Component },
      { path: 'MAC12110000', component: MAC12110000Component },
      { path: 'NOT10000000', component: NOT10000000Component },
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
})
export class AccRoutingPageModule { }
