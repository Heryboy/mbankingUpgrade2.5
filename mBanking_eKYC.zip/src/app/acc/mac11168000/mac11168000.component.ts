import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { IonContent } from '@ionic/angular';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { AccountCardModel } from '../mac11000000/mac11000000.model';

@Component({
  selector: 'app-mac11168000',
  templateUrl: './mac11168000.component.html',
  styleUrls: ['./mac11168000.component.scss'],
})
export class MAC11168000Component implements OnInit, AfterViewInit {

  public scrollable = false;
  result = false;
  resBody = new CEB2411Res().body;
  data;
  total: number;
  @ViewChild(IonContent, { read: IonContent, static: false }) myContent: IonContent;
  isTranDataFromPush: boolean;

  constructor(
    private modalService: ModalService,
    private router: Router,
    private socialShare: SocialSharing,
    private shareTransactionDetail: ShareTransactionDetailService,
    private backService: BackService
    ) { }

  ngOnInit() {
    if (this.data) {
      this.resBody = this.data;
      this.total = Number(this.resBody.transactionAmount) + Number(this.resBody.handleFee) + Number(this.resBody.cableCharge);
    }
  }

  ionViewWillEnter() {
    this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
    console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
    if ( this.isTranDataFromPush ) {
        this.backService.subscribe('my_account');
    }
 }

  ngAfterViewInit(): void {

    this.myContent.getScrollElement().then((element: HTMLElement) => {
      if (element.scrollHeight > element.clientHeight) {
        this.scrollable = true;
      } else {
        this.scrollable = false;
      }

    });
  }

  btnTransterAgain() {
    const account = {
      accountNo: this.data.accountNo,
      accountName: this.data.accountName,
      currencyCode: this.data.currencyCode,
      depositSubjectCode: this.data.depositSubjectCode,
      availableBalance: this.data.availableBalance,
      accountNickName: this.data.accountNickName
    };
    DataCenter.set('widthDrawAbleAccount', 'account', account);

    DataCenter.set('transactionScreen', 'transactionDetails', this.resBody);
    this.back();
    console.log('DataCenter.get(\'transactionScreen\', \'transactionDetails\');');
    this.router.navigate(['/quick/overseas-transfer']);
  }

  back() {
    if ( this.isTranDataFromPush ) {
      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
      this.backService.fire();
  } else {

      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }
  }


  share() {
    this.shareTransactionDetail.OverseasWithdrawalSWIFT(this.resBody).then(res => {
      console.log(res);
      this.socialShare.share(res).then(function () {
        // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
      }).catch(function (error) {
        // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
      });
    });

  }

}
