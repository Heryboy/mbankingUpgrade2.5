import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11168100Component } from './mac11168100.component';

describe('MAC11168100Component', () => {
  let component: MAC11168100Component;
  let fixture: ComponentFixture<MAC11168100Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11168100Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11168100Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
