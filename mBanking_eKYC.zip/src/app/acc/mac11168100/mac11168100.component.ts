import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { IonContent } from '@ionic/angular';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

@Component({
  selector: 'app-mac11168100',
  templateUrl: './mac11168100.component.html',
  styleUrls: ['./mac11168100.component.scss'],
})
export class MAC11168100Component implements OnInit, AfterViewInit {

  public scrollable = false;

  resBody = new CEB2411Res().body;
  data;
  result = false;
  total: number;
  @ViewChild(IonContent, { read: IonContent, static: false }) myContent: IonContent;
  isTranDataFromPush: boolean;

  constructor(
    private router: Router,
    private socialShare: SocialSharing,
    private shareTransactionDetail: ShareTransactionDetailService,
    private modalService: ModalService,
    private backService: BackService
  ) { }

  ngOnInit() {
    if (this.data) {
      this.resBody = this.data;
      console.log(this.resBody.transactionAmount, this.resBody.feeAmount);
      this.total = Number(this.resBody.transactionAmount) + Number(this.resBody.feeAmount);
    }
  }

  ngAfterViewInit(): void {
    this.myContent.getScrollElement().then((element: HTMLElement) => {
      if (element.scrollHeight > element.clientHeight) {
        this.scrollable = true;
      } else {
        this.scrollable = false;
      }

    });
  }

  ionViewWillEnter() {
    this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
    console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
    if (this.isTranDataFromPush) {
      this.backService.subscribe('my_account');
    }
  }
  btnTransferAgain() {
    const account = {
      accountNo: this.data.accountNo,
      accountName: this.data.accountName,
      currencyCode: this.data.currencyCode,
      depositSubjectCode: this.data.depositSubjectCode,
      availableBalance: this.data.availableBalance,
      accountNickName: this.data.accountNickName
    };
    DataCenter.set('widthDrawAbleAccount', 'account', account);
    DataCenter.set('transactionScreen', 'transactionDetails', this.resBody);
    this.back();
    console.log(' DataCenter.get(\'transactionScreen\', \'transactionDetails\');');

    this.router.navigate(['/quick/wu-application-form']);
  }
  btnShare() {
    this.shareTransactionDetail.sharePaymentMerchant(this.data).then(res => {
      console.log(res);
      this.socialShare.share(res).then(function () {
        // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
      }).catch(function (error) {
        // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
      });
    });
  }
  back() {
    if (this.isTranDataFromPush) {
      this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
      this.backService.fire();
    } else {

      this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
    }
  }
}
