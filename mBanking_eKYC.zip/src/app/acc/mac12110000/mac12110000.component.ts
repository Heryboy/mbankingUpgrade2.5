import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { BizserverService } from '../../shared/services/bizserver.service';
import { BUTTON_ROLE } from '../../shared/constants/common.const';
import { DataCenter } from '../../shared/utils/data-center.static';
import { CEB3111FavoriteAccountListRes } from '../../shared/TRClass/CEB3111-res';
import { InquiryTransactionTypeCode } from '../mac11111000/mac11111000.model';
import { IonInfiniteScroll } from '@ionic/angular';
import { Utils } from '../../shared/utils/utils.static';
import { CEB3211Req } from '../../shared/TRClass/CEB3211-req';
import { CEB3211Res, CEB3211ItemsRes } from '../../shared/TRClass/CEB3211-res';
import { MAC12120000Component } from '../mac12120000/mac12120000.component';
import { ChooseWithdrawalAccountService } from '../../shared/services/choose-withdrawal-account.service';
import { SelectWidthdrawAbleAccount } from '../../shared/component/withdraw-able-ccount/withdraw-able-account.model';
import { CEB2212ItemsRes } from 'src/app/shared/TRClass/CEB2212-res';
import { DateRange } from 'src/app/shared/component/filter/filter.model';
import { TransactionService } from '../mac11111000/mac11111000.service';
import { ModalService } from '../../shared/services/modal.service';
import { BackService } from '../../shared/services/back.service';
@Component({
  selector: 'app-mac12110000',
  templateUrl: './mac12110000.component.html',
  styleUrls: ['./mac12110000.component.scss'],
})
export class MAC12110000Component implements OnInit {

  public changeTitle = false;
  item: CEB3111FavoriteAccountListRes;
  items: CEB3211ItemsRes[];
  currentPageNo = 1;
  fromDate: string;
  reqTr: CEB3211Req;
  filter: InquiryTransactionTypeCode;
  toDate: string;
  isLoad: boolean;
  checkImage: boolean;
  totalCount: number;
  transactionList: any = [];
  lastTransactionDate: any;
  public data: SelectWidthdrawAbleAccount;
  noHistory: boolean;
  readonly pageSize = 10;
  @ViewChild(IonInfiniteScroll, { static: true }) ionInfiniteScroll: IonInfiniteScroll;

  constructor(
    private bizServer: BizserverService,
    private transactionService: TransactionService,
    private chooseWithdrawalAccountService: ChooseWithdrawalAccountService,
    private modalService: ModalService,
    private zone: NgZone,
    private backService: BackService
  ) {
    this.reqTr = new CEB3211Req();
    this.filter = new InquiryTransactionTypeCode();
    this.setRequestBody(true);
    this.transactionService.setModal(this.modalService);
  }

  ngOnInit() {
    this.item = DataCenter.get('item', 'item');
    this.backService.subscribe();
  }
  recordClicked(transaction: CEB2212ItemsRes) {
    this.transactionService.viewDetail(transaction);
  }
  setRequestBody(init?: boolean) {
    this.reqTr.header.screenID = 'MAC12110000'; // your screenID
    if (init) {
      Utils.setUserInfoTo(this.reqTr.body);
      this.reqTr.body.pageSize = this.pageSize;
    } else {
      this.reqTr.body.debitCreditTypeCode = this.filter.data.debitCreditTypeCode;
      this.reqTr.body.receiverAccountNo = this.item.receiverAccountNumber;        // receiverAccountNumber
      this.reqTr.body.pageNumber = this.currentPageNo;
      this.reqTr.body.fromDate = this.fromDate;
      this.reqTr.body.toDate = this.toDate;
    }
  }

  requestData(showLoading: boolean) {
    this.noHistory = false;
    this.setRequestBody();
    this.bizServer.bizMOBPost('CEB3211', this.reqTr, showLoading).then(data => {
      const resTr = data as CEB3211Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.totalCount = resTr.body.totalCount;        // TTCN
        this.lastTransactionDate = resTr.body.lastTransactionDate;
        this.items = resTr.body.items;        // ITEMS
        this.setTransactionList(resTr.body.items as any);
      }
      this.ionInfiniteScroll.complete();
    });
  }

  checkLoadImage() {
    return this.checkImage = true;
  }

  dateFilterChanged(dateRange: DateRange) {
    this.fromDate = dateRange.fromDateAsServerFormat;
    this.toDate = dateRange.toDateAsServerFormat;
    this.clearTransactionList();
    this.requestData(false);
  }
  setTransactionList(list: []) {
    if (list.length === 0) {
      this.ionInfiniteScroll.disabled = true;
      if (this.transactionList.length === 0) {
        this.noHistory = true;
      }
      return;
    } else if (list.length < this.pageSize) { // last records.
      this.ionInfiniteScroll.disabled = true;
    }
    this.transactionList = [...this.transactionList, ...list] as any;
    this.currentPageNo++;
  }
  loadData() {
    this.requestData(true);
  }
  clearTransactionList() {
    this.transactionList = [];
    this.currentPageNo = 0;
    this.ionInfiniteScroll.disabled = false;
  }
  async filterClicked() {
    this.modalService.open({
      content: MAC12120000Component,
      message: { data: this.filter.data },
      modalClass: ['pop_top'],
      callback: (result) => {
        if (result.role === BUTTON_ROLE.APPLY) {
          this.filter.set(result.data);
          this.clearTransactionList();
          this.requestData(false);
        }
      }
    });
  }
  back() {
    this.backService.fire();
  }
  onTransfer() {
    this.data = {
      title: 'QUI11000000.BUTTON.ACCOUNT_TRANSFER',
    };
    DataCenter.set('transactionScreen', 'transactionDetails', this.item); // Don't change screenID and Key
    const accountTransfer = '/quick/account-transfer';
    this.chooseWithdrawalAccountService.openWidthdrawAbleAccount(this.data, accountTransfer, 'update');
  }
  onScrollHandler(event) {
    if (event.detail.scrollTop < 88) {
      this.changeTitle = false;
    } else {
      this.changeTitle = true;
    }
  }
}
