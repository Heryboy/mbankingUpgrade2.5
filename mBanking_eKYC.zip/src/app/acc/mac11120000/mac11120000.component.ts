import { DEPOSIT_SUBJECT_CODE, DEPOSIT_ROLLOVER_DIVIDE_CODE } from './../../shared/constants/common.const';
import { Component, OnInit, Input, ViewChild, NgZone } from '@angular/core';
import { CEB2214Req } from 'src/app/shared/TRClass/CEB2214-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB2214Res } from 'src/app/shared/TRClass/CEB2214-res';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { AccountCardModel } from '../mac11000000/mac11000000.model';
import { InquiryTransactionTypeCode } from '../mac11111000/mac11111000.model';
import { CEB2212Req } from 'src/app/shared/TRClass/CEB2212-req';
import { DateRange } from 'src/app/shared/component/filter/filter.model';
import { IonInfiniteScroll } from '@ionic/angular';
import { CEB2212ItemsRes, CEB2212Res } from 'src/app/shared/TRClass/CEB2212-res';
import { Router } from '@angular/router';
import { TransactionService } from '../mac11111000/mac11111000.service';
import { TranslateService } from '@ngx-translate/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ACCOUNT_DEVIDE_CODE } from '../../shared/constants/common.const';
@Component({
  selector: 'app-mac11120000',
  templateUrl: './mac11120000.component.html',
  styleUrls: ['./mac11120000.component.scss'],
})
export class MAC11120000Component implements OnInit {

    @ViewChild(IonInfiniteScroll, {static: true}) ionInfiniteScroll: IonInfiniteScroll;
    @Input() modal: any;
    screenId: 'MAC11120000' | 'MAC11130000';
    changeTitle: boolean;
    account: AccountCardModel;
    accountDetail = new CEB2214Res().body;
    showLoanAccList: boolean;
    depositRolloverDivideText: string;

    transactionList: CEB2212ItemsRes[];
    accountList: AccountCardModel[];
    noHistory: boolean;
    reqTr: CEB2212Req;
    fromDate: string;
    toDate: string;
    filter: InquiryTransactionTypeCode;
    currentPageNo = 1;
    readonly pageSize = 10;
    // avoid dub req
    ongoingRequest: boolean;
    pendingRequest: boolean;
    // pre-calculates data
    interest = 0;
    total = 0;
    totalLoanBalance = 0;
    loanAble: boolean;
    isScrollOnButton: boolean;
    individual  = ACCOUNT_DEVIDE_CODE.INDIVIDUAL;

    constructor(
        private bizServer: BizserverService, private router: Router, private transactionService: TransactionService,
        private translate: TranslateService,
        private modalService: ModalService,
        private zone: NgZone,
    ) {
        this.filter = new InquiryTransactionTypeCode();
        this.setRequestBody(true);
        this.transactionService.setModal(this.modalService);
    }

    ngOnInit() { }

    onScrollHandler(event: any) {
        // console.log(event.detail.scrollTop);
        if (event.detail.scrollTop < 88 ) {
            this.changeTitle = false;
        } else {
            this.changeTitle = true;
        }
    }

    onScroll(event) {
        // used a couple of "guards" to prevent unnecessary assignments if scrolling in a direction and the var is set already:        
        let elem: HTMLElement = document.getElementById('active_height'); 
        if (event.detail.scrollTop > 1) {
          this.isScrollOnButton = true;         
          elem.setAttribute("style", "padding-bottom:12vh");
        } else {          
          this.isScrollOnButton = false;
          elem.setAttribute("style", "padding-bottom:0px");
        };
      };

    setSelectedAccount(acc: AccountCardModel) {
        console.log('accountColor', acc.accountColor);
        this.account = acc;
        this.screenId = (acc.depositSubjectCode === '130' as any) ? 'MAC11120000' : 'MAC11130000';
        this.clearAccDetail();
        this.reqAccDetail(acc);
        if (this.fromDate && this.toDate) { // sync init request with dateFilterChanged event.
            this.renewRequest();
        }
    }

    setAccDetail(accDetail: any) {
        // accountBalance for check interest rate
        this.accountDetail = accDetail;
        // this.interest = this.accountDetail.accountBalance * this.accountDetail.applyInterestRate / 100;
        this.interest = this.accountDetail.accruedInterestAmount;
        this.total = this.accountDetail.accountBalance + this.interest;

        this.totalLoanBalance = 0;
        this.accountDetail.accountList.forEach( (acc) => {
            this.totalLoanBalance += acc.loanAmount as any;
        });
        this.loanAble = this.totalLoanBalance < (this.accountDetail.loanLimitAmount as any);
    }

    setRequestBody(init?: boolean) { // set request transaction list

        if (init) {
            this.reqTr = new CEB2212Req();
            Utils.setUserInfoTo(this.reqTr.body);
            this.reqTr.body.businessCode = 'PDP';
            this.reqTr.body.pageSize = this.pageSize;
        } else {
            this.reqTr.body.accountNo = this.account.accountNo;
            const filterData = this.filter.data;
            this.reqTr.body.debitCreditTypeCode = filterData.debitCreditTypeCode;
            this.reqTr.body.inquiryTransactionTypeCode = filterData.inquiryTransactionTypeCode;
            this.reqTr.body.inquiryTransferTransactionTypeCode = filterData.inquiryTransferTransactionTypeCode;
            this.reqTr.body.pageNumber = this.currentPageNo;
            this.reqTr.body.fromDate = this.fromDate;
            this.reqTr.body.toDate = this.toDate;
        }
    }

    // NOTED: kimleng reported 2020-04-30
    setDepositRolloverDivideText( depositRolloverDivideCode: string ) {
        switch (depositRolloverDivideCode) {
            case DEPOSIT_ROLLOVER_DIVIDE_CODE.ROLLOVER:
                this.depositRolloverDivideText = this.translate.instant('MAC11120000.LABEL.ROLLOVER');
                break;
            case DEPOSIT_ROLLOVER_DIVIDE_CODE.MONTHLY_PAYMENT_BUT_ROLLOVER:
                this.depositRolloverDivideText = this.translate.instant('MAC11120000.LABEL.ROLLOVER');
                break;
            case DEPOSIT_ROLLOVER_DIVIDE_CODE.TRANSFER_TO_NOMINATE_ACCOUNT:
                this.depositRolloverDivideText = this.translate.instant('MAC11120000.LABEL.TRANSFER_TO_NOMINATED_ACCOUNT');
                break;
            case DEPOSIT_ROLLOVER_DIVIDE_CODE.SELF_TERMINATION:
                this.depositRolloverDivideText = this.translate.instant('MAC11120000.LABEL.NOT_ROLLOVER');
                break;
        }
    }

    setTransactionList(list: CEB2212ItemsRes[]) {
        if (list.length === 0) {
            this.ionInfiniteScroll.disabled = true;
            if (this.transactionList.length === 0) {
                this.noHistory = true;
            }
            return;
        } else if (list.length < this.pageSize) { // last records.
            this.ionInfiniteScroll.disabled = true;
        }
        this.transactionList = [...this.transactionList, ...list];
        this.currentPageNo++;
    }

    clearTransactionList() {
        this.transactionList = [];
        this.currentPageNo = 1;
        this.ionInfiniteScroll.disabled = false;
    }

    clearAccDetail() {
        this.accountDetail = new CEB2214Res().body;
        this.interest = 0;
        this.total = 0;
        this.totalLoanBalance = 0;
        this.loanAble = false;
    }

    reqAccDetail(acc: AccountCardModel) {
        const reqTr = new CEB2214Req();
        Utils.setUserInfoTo(reqTr.body);
        reqTr.body.accountNo = acc.accountNo;
        reqTr.body.businessCode = acc.businessCode;
        reqTr.body.loanAccountNo = acc.loanAccountNo;
        this.bizServer.bizMOBPost('CEB2214', reqTr).then( (data) => {
            const resTr = data as CEB2214Res;
            console.log(resTr);
            if (this.bizServer.checkResponse(resTr.header)) {
                this.setAccDetail(resTr.body);
                this.setDepositRolloverDivideText( resTr.body.depositRolloverDivideCode );
            }
        });
    }

    requestData(showLoading: boolean) { // request transaction list
        if (this.ongoingRequest) { // avoid dub req
            this.pendingRequest = true;
            return;
        } else {
            this.ongoingRequest = true;
            this.noHistory = false;
        }
        this.setRequestBody();
        this.bizServer.bizMOBPost('CEB2212', this.reqTr, !showLoading).then( (data) => {
            const resTr = data as CEB2212Res;
            // console.log(data);
            if (this.bizServer.checkResponse(resTr.header as any)) {
                this.setTransactionList(resTr.body.items);
            }
            this.ionInfiniteScroll.complete();
            this.finishRequest(); // avoid dub req
        });
    }

    finishRequest() {
        this.ongoingRequest = false;
        if (this.pendingRequest) {
            this.pendingRequest = false;
            this.renewRequest();
        }
    }

    renewRequest() { // renew transaction list
        this.clearTransactionList();
        this.requestData(true);
    }

    dateFilterChanged(dateRange: DateRange) {
        // console.log('dateFilterChanged', dateRange);
        this.fromDate = dateRange.fromDateAsServerFormat;
        this.toDate = dateRange.toDateAsServerFormat;
        this.renewRequest();
    }

    loadData(event) {
        this.requestData(false);
        console.log('loadData');
    }

    recordClicked(transaction: CEB2212ItemsRes) {
        this.transactionService.viewDetail(transaction);
    }

    getLoanAgainstDeposit() {

        const maxOpeningBalance = 560;	// sample
        const currencyCode = 'USD';		// sample

        let isValidBalance = false;
        let hasFixedInstallAccount = false;

        if ( this.account.depositSubjectCode.toString() === DEPOSIT_SUBJECT_CODE.INSTALLMENT
        || this.account.depositSubjectCode.toString() === DEPOSIT_SUBJECT_CODE.FIXED
        ) {

            hasFixedInstallAccount = true;

            // availableBalance to check loan againts deposit
            if ( (this.account.availableBalance as any >= maxOpeningBalance) && !isValidBalance ) {
                isValidBalance = true;
            }
        }
        if (hasFixedInstallAccount && !isValidBalance) {
            const msg = this.translate.instant('MAC11D00000.LABEL.YOU_SHOULD_HAVE_A_FIXED_OR_INSTALL_ACCOUNT_WITH_A_MINIMUM');
            this.modalService.alert({
              content: `${msg} ${maxOpeningBalance} ${currencyCode}`,
              btnText: this.translate.instant('COMMON.BUTTON.OK'),
              callback: () => { }
            });
          } else {
            // this.zone.run(() =>  this.router.navigate(['/open/loan/intro'], {queryParams: {accountNo: this.account.accountNo }}));
            this.zone.run(() =>  this.router.navigate(['/open/loan/agreement'], { replaceUrl: true, queryParams: { accountNo: this.account.accountNo } }));
          }
    }

    onClose() {
        this.modal.close();
    }

}
