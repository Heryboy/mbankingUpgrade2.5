import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11120000Component } from './mac11120000.component';

describe('MAC11120000Component', () => {
  let component: MAC11120000Component;
  let fixture: ComponentFixture<MAC11120000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11120000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11120000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
