import { Component, OnInit } from '@angular/core';
import { RepaymentDetails } from '../mac11170000/mac11170000.model';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';

@Component({
  selector: 'app-mac11172200',
  templateUrl: './mac11172200.component.html',
  styleUrls: ['./mac11172200.component.scss'],
})
export class MAC11172200Component implements OnInit {

  public repaymentDetails: RepaymentDetails;
  constructor(public modalService: ModalService) { }

  ngOnInit() {}

  onClickOk() {
    this.modalService.dismiss({role: BUTTON_ROLE.OK});
  }

}
