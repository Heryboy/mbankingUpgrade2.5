import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC1116A330Component } from './mac1116-a330.component';

describe('MAC1116A330Component', () => {
  let component: MAC1116A330Component;
  let fixture: ComponentFixture<MAC1116A330Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC1116A330Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC1116A330Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
