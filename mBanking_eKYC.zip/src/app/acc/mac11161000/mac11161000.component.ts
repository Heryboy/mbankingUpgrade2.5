import { Utils } from 'src/app/shared/utils/utils.static';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { IonContent } from '@ionic/angular';
import { BUTTON_ROLE, EBANK_TRANSACTION_TYPE_CODE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { RecipientAccountListService } from 'src/app/shared/services/recipient-account-list.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { BankList, FormMode } from 'src/app/trf/qui11110000/qui11110000.model';
import { ShareTransactionDetailService } from '../../shared/services/share-transaction-detail-info.service';
import { BackService } from 'src/app/shared/services/back.service';
@Component({
  selector: 'app-mac11161000',
  templateUrl: './mac11161000.component.html',
  styleUrls: ['./mac11161000.component.scss'],
})
export class MAC11161000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read : IonContent, static : false } ) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    INTERBANK_TRANSFER: string;
    bankList: BankList[];
    setRecurring: boolean;
    isPersonal: boolean;
    name = 'Transfer';
    isTranDataFromPush: boolean;
    constructor(
        private modalService: ModalService,
        private router: Router,
        private shareTransactionDetail: ShareTransactionDetailService,
        private socialShare: SocialSharing,
        private backService: BackService,
        private recipientAccountListService: RecipientAccountListService
    ) {}

    async ngOnInit() {
        this.isPersonal = Utils.personalAccount();
        this.INTERBANK_TRANSFER = EBANK_TRANSACTION_TYPE_CODE.INTERBANK_TRANSFER;
        this.bankList = await this.recipientAccountListService.inquiryBankListForRecurringList(this.data.currencyCode);

        const code = this.data.transactionFrequencyCode;
        if (code === '01' || code === '00' || code === '02') {
            return this.setRecurring = false;
        }
        if (this.bankList) {
            this.setRecurring =  this.bankList.some((item) => {
                return this.data.receiverBankCode === item.code;
            });
        }
        if (this.data.receiverBankCode && this.data.receiverBankCode.length > 3) {
            return  this.setRecurring = true;
        }
     }
     ionViewWillEnter() {
        this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
        console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
        if ( this.isTranDataFromPush ) {
            this.backService.subscribe('my_account');
        }
     }

    ngAfterViewInit(): void {
        this.myContent.getScrollElement().then( (element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }

    btnBackClicked() {
        if ( this.isTranDataFromPush ) {
            this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
            this.backService.fire();
        } else {

            this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
        }
    }

    btnShareClicked() {
        const shareInfo = this.shareTransactionDetail.shareDeposit(this.data, this.name);
        this.socialShare.share(shareInfo).then(function () {
            // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
        }).catch(function (error) {
            // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
        });
    }

    btnSetAsRecurringTransferClicked() {
        this.setAccount();
        DataCenter.set('transactionScreen', 'transactionDetails', this.data) ;
        this.btnBackClicked();
        this.router.navigateByUrl('open/overflow/rec-sche-transfer/transfer/update');
        /* set Recurring from transfer data */
    }

    btnTransferAgainClicked() {
        if( this.data.eBankTransactionTypeCode === EBANK_TRANSACTION_TYPE_CODE.BAKONG_TRANSFER ) {

            this.setAccount();
            DataCenter.set('transactionScreen', 'transactionDetails', this.data);
            this.btnBackClicked();
            const formMode: FormMode = 'again';
            this.router.navigate(['/quick/bakong-transfer'], {queryParams: {mode: formMode}}); // edit mode for transfer again
            
        } else {
            
            this.setAccount();
            DataCenter.set('transactionScreen', 'transactionDetails', this.data);
            this.btnBackClicked();
            const formMode: FormMode = 'again';
            this.router.navigate(['/quick/account-transfer'], {queryParams: {mode: formMode}}); // edit mode for transfer again
        }
    }

    setAccount() {
        const account = {
            accountNo : this.data.accountNo,
            accountName : this.data.accountName,
            currencyCode : this.data.currencyCode,
            depositSubjectCode : this.data.depositSubjectCode,
            availableBalance : this.data.availableBalance,
            accountNickName: this.data.accountNickName,
        };
        DataCenter.set('widthDrawAbleAccount', 'account', account);
    }
}
