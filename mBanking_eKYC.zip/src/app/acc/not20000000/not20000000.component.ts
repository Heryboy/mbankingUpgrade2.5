import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';

@Component({
  selector: 'app-not20000000',
  templateUrl: './not20000000.component.html',
  styleUrls: ['./not20000000.component.scss'],
})
export class NOT20000000Component implements OnInit {
  constructor(
    private modalService: ModalService
  ) { }

  ngOnInit() {
  }

  onDismiss() {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }
}
