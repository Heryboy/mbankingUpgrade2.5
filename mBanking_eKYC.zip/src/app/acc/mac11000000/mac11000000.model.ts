import { CEB2211AccountListRes } from 'src/app/shared/TRClass/CEB2211-res';
import { CEB2011ItemsRes } from '../../shared/TRClass/CEB2011-res';

export type CardButtonRole = 'btn_topup' | 'btn_payment' | 'btn_transfer' | 'btn_transfer_maturity' | 'btn_setting' | 'card';

export type DepositSubjectType = 'current' | 'saving' | 'fixed' | 'installment';

export type DepositAccountStatusType = 'normal' | 'dormant' | 'blocked' | 'early_termination' | 'account_closed';

export type AccountCardModel = CEB2211AccountListRes;
export type AccountCheckModel = CEB2011ItemsRes;

export class UserProfile {
    hasNotification: boolean;     // hasNotification
    lateLogInDateTime: string;     // lateLogInDateTime, YYYYMMDDHHMMSS ex) 20161226171431
    imageURL: string;
    userName: string;
}
