import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BFS13100000Component } from 'src/app/hom/bfs13100000/bfs13100000.component';
import { BANNER_TYPE_CODE, CHANNEL, DEPOSIT_SUBJECT_CODE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { GroupByPipe } from 'src/app/shared/pipes/group-by-pipe';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB2211Req } from 'src/app/shared/TRClass/CEB2211-req';
import { CEB2211Res } from 'src/app/shared/TRClass/CEB2211-res';
import { PPCB0100Req } from 'src/app/shared/TRClass/PPCB0100-req';
import { PPCB0100Res } from 'src/app/shared/TRClass/PPCB0100-res';
import { Util } from 'src/app/shared/util';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';
import { MAC11D00000Component } from 'src/app/trf/mac11-d00000/mac11-d00000.component';
import { MAC11800000Component } from 'src/app/trf/mac11800000/mac11800000.component';
import { environment } from 'src/environments/environment';
import { MAC11300000Component } from '../../opn/mac11300000/mac11300000.component';
import { QuickAccessService } from '../../shared/services/quick-access.service';
import { MAX_OPENING_LOAN_BALANCE } from './../../shared/constants/common.const';
import { AccountCardModel, CardButtonRole } from './mac11000000.model';
@Component({
  selector: 'app-mac11000000',
  templateUrl: './mac11000000.component.html',
  styleUrls: ['./mac11000000.component.scss'],
})
export class MAC11000000Component implements OnInit {

  accountList: AccountCardModel[];
  readonly newAccountDaysAmount = 7;
  private isCardButtonClick: boolean;
  modal: any;
  // userInfo: any;
  isPersonal;
  interval: any;
  remainTime = 0;
  remain = 0;
  imgList: any[];
  src: string;
  i = 0;
  newsIdList: any[];
  activeIndex: number;
  advertiseList: any[];
  bizMOBServer = environment.bizMOBServer;
  languageCode: string;
  util = new Util();
  constructor(private bizServer: BizserverService,
    private router: Router,
    private groupByPipe: GroupByPipe,
    private quickAccessService: QuickAccessService,
    private modalService: ModalService,
    private zone: NgZone
  ) {
  }

  ngOnInit() {
    const reqTr = new CEB2211Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    this.bizServer.bizMOBPost('CEB2211', reqTr).then((data) => {
      const resTr = data as CEB2211Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.accountList = resTr.body.accountList;
        DataCenter.set('my-account', 'accountList', this.accountList);
      }
    });
    this.doReqBanner(); // tmp comment
    this.languageCode = this.util.getSecureStorage(LOCAL_STORAGE.LANGUAGE_CODE);

    // this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    // const customerTypeCode = this.userInfo['customerTypeCode'];
    // if (customerTypeCode === CUSTOMER_TYPE_CODE.INDIVIDUAL_BANKING) {
    //     this.isPersonal = true;
    // }

    this.isPersonal = Utils.personalAccount();
  }

  cardClicked(account: AccountCardModel, index?: number) {
    if (this.isCardButtonClick) {
      this.isCardButtonClick = false;
      return;
    }
    let path: string;
    if (account.businessCode === 'PDP' as any) {
      const dsc: string = account.depositSubjectCode;
      path = (dsc === '110' || dsc === '120') ? 'saving' : 'deposit';
    } else {
      path = 'loan';
    }
    DataCenter.set('my-account', 'account', account);
    this.router.navigate(['/acc/account-inquiry', path]);
  }

  async cardButtonClicked(role: CardButtonRole, data: AccountCardModel, index?: number) {
    DataCenter.set('my-account', 'account', data);
    this.isCardButtonClick = true;
    switch (role) {
      case 'btn_topup':
        this.quickAccessService.open('topup', data);
        /*   this.modalService.open(
          { content: MAC11800000Component, modalClass: ['pop_bottom'], message: {currencyCode: data.currencyCode}  }); */
        break;
      case 'btn_payment':
        this.quickAccessService.open('payment', data);
        break;
      // case 'btn_payment':     this.router.navigateByUrl('/quick/payment-merchant'); break;
      case 'btn_transfer':
        // const currencyCodeKHR = 'KHR' as string;
        /* if (data.currencyCode === currencyCodeKHR ) {
            this.router.navigateByUrl('quick/account-transfer');
        } else {
            this.quickAccessService.open('transfer'); console.log('btn_transfer', data, index);
        } */
        this.quickAccessService.open('transfer', data);
        break;
      case 'btn_transfer_maturity':
        this.zone.run(() => {
          this.router.navigateByUrl('/acc/MAC11910000');
        });
        break;
      case 'btn_setting': this.modalService.open({ content: MAC11300000Component, modalClass: ['pop_bottom'] }); break;
    }
  }

  suppriesCardClicked() {
    console.log('suppriesCardClicked');
  }

  btnAddNewAccountClicked() {
    const maxOpeningBalance = MAX_OPENING_LOAN_BALANCE;	// sample
    const currencyCode = 'USD';		// sample

    let isValidBalance = false;
    let hasFixedInstallAccount = false;

    this.accountList.forEach((item) => {
      if (item.depositSubjectCode.toString() === DEPOSIT_SUBJECT_CODE.INSTALLMENT
        || item.depositSubjectCode.toString() === DEPOSIT_SUBJECT_CODE.FIXED
      ) {

        hasFixedInstallAccount = true;

        if ((item.availableBalance as any >= maxOpeningBalance) && !isValidBalance) {
          isValidBalance = true;
        }
      }
    });

    this.modalService.open({
      content: MAC11D00000Component,
      modalClass: ['pop_bottom bg_transparent'],
      message: {
        amount: maxOpeningBalance,
        currencyCode,
        isValidBalance,
        hasFixedInstallAccount
      }
    });
  }

  doReqBanner() {
    const reqTr = new PPCB0100Req();

    reqTr.body.bannerTypeCode = BANNER_TYPE_CODE.AFTER_LOGIN;
    reqTr.body.userID = this.util.getSecureStorage(LOCAL_STORAGE.GUESS_USER_ID);

    this.bizServer.bizMOBPost('PPCB0100', reqTr, true).then(data => {
      const resTr = data as PPCB0100Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.advertiseList = resTr.body.noticeItems;
        // const length = this.advertiseList.length;
        this.newsIdList = this.groupByPipe.transform(this.advertiseList, 'itemId');
        this.imgList = [];
        // this.newsIdList = [];
        this.newsIdList.forEach(element => {
          this.imgList.push({
            src: this.bizMOBServer + '/api/mgmt/newsevent-banner/' + element.key + '/' + this.languageCode,
            id: element.key
          });
        });
        // this.newsIdList = this.groupByPipe.transform(this.imgList, 'id');
        this.periodHandler();
      }
    });
  }

  periodHandler() {
    this.interval = setInterval(() => {
      this.remainTime++;
      this.remain++;
      let length = this.imgList.length - 1;
      if (this.remain === 3) {
        if (this.i > length) {
          this.i = 0;
        } else {
          this.src = this.imgList[this.i].src;
          this.activeIndex = this.i;
          this.i++;
        }
        this.remain = 0;
      }
      if (this.remainTime === 0) {
        this.remainTime = 30;
      }
    }, 1000);
  }

  clearInterval() {
    clearInterval(this.interval);
    this.interval = undefined;
  }

  btnToDetailsEvents() {
    if (this.newsIdList[this.activeIndex].key) {
      this.modalService.modal({
        component: BFS13100000Component,
        componentProps: { data: this.newsIdList, newsIdIndex: this.activeIndex }
      });
    }
  }

}
