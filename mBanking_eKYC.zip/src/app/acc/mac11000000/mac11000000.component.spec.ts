import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAC11000000Component } from './mac11000000.component';

describe('MAC11000000Component', () => {
  let component: MAC11000000Component;
  let fixture: ComponentFixture<MAC11000000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAC11000000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAC11000000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
