import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GroupByPipe } from '../shared/pipes/group-by-pipe';
import { ShareModule } from '../shared/share.module';
import { MAC1116B000Component } from './mac1116-b000/mac1116-b000.component';
import { MAC1116C000Component } from './mac1116-c000/mac1116-c000.component';
import { MAC11161000Component } from './mac11161000/mac11161000.component';
import { MAC11162000Component } from './mac11162000/mac11162000.component';
import { MAC11163000Component } from './mac11163000/mac11163000.component';
import { MAC11164000Component } from './mac11164000/mac11164000.component';
import { MAC11165000Component } from './mac11165000/mac11165000.component';
import { MAC11166000Component } from './mac11166000/mac11166000.component';
import { MAC11167000Component } from './mac11167000/mac11167000.component';
import { MAC11168000Component } from './mac11168000/mac11168000.component';
import { MAC11168100Component } from './mac11168100/mac11168100.component';
import { MAC11169000Component } from './mac11169000/mac11169000.component';
import { MAC11171000Component } from './mac11171000/mac11171000.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ShareModule,
    DialogModule
],
  declarations: [
    MAC11161000Component,
    MAC11162000Component,
    MAC11163000Component,
    MAC11164000Component,
    MAC11165000Component,
    MAC11166000Component,
    MAC11167000Component,
    MAC11168000Component,
    MAC11168100Component,
    MAC11169000Component,
    MAC1116B000Component,
    MAC1116C000Component,
    MAC11171000Component
  ],
  entryComponents: [
    MAC11161000Component,
    MAC11162000Component,
    MAC11163000Component,
    MAC11164000Component,
    MAC11165000Component,
    MAC11166000Component,
    MAC11167000Component,
    MAC11168000Component,
    MAC11168100Component,
    MAC11169000Component,
    MAC1116B000Component,
    MAC1116C000Component,
    MAC11171000Component
  ],
  providers: [
    GroupByPipe
  ]
})
export class AccShareModule {}
