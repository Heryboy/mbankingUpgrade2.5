import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Mac12231000Component } from 'src/app/acc/mac12231000/mac12231000.component';
import { MAC11210000Component } from '../opn/mac11210000/mac11210000.component';
import { MAC11300000Component } from '../opn/mac11300000/mac11300000.component';
import { MAC11710000Component } from '../opn/mac11710000/mac11710000.component';
import { ShareModule } from '../shared/share.module';
import { SBSharedModule } from '../shared/shared.module';
import { MAC11D00000Component } from '../trf/mac11-d00000/mac11-d00000.component';
import { TrfShareModule } from '../trf/trf-share.module';
import { AccMainComponent } from './acc-main/acc-main.component';
import { AccRoutingPageModule } from './acc-routing.module';
import { AccShareModule } from './acc-share.module';
import { AccPage } from './acc.page';
import { MAC11000000Component } from './mac11000000/mac11000000.component';
import { MAC11111000Component } from './mac11111000/mac11111000.component';
import { TransactionService } from './mac11111000/mac11111000.service';
import { MAC11120000Component } from './mac11120000/mac11120000.component';
import { MAC11140000Component } from './mac11140000/mac11140000.component';
import { MAC1116A000Component } from './mac1116-a000/mac1116-a000.component';
import { MAC11170000Component } from './mac11170000/mac11170000.component';
import { MAC11172100Component } from './mac11172100/mac11172100.component';
import { MAC11172200Component } from './mac11172200/mac11172200.component';
import { MAC12100000Component } from './mac12100000/mac12100000.component';
import { MAC12110000Component } from './mac12110000/mac12110000.component';
import { MAC12120000Component } from './mac12120000/mac12120000.component';
import { MAC12200000Component } from './mac12200000/mac12200000.component';
import { MAC12230000Component } from './mac12230000/mac12230000.component';
import { MAC13000000Component } from './mac13000000/mac13000000.component';
import { NOT10000000Component } from './not10000000/not10000000.component';
import { NOT20000000Component } from './not20000000/not20000000.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AccRoutingPageModule,
    SBSharedModule,
    ShareModule,
    TrfShareModule,
    AccShareModule
  ],
  declarations: [
    AccPage,
    AccMainComponent,
    MAC11000000Component,
    MAC11111000Component,
    MAC11120000Component,
    MAC11140000Component,
    MAC11170000Component,
    MAC11172100Component,
    MAC11172200Component,
    MAC11D00000Component,
    MAC1116A000Component,
    MAC12100000Component,
    MAC12110000Component,
    MAC12200000Component,
    MAC13000000Component,
    NOT10000000Component,
    NOT20000000Component,
    MAC12230000Component,
    MAC11300000Component,
    Mac12231000Component,
    MAC12120000Component,
    MAC11210000Component,
    MAC11710000Component,
  ],
  entryComponents: [
    MAC11140000Component,
    MAC11172100Component,
    MAC11172200Component,
    MAC11D00000Component,
    MAC1116A000Component,
    MAC12110000Component,
    MAC12200000Component,
    NOT10000000Component,
    NOT20000000Component,
    MAC11300000Component,
    Mac12231000Component,
    MAC12120000Component,
    MAC11210000Component,
    MAC11710000Component,
  ],
  providers: [TransactionService]
})
export class AccPageModule {}
