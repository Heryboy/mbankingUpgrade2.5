import { Utils } from 'src/app/shared/utils/utils.static';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { IonContent } from '@ionic/angular';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { MAC11167000Req } from 'src/app/shared/TRClass/MAC11167000Req-req';
import { MAC11167000Res } from 'src/app/shared/TRClass/MAC11167000Req-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-mac11171000',
  templateUrl: './mac11171000.component.html',
  styleUrls: ['./mac11171000.component.scss'],
})
export class MAC11171000Component implements OnInit, AfterViewInit {

  public scrollable = false;
  result = false;
  resBody = new CEB2411Res().body;
  total: number;
  @ViewChild(IonContent, { read: IonContent, static: false }) myContent: IonContent;
  data = new CEB2411Res().body;
  isPersonal: boolean;
  isTranDataFromPush: boolean;

  constructor(
    private modalService: ModalService,
    private router: Router,
    private socialShare: SocialSharing,
    private backService: BackService,
    private shareTransactionDetail: ShareTransactionDetailService,
    private bizServer: BizserverService
  ) { }

  ngOnInit() {
    this.isPersonal = Utils.personalAccount();
    if (this.data) {
      this.resBody = this.data;
      this.total = Number(this.resBody.feeAmount) + Number(this.resBody.transactionAmount);
    }
  }

  ngAfterViewInit() {

    this.myContent.getScrollElement().then((element: HTMLElement) => {
      // console.log( element.scrollHeight );
      // console.log( element.clientHeight );

      if (element.scrollHeight > element.clientHeight) {
        this.scrollable = true;
      } else {
        this.scrollable = false;
      }

    });
  }

  ionViewWillEnter() {
    this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
    console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
    if (this.isTranDataFromPush) {
      this.backService.subscribe('my_account');
    }
  }

  btnToTransterAgain() {
    const account = {
      accountNo: this.data.accountNo,
      accountName: this.data.accountName,
      currencyCode: this.data.currencyCode,
      depositSubjectCode: this.data.depositSubjectCode,
      availableBalance: this.data.availableBalance,
      accountNickName: this.data.accountNickName
    };
    DataCenter.set('widthDrawAbleAccount', 'account', account);
    DataCenter.set('transactionScreen', 'transactionDetails', this.resBody);
    this.btnBack();
    this.router.navigate(['/quick/amk-transfer'], { queryParams: { mode: 'again' } }); // edit mode for transfer again
  }
  btnBack() {
    if (this.isTranDataFromPush) {
      this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
      this.backService.fire();
    } else {

      this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
    }
  }

  share() {
    this.shareTransactionDetail.shareWing(this.data).then(res => {
      console.log(res);
      this.socialShare.share(res).then(function () {
        // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
      }).catch(function (error) {
        // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
      });
    });
  }

  doReq() {
    const reqTr = new MAC11167000Req();
    this.bizServer.bizMOBPost('PPCB01E0', reqTr).then(data => {
      const resTr = data as MAC11167000Res;
      const resultSuccess = this.bizServer.checkResponse(resTr.header);

      if (resultSuccess) {
        const body = {
          accountNumber: '1-234-12345678-9',
          accountName: 'content',
          dateTime: '12/JUN/2019, 09:00',
          currency: 'USD',
          amount: 900.00,
          amountFee: 10.00,
          total: 999.99,
          receiptAccount: '1-234-90987654-1',
          transterRemark: 'content text content text content text',
          remark: 'content text content text content text'
        };
        /*  this.resBody = resTr.body; */
        // this.resBody = body;
      }
    });
  }
}
