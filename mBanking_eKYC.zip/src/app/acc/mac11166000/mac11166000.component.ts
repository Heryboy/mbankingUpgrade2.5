import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonContent } from '@ionic/angular';
import { BUTTON_ROLE, EBANK_TRANSACTION_TYPE_CODE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { ShareTransactionDetailService } from 'src/app/shared/services/share-transaction-detail-info.service';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-mac11166000',
  templateUrl: './mac11166000.component.html',
  styleUrls: ['./mac11166000.component.scss'],
})
export class MAC11166000Component implements OnInit {

  public scrollable = false;
  result = false;
  resBody = new CEB2411Res().body;
  data;
  total: number;
  name = 'Payment';
  transactionTypeElectricity;
  transactionTypeMerchant;
  transactionTypeWater;
  @ViewChild(IonContent, { read : IonContent, static : false } ) myContent: IonContent;
  isTranDataFromPush: boolean;

  constructor(
              private router: Router,
              private socialShare: SocialSharing,
              private shareTransactionDetail: ShareTransactionDetailService,
              private backService: BackService,
              private modalService: ModalService
              ) { }

  ngOnInit() {
    if (this.data ) {
        this.resBody = this.data;
        this.transactionTypeElectricity = EBANK_TRANSACTION_TYPE_CODE.BILL_PAYMENT_ELECTRICITY;
        this.transactionTypeWater = EBANK_TRANSACTION_TYPE_CODE.BILL_PAYMENT_WATER;
        this.transactionTypeMerchant = EBANK_TRANSACTION_TYPE_CODE.MERCHANT_PAYMENT;
        this.total   = Number(this.resBody.feeAmount) + Number(this.resBody.transactionAmount);
    }
  }
  ionViewWillEnter() {
    this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
    console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
    if ( this.isTranDataFromPush ) {
        this.backService.subscribe('my_account');
    }
 }
  ngAfterViewInit(): void {

    this.myContent.getScrollElement().then((element: HTMLElement) => {
      if ( element.scrollHeight > element.clientHeight ) {
        this.scrollable = true;
      } else {
        this.scrollable = false;
      }
    });

  }


  payAgain() {
    const account = {
        accountNo : this.data.accountNo,
        accountName : this.data.accountName,
        currencyCode : this.data.currencyCode,
        depositSubjectCode : this.data.depositSubjectCode ? this.data.depositSubjectCode : null,
        availableBalance : this.data.availableBalance,
        accountNickName: this.data.accountNickName
    };
    DataCenter.set('widthDrawAbleAccount', 'account', account);
    DataCenter.set('transactionScreen', 'transactionDetails', this.resBody);
    this.back();
    /* this.router.navigate(['/quick/payment-merchant-form']); */

    DataCenter.set('payment-merchant-form', 'payment-merchant-form', this.resBody);
    this.router.navigate(['/quick/payment-merchant-form']);
  }
  back() {
    if ( this.isTranDataFromPush ) {
      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
      this.backService.fire();
  } else {

      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }
  }

  share() {
    this.shareTransactionDetail.sharePaymentMerchant(this.data).then( res => {
      this.socialShare.share(res).then(function () {
        // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
      }).catch(function (error) {
          // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
      });
    });
  }

  btnShareClicked() {
    console.log(this.data);
    const shareInfo = this.shareTransactionDetail.shareDeposit(this.data, this.name);
    console.log('this.name', this.name);
    this.socialShare.share(shareInfo).then(function () {
        // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
    }).catch(function (error) {
        // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
    });
}

}
