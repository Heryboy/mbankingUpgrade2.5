import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mac12231000Component } from './mac12231000.component';

describe('Mac12231000Component', () => {
  let component: Mac12231000Component;
  let fixture: ComponentFixture<Mac12231000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mac12231000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mac12231000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
