import { Component, OnInit } from '@angular/core';
import { BUTTON_ROLE } from '../../shared/constants/common.const';
import { ModalService } from '../../shared/services/modal.service';

@Component({
  selector: 'app-mac12231000',
  templateUrl: './mac12231000.component.html',
  styleUrls: ['./mac12231000.component.scss'],
})
export class Mac12231000Component implements OnInit {
  receiverName: string;
  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }
  onClickButtonNo(): void {
    this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
  }
  onClickButtonYes() {
    this.modalService.dismiss({ role: BUTTON_ROLE.APPLY });
  }
}
