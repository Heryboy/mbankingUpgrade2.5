import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Mac1116C000Component } from './mac1116-c000.component';

describe('Mac1116C000Component', () => {
  let component: Mac1116C000Component;
  let fixture: ComponentFixture<Mac1116C000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Mac1116C000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Mac1116C000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
