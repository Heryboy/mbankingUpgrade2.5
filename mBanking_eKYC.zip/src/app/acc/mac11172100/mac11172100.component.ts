import { Component, OnInit } from '@angular/core';
import { RepaymentDetails } from '../mac11170000/mac11170000.model';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-mac11172100',
  templateUrl: './mac11172100.component.html',
  styleUrls: ['./mac11172100.component.scss'],
})
export class MAC11172100Component implements OnInit {

  public repaymentDetails: RepaymentDetails;

  constructor( public modalService: ModalService) { }

  ngOnInit() {}

  onClickYes() {
    this.modalService.dismiss({role: BUTTON_ROLE.YES});
  }
  onClickNo() {
    this.modalService.dismiss({role: BUTTON_ROLE.NO});
  }
}
