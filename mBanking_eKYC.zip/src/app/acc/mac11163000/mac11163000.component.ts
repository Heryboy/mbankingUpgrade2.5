import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { CEB2411Res } from 'src/app/shared/TRClass/CEB2411-res';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { ShareTransactionDetailService } from '../../shared/services/share-transaction-detail-info.service';
import { BackService } from 'src/app/shared/services/back.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
@Component({
    selector: 'app-mac11163000',
    templateUrl: './mac11163000.component.html',
    styleUrls: ['./mac11163000.component.scss'],
})
export class MAC11163000Component implements OnInit, AfterViewInit {

    @ViewChild(IonContent, { read: IonContent, static: false }) myContent: IonContent;
    scrollable = false;
    data = new CEB2411Res().body;
    name = 'Transfer';
    isTranDataFromPush: boolean;

    constructor(
        private modalService: ModalService,
        private shareTransactionDetail: ShareTransactionDetailService,
        private socialShare: SocialSharing,
        private backService: BackService
    ) { }

    ngOnInit() { }

    ngAfterViewInit(): void {
        this.myContent.getScrollElement().then((element: HTMLElement) => {
            this.scrollable = element.scrollHeight > element.clientHeight;
        });
    }

    ionViewWillEnter() {
        this.isTranDataFromPush = DataCenter.get('isTranDataFromPush', 'isTranDataFromPush');
        console.log('isTranDataFromPush', DataCenter.get('isTranDataFromPush', 'isTranDataFromPush'));
        if (this.isTranDataFromPush) {
            this.backService.subscribe('my_account');
        }
    }

    btnBackClicked() {
        if (this.isTranDataFromPush) {
            this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
            this.backService.fire();
        } else {

            this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
        }
    }

    btnShareClicked() {
        const shareInfo = this.shareTransactionDetail.shareDeposit(this.data as any, this.name);
        console.log('this.name', this.name);
        this.socialShare.share(shareInfo).then(function () {
            // messages = 'MAC11300000.LABEL.SUCCESS_MSG_SHARE';
        }).catch(function (error) {
            // messages = 'MAC11300000.LABEL.FAILED_MSG_SHARE';
        });
    }

}
