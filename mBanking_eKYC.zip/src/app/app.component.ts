import { DOCUMENT } from '@angular/common';
import { Component, Inject, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { BizWaveContentsIntegrity } from '@ionic-native/bizwave-plugin-checkintegrity/ngx';
import { Broadcaster } from '@ionic-native/broadcaster/ngx';
// import { ThemeDetection, ThemeDetectionResponse } from "@ionic-native/theme-detection/ngx";
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { NavController, Platform } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { BizPushService } from './bizmob/biz-push.service';
import { CheckContentsParam } from './bizmob/classes/check-contents-param';
import { InitializeService } from './bizmob/initialize.service';
import { BFS12300000Component } from './hom/bfs12300000/bfs12300000.component';
import { BFS13100000Component } from './hom/bfs13100000/bfs13100000.component';
import { BFS18100000Component } from './hom/bfs18100000/bfs18100000.component';
import { InfServiceService } from './inf/services/inf-service.service';
import { MenuClick } from './shared/component/timepicker/time-picker-modal/slideIndexImp';
import { DEVICE_OS_TYPE, LANGUAGE, LOCAL_STORAGE } from './shared/constants/common.const';
import { BackService } from './shared/services/back.service';
import { BizserverService } from './shared/services/bizserver.service';
import { EncryptService } from './shared/services/encrypt.service';
import { LogService } from './shared/services/log.service';
import { MessageService } from './shared/services/message.service';
import { ModalService } from './shared/services/modal.service';
import { LOGINReq } from './shared/TRClass/LOGIN-req';
import { Util } from './shared/util';
import { DataCenter } from './shared/utils/data-center.static';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {

  util = new Util();
  isAppInForeground = false;
  userInfo: any;
  localLangCode: any;
  i18n: any;
  deviceInfo: any;
  AESIV: string;
  errorCode: string;
  isFingerprintAvailable: boolean;
  isShortcut: boolean;
  isShortcutBackground = true;
  isRememberId: boolean;

  projectInitializeComplete = false;
  isPayLoadMessage = false;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private translate: TranslateService,
    private broadcast: Broadcaster,
    private router: Router,
    private zone: NgZone,
    private modalService: ModalService,
    private init: InitializeService,
    private encryptService: EncryptService,
    private backService: BackService,
    private bizServer: BizserverService,
    private androidPermissions: AndroidPermissions,
    private locationAccuracy: LocationAccuracy,
    private fingerAIO: FingerprintAIO,
    private statusBar: StatusBar,
    private mobileAccessibility: MobileAccessibility,
    private messageService: MessageService,
    private infService: InfServiceService,
    private navCtrl: NavController,
    @Inject(DOCUMENT) private document: Document,
    private checkContents: BizWaveContentsIntegrity,
    private logger: LogService,
    private deeplinks: Deeplinks,
    private bizPushService: BizPushService,
  ) {
    this.checkisAppInForeground();
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      if (mobileAccessibility.isScreenReaderRunning) {
        mobileAccessibility.usePreferredTextZoom(false);
      }
      this.setInitialAppLanguage();
      this.shortcutReceiver();
      this.pushNotificationReceiver();
      this.setupDeeplinks();
      this.initializeApp();
    });
  }

  initializeApp() {
    // if (environment.targetType !== 'emulator') {
    if (this.platform.is('cordova')) {

      this.init.initSecurity().then(
        (res) => {
          const progerssOption = {
            show: true,
            // title: 'Update',
            // message: 'Updating New Contents...',
            // messageColor: '0770FF',        // #이 없다면 알아서 붙이도록 작업했음 (default #000000),
            // progressWidthPercent: 90,      // 1~100
            // progressLocationYPercent: 60,  // 1~100
            // backgroundColor: '00000000',
            // progressColor: '0770FF',      // #이 없다면 알아서 붙이도록 작업했음 (default #2196f3)
            // progressBgColor: '0770FF'    // #이 없다면 알아서 붙이도록 작업했음 (default #acacac)
            // titleAlign : "center",          //center, left, right (default center)
            // titleColor : "000000",         //#이 없다면 알아서 붙이도록 작업했음 (default #000000)
            // messageAlign : "left",          //center, left, right (default left)
            message: 'Updating New Contents...',
            // messageAlign : "left",          //center, left, right (default left)
            messageColor: '757575',        // #이 없다면 알아서 붙이도록 작업했음 (default #000000),
            progressAlign: 'left', // left, center
            progressWidthPercent: 80,         // 1~100
            progressLocationXPercent: 8.3, // 1~100
            progressLocationYPercent: 60, // 1~100
            backgroundColor: '00FFFFFF', // a(2)R(2)G(2)B(2) #이 없다면 알아서 붙이도록 작업했음 (default #2196f3)
            progressColor: '217FFF',      // #이 없다면 알아서 붙이도록 작업했음 (default #2196f3)
            progressColorEnd: '0770FF',      // #이 없다면 알아서 붙이도록 작업했음 (default #2196f3)
            progressBgColor: 'E5E5E6'    // #이 없다면 알아서 붙이도록 작업했음 (default #acacac)
          };

          this.init.initUpdate(progerssOption).then(
            (res1) => {
              if (res1.header.apiName === 'APP_UPDATE') {
                this.forceUpdate(res1.header.errorText);
                // this.splashScreen.hide();
              } else {
                const checkContentsParam = new CheckContentsParam('check');
                this.logger.log('[Native] dectecting contents change......');
                this.checkContents.checkIntegrity(checkContentsParam).then(
                  (checkContentsRes) => {
                    console.error(checkContentsRes);
                    this.logger.log('[Native] Contents change is not dectected.');
                    this.projectInitialize();
                  },
                  (checkContentsErr) => {
                    console.error(checkContentsErr);
                    this.logger.log('[Native] dectecting contents change is failed.');
                    this.uploadContentFail();
                    // this.splashScreen.hide();
                  }
                );
              }
            },
            (err) => {
              this.uploadContentFail();
              // this.splashScreen.hide();
            }
          );

        },
        (err) => {
          this.securityCheckFail(err);
          this.splashScreen.hide();
        }
      );
    } else {
      this.projectInitialize();
    }
  }

  setupDeeplinks() {
    const paths = { '/:slug': 'posts' };
    this.deeplinks.route(paths).subscribe(match => {
      console.log('DEEP LINK - match : ', JSON.stringify(match));
    }, nomatch => {
      console.log('DEEP LINK - nomatch : ', JSON.stringify(nomatch));
    });
  }
  projectInitialize() {
    this.platform.backButton.subscribeWithPriority(0, () => {
      this.backService.fire();
    });
    const ispermission = this.util.getSecureStorage(LOCAL_STORAGE.IS_PERMSSION_ALREADY_REQUESTED);
    if ( !ispermission ) {
      this.permisstion();
    }
    if (!this.isPayLoadMessage) {
      this.legacyLogin();
    }
  }

  legacyLogin() {
    const login = new LOGINReq();

    login.body.legacy_message.header.trcode = 'CEB0000';
    login.body.legacy_trcode = 'CEB0000';

    if (login.body.legacy_message.header.smartPhoneVersionTypeCode === DEVICE_OS_TYPE.IOS) {
      login.body.app_key = environment.appKey.iOS;
    } else {
      login.body.app_key = environment.appKey.Android;
    }

    this.bizServer.bizMOBPost('LOGIN', login).then((resTr: any) => {
      if (!this.bizServer.cookie) {
        this.initNavigation(resTr.body.legacy_message.header, resTr);
      } else {
        this.bizServer.bizMOBPost('LOGIN', login).then((resTrSub: any) => {
          this.initNavigation(resTrSub.body.legacy_message.header, resTrSub);
        });
      }
    });
  }

  initNavigation(legacyHeader: any, resTr: any) {
    if (legacyHeader.result && resTr.header) {
      const userID = resTr.body.legacy_message.body.dummy;
      this.util.setSecureStorage(LOCAL_STORAGE.GUESS_USER_ID, userID);
      this.util.setSecureStorage(LOCAL_STORAGE.ALREADY_SHOW_GUIDE, false); // ADDED: 2020-03-27
      this.util.setSecureStorage(LOCAL_STORAGE.ALREADY_SHOW_GUIDE_BILL_PAYMENT, false); // ADDED: 2020-05-12
      const isWelcomePageShow = this.util.getSecureStorage(LOCAL_STORAGE.IS_WELCOME_PAGE_SHOW);

      // if (environment.targetType !== 'emulator') {
      if (this.platform.is('cordova')) {

        this.util.removeSecureStorage(LOCAL_STORAGE.USER_INFO);
        this.util.removeSecureStorage(LOCAL_STORAGE.AESIV);
        this.util.removeSecureStorage(LOCAL_STORAGE.ERROR_CODE);

        this.encryptService.storePublicKey(() => {
          this.encryptService.registerAes(() => {

            this.projectInitializeComplete = true;

            if ( ( !this.i18n || !this.localLangCode) && !isWelcomePageShow) {
              this.backService.language();
              // this.splashScreen.hide();
            } else if (( this.i18n || this.localLangCode) && isWelcomePageShow) {
              this.backService.welcome();
            } else {
              if (!this.isShortcut) {
                  if (!this.isPayLoadMessage) {
                    this.backService.home();
                    // this.splashScreen.hide();
                  }
              } else {
                if (!this.isPayLoadMessage) {
                  this.backService.login();
                  // this.splashScreen.hide();
                }
              }
            }
            this.isShortcutBackground = false;
          });
        });
      } else {

        this.encryptService.storePublicKey(() => {
          this.encryptService.registerAes(() => {
            if (( !this.i18n || !this.localLangCode) && !isWelcomePageShow) {
              this.backService.language();
              // this.splashScreen.hide();
            } else if (( this.i18n || this.localLangCode) && isWelcomePageShow) {
              this.backService.welcome();
            } else  {
              if (!this.isShortcut) {
                if (!this.isPayLoadMessage) {
                  this.backService.home();
                }
              }
            }
          });
        });
      }
    } else {
      if (!this.isPayLoadMessage) {
        this.legacyLogin();
      }
    }
  }

  shortcutReceiver() {
    this.broadcast.addEventListener('shortcutpress').subscribe((event) => {
      DataCenter.set('root', 'shortcut', event);
      if (this.isShortcutBackground === false) {
        this.isShortcut = true;
      } else {
        this.isShortcut = true;
      }
    });

    this.broadcast.fireNativeEvent('init', {});
  }

  checkReservationArrival(message: string, status?: string, messageId?: string) {


    if (message.indexOf('[Visit Reservation Notification]') >= 0) {
      const userInfo = new Util().getSecureStorage(LOCAL_STORAGE.USER_INFO);
      if (userInfo !== null) {
        this.infService.showReservationArrivalPopUp(message);
      } else {
        DataCenter.set('HomPage', 'push', true);
        DataCenter.set('HomPage', 'reservation-arrival', true);
        this.backService.login();
      }
    } else {
      if (this.platform.is('ios')) {
        console.log('isAppInForeground: ', this.isAppInForeground);
        if (status === 'read') {
          this.isPayLoadMessage = true;
          const userId = this.util.getSecureStorage(LOCAL_STORAGE.USER_ID);
          this.bizPushService.getPayLoad(userId, messageId).then((payLoad) => {
            console.log('payLoad', payLoad);
            if (payLoad) {
              this.navigateScreenFromPush(payLoad);
            } else {
              this.onNotificationTab();
            }
          }).catch(error => {
            console.log('error', error);
          });
        }
      } else {
        console.log('isAppInForeground: ', this.isAppInForeground);
        if (this.isAppInForeground) {
          if ( status === 'read' ) {
            console.log('User Tab on Push Notification');
            const userId = this.util.getSecureStorage(LOCAL_STORAGE.USER_ID);
            this.bizPushService.getPayLoad(userId, messageId).then((payLoad) => {
              console.log('payLoad', payLoad);
              if (payLoad) {
                this.navigateScreenFromPush(payLoad);
              } else {
                this.onNotificationTab();
              }
            }).catch(error => {
              console.log(error);
            });
          }
        } else {
          if ( status === 'read' ) {
            console.log('Push Received in background');
            console.log('Initial Push Received');
            const userId = this.util.getSecureStorage(LOCAL_STORAGE.USER_ID);
            this.bizPushService.getPayLoad(userId, messageId).then((payLoad) => {
              console.log('payLoad', payLoad);
              if (payLoad) {
                this.navigateScreenFromPush(payLoad);
              } else {
                this.onNotificationTab();
              }
            }).catch(error => {
              console.log(error);
            });
          }
        }
      }
    }
  }

  pushNotificationReceiver() {
    /* Application is closed, user tab on notification from notification bar.
    Thus language not yet initialized.*/
    const localLangCode = this.util.getSecureStorage(LOCAL_STORAGE.LANGUAGE_CODE);
    const i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);
    if (!i18n || !localLangCode) {
      this.setInitialAppLanguage();
    }
    // let event: any;

    this.broadcast.addEventListener('push').subscribe((event) => {
    let message: string;
    let messageId: string;
    let status: string;
    DataCenter.set('HomPage', 'push-event', event);
    this.messageService.sendNewNotification(); // Update 'N' badge at my account screen
    console.log('push event: ', JSON.stringify(event));
    if (this.platform.is('ios')) {
      message = JSON.parse(event.data).message;
      messageId = JSON.parse(event.data).messageId;
      status = JSON.parse(event.data).status;
      console.log('[ios] push message: ', message);
      console.log('event.background: ', event.background);
      console.log('typeof event.background: ', typeof JSON.parse(event.data).background);
      if (message) {
        this.checkReservationArrival(message, status, messageId);
      }
    } else {
      message = JSON.parse(event.data).message;
      messageId = JSON.parse(event.data).messageId;
      status = JSON.parse(event.data).status;
      console.log('[android] push message: ', message);
      if (message) {
        this.checkReservationArrival(message, status,messageId);
      }
    }
    });
  }

  onNotificationTab() {
    this.util.setSecureStorage('IS_HAVING_NEW_PUSH', false);
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    if (this.userInfo !== null) {
      new MenuClick().clearListMenu();
      this.zone.run(() => this.router.navigate(['/acc/NOT10000000'])); // ==> go to notification screen
    } else {
      DataCenter.set('HomPage', 'push', true);
      DataCenter.set('HomPage', 'reservation-arrival', false);
      this.backService.login();
    }
  }

  forceUpdate(version) {
    this.modalService.alert({
      title: 'Application Update',
      content: 'A new version of PPCBank mobile app is now available. Please update to the version ' + version,
      callback: () => {
        if (this.platform.is('android')) {
          window.open('https://play.google.com/store/apps/details?id=kh.com.ppcbank.mbanking2p', '_system', 'location=yes');
        } else {
          window.open('itms-apps://itunes.apple.com/app/apple-store/id1499620876?mt=8', '_system', 'location=yes');
        }

        this.backService.exit();
      },
    });
  }

  uploadContentFail() {
    this.splashScreen.hide();
    this.modalService.alert({
      title: 'Contents updating',
      content: '[FAIL] Update is failed. try it again later.',
      callback: () => {
        this.backService.exit();
      },
    });
  }

  securityCheckFail(err: any) {
    this.splashScreen.hide();
    this.modalService.alert({
      title: 'Security',
      // content: '[FAIL] App changing detected.',
      content: err.header.errorText,
      callback: () => {
        this.backService.exit();
      },
    });
  }

  checkisAppInForeground() {
    this.platform.pause.subscribe(() => {
      this.isAppInForeground = false;
      console.log('isAppInForeground: ', this.isAppInForeground);
    });

    this.platform.resume.subscribe(() => {
      // this.isDarkModeEnabled();
      if (this.projectInitializeComplete) {
        this.isAppInForeground = true;

        const userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);

        if (!userInfo) {
          const login = new LOGINReq();

          login.body.legacy_message.header.trcode = 'CEB0000';
          login.body.legacy_trcode = 'CEB0000';

          if (login.body.legacy_message.header.smartPhoneVersionTypeCode === DEVICE_OS_TYPE.IOS) {
            login.body.app_key = environment.appKey.iOS;
          } else {
            login.body.app_key = environment.appKey.Android;
          }

          this.bizServer.bizMOBPost('LOGIN', login).then((resTr: any) => {
            const legacyHeader = resTr.body.legacy_message.header;
            if (this.bizServer.checkResponse(legacyHeader) && resTr.header) {

              const userID = resTr.body.legacy_message.body.dummy;
              new Util().setSecureStorage(LOCAL_STORAGE.GUESS_USER_ID, userID);
              this.encryptService.storePublicKey(() => {
                this.encryptService.registerAes(() => {
                });
              });
            }

          });
        }
      }
    });
  }

  setInitialAppLanguage() {
    this.localLangCode = this.util.getSecureStorage(LOCAL_STORAGE.LANGUAGE_CODE);
    this.i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);

    if (!this.i18n || !this.localLangCode) {
      this.translate.setDefaultLang(LANGUAGE.I18N_EN.toString());
      this.translate.use(LANGUAGE.I18N_EN.toString()).toPromise();
    } else {
      this.translate.setDefaultLang(this.i18n);
      this.translate.use(this.i18n).toPromise();
    }
  }


  permisstion() {
    this.util.setSecureStorage(LOCAL_STORAGE.IS_PERMSSION_ALREADY_REQUESTED, true);
    if (this.platform.is('cordova') && this.platform.is('android')) {
      const permissions = [
        this.androidPermissions.PERMISSION.CAMERA,
        this.androidPermissions.PERMISSION.READ_CONTACTS,
        this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE,
        this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE,
        this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION
        // this.androidPermissions.PERMISSION.READ_PHONE_NUMBERS
      ];
      this.locationAccuracy.canRequest().then( ( canRequest: boolean ) => {
        if ( canRequest ) {
          // permissions.push(this.androidPermissions.PERMISSION.REQUEST_PRIORITY_HIGH_ACCURACY);
          permissions.push(this.androidPermissions.PERMISSION.GET_ACCOUNTS);
        }
        this.androidPermissions.requestPermissions(permissions);
      });
    }
  }

  navigateScreenFromPush(payLoadMessage: any) {

    const login = new LOGINReq();
    login.body.legacy_message.header.trcode = 'CEB0000';
    login.body.legacy_trcode = 'CEB0000';
    if (login.body.legacy_message.header.smartPhoneVersionTypeCode === DEVICE_OS_TYPE.IOS) {
      login.body.app_key = environment.appKey.iOS;
    } else {
      login.body.app_key = environment.appKey.Android;
    }
    this.bizServer.bizMOBPost('LOGIN', login).then((resTr: any) => {
      const legacyHeader = resTr.body.legacy_message.header;
      if (this.bizServer.checkResponse(legacyHeader) && resTr.header) {
        const userID = resTr.body.legacy_message.body.dummy;
        this.util.setSecureStorage(LOCAL_STORAGE.GUESS_USER_ID, userID);
        this.encryptService.storePublicKey(() => {
          this.encryptService.registerAes(() => {
            if (payLoadMessage.slipNo && payLoadMessage.userID) {
              DataCenter.set('isTranDataFromPush', 'isTranDataFromPush', true);
              DataCenter.set('payLoadMessageData', 'payLoadMessageData', payLoadMessage);
              this.backService.login();
            } else if (payLoadMessage.boardId) { // News and Events
              DataCenter.set('isNewsEventsFromPush', 'isNewsEventsFromPush', true);
              this.modalService.modal({
                component: BFS13100000Component,
                componentProps: {
                  data: [{
                    key: payLoadMessage.boardId
                  }],
                  newsIdIndex: 0
                }
              });
            } else if (payLoadMessage.branchId) { // Branch and ATM
              DataCenter.set('isDranchIDFromPush', 'isDranchIDFromPush', true);
              this.modalService.modal({
                component: BFS12300000Component,
                componentProps: {
                  data: {
                    branchCategory: payLoadMessage.branchCategory,
                    branchCode: payLoadMessage.branchId,
                    userLocation: {
                      lat: 0,
                      lng: 0
                    }
                  }
                }
              });
            } else if (payLoadMessage.merchantId) {
              this.router.navigate(['/home/find-merchant'], {
                replaceUrl: true, queryParams: {
                  category: payLoadMessage.merchantType === '01'? 'merchant' : 'mobile',
                  code: payLoadMessage.merchantId
                }
              });
            } else if (payLoadMessage.productId) {
              DataCenter.set('isProductIDFromPush', 'isProductIDFromPush', true);
              this.modalService.modal({
                component: BFS18100000Component,
                componentProps: {
                  data: {
                    product : {
                      id: payLoadMessage.productId
                    }
                  }
                }
              });
            } else { // servey
              this.onNotificationTab();
            }
          });
        });
      }
    });
  }
}
