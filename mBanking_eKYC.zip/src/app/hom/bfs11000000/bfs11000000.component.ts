import { DialogService, DialogRef } from '@progress/kendo-angular-dialog';
import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit, Input, NgZone, ViewChild, TemplateRef } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Router } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Util } from '../../shared/util';
import { LOCAL_STORAGE } from '../../shared/constants/common.const';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import * as $ from 'jquery';
@Component({
  selector: 'app-bfs11000000',
  templateUrl: './bfs11000000.component.html',
  styleUrls: ['./bfs11000000.component.scss'],
})
export class BFS11000000Component implements OnInit {

  @Input() modal: any;
  util = new Util();
  isUserInfo: object;
  phoneNumberModel: string;
  @ViewChild('choosePhoneNumberTemplate', {static: false}) choosePhoneNumberTemplate: TemplateRef<HTMLBodyElement>;
  phoneNumbers = [{
    value : '023909909',
    text : '023909909'
  },{
    value : '0963909909',
    text : '0963 909 909'
  }];
  constructor( 
      private zone: NgZone,
      private modalService: ModalService,
      private callNumber: CallNumber,
      private router: Router,
      private translate: TranslateService,
      private dialogKendo: DialogService,
      private iab: InAppBrowser) { }

  ngOnInit() {
    this.isUserInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
  }
  onClosePopup() {
    this.modal.close();
  }
  onLiveChat(): void {
    this.modal.close();
    this.router.navigate(['/quick/live-chat'], { replaceUrl: true, queryParams: { from: 'menu'} });
  }

  btnFAQ() {
      this.modal.close();
      this.zone.run(() => {
        this.router.navigate(['/home/bfs11100000']);
      });
  }

  onCallUs() {
    // this.callNumber.callNumber('023909909', true)
    // .then(res => console.log('Launched dialer!', res))
    // .catch(err => console.log('Error launching dialer', err));
    this.onChoosePhoneNumber(this.choosePhoneNumberTemplate);
  }

  onChoosePhoneNumber(template: TemplateRef<any>) {
    this.translate.get('COMMON.BUTTON').subscribe( res => {
      const dialog = this.dialogKendo.open({
        title: this.translate.instant('BFS11000000.LABEL.CHOOSE_PHONE_NO'),
        content: template,
        actions: [
          { text: res.CANCEL },
          { text: res.CALL, primary: true}
        ]
      });
      $('kendo-dialog').on('click', '.k-overlay', () => {
        dialog.close();
      });
      dialog.dialog.location.nativeElement.classList.add('pop_confirm');
      this.pushKendoDialog(dialog);
      dialog.result.subscribe( (response: any) => {
        this.removeKendoDialog(dialog); // back btn impl
        if (response && response.primary) {
          if (this.phoneNumberModel === undefined) {
            this.modalService.alert({
              title: '',
              content: this.translate.instant('COMMON.ALERT.PHONE_NUMBER_NOT_AVAILABLE'),
              btnText: this.translate.instant('COMMON.BUTTON.OK')
            });
          } else {
            this.callNumber.callNumber(this.phoneNumberModel, false);
          }
        }
      });
    });
  }

  pushKendoDialog(dialog: DialogRef) {
    let dialogList = DataCenter.get('modal-service', 'dialogList', false) as DialogRef[];
    if (!dialogList) {
        dialogList = [];
        DataCenter.set('modal-service', 'dialogList', dialogList, true);
    }
    dialogList.push(dialog);
  }

  removeKendoDialog(dialog: DialogRef) {
    const dialogList = DataCenter.get('modal-service', 'dialogList', false) as DialogRef[];
    if (!dialogList) {
        return;
    }
    const index = dialogList.findIndex(d => d === dialog);
    if (index > -1) {
        dialogList.splice(index, 1);
    }
  }


  onVisitweb() {
    // window.location.href = 'https://www.ppcbank.com.kh/';
    // this.iab.create('https://www.ppcbank.com.kh/','_system','location=yes');
    this.iab.create('https://www.ppcbank.com.kh/', '_system', 'location=yes');
    // if (this.iab) {
    //   this.iab.create('https://www.ppcbank.com.kh/', "_system", "location=yes,enableviewportscale=yes");
    // } else {
    //   window.open('https://www.ppcbank.com.kh/', "_system", "location=yes");
    // }
  }

}
