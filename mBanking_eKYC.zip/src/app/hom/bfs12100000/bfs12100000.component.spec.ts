import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS12100000Component } from './bfs12100000.component';

describe('BFS12100000Component', () => {
  let component: BFS12100000Component;
  let fixture: ComponentFixture<BFS12100000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS12100000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS12100000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
