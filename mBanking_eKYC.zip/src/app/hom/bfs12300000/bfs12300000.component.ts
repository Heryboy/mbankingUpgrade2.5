import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE, FACILITY_CODE, LANGUAGE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { PPCB0170Req } from 'src/app/shared/TRClass/PPCB0170-req';
import { PPCB0170Res, PPCB0170BranchDetailsRes } from 'src/app/shared/TRClass/PPCB0170-res';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { MapsService } from 'src/app/shared/services/maps.service';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Util } from 'src/app/shared/util';
import { TranslateService } from '@ngx-translate/core';
import { DestinationObject } from 'src/app/shared/component/maps/maps.model';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-bfs12300000',
  templateUrl: './bfs12300000.component.html',
  styleUrls: ['./bfs12300000.component.scss'],
})
export class BFS12300000Component implements OnInit {

  data: any;
  detail: PPCB0170BranchDetailsRes;
  facilityCode = FACILITY_CODE;
  isDranchIDFromPush: boolean;
  appLanguageModel = {
    en: LANGUAGE.I18N_EN,
    ja: LANGUAGE.I18N_JA,
    km: LANGUAGE.I18N_KM,
    ko: LANGUAGE.I18N_KO,
    zh: LANGUAGE.I18N_ZH
  };
  appLanguage: string;
  util = new Util();
  userInfo: any;
  constructor(
    private modalService: ModalService,
    private bizServer: BizserverService,
    private mapService: MapsService,
    private callNumber: CallNumber,
    private socialShare: SocialSharing,
    private translate: TranslateService,
    private backService: BackService
  ) { }

  ngOnInit() {
    this.isDranchIDFromPush = false;
    this.appLanguage = (new Util()).getSecureStorage(LOCAL_STORAGE.I18N);
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    this.isDranchIDFromPush = DataCenter.get('isDranchIDFromPush', 'isDranchIDFromPush', true);
    const isFromBranchScreen = DataCenter.get('isFromBranchScreen', 'isFromBranchScreen', true);
    this.reqDetail();
    if ( this.isDranchIDFromPush && this.userInfo === undefined ) {
      this.backService.home();
    } else if (isFromBranchScreen) {
      this.backService.subscribe();
    } else {
      this.backService.my_account();
    }
    console.log('Data', this.data);
  }

  reqDetail() {
    const reqTr = new PPCB0170Req();

    reqTr.body.branchCategory = this.data.branchCategory;
    reqTr.body.branchCode = this.data.branchCode;
    reqTr.body.userLatitude = 0; // this.data.userLocation.lat;
    reqTr.body.userLongitude = 0; // this.data.userLocation.lng;
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

    this.bizServer.bizMOBPost('PPCB0170', reqTr).then( data => {
      const resTr = data as PPCB0170Res;
      const resultSuccess = this.bizServer.checkResponse(resTr.header);
      if (resultSuccess) {
       this.detail = resTr.body;
      }
    });
  }

  onCall(tel: string) {
    const num = tel;
    if (num && num.trim().length > 0) {
      this.callNumber.callNumber(num, false);
    }
  }

  onShare(data) {
    this.translate.get('BFS12300000.LABEL').subscribe(translate => {
      if (translate) {
        const shareData = `${translate.BRANCH_NAME} : ${this.appLanguage === this.appLanguageModel.en ? data.branchNameEn :
          this.appLanguage === this.appLanguageModel.ja ? data.branchNameJp :
          this.appLanguage === this.appLanguageModel.ko ? data.branchNameKr :
          this.appLanguage === this.appLanguageModel.km ? data.branchNameKh :
          this.appLanguage === this.appLanguageModel.zh ? data.branchNameCn :
          data.branchNameEn}
          ${translate.BRANCH_ADDRESS} : ${this.appLanguage === this.appLanguageModel.en ? data.branchAddressEn :
          this.appLanguage === this.appLanguageModel.ja ? data.branchAddressJp :
          this.appLanguage === this.appLanguageModel.ko ? data.branchAddressKr :
          this.appLanguage === this.appLanguageModel.km ? data.branchAddressKh :
          this.appLanguage === this.appLanguageModel.zh ? data.branchAddressCn :
          data.branchNameEn}`;
        this.socialShare.share(shareData);
      }
    });
  }

  onDirections() {
    const destination: DestinationObject = { lat: this.data.latitude, lng: this.data.longitude, code: this.data.branchCode };
    this.mapService.calculateAndDisplayRoute(destination);
    this.dismiss('onDirections');
  }

  dismiss(data?: any) {
    if ( this.isDranchIDFromPush ) {
      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
      this.backService.fire();
    } else {
      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE, data });
    }
  }

}
