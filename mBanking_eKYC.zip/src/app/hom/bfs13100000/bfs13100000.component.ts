import { Component, OnInit } from '@angular/core';
import { PPCB0120Req } from 'src/app/shared/TRClass/PPCB0120-req';
import { PPCB0120Res } from 'src/app/shared/TRClass/PPCB0120-res';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { Util } from 'src/app/shared/util';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

@Component({
  selector: 'app-bfs13100000',
  templateUrl: './bfs13100000.component.html',
  styleUrls: ['./bfs13100000.component.scss'],
})
export class BFS13100000Component implements OnInit {
  data;
  newsIdIndex;
  countData: number;
  index: number;
  template: '';
    imageURL: '';
    publishDateTime: string;
    title: string;

    i18n;
    util = new Util();
    isNewsEventsFromPush: boolean;
    userInfo: any;

  constructor(
     private bizServer: BizserverService,
     private modalService: ModalService,
     private backService: BackService
  ) { }

  ngOnInit() {

    this.isNewsEventsFromPush = false;
    this.i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);

    this.index = this.newsIdIndex;
    this.countData = this.data.length - 1;
    this.doReq();
    this.isNewsEventsFromPush = DataCenter.get('isNewsEventsFromPush', 'isNewsEventsFromPush', true);
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    const isFromNewEventsScreen = DataCenter.get('isFromNewEventsScreen', 'isFromNewEventsScreen', true);
    if ( this.isNewsEventsFromPush && this.userInfo === undefined) {
      this.backService.home();
    } else if (isFromNewEventsScreen) {
      this.backService.subscribe();
    } else {
      this.backService.my_account();
    }

  }
  doReq() {
    if ( this.data !== undefined ) {
      const reqTr = new PPCB0120Req();
      const newsId =   +this.data[this.index].key;
      // if (!newsId) {
        //   this.btnConfrim();
        // }
      reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
      reqTr.body.newsId  = newsId;        // newsId
      this.bizServer.bizMOBPost('PPCB0120', reqTr).then(data => {
        const resTr = data  as PPCB0120Res;
        if ( this.bizServer.checkResponse(resTr.header)) {
        this.publishDateTime = data.publishDateTime;
        if ( resTr.body !== undefined || resTr.body) {
            // console.log(data.body);
            this.publishDateTime = data.body.publishDateTime;
            // this.imageURL = 'https://image.shutterstock.com/image-vector/sample-stamp-grunge-texture-vector-600w-1389188336.jpg';
            this.imageURL = data.body.imageURL;
            this.template = data.body.content;
            this.title    = data.body.title;
          }
        }
      });
    }
  }

  btnPre() {
    if (this.index > 0) {
      --this.index;
      this.doReq();
    }
  }

  btnNext() {
    if (this.countData > this.index) {
      ++this.index;
      this.doReq();
    }
  }
  btnConfrim() {
    if ( this.isNewsEventsFromPush ) {
      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
      this.backService.home();
    } else {

      this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
    }
  }
  btnClose() {
    this.btnConfrim();
  }
}
