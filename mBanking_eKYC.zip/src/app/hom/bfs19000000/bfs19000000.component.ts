import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Product } from 'src/app/shared/TRClass/PPCB0130-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { LoanApplyService } from '../bfs19100000/loan-apply.service';

@Component({
  selector: 'app-bfs19000000',
  templateUrl: './bfs19000000.component.html',
  styleUrls: ['./bfs19000000.component.scss'],
})
export class BFS19000000Component implements OnInit {

  @Input() modal: any;
  loanCssClass = ['business_loan', 'housing_loan', 'car_loan', 'songkhoem_loan'];
  loanList: Array<Product>;
  recommendLoanList: Array<Product> = [];

  constructor(
    private router: Router,
    private translate: TranslateService,
    private loanApply: LoanApplyService
  ) {
    this.translate.get('BFS19000000.TS.LOAN_LIST').subscribe(tran => {
      this.loanList = [
        {
          categoryCode: 'CAT000006',
          categoryName: tran.LOANS,
          description: tran.BUSINESS_LOAN.DESCRIPTION,
          id: '',
          imagePath: '',
          name: tran.BUSINESS_LOAN.NAME
        },
        {
          categoryCode: 'CAT000006',
          categoryName: tran.LOANS,
          description: tran.HOUSING_LOAN.DESCRIPTION,
          id: '101',
          imagePath: '',
          name: tran.HOUSING_LOAN.NAME
        },
        {
          categoryCode: 'CAT000006',
          categoryName: tran.LOANS,
          description: tran.CAR_LOAN.DESCRIPTION,
          id: '102',
          imagePath: '',
          name: tran.CAR_LOAN.NAME
        },
        {
          categoryCode: 'CAT000006',
          categoryName: tran.LOANS,
          description: tran.SONGKHOEM_LOAN.DESCRIPTION,
          id: '3479',
          imagePath: '',
          name: tran.SONGKHOEM_LOAN.NAME
        }
      ];
    });
  }

  ngOnInit() {}

  onClose(): void {
    this.modal.close();
  }

  async getLoanList() {
    await this.loanApply.getLoanList().then(data => {
      this.loanList = data;
    });
    for (const i of this.loanList) {
      if (
        i.name === 'Business Loan' ||
        i.name === 'Housing Loan' ||
        i.name === 'Car Loan' ||
        i.name === 'Songkhoem Loan'
        ) {
        this.recommendLoanList.push(i);
      }
    }
  }

  async onLoanClick(selectedLoan: Product) {
    await this.loanApply.getLoanDetail(selectedLoan.id).then(data => {
      DataCenter.set('loan-apply', 'selectedLoan', data);
    });
    this.router.navigateByUrl('/loan-apply/loan-term-condition', {replaceUrl: true});
    this.onClose();
  }
}
