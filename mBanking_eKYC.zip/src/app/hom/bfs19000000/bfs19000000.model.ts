export interface LoanList {
    loanName: string;
    loanDescription: string;
}
