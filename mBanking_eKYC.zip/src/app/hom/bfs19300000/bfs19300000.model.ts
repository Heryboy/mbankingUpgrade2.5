export interface OccupationalInfo {
    personalAddressCityCode: string;
    personalAddress: string;
    occupationTypeCode: string;
    companyName: string;
    companyCityCode: string;
    companyAddress: string;
    lengthOfService: number;
    monthlyIncome: number;
    requestedAmount: number;
}
