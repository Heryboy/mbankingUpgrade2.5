import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { SelectFullOptionModel } from 'src/app/shared/component/select-full-option/select-full-option.model';
import { OccupationalInfo } from './bfs19300000.model';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { RetrieveProvinceCodeListService } from 'src/app/shared/services/retrieve-province-code-list.service';
import { Product } from 'src/app/shared/TRClass/PPCB0130-res';
import { TranslateService } from '@ngx-translate/core';
import { LoanApplyService } from '../bfs19100000/loan-apply.service';
import { Util } from 'src/app/shared/util';
import { LOCAL_STORAGE, PRODUCT_CATEGORY_CODE, LOAN_PURPOSE_CODE, LANGUAGE } from 'src/app/shared/constants/common.const';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';

@Component({
  selector: 'app-bfs19300000',
  templateUrl: './bfs19300000.component.html',
  styleUrls: ['./bfs19300000.component.scss'],
})
export class BFS19300000Component implements OnInit {

  occupationInfo: OccupationalInfo = {
    personalAddressCityCode: '',
    personalAddress: '',
    occupationTypeCode: '',
    companyName: '',
    companyCityCode: '',
    companyAddress: '',
    lengthOfService: 0,
    monthlyIncome: 0,
    requestedAmount: 0,
  };

  personalAddressCity: string;
  companyAddressCity: string;
  rdbOccupationType: string;

  // selectedLoan: Product;
  isResidanceInfoInputDone = false;
  isOccupationInfoInputDone = false;
  isLoanAmountInfoInputDone = false;

  isResidanceInfoInputEnabled = false;
  isOccupationInfoInputEnabled = false;
  isLoanAmountInfoInputEnabled = false;

  residanceList: SelectFullOptionModel;
  companyLocationList: SelectFullOptionModel;
  loanPurposeList: SelectBoxOptionModel;
  RecommendLoan = [];
  selectedLoan: any;

  util = new Util();
  selectedBranchName: string;

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private province: RetrieveProvinceCodeListService,
    private translate: TranslateService,
    private loanApply: LoanApplyService
  ) {
    this.translate.get('BFS19000000.TS.LOAN_LIST').subscribe(tran => {
      this.RecommendLoan = [
        {
          categoryCode: PRODUCT_CATEGORY_CODE.LOANS,
          categoryName: tran.LOANS,
          description: '',
          id: '',
          imagePath: '',
          name: 'Business',
          loanPurposeCode: LOAN_PURPOSE_CODE.BUSINESS
        },
        {
          categoryCode: PRODUCT_CATEGORY_CODE.LOANS,
          categoryName: tran.LOANS,
          description: '',
          id: '',
          imagePath: '',
          name: 'Purchase Cars',
          loanPurposeCode: LOAN_PURPOSE_CODE.PURCHASE_CARS
        },
        {
          categoryCode: PRODUCT_CATEGORY_CODE.LOANS,
          categoryName: tran.LOANS,
          description: '',
          id: '',
          imagePath: '',
          name: 'Purchase House',
          loanPurposeCode: LOAN_PURPOSE_CODE.PURCHASE_HOUSE
        },
        {
          categoryCode: PRODUCT_CATEGORY_CODE.LOANS,
          categoryName: tran.LOANS,
          description: '',
          id: '',
          imagePath: '',
          name: 'Renovate House',
          loanPurposeCode: LOAN_PURPOSE_CODE.RENOVATE_HOUSE
        },
        {
          categoryCode: PRODUCT_CATEGORY_CODE.LOANS,
          categoryName: tran.LOANS,
          description: '',
          id: '',
          imagePath: '',
          name: 'Other',
          loanPurposeCode: LOAN_PURPOSE_CODE.OTHER
        }
      ];
    });
    this.occupationInfo.lengthOfService = undefined;
    this.occupationInfo.monthlyIncome = undefined;
    this.occupationInfo.requestedAmount = undefined;
    // this.selectedLoan = DataCenter.get('loan-apply', 'selectedLoan', false);
    const appLanguage = this.util.getSecureStorage(LOCAL_STORAGE.I18N);
    const selectedBranch = DataCenter.get('Loan-Apply', 'selectedBranch', false);
    if (selectedBranch) {
      if (appLanguage === LANGUAGE.I18N_KM) {
        this.selectedBranchName = selectedBranch.branchNameKh;
      } else {
        this.selectedBranchName = selectedBranch.branchNameEn;
      }
    }
  }

  ngOnInit() {
    this.getSelectCompanyLocationList();
    this.getSelectResidanceList();
    this.getSelectLoanPurposeList();
  }

  onBtnConfirmResidanceInputInfo(): void {
    this.isResidanceInfoInputDone = true;
  }

  onBtnConfirmOccupationInputInfo(): void {
    this.isOccupationInfoInputDone = true;
  }

  btnBackTest(): void {
    this.router.navigateByUrl('/loan-apply/select-branch');
  }

  onModalDismiss(): void {
    this.navCtrl.back();
  }

  changeClick(ev): void {
    console.log(ev);
    this.onCheckValidation();
  }

  async getSelectResidanceList() {
    await this.province.getRequestCodeList().then(codeList => {
      this.translate.get('BFS19300000.TS').subscribe(tran => {
        this.residanceList = {
          title: tran.PROVINCE,
          itemTextField: 'value',
          itemValueField: 'code',
          option: codeList
        };
      });
    });
  }

  async getSelectCompanyLocationList() {
    await this.province.getRequestCodeList().then(codeList => {
      this.translate.get('BFS19300000.TS').subscribe(tran => {
        this.companyLocationList = {
          title: tran.PROVINCE,
          itemTextField: 'value',
          itemValueField: 'code',
          option: codeList
        };
      });
    });
  }

  getSelectLoanPurposeList(): void {
    const loanOption = [];
    for ( const i of this.RecommendLoan) {
      loanOption.push({value: i.loanPurposeCode, text: i.name});
    }
    this.loanPurposeList = {
      title: 'Select',
      selectedTabValue: '',
      items: [{
        title: '',
        seletedOpt: '',
        itemValueField: 'value',
        itemTextField: 'text',
        option: loanOption
      }]
    };
  }

  onLoanPurposeChange(ev): void {
    console.log(ev);
    for (const i of this.RecommendLoan) {
      if (i.loanPurposeCode === ev.value) {
        this.selectedLoan = i;
      }
    }
    this.onCheckValidation();
  }

  onBtnModifyclick(index: number): void {
    if (index === 0) {
      if (this.isOccupationInfoInputDone === false) {
        this.isLoanAmountInfoInputDone = false;
        this.isOccupationInfoInputDone = false;
        this.isResidanceInfoInputDone = false;
      } else {
        this.isResidanceInfoInputDone = false;
        this.isOccupationInfoInputDone = true;
      }
    } else {
      this.isResidanceInfoInputDone = true;
      this.isOccupationInfoInputDone = false;
    }
  }

  onCheckValidation(): void {
    if (this.occupationInfo.personalAddressCityCode === '' || this.occupationInfo.personalAddress === '') {
      this.isResidanceInfoInputEnabled = false;
    } else {
      this.isResidanceInfoInputEnabled = true;
    }

    if (!this.rdbOccupationType) {
      this.isOccupationInfoInputEnabled = false;
    } else {
      if (this.occupationInfo.companyAddress === '' ||
          this.occupationInfo.companyName === '' ||
          this.occupationInfo.companyCityCode === '' ||
          !this.occupationInfo.lengthOfService ||
          !this.occupationInfo.monthlyIncome) {
          this.isOccupationInfoInputEnabled = false;
      } else {
          this.isOccupationInfoInputEnabled = true;
      }
    }

    if (!this.occupationInfo.requestedAmount || !this.selectedLoan) {
      this.isLoanAmountInfoInputEnabled = false;
    } else {
      this.isLoanAmountInfoInputEnabled = true;
    }
  }

  onResidanceChange(ev): void {
    console.log(ev);
    this.personalAddressCity = ev.value;
    console.log(this.personalAddressCity);
    this.occupationInfo.personalAddressCityCode = ev.code;
    this.onCheckValidation();
  }

  onCompanyLocationChange(ev): void {
    console.log(ev);
    this.companyAddressCity = ev.value;
    console.log(this.companyAddressCity);
    this.occupationInfo.companyCityCode = ev.code;
    this.onCheckValidation();
  }

  onInputChange(ev): void {
    console.log('loan request amount: ', this.occupationInfo.requestedAmount);
    this.onCheckValidation();
  }

  onBtnCancelClick(): void {
    this.loanApply.onCancel();
  }

  onBtnConfirmLoanInputInfo(): void {
    this.isLoanAmountInfoInputDone = true;
    this.occupationInfo.occupationTypeCode = this.rdbOccupationType;
    DataCenter.set('loan-apply', 'occupationInfo', this.occupationInfo);
    DataCenter.set('loan-apply', 'selectedLoan', this.selectedLoan);
    this.router.navigateByUrl('/loan-apply/confirm');
  }
}
