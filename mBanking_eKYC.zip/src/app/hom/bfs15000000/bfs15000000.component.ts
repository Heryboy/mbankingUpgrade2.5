import { Component, OnInit } from '@angular/core';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-bfs15000000',
  templateUrl: './bfs15000000.component.html',
  styleUrls: ['./bfs15000000.component.scss'],
})
export class BFS15000000Component implements OnInit {

  constructor
  (
    private backService: BackService
    )  {
   }

  ngOnInit() {}

  ionViewWillEnter() {
    this.backService.subscribe('home');
  }

  onBack() {
    this.backService.fire();
  }
}
