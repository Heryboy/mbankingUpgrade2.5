import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs10000000',
  templateUrl: './bfs10000000.component.html',
  styleUrls: ['./bfs10000000.component.scss'],
})
export class BFS10000000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
