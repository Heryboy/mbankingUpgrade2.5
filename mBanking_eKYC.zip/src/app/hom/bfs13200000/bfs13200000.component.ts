import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs13200000',
  templateUrl: './bfs13200000.component.html',
  styleUrls: ['./bfs13200000.component.scss'],
})
export class BFS13200000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
