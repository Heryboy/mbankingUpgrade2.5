import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Bfs11100000Page } from './bfs11100000.page';

describe('Bfs11100000Page', () => {
  let component: Bfs11100000Page;
  let fixture: ComponentFixture<Bfs11100000Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Bfs11100000Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Bfs11100000Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
