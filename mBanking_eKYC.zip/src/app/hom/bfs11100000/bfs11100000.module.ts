import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TitleComponent } from 'src/app/shared/component/title/title.component';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ShareModule } from 'src/app/shared/share.module';
import { Bfs11100000Page } from './bfs11100000.page';
import { BFS11200000Component } from './bfs11200000/bfs11200000.component';
import { SBSharedModule } from 'src/app/shared/shared.module';
// import { GroupByPipe } from 'src/app/shared/pipes/group-by-pipe';
const routes: Routes = [
  {
    path: '', component: Bfs11100000Page
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
    FormsModule,
    ShareModule,
    SBSharedModule
  ],
  declarations: [
    Bfs11100000Page, 
    // Bfs11110000Component,
    BFS11200000Component, 
    // Bfs11110000AComponent
  ],
  exports: [
    // TitleComponent
  ],
  entryComponents: [ 
    // Bfs11110000Component, 
    BFS11200000Component, 
    // Bfs11110000AComponent
  ],
  // providers: [
  //   // GroupByPipe
  //   , ModalService]
})
export class Bfs11100000PageModule {}