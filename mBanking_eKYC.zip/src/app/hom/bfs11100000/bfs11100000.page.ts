import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { SelectBoxOptionModel, TabOption } from 'src/app/shared/component/select-option/select-option.model';
import { TitleModel } from 'src/app/shared/component/title/title.model';
import { LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { GroupByPipe } from 'src/app/shared/pipes/group-by-pipe';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PPCB01E0Req } from 'src/app/shared/TRClass/PPCB01E0-req';
import { Bfs11110000AComponent } from './bfs11110000-a/bfs11110000-a.component';
import { Utils } from 'src/app/shared/utils/utils.static';
import { Util } from 'src/app/shared/util';

@Component({
  selector: 'app-bfs11100000',
  templateUrl: './bfs11100000.page.html',
  styleUrls: ['./bfs11100000.page.scss'],
})
export class Bfs11100000Page implements OnInit {
  title: TitleModel;
  items: any[];
  typeItems: any[];
  faqIdList: any[];
  // tempItem: any;
  // typeTempItem: any;
  fqaId: string;
  searchTerm: any = '';
  searchValue: any[];
  listValue: any[];
  option: any[];
  default = 'all';
  searchResult: any;
  faqIdListTemp: any;
  selectFAQ: SelectBoxOptionModel;
  tabOption: TabOption[];
  viewText: any;
  viewTextTitle: any;
  constructor(
              private translate: TranslateService,
              private model: ModalService,
              private bizServer: BizserverService,
              private groupByPipe: GroupByPipe,
              private backService: BackService,
              private router: Router) { }

ngOnInit() {
    this.translate.get('COMMON.LABEL').subscribe((res) => {
      this.viewText = res;
    });
    this.translate.get('BFS11110000.LABEL').subscribe((res) => {
      this.viewTextTitle = res;
    });
    this.title = {
      text: this.viewTextTitle.Title,
      class: 'string',
      backBtn: {
        icon: {
          icon: 'Close'
        },
        class: 'Back',
        defaultHref: '/home',
        handler: () => {
          // console.log('backAction');
        }
      }
    };
    this.requestData();
  }

  ionViewWillEnter() {
    this.backService.subscribe();
  }

  back() {
    this.backService.fire();
  }

  toDetails(val) {
    let index = 0;
    const length = this.faqIdListTemp.length;
    this.faqIdList = [];
    for ( let i = 0; i < length; i++) {
        if (this.faqIdListTemp[i].key) {
          if ( val.toString() === this.faqIdListTemp[i].key.toString()) {
            index = i;
          }
          const countValue = this.faqIdListTemp[i].value.length;
          for (let j = 0; j < countValue; j++) {
              this.faqIdList.push({
                faqId: this.faqIdListTemp[i].value[j].faqId,
                categoryCode: this.faqIdListTemp[i].value[j].categoryCode,
                categoryName: this.faqIdListTemp[i].value[j].categoryName,
              });
          }
        }
    }

    this.model.modal({
      component: Bfs11110000AComponent, /* Bfs11110000AComponent, */
      componentProps: { data: this.faqIdList, faqIdIndex: index }
    });
  }

  private requestData() {
    const reqTr = new PPCB01E0Req();
    reqTr.body.typeCode = "006";  // Mobile Banking
    reqTr.body.userID =  new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

    this.bizServer.bizMOBPost('PPCB01E0', reqTr).then(data => {

      if ( data.body.faqList) {
        this.items = this.groupByPipe.transform(data.body.faqList, 'categoryName');
        // this.tempItem = this.groupByPipe.transform(data.body.faqList, 'categoryCode');
        // this.typeItems = this.groupByPipe.transform(data.body.faqList, 'typeName');
        // this.typeTempItem = this.groupByPipe.transform(data.body.faqList, 'typeCode');
        this.faqIdListTemp = this.groupByPipe.transform(data.body.faqList, 'faqId');
        // this.tempItem = JSON.parse(JSON.stringify(this.tempItem));
        this.searchValue = this.items;
        this.getSelectFAQ();
      }
    });
  }

Cancel() {
   this.router.navigate(['/home']);
}

setFilteredItems() {
  this.searchFAQCon(this.items, 'key' , 'value', this.searchTerm, 'key', this.default);
}

filterItems() {
  this.searchValue = [];
  for (const item of this.items) {
    const tmp = item.value.filter( data => data.title.toLowerCase().includes(this.searchTerm) );
    this.searchValue.push( { key: item.key, value: tmp });
  }
}
searchFAQCon(arr: any[], fieldTitleName: string, listValueName: string, searchValue: any, cateName?: string, cateValue?: string|number) {
  this.searchValue = [];
  let listData = [];
  for (const item of arr) {
    const tempData = {key: item[fieldTitleName], value: item[listValueName]};
    listData.push(tempData);
    if (cateName) {
      if (item[cateName] === cateValue ) {
        listData = [tempData];
        break;
      }
    }
  }
  console.log(searchValue);
  
  const newVal = [];
  for (const searchArr of  listData ) {
    for (const data of searchArr.value) {
        const searchIndex = data.title.toLocaleLowerCase().indexOf(searchValue.toLocaleLowerCase());
        const tmp = {...data};

        if ( searchIndex !== -1 ) {
          let em = '';
          const temp = tmp.title.substr(searchIndex, searchValue.trim().length );

          if (this.searchTerm.trim() !== '') {
            em = `<em>${temp}</em>`;
          }

          tmp.title = tmp.title.replace(temp, em );
          newVal.push(tmp);
        }
      }
    this.searchValue.push( { key: searchArr.key, value: newVal });
  }
}

getSelectFAQ() {
  this.option = [];
  const length = this.items.length;
  this.option.push({
    text: this.viewText.ALL,
    value: 'all'
  });
  for ( let i = 0; i < length; i++) {
     this.option.push({
      text: this.items[i].key,
      value: this.items[i].key
    });
  }

  this.selectFAQ = {
    title: this.viewText.CATEGORY,
    selectedTab: 1,
    selectedTabValue: '',
    items: [
      {
        title: 'titleTab',
        itemValueField: 'value',
        itemTextField: 'text',
        seletedOpt: 'all',
        option: this.option
      }
    ]
  };
}
keyPressed(e) {
  e.detail.target.maxLength = 25;
}

}
