import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Bfs11110000AComponent } from './bfs11110000-a.component';

describe('Bfs11110000AComponent', () => {
  let component: Bfs11110000AComponent;
  let fixture: ComponentFixture<Bfs11110000AComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Bfs11110000AComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Bfs11110000AComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
