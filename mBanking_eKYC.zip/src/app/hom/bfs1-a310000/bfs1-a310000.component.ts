import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs1-a310000',
  templateUrl: './bfs1-a310000.component.html',
  styleUrls: ['./bfs1-a310000.component.scss'],
})
export class BFS1A310000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
