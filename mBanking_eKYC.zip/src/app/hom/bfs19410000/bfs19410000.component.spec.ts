import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS19410000Component } from './bfs19410000.component';

describe('BFS19410000Component', () => {
  let component: BFS19410000Component;
  let fixture: ComponentFixture<BFS19410000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS19410000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS19410000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
