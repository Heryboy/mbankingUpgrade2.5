import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS19500000Component } from './bfs19500000.component';

describe('BFS19500000Component', () => {
  let component: BFS19500000Component;
  let fixture: ComponentFixture<BFS19500000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS19500000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS19500000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
