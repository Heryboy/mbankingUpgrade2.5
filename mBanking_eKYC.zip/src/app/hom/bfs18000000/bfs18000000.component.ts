import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB5720Res } from 'src/app/shared/TRClass/CEB5720-res';
import { CEB5720Req } from 'src/app/shared/TRClass/CEB5720-req';
import { Component, OnInit } from '@angular/core';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { PPCB0130Req } from 'src/app/shared/TRClass/PPCB0130-req';
import { PPCB0130Res } from 'src/app/shared/TRClass/PPCB0130-res';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BFS18100000Component } from '../bfs18100000/bfs18100000.component';
import { GroupByPipe } from 'src/app/shared/pipes/group-by-pipe';
import { TranslateService } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { Util } from 'src/app/shared/util';
import { LOCAL_STORAGE, LOAN_PRODUCT_BU_CODE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

@Component({
  selector: 'app-bfs18000000',
  templateUrl: './bfs18000000.component.html',
  styleUrls: ['./bfs18000000.component.scss'],
})
export class BFS18000000Component implements OnInit {

  i18n;

  selectCategory: SelectBoxOptionModel;
  productList: any[];
  selectCategoryDeful = 'All';
  items: any[];
  trmItems: any[];
  optionCategoryList: any[];
  categoryList: any[];
  viewText: any;
  bizMOBServer = environment.bizMOBServer;
  util = new Util();
  languageCode: string;
  orders = ['Deposits', 'Loans', 'Card Service', 'e-Banking Service', 'Trade Finance', 'Fund Transfer', 'Cash Management Service'];
  accountList;
  isShowButton = false;
  uerInfo: any;
  constructor(
    private bizServer: BizserverService,
    private groupByPipe: GroupByPipe,
    private modal: ModalService,
    private backService: BackService,
    private translate: TranslateService
  ) { }

  ngOnInit() {

    this.i18n = this.util.getSecureStorage(LOCAL_STORAGE.I18N);

    this.languageCode = this.util.getSecureStorage( LOCAL_STORAGE.LANGUAGE_CODE ) ;
    console.log( this.languageCode );
    this.translate.get('COMMON.LABEL').subscribe((res) => {
      this.viewText = res;
    });
    this.doReq();
  }

  ionViewWillEnter() {
    this.uerInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    if ( this.uerInfo ) {
      this.backService.subscribe();
    } else {
      this.backService.subscribe('home');
    }
  }

  back() {
    this.backService.fire();
  }
  doReq() {
    const reqTr = new PPCB0130Req();

    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

    this.bizServer.bizMOBPost('PPCB0130', reqTr).then(async data => {
      const resTr = data as  PPCB0130Res;
      const resultSuccess = this.bizServer.checkResponse(resTr.header);
      if ( resultSuccess ) {
        this.productList = await resTr.body.productList;
        this.categoryList = resTr.body.categoryList;
        this.trmItems = await this.groupByPipe.transform(this.productList, 'categoryName');
        this.items = this.trmItems;
        // this.items = [];
        // if(this.trmItems) {
        //   for(let i = 0; i < this.trmItems.length; i++) {
        //     this.items[i] = this.trmItems[i];
        //   }
        // }
        // this.requestCollateralAccount();
        this.sortCategory();
        this.sort();
        this.setSelectCategory();
      }

    });
  }

  async requestCollateralAccount(accountNo?: any) {
    const reqTr = new CEB5720Req();
    reqTr.body.userID          = Utils.getUserInfo().userID;
    reqTr.body.loanProductCode = LOAN_PRODUCT_BU_CODE;
    reqTr.body.customerNo      = Utils.getUserInfo().customerNo;

    await this.bizServer.bizMOBPost('CEB5720', reqTr).then(data => {
      const resTr = data as CEB5720Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.accountList = resTr.body.collateralAccountInfoList;

        this.accountList.forEach( (account, index) => {
          const isAccount = account.accountNo ? account.accountNo : null;

          if ( isAccount ) {
            this.isShowButton = true;
          }

        });
      }
    });
  }


  setSelectCategory() {
    this.optionCategoryList = [];
    this.optionCategoryList.push({
      text: this.viewText.ALL_CATEGORY,
      value: 'all'
    });

    // this.categoryList = this.groupByPipe.transform(this.productList , 'categoryId');
    // for (const searchArr of  this.categoryList ) {
    //   for (const data of searchArr.value) {
    //     this.optionCategoryList.push({
    //       text: data.categoryName,
    //       value: data.categoryName
    //     });
    //     console.log(data.categoryName);
    //   }
    // }

    // console.log(this.categoryList);
    for (const arr of  this.categoryList ) {
        this.optionCategoryList.push({
          text: arr.name,
          value: arr.name
        });
    }

    // console.log(this.categoryList);

    this.selectCategory = {
      title: this.viewText.CATEGORY, // sort text
      selectedTab: 0,
      selectedTabValue: '',
      items: [
        {
          title: 'titleTab',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: 'all',
          option: this.optionCategoryList
        }
      ]
    };
  }

  filterCategory() {
    // console.log(this.selectCategoryDeful);
    this.items = [];
    // console.log(this.trmItems);
    if ( this.selectCategoryDeful === 'all' ) {
      this.items = this.trmItems;
    } else if ( this.selectCategoryDeful !== 'all') {

      for ( const arr of this.trmItems) {
            if ( arr.key === this.selectCategoryDeful ) {
                this.items.push({
                  key: arr.key,
                  value: arr.value
                });
            }
      }

    }

  }

  toProductDetails(val) {
    DataCenter.set('isFromProductScreen', 'isFromProductScreen', true);
    this.modal.modal({
      component: BFS18100000Component, /* Bfs11110000AComponent, */
      componentProps: { product: val }
    });
  }

  // pipe(arr: any[], property: string) {
  //   let length = arr.length - 1;
  //   for ( const con of arr ) {

  //   }
  // }

  sortCategory() {
    this.categoryList = this.categoryList.sort( (a, b) => {
      const index1 = this.orders.indexOf(a.name);
      const index2 = this.orders.indexOf(b.name);
      if ( index1 === -1) {
        return 1;
      }
      if (index2 === -1) {
        return -1;
      }
      return  index1 - index2;
    } );
  }

  sort() {
    this.items = this.items.sort( (a, b) => {
      const index1 = this.orders.indexOf(a.key);
      const index2 = this.orders.indexOf(b.key);
      if ( index1 === -1) {
        return 1;
      }
      if (index2 === -1) {
        return -1;
      }
      return  index1 - index2;
    } );
  }
}
