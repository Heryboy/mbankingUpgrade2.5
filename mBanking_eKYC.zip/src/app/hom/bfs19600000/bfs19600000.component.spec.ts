import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Bfs19600000Component } from './bfs19600000.component';

describe('Bfs19600000Component', () => {
  let component: Bfs19600000Component;
  let fixture: ComponentFixture<Bfs19600000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Bfs19600000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Bfs19600000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
