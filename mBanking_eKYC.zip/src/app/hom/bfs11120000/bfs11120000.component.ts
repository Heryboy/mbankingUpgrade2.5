import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs11120000',
  templateUrl: './bfs11120000.component.html',
  styleUrls: ['./bfs11120000.component.scss'],
})
export class BFS11120000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
