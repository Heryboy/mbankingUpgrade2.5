import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { MapsService } from 'src/app/shared/services/maps.service';
import { TranslateService } from '@ngx-translate/core';
import { InitMapsModel, DestinationObject } from 'src/app/shared/component/maps/maps.model';
import { BFS14300000Component, SortByType } from '../bfs14300000/bfs14300000.component';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { ModalService } from 'src/app/shared/services/modal.service';
import { MapsComponent } from 'src/app/shared/component/maps/maps.component';
import { Util } from 'src/app/shared/util';
import { LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { IonSlides } from '@ionic/angular';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { PPCB0215Res } from 'src/app/shared/TRClass/PPCB0215-res';
import { DialogService, DialogRef } from '@progress/kendo-angular-dialog';
import { BackService } from 'src/app/shared/services/back.service';
import * as $ from 'jquery';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-bfs14100000',
  templateUrl: './bfs14100000.component.html',
  styleUrls: ['./bfs14100000.component.scss'],
})
export class BFS14100000Component implements OnInit {

  @ViewChild(MapsComponent, { static: true }) mapsComponent: MapsComponent;
  @ViewChild('merChantSlide', { static: true }) ionSlides: IonSlides;

  private util = new Util();
  defaultFilterSelectedText: string;

  userInfo: any;
  categoryCode: string;
  page: number;
  rowsPerPage: number;
  searchText: string;
  userId: string;

  merchantList: PPCB0215Res['body']['items'];
  merchantCategory: any[];
  data: any;
  initMapsData: InitMapsModel;
  dataBranchId = 0;
  sortDefault: SortByType = 'distance';
  typeList = 'partner_with_type';

  hideList = true;
  radioFilter = 'all';

  search: any;
  merchantSearchList: PPCB0215Res['body']['items'];
  defaultFilterSelected = '0';
  distanceRange = {lower: 0, upper: 15};
  markerSetAble = true;

  phoneNumber: Array<string> | string;
  phoneNumberModel: string;

  pageNumber = 1;
  scrollEvent = false;
  merchantType = 'merchant';
  merchanDataFromPush: any;
  @ViewChild('choosePhoneNumberTemplate', {static: false}) choosePhoneNumberTemplate: TemplateRef<HTMLBodyElement>;
  constructor(
    public mapsServices: MapsService,
    private translate: TranslateService,
    private modal: ModalService,
    private callNumber: CallNumber,
    private socialShare: SocialSharing,
    private keyboard: Keyboard,
    private dialogKendo: DialogService,
    private backService: BackService,
    private activeRoute: ActivatedRoute
  ) {
    this.merchantList = [];
  }

  ngOnInit() {
    this.activeRoute.queryParams.subscribe( ( param ) => {
      this.merchanDataFromPush = {
        category: param.category,
        code: param.code
      };
    });
  }

  ionViewDidEnter() {
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    if (this.userInfo) {
      this.backService.subscribe('menu');
    } else {
      this.backService.subscribe('home');
    }
    this.translate.get('BFS14100000.LABEL').subscribe((res) => {
      this.defaultFilterSelectedText = res.ALL;
    });
  }

  async retrieveMerchantData(event: any) {
    if (event) {
      this.merchantList = event as PPCB0215Res['body']['items'];
      if (this.merchantList.length > 0) {
        DataCenter.set('BFS14100000', 'merchantList', this.merchantList);
        this.merchantList = this.util.sortByNumberField(this.merchantList, 'distance')
                                      .filter(
                                        (merchant) =>
                                          (this.distanceRange.lower * 1000 <= merchant.distance)
                                          && (this.distanceRange.upper * 1000 >= merchant.distance)
                                      );
        this.merchantSearchList = this.merchantList;
        this.merchantCategory = await this.mapsServices.getMerchanCategorytList();
      }
      if ( this.merchanDataFromPush ) {
        this.markerClicked(this.merchanDataFromPush);
        this.ionSlideDidChange();
      }

    }
  }

  onClose() {
    this.backService.fire();
  }

  onShowList(): void {
    this.mapsComponent.clearMapRoute();
    this.hideList = false;
  }

  onShowMap(): void {
    this.mapsComponent.clearMapRoute();
    this.hideList = true;
  }

  onFilter() {
    this.mapsComponent.clearMapRoute();
    this.mapsComponent.hideSlide = false;
    this.modal.open({
      message: {
        defaultFilterSelected: this.defaultFilterSelected,
        merchantCategory: this.merchantCategory,
        sortDefault: this.sortDefault,
        distanceRange: this.distanceRange,
        discountType: this.merchantType
      },
      content: BFS14300000Component, modalClass: ['pop_top'],
      callback: (data) => {
        if (data) {
          // this.changeMerchantList(data.discountType);
          this.sortDefault = data.sortingByValue;
          this.defaultFilterSelected = data.defaultFilterSelected;
          this.distanceRange = data.distanceRange;
          if (data.merchantList && data.merchantList.length >= 0) {
            this.merchantCategory.filter( (category: any) => {
              if (this.defaultFilterSelected === category.categoryCode) {
                this.defaultFilterSelectedText = category.categoryName;
              }
            });
            if (this.defaultFilterSelected === '0') {
              this.translate.get('BFS14100000.LABEL').subscribe((res) => {
                this.defaultFilterSelectedText = res.ALL;
              });
            }
            this.merchantList = data.merchantList;
            this.merchantSearchList = this.merchantList;
            this.mapsComponent.setListMarkerOnMap(this.merchantSearchList);
          }
        }
      }
    });
  }

  filterData(list: PPCB0215Res['body']['items']) {
    if (list) {
      this.merchantList = list;
      if (this.distanceRange) {
        this.merchantList = this.merchantList.filter((merchant) => (this.distanceRange.lower <= merchant.distance / 1000)
                                                                && (this.distanceRange.upper >= merchant.distance / 1000));
      }

      if (this.merchantList.length > 0) {
        switch (this.sortDefault) {
          case 'name':
            this.merchantList = this.util.sortByTextField(this.merchantList, 'name');
            break;
          case 'distance':
            this.merchantList = this.util.sortByNumberField(this.merchantList, 'distance');
            break;
          case 'discount':
            this.merchantList = this.util.sortByNumberField(this.merchantList, 'discountRateEnd', 'DESC');
            break;
        }
      }

      if (this.defaultFilterSelected !== '0' && this.merchantList.length > 0) {
        this.merchantList = this.merchantList.filter((merchant) => this.defaultFilterSelected === merchant.categoryCode);
      }
      this.merchantSearchList = this.merchantList;
      this.mapsComponent.setListMarkerOnMap(this.merchantSearchList);
    }
  }


  searchSelectElement() {
    this.mapsComponent.clearMapRoute();
    this.merchantSearchList = this.util.searchSelectElement(this.search, this.merchantList, 'name');
  }

  onCall(description: string) {
    this.mapsComponent.clearMapRoute();
    this.phoneNumber = this.getPhoneNumber(description);
    if (this.phoneNumber === undefined) {
      this.modal.alert({
        title: '',
        content: this.translate.instant('COMMON.ALERT.PHONE_NUMBER_NOT_AVAILABLE'),
        btnText: this.translate.instant('COMMON.BUTTON.OK')
      });
    }
    if (this.phoneNumber) {
      if (typeof this.phoneNumber === 'string') {
        this.callNumber.callNumber(this.formatPhoneNumber(this.phoneNumber), false);
      } else if (typeof this.phoneNumber === 'object') {
        this.phoneNumberModel = this.phoneNumber[0];
        this.onChoosePhoneNumber(this.choosePhoneNumberTemplate);
      }
    }
  }

  formatPhoneNumber(phoneNumber: string): string {
    if (!phoneNumber.match(/^[8][5][5][)]|^[0]/g)) {
      return '0' + phoneNumber;
    } else {
      return phoneNumber.trim().replace('855)', '0');
    }
  }

  getPhoneNumber(description: string): Array<string> | string {
    const regexTelFormat = /[(855)]{5}[1-9]{1,1}[0-9]{7,8}|[/0-9]{9,10}|[^0-9][+0]{1,1}[1-9]{2,2}[-\s\.0-9]{6,10} */g;
    const merchantDescription = String(description);
    const phoneNumberAfterSearch = merchantDescription ? merchantDescription.replace(/[\s-]/g, '').match(regexTelFormat) : undefined;
    const phoneNumberAfterFormat = phoneNumberAfterSearch ?
                                      merchantDescription
                                      .replace(/[\s-]/g, '')
                                        .match(regexTelFormat)
                                        .map(p => p.substr(1, p.length))
                                          : undefined;
    if (phoneNumberAfterFormat) {
      if (phoneNumberAfterFormat.length === 1) {
        return phoneNumberAfterFormat.toString();
      } else if (phoneNumberAfterFormat.length > 1) {
        return phoneNumberAfterFormat;
      } else {
        return;
      }
    } else {
      return ;
    }
  }

  onChoosePhoneNumber(template: TemplateRef<any>) {
    this.translate.get('COMMON.BUTTON').subscribe( res => {
      const dialog = this.dialogKendo.open({
        title: this.translate.instant('BFS14100000.ALERT.CHOOSE_MERCHANT_PHONE_NUMBER'),
        content: template,
        actions: [
          { text: res.CANCEL },
          { text: res.CALL, primary: true}
        ]
      });
      $('kendo-dialog').on('click', '.k-overlay', () => {
        dialog.close();
      });
      dialog.dialog.location.nativeElement.classList.add('pop_confirm');
      this.pushKendoDialog(dialog);
      dialog.result.subscribe( (response: any) => {
        this.removeKendoDialog(dialog); // back btn impl

        if (response && response.primary) {
          this.callNumber.callNumber(this.formatPhoneNumber(this.phoneNumberModel), false);
        }
      });
    });
  }

  pushKendoDialog(dialog: DialogRef) {
    let dialogList = DataCenter.get('modal-service', 'dialogList', false) as DialogRef[];
    if (!dialogList) {
        dialogList = [];
        DataCenter.set('modal-service', 'dialogList', dialogList, true);
    }
    dialogList.push(dialog);
  }

  removeKendoDialog(dialog: DialogRef) {
    const dialogList = DataCenter.get('modal-service', 'dialogList', false) as DialogRef[];
    if (!dialogList) {
        return;
    }
    const index = dialogList.findIndex(d => d === dialog);
    if (index > -1) {
        dialogList.splice(index, 1);
    }
  }

  onShare(data) {
    this.translate.get('BFS14100000.LABEL').subscribe(translate => {
      if (translate) {
        const shareData = `${translate.MERCHANT_NAME}: ${data.name}
        ${translate.MERCHANT_ADDRESS}: ${data.address}
        ${translate.MERCHANT_DISCOUNT_RATE}: ${data.discountRateEnd}%~${data.discountRateEnd}%`;
        this.mapsComponent.clearMapRoute();
        this.socialShare.share(shareData);
      }
    });
  }

  onDirections(lat: number, lng: number, code: string) {
    this.mapsComponent.clearMapRoute();
    this.mapsServices.calculateAndDisplayRoute({lat, lng, code} as DestinationObject);
    this.onShowMap();
  }

  markerClicked(merchant: any) {
    this.mapsComponent.clearMapRoute();
    this.markerSetAble = false;
    const index = this.merchantList.findIndex( m => m.code === merchant.code && merchant.category === 'merchant');
    this.ionSlides.slideTo(index);
  }

  ionSlideDidChange() {
    this.mapsComponent.clearMapRoute();
    if (!this.markerSetAble) {
        this.markerSetAble = true;
        return;
    }
    this.ionSlides.getActiveIndex().then( (index) => {
      const merchant = this.merchantList[index];
      this.mapsComponent.setMarker(merchant.latitude, merchant.longitude, merchant.code);
    });
  }

  onSearchBarClicked() {
    if (!this.merchantList || this.merchantList.length === 0) {
      this.hideList = true;
    } else {
      this.hideList = false;
    }
  }

  hideKeyboard() {
    this.keyboard.hide();
  }

  scrollLoadData(event) {
    setTimeout(() => {
        if​​(this.merchantList.length >​​​0) {
          this.pageNumber = ++this.pageNumber;
          // this.retrieveMerchantData();
        }
        event.target.complete();
        if (this.merchantList.length === 0) {
          event.target.disabled = !this.scrollEvent;
       }
    }, 500);
  }

  slideLoadData() {
    if​​(this.merchantList.length >​​​0) {
      this.pageNumber = this.pageNumber;
      // this.retrieveMerchantData();
    }
  }

  setMaxLength(e) {
    e.detail.target.maxLength = 25;
  }

  // async changeMerchantList(value) {
  //   this.merchantType = value;
  //   await this.mapsComponent.reqMapDataList(this.merchantType === 'merchant' ? '02' : '01');
  //   await this.retrieveMerchantData(this.mapsComponent.list);
  //   this.mapsComponent.clearMapRoute();
  //   this.mapsComponent.hideSlide = false;
  //   this.filterData(this.merchantList);
  // }
  async changeMerchantList() {
    await this.mapsComponent.reqMapDataList(this.merchantType === 'merchant' ? '02' : '01');
    await this.retrieveMerchantData(this.mapsComponent.list);
    this.mapsComponent.clearMapRoute();
    this.mapsComponent.hideSlide = false;
    this.filterData(this.merchantList);
  }
}
