import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

export class Facility {
  name?: string;
  code?: string;
  checked?: boolean;
}
@Component({
  selector: 'app-bfs12400000',
  templateUrl: './bfs12400000.component.html',
  styleUrls: ['./bfs12400000.component.scss'],
})
export class BFS12400000Component implements OnInit {

  @Input() modal;
  filterValue: string;
  branchList: any[];
  branchFacility: Facility[];
  checkedFacility: any[];

  constructor(
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.branchList = this.modal.message.branchList;
    this.filterValue = this.modal.message.filterValue;
    this.checkedFacility = this.modal.message.facility;
    if (this.checkedFacility && this.checkedFacility.length > 0) {
      this.branchFacility = this.checkedFacility;
    } else {
      this.branchFacility = this.branchFacility.map((facility: any) => {
        return { name: facility.name, code: facility.code, checked: false };
      });
    }
  }
  onCheck() {
    this.checkedFacility = this.branchFacility;
  }

  filterValueChange() {
    this.branchFacility = this.branchFacility.map((facility: any) => {
      return { name: facility.name, code: facility.code, checked: true };
    });
    this.checkedFacility = this.branchFacility;
  }

  onApply() {
    this.onClose();
    this.modal.callback({checkedFacility: this.checkedFacility, filterValue: this.filterValue});
  }

  onClose() {
    this.modal.close();
  }
}
