import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs14200000',
  templateUrl: './bfs14200000.component.html',
  styleUrls: ['./bfs14200000.component.scss'],
})
export class BFS14200000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
