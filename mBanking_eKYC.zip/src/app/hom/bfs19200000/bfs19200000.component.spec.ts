import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS19200000Component } from './bfs19200000.component';

describe('BFS19200000Component', () => {
  let component: BFS19200000Component;
  let fixture: ComponentFixture<BFS19200000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS19200000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS19200000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
