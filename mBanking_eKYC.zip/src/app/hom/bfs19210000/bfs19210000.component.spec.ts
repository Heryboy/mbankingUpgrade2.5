import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS19210000Component } from './bfs19210000.component';

describe('BFS19210000Component', () => {
  let component: BFS19210000Component;
  let fixture: ComponentFixture<BFS19210000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS19210000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS19210000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
