import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BFS14400000Component } from './bfs14400000.component';

describe('BFS14400000Component', () => {
  let component: BFS14400000Component;
  let fixture: ComponentFixture<BFS14400000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BFS14400000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BFS14400000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
