import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bfs14400000',
  templateUrl: './bfs14400000.component.html',
  styleUrls: ['./bfs14400000.component.scss'],
})
export class BFS14400000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
