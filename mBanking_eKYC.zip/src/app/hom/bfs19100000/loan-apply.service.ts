import { Injectable } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Router } from '@angular/router';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { CEB1621Req } from 'src/app/shared/TRClass/CEB1621-req';
import { PersonalInfo } from '../bfs19200000/bfs19200000.model';
import { OccupationalInfo } from '../bfs19300000/bfs19300000.model';
import { Product, PPCB0130Res, ProductCategory } from 'src/app/shared/TRClass/PPCB0130-res';
import { Util } from 'src/app/shared/util';
import { UserInfo } from 'src/app/shared/TRClass/CEB5621-req';
import { CEB1621ResponeBody, CEB1621Res } from 'src/app/shared/TRClass/CEB1621-res';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { LOCAL_STORAGE, PRODUCT_CATEGORY_CODE } from 'src/app/shared/constants/common.const';
import { TranslateService } from '@ngx-translate/core';
import { PPCB0130Req } from 'src/app/shared/TRClass/PPCB0130-req';
import { PPCB0140Req } from 'src/app/shared/TRClass/PPCB0140-req';
import { PPCB0140Res, ProductDetail } from 'src/app/shared/TRClass/PPCB0140-res';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { SelectService } from 'src/app/shared/services/select.service';
import { MapsService } from 'src/app/shared/services/maps.service';
import { PPCB0160Req } from 'src/app/shared/TRClass/PPCB0160-req';
import { PPCB0160Res } from 'src/app/shared/TRClass/PPCB0160-res';
import { BackService } from 'src/app/shared/services/back.service';

@Injectable({
  providedIn: 'root'
})
export class LoanApplyService {

  isUserSignedIn: boolean;
  personalInfo: PersonalInfo;
  occupationInfo: OccupationalInfo;
  selectedLoan: any;
  selectedBranch: any;
  util = new Util();
  userInfo: UserInfo;
  loanApplyRes: CEB1621ResponeBody;
  transactionCurrencyCode: string;
  branchList = [];
  selectBranch: SelectBoxOptionModel;
  currentLocation: any;

  constructor(
    private modal: ModalService,
    private router: Router,
    private bizServer: BizserverService,
    private translate: TranslateService,
    private selectService: SelectService,
    private map: MapsService,
  ) {}

  loadData(): void {
    this.isUserSignedIn = DataCenter.get('loan-apply', 'isSignedIn', false);
    console.log('is user signed in? ', this.isUserSignedIn);
    this.transactionCurrencyCode = DataCenter.get('loan-apply', 'transactionCurrencyCode', false);
    this.selectedBranch = DataCenter.get('loan-apply', 'selectedBranch', false);
    this.selectedLoan = DataCenter.get('loan-apply', 'selectedLoan', false);
    this.personalInfo = DataCenter.get('loan-apply', 'personalInfo', false);
    this.occupationInfo = DataCenter.get('loan-apply', 'occupationInfo', false);
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    console.log(this.userInfo);
  }

  clearDataCenter(): void {
    DataCenter.clear('loan-apply', 'selectedLoan');
    DataCenter.clear('loan-apply', 'personalInfo');
    DataCenter.clear('loan-apply', 'occupationInfo');
    DataCenter.clear('loan-apply', 'transactionCurrencyCode');
    DataCenter.clear('bfs19410000');
  }

  async getBranchList() {
    this.currentLocation = await this.map.getCurrentLocation().catch( error => console.log(error));
    this.branchList = [];
    const reqTr = new PPCB0160Req();
    const branchOptionCode = '01';
    reqTr.body.branchOptionCode = branchOptionCode;
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

    const resTr = await this.bizServer.bizMOBPost('PPCB0160', reqTr) as PPCB0160Res;
    const resultSuccess = this.bizServer.checkResponse(resTr.header);
    if (resultSuccess) {
      this.branchList = resTr.body.branchList;
      if (this.currentLocation) {
        this.branchList = this.branchList.map((branch: any) => {
            const destination = {lat: branch.latitude, lng: branch.longitude};
            const distance = this.map.calculateDirectDistanceFromUser(destination, this.currentLocation);
            const branchObject = {...branch, distance, userLocation: this.currentLocation};
            return branchObject;
        });
        this.branchList = this.branchList.sort((a: any, b: any) => a.distance - b.distance);
      }
      return this.branchList;
    }
  }

  async onSelectBranch(routeTo?: string) {
    const appLang = this.util.getSecureStorage(LOCAL_STORAGE.I18N);
    if (!this.branchList || this.branchList.length === 0) {
      this.branchList = await this.getBranchList();
    }
    const optionList = [];
    for (const i of this.branchList) {
      let branchName: string;
      let branchAddress: string;

      if (appLang === 'zh') {
        branchName = i.branchNameCn;
        branchAddress = i.branchAddressCn;
      } else if (appLang === 'km') {
        branchName = i.branchNameKh;
        branchAddress = i.branchAddressKh;
      } else if (appLang === 'ja') {
        branchName = i.branchNameJp;
        branchAddress = i.branchAddressJp;
      } else if (appLang === 'ko') {
        branchName = i.branchNameKr;
        branchAddress = i.branchAddressKr;
      } else {
        branchName = i.branchNameEn;
        branchAddress = i.branchAddressEn;
      }

      const obj = {};
      obj['itemValueField'] = i.branchNameEn;
      obj['itemTextField'] = '<span class=\' account_name\'>' + branchName + '</span> <br/> ' +
        '<span>' + branchAddress + '</span>';
      optionList.push(obj);
    }

    this.selectBranch = {
      title: this.translate.instant('BFS19100000.LABEL.SELECT_NEAREST_BRANCH'),
      items: [
        {
          title: 'Select',
          itemValueField: 'itemValueField',
          itemTextField: 'itemTextField',
          seletedOpt: 0,
          option: optionList
        },
      ]
    };
    const result = await this.selectService.present(this.selectBranch);
    console.log(' result: ', result);
    if (result) {
      for (const i of this.branchList) {
        if (result && result.itemValueField === i.branchNameEn) {
          DataCenter.set('loan-apply', 'selectedBranch', i);
          if (routeTo) {
            this.router.navigateByUrl(routeTo, {replaceUrl: true});
          }
          break;
        }
      }
    }
    return result;
  }

  onCancel(): void {
    this.loadData();
    this.translate.get('BFS19100000.TS').subscribe(tran => {
      this.modal.confirm({
        content: tran.DO_YOU_WANT_TO_CANCEL_LOAN_APPLY,
        height: 200,
        width: 300,
        minWidth: 300,
        modalClass: ['pop_confirm'],
        lBtn: {
          btnText: tran.NO,
        },
        rBtn: {
          btnText: tran.YES,
          callback: () => {
            if (this.isUserSignedIn) {
              this.router.navigateByUrl('/open/loan-apply/select-loan', {replaceUrl: true});
            } else {
              this.router.navigateByUrl('/home', {replaceUrl: true});
            }
            this.clearDataCenter();
          }
        }
      });
    });
  }

  async onConfirm() {
    this.loadData();
    await this.requestLoanApply();
    if (this.loanApplyRes) {
      // Success To-Do
      this.router.navigateByUrl('/home/loan-apply/result', {replaceUrl: true});
    } else {
      // Fail To-Do
      console.log('Request to server fail.');
    }
  }

  async requestLoanApply() {
    this.loadData();
    let branchCode: string;
    if (this.selectedBranch) {
      branchCode = this.selectedBranch.branchCode;
    } else {
      branchCode = '';
    }
    const reqTr = new CEB1621Req();
    reqTr.body.userID  = this.isUserSignedIn ? this.userInfo.userID : '';
    reqTr.body.customerNo = this.isUserSignedIn ? this.userInfo.customerNo : '';
    reqTr.body.familyName = this.personalInfo.familyName;
    reqTr.body.firstName = this.personalInfo.firstName;
    reqTr.body.nationalID = this.personalInfo.nationalID;
    reqTr.body.phoneNo = this.personalInfo.phoneNo;
    reqTr.body.visitBranchCode = branchCode;
    reqTr.body.gender = this.personalInfo.gender;
    reqTr.body.maritalStatusCode = this.personalInfo.maritalStatusCode;
    reqTr.body.birthCountryCode = this.personalInfo.birthCountryCode;
    reqTr.body.birthProvince = this.personalInfo.birthProvince;
    reqTr.body.personalAddressCityCode = this.occupationInfo.personalAddressCityCode;
    reqTr.body.personalAddress = this.occupationInfo.personalAddress;
    reqTr.body.occupationTypeCode = this.occupationInfo.occupationTypeCode;
    reqTr.body.companyName = this.occupationInfo.companyName;
    reqTr.body.companyCityCode = this.occupationInfo.companyCityCode;
    reqTr.body.companyAddress = this.occupationInfo.companyAddress;
    reqTr.body.lengthOfService = this.occupationInfo.lengthOfService;
    reqTr.body.monthlyIncome = this.occupationInfo.monthlyIncome;
    reqTr.body.loanPurposeCode = this.selectedLoan.loanPurposeCode;
    reqTr.body.loanRequestAmount = this.occupationInfo.requestedAmount;
    reqTr.body.transactionCurrencyCode = this.transactionCurrencyCode;

    const resTr = await this.bizServer.bizMOBPost('CEB1621', reqTr) as CEB1621Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      this.loanApplyRes = resTr.body;
    }
  }

  async getLoanList() {
    let productList: Array<Product>;
    let categoryList: Array<ProductCategory>;
    const loanList: Array<Product> = [];
    const reqTr = new PPCB0130Req();

    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

    const resTr = await this.bizServer.bizMOBPost('PPCB0130', reqTr) as PPCB0130Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      // Success To-Do
      productList = resTr.body.productList;        // productList
      categoryList = resTr.body.categoryList;        // categoryList
      for (const i of productList) {
        if (i.categoryCode === PRODUCT_CATEGORY_CODE.LOANS) {
          loanList.push(i);
        }
      }
    } else {
      // Fail To-Do
    }
    return loanList;
  }

  async getLoanDetail(productID: string) {
    let selectedLoan: ProductDetail;
    const reqTr = new PPCB0140Req();
    reqTr.body.productID = Number(productID);
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
     // PPCB0140
    const resTr = await this.bizServer.bizMOBPost('PPCB0140', reqTr) as PPCB0140Res;
    if (this.bizServer.checkResponse(resTr.header)) {
      selectedLoan = resTr.body as ProductDetail;
    }
    return selectedLoan;
  }

  onSuccess(): void {
    if (this.isUserSignedIn) {
      this.router.navigateByUrl('/acc/main/my-account', {replaceUrl: true});
    } else {
      this.router.navigateByUrl('/home', {replaceUrl: true});
    }
    this.clearDataCenter();
  }
}

export interface CurrentLocation {
  lat: number;
  lng: number;
}

