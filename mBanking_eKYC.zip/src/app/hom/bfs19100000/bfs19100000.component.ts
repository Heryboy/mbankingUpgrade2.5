import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { BackService } from 'src/app/shared/services/back.service';
import { Util } from 'src/app/shared/util';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { LoanApplyService } from './loan-apply.service';

@Component({
  selector: 'app-bfs19100000',
  templateUrl: './bfs19100000.component.html',
  styleUrls: ['./bfs19100000.component.scss'],
})
export class BFS19100000Component implements OnInit, AfterViewInit {

  isBtnAgreeEnabled = false;
  scrollDepthTriggered = false;
  @ViewChild(IonContent, {static: false}) content: IonContent;

  util = new Util();
  selectedBranch: any;
  selectBranch: SelectBoxOptionModel;
  isBtnAgreeTermAndConditionClicked: boolean;

  constructor(
    private loanApply: LoanApplyService,
    private backService: BackService
  ) {}

  ngOnInit() {}

  async ngAfterViewInit() {
    const scrollElement = await this.content.getScrollElement();
    const hasScrollbar = scrollElement.scrollHeight > scrollElement.clientHeight;
    if (!hasScrollbar) {
      //your screen if no scroll
      this.isBtnAgreeEnabled = true;
    }
  }

  ionViewWillEnter() {
    this.subscribeBackButton();
  }

  subscribeBackButton(): void {
    const isSignedIn = DataCenter.get('loan-apply', 'isSignedIn', false);
    if (isSignedIn) {
      this.backService.subscribe('select_loan');
    } else {
      this.backService.subscribe('loan_apply');
    }
  }

  async onScroll($event) {
    // only send the event once
    if (this.scrollDepthTriggered) {
      return;
    }
    const scrollElement = await $event.target.getScrollElement();
    const scrollHeight = scrollElement.scrollHeight - scrollElement.clientHeight;
    const currentScrollDepth = $event.detail.scrollTop;
    const targetPercent = 90;
    const triggerDepth = ((scrollHeight / 100) * targetPercent);
    if (currentScrollDepth > triggerDepth) {
      this.scrollDepthTriggered = true;
      this.isBtnAgreeEnabled = true;
    }
  }

  async onBtnAgreeTermAndCondition() {
    if (!this.isBtnAgreeTermAndConditionClicked) {
      this.loanApply.onSelectBranch('/home/loan-apply/personal-info');
      this.isBtnAgreeTermAndConditionClicked = true;
    }
    setTimeout(() => {
      this.isBtnAgreeTermAndConditionClicked = false;
    }, 1500);
  }

  onBtnCancelClick(): void {
    this.loanApply.onCancel();
  }

}
