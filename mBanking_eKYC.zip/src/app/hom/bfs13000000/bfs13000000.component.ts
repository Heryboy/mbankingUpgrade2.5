import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { IonInfiniteScroll } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { TitleModel } from 'src/app/shared/component/title/title.model';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PPCB0110Req } from 'src/app/shared/TRClass/PPCB0110-req';
import { PPCB0110Res } from 'src/app/shared/TRClass/PPCB0110-res';
import { PPCBHeader } from 'src/app/shared/TRclasses/ppcbheader';
import { Util } from 'src/app/shared/util';
import { BFS13100000Component } from '../bfs13100000/bfs13100000.component';
import { NEWS_EVENT_CATEGORY_CODE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { Router } from '@angular/router';
import { GroupByPipe } from 'src/app/shared/pipes/group-by-pipe';
import { BackService } from 'src/app/shared/services/back.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

@Component({
  selector: 'app-bfs13000000',
  templateUrl: './bfs13000000.component.html',
  styleUrls: ['./bfs13000000.component.scss'],
})
export class BFS13000000Component implements OnInit {
  PPCBHeader: PPCBHeader;
  PPCB0110Res: PPCB0110Res[];
  newsList: any[];
  default = NEWS_EVENT_CATEGORY_CODE.ALL;
  select: SelectBoxOptionModel;
  searchResult: any;
  title: TitleModel;
  rowsPerPage = 10;
  page = 1;
  reqTr = new PPCB0110Req();
  length: number;
  items: any[];
  newsIdList: any[];
  search: string;
  searchValue: any[];
  @ViewChild(IonInfiniteScroll, {static : true}) infiniteScroll: IonInfiniteScroll;
  constructor(
    private translate: TranslateService,
    private modalService: ModalService,
    private bizServer: BizserverService,
    private groupByPipe: GroupByPipe,
    private router: Router,
    private backService: BackService,
    private zone: NgZone  ) {
      this.newsList = [];
      this.newsIdList = [];
      this.reqTr.body.page  = this.page;        // page
      this.reqTr.body.categoryCode  = this.default;        // categoryCode '000000': All, '004002':News, 'Event': 004003 '004004':Notification
      this.reqTr.body.rowsPerPage  = this.rowsPerPage;        // rowsPerPage
      this.reqTr.body.searchKey = '';
      this.reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
      this.search = '';
  }

  languageCode: string;
  util = new Util();
  userInfo: object;
  buttonTextAuth: string;
  viewText: any;
  categoryCode = {
    news: NEWS_EVENT_CATEGORY_CODE.NEWS,
    notices: NEWS_EVENT_CATEGORY_CODE.NOTIFICATION,
    event: NEWS_EVENT_CATEGORY_CODE.EVENT
  };
  ionViewWillEnter() {
    const uerInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    if ( uerInfo ) {
      this.backService.subscribe();
    } else {
      this.backService.subscribe('home');
    }
  }
  ngOnInit() {
    this.translate.get('COMMON.LABEL').subscribe((res) => {
      this.viewText = res;
      // this.title = {
      //   text: 'FAQ',
      //   class: 'string btn_head_back',
      //   backBtn: {
      //      icon: {
      //       icon: ''
      //     },
      //     class: 'Back',
      //      defaultHref: '/home/before-sign',
      //     handler: () => {
      //       console.log('backAction');
      //     }
      //   }
      // };
      this.doReq(false);
      this.setFilter();
    });
    // this.backService.subscribe();
  }
  back() {
    this.backService.fire();
  }
  doReq(v: boolean) {
    this.bizServer.bizMOBPost('PPCB0110', this.reqTr, v).then(data => {
      const res = data as PPCB0110Res;
      if ( this.bizServer.checkResponse(res.header) ) {
        this.PPCB0110Res = data.body;
        this.length = data.body.newsList.length;
        this.newsList = data.body.newsList;
        this.searchValue = this.newsList;
        if ( this.search !== '') {
          this.searchSelectElement(this.searchValue);
        }
      }
    });
  }

  btnToDetailsEvents(newsId) {
    DataCenter.set('isFromNewEventsScreen', 'isFromNewEventsScreen', true);
    let indexOf = 0;
    const newsIdList = this.groupByPipe.transform(this.newsList, 'newsId');
    const index = newsIdList.length;
    if ( index > 0 ) {
      for ( let i = 0; i < index ; i++) {
          if ( Number(newsId) === Number(newsIdList[i].key) ) {
            console.log('is compared', newsId, Number(newsIdList[i].key), i);
            indexOf = i;
            break;
          }
      }
    }
    this.modalService.modal({
      component: BFS13100000Component,
      componentProps: {data: newsIdList, newsIdIndex: indexOf}
    });

  }

  setFilter() {
    this.items = this.groupByPipe.transform(this.newsList, 'categoryName');
    this.select = {
      title: this.viewText.SORT, // sort text
      selectedTab: 0,
      selectedTabValue: 'All',
      items: [
        {
          title: 'titleTab',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: NEWS_EVENT_CATEGORY_CODE.ALL,
          option: [
            {
              text: this.viewText.ALL,
              value: NEWS_EVENT_CATEGORY_CODE.ALL
            },
            {
              text: this.viewText.NOTIFIACATION,
              value: this.categoryCode.notices
            },
            {
              text: this.viewText.NEWS,
              value: this.categoryCode.news
            },
            {
              text: this.viewText.EVENT,
              value: this.categoryCode.event
            }
          ]
        }
      ]
    };
  }

  scrollLoadData(event) {

     setTimeout(() => {
        if ( this.length > 0 ) {
          this.reqTr.body.page += this.page;
          this.reqTr.body.categoryCode  = this.default;
          this.reqTr.body.rowsPerPage = this.rowsPerPage;        // rowsPerPage
          this.reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

          this.bizServer.bizMOBPost('PPCB0110', this.reqTr, true).then(data => {
              this.PPCB0110Res = data.body;
              if ( data.body.newsList && data.body.newsList !== []) {
                this.length = data.body.newsList.length;
                this.newsList = [...this.newsList, ...data.body.newsList];
                this.searchValue = this.newsList;
              }
          });
        }
        event.target.complete();
        if (this.length === 0) {
           event.target.disabled = true;
        }
     }, 500);
  }

  toggleInfiniteScroll() {
    this.infiniteScroll.disabled = !this.infiniteScroll.disabled;
  }

  selectChange() {
    this.reqTr.body.page  = this.page;
    this.reqTr.body.categoryCode  = this.default;
    this.reqTr.body.rowsPerPage  = this.rowsPerPage;
    this.reqTr.body.searchKey = this.search;
    this.reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
    this.doReq(true);
  }


  keyPressed(e) {
    console.log(e.target.value.length);
    e.detail.target.maxLength = 25;
  }

  searchBar(event) {
      this.reqTr.body.page  = 1;        // page
      this.reqTr.body.categoryCode  = this.default;   // categoryCode '000000': All, '004002':News, 'Event': 004003 '004004':Notification
      this.reqTr.body.rowsPerPage  = this.rowsPerPage;        // rowsPerPage
      this.reqTr.body.searchKey = this.search;
      this.reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
      /* console.log('key search', this.reqTr.body); */
      this.doReq(true);
  }

  searchSelectElement(arr) {
    const newVal = [];
    for (const searchArr of  arr ) {
          const searchIndex = searchArr.title.toLocaleLowerCase().indexOf(this.search.toLocaleLowerCase());
          const tmp = {...searchArr};
          if ( searchIndex !== -1 ) {
            let em = '';
            const temp = tmp.title.substr(searchIndex, this.search.trim().length );
            if (this.search.trim() !== '') {
              em = `<em>${temp}</em>`;
            }
            tmp.title = tmp.title.replace(temp, em );
          }
          newVal.push(tmp);
          this.searchValue = newVal;
    }
  }

  btnBack() {
   this.zone.run(() => { this.router.navigate(['/home']); });
  }
  btnCancel() {
    this.zone.run(() => { this.router.navigate(['/home']); });
  }

}
