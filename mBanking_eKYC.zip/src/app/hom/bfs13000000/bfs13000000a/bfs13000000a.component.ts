import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { Util } from 'src/app/shared/util';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { LOCAL_STORAGE, LANGUAGE } from 'src/app/shared/constants/common.const';
import { PPCB0120Req } from 'src/app/shared/TRClass/PPCB0120-req';
import { PPCB0120Res } from 'src/app/shared/TRClass/PPCB0120-res';

@Component({
  selector: 'app-bfs13000000a',
  templateUrl: './bfs13000000a.component.html',
  styleUrls: ['./bfs13000000a.component.scss'],
})
export class BFS13000000aComponent implements OnInit {

  constructor(
    // private navParams: NavParams,
     private bizServer: BizserverService,
  ) { }

  // languageCode: string;
  // util = new Util();

  ngOnInit() {
    /* const newsId = this.navParams.get('reqData');

    const reqTr = new PPCB0120Req();

    reqTr.body.newsId = newsId;

    this.bizServer.bizMOBPost(reqTr).subscribe(data => {
      const resTr         = data as PPCB0120Res;
      const resultSuccess = this.bizServer.checkResponse(resTr.header);

      if ( resultSuccess ) {
        const newsDetail = resTr.body;

        // TODO: render news Detail
        console.log( newsDetail );
      }
    }); */
  }

  doReq() {
    const reqTr = new PPCB0120Req();
    reqTr.body.newsId  = 1;        // newsId
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );
    this.bizServer.bizMOBPost('PPCB0120', reqTr).then(data => {
      const resTr = data as PPCB0120Res;

    });
  }

}
