import { HttpClient, HttpClientJsonpModule, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { BizWaveAppIron } from '@ionic-native/bizwave-plugin-appiron/ngx';
import { BizWaveApplicationExit } from '@ionic-native/bizwave-plugin-applicationexit/ngx';
import { AuthSecurity } from '@ionic-native/bizwave-plugin-authsecurity/ngx';
import { BizWaveCheckProxy } from '@ionic-native/bizwave-plugin-checkproxy/ngx';
import { BizWaveDeviceInfo } from '@ionic-native/bizwave-plugin-deviceinfo/ngx';
import { BizWavePush } from '@ionic-native/bizwave-plugin-bizpush/ngx';
import { BizWaveSecureKeypad } from '@ionic-native/bizwave-plugin-securekeypad/ngx';
// import { BizWaveUpdate } from '@ionic-native/bizwave-plugin-update/ngx';
import { Broadcaster } from '@ionic-native/broadcaster/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Camera } from '@ionic-native/camera/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { Contact, Contacts } from '@ionic-native/contacts/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { ImagePicker } from '@ionic-native/image-picker/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Network } from '@ionic-native/network/ngx';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { TouchID } from '@ionic-native/touch-id/ngx';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BizPushService } from './bizmob/biz-push.service';
import { SBSharedModule } from './shared/shared.module';
import { HTTP } from '@ionic-native/http/ngx';
// import { BizWaveSpeechToText } from '@ionic-native/bizwave-plugin-speechtotext/ngx';
import { Diagnostic } from '@ionic-native/diagnostic/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
import { ThemeDetection } from '@ionic-native/theme-detection/ngx';
import { Badge } from '@ionic-native/badge/ngx';
import { Injector, APP_INITIALIZER } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LOCATION_INITIALIZED, DatePipe } from '@angular/common';
import { ShareModule } from './shared/share.module';
// import { AppLauncher } from '@ionic-native/app-launcher/ngx';
import { InterceptorService } from './shared/interceptor.service';
// import { BizWaveFBAnalytics } from '@ionic-native/bizwave-plugin-firebaseAnalytics';
// import { AppAvailability } from '@ionic-native/app-availability/ngx';
// import { KakaoCordovaSDK } from 'kakao-sdk/ngx';
import { BizWaveUpdateBizportal } from '@ionic-native/bizwave-plugin-update-bizportal/ngx';
import { BizWaveCheckRooting } from '@ionic-native/bizwave-plugin-checkrooting/ngx';
import { BizWaveContentsIntegrity } from '@ionic-native/bizwave-plugin-checkintegrity/ngx';
import { QRScanner } from '@ionic-native/qr-scanner/ngx';
import { BizWaveEkycCamera } from '@ionic-native/bizwave-plugin-ekyc-camera/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

export function appInitializerFactory(translate: TranslateService, injector: Injector) {


  return () => new Promise<any>((resolve: any) => {
    const locationInitialized = injector.get(LOCATION_INITIALIZED, Promise.resolve(null));
    locationInitialized.then(() => {
      const langToSet = 'en'; // translate.getBrowserLang();

      translate.setDefaultLang(langToSet);
      translate.use(langToSet).subscribe(() => {
        console.log(`Translation is initialized by '${langToSet}' language successfully.'`);
      }, err => {
        console.timeStamp(`Language initialization with '${langToSet}' .' is failed.`);
      }, () => {
        resolve(null);
      });
    });
  });
}

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    HttpClientJsonpModule,
    IonicModule.forRoot( {animated: false} ),
    IonicStorageModule.forRoot(),
    SBSharedModule,
    ShareModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      },
    }),
    BrowserAnimationsModule,
    WindowModule,
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializerFactory,
      deps: [TranslateService, Injector],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    },
    HTTP,
    Contacts,
    Contact,
    CallNumber,
    InAppBrowser,
    StatusBar,
    Clipboard,
    SplashScreen,
    Camera,
    File,
    FileTransfer,
    ImagePicker,
    AndroidPermissions,
    LocationAccuracy,
    Geolocation,
    SocialSharing,
    Broadcaster,
    BizPushService,
    BizWavePush,
    Keyboard,
    BizWaveSecureKeypad,
    BizWaveAppIron,
    BizWaveCheckProxy,
    // BizWaveUpdate,
    BizWaveApplicationExit,
    BizPushService,
    BizWaveDeviceInfo,
    Network,
    AuthSecurity,
    FingerprintAIO,
    TouchID,
    SmsRetriever,
    // BizWaveSpeechToText,
    Diagnostic,
    MobileAccessibility,
    ThemeDetection,
    Badge,
    // BizWaveFBAnalytics,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    DatePipe,
    // AppLauncher,
    // AppAvailability,
    // KakaoCordovaSDK,
    BizWaveUpdateBizportal,
    BizWaveCheckRooting,
    BizWaveContentsIntegrity,
    QRScanner,
    BizWaveEkycCamera,
    Deeplinks,
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {

  }
}
