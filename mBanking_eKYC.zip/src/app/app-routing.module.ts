import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: 'home', loadChildren: () => import('./hom/hom.module').then(m => m.HomPageModule) },
  { path: '', loadChildren: () => import('./log/log.module').then(m => m.LogPageModule) },
  //{ path: '', loadChildren: () => import('./wel/wel.module').then(m => m.WelModule) },
  { path: '', loadChildren: () => import('./inf/inf.module').then(m => m.InfPageModule) },
  { path: '', loadChildren: () => import('./acc/acc.module').then(m => m.AccPageModule) },
  { path: '', loadChildren: () => import('./opn/opn.module').then(m => m.OpnPageModule) },
  { path: '', loadChildren: () => import('./trf/trf.module').then(m => m.TrfPageModule) },
  { path: '', loadChildren: () => import('./car/car.module').then(m => m.CarModule) },
  { path: '', loadChildren: () => import('./kyc/kyc.module').then( m => m.KycPageModule )},
  { path: '', loadChildren: () => import('./pay/pay.module').then( m => m.PayPageModule )},
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
