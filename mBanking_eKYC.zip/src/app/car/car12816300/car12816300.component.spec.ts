import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12816300Component } from './car12816300.component';

describe('CAR12816300Component', () => {
  let component: CAR12816300Component;
  let fixture: ComponentFixture<CAR12816300Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12816300Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12816300Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
