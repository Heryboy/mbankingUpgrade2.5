import { Component, OnInit } from '@angular/core';
import { BackService } from '../../shared/services/back.service';

@Component({
  selector: 'app-car12816300',
  templateUrl: './car12816300.component.html',
  styleUrls: ['./car12816300.component.scss'],
})
export class CAR12816300Component implements OnInit {

  constructor(
    private backService: BackService
  ) { }

  ngOnInit() {
    this.backService.subscribe();
  }

  onClickOk() {
    this.backService.fire();
  }

}
