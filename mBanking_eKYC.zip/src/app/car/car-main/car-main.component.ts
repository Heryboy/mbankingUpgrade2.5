import { Component, OnInit, ViewChild } from '@angular/core';
import { CardSegmentValue } from './car-main.model';
import { ActivatedRoute, Router } from '@angular/router';
import { BackService } from '../../shared/services/back.service';
import { Util } from '../../shared/util';
import { AppFooterMenuComponent } from '../../shared/component/app-footer-menu/app-footer-menu.component';
import { MenuClick } from '../../shared/component/timepicker/time-picker-modal/slideIndexImp';
import { TranslateService } from '@ngx-translate/core';
import { DataCenter } from '../../shared/utils/data-center.static';

@Component({
  selector    : 'app-car-main',
  templateUrl : './car-main.component.html',
  styleUrls   : ['./car-main.component.scss'],
})
export class CarMainComponent implements OnInit {

  @ViewChild(AppFooterMenuComponent, { static: true }) comp: AppFooterMenuComponent;
  changeTitle: boolean;
  tabValue: CardSegmentValue = 'tab_my_cards';
  isHasNotification: boolean;
  menuClick = new MenuClick();
  util      = new Util();
  tabCardCache: boolean;
  tabRecentCache: boolean;
  tabPointCache: boolean;
  constructor(
    private route: ActivatedRoute,
    private backService: BackService,
    private router: Router,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.route.params.subscribe((param) => {
      if (param.tab !== this.tabValue) {
        this.setTab(param.tab);
      }
    });
  }
  setTab(value: CardSegmentValue) {
    const test      = ['tab_my_cards', 'tab_recent', 'tab_my_point'].includes(value);
    if (test) {
      this.tabValue = value;
    } else {
      console.log('setTab failed on value', value);
    }
  }
  btnLogoutClicked() {
    this.backService.fire();
  }
  btnNotificationClicked() {
    this.util.setSecureStorage('IS_HAVING_NEW_PUSH', false);
    DataCenter.set('my_card', 'my_card', true);
    this.router.navigate(['/acc/NOT10000000'], { replaceUrl: true });
  }
  onScrollHandler(event: any) {
    if (event.detail.scrollTop < 104) {
      this.changeTitle = false;
    } else {
      this.changeTitle = true;
    }
  }
  checkNewPushNotification() {
    this.isHasNotification = this.util.getSecureStorage('IS_HAVING_NEW_PUSH');
  }
  setCache(b: boolean) {
    if (b) {
      switch (this.tabValue) {
        case 'tab_my_cards' : this.tabCardCache   = true; break;
        case 'tab_recent'   : this.tabRecentCache = true; break;
        case 'tab_my_point' : this.tabPointCache  = true; break;
      }
    } else {
      this.tabCardCache   = false;
      this.tabRecentCache = false;
      this.tabPointCache  = false;
    }
  }
  tabChange() {
    this.setCache(true);
  }
  ionViewWillEnter() {
    this.checkNewPushNotification();
    this.setCache(true); // init tab view
    this.menuClick.clearListMenu();
    this.backService.subscribe('logged_out'
      , { title: this.translate.instant('COMMON.MESSAGE.LOGOUT')
      , content: this.translate.instant('COMMON.MESSAGE.DO_YOU_REALLY_WANT_TO_LOGOUT') }
    );
    this.comp.tabValue = 'card';
  }

  ionViewDidLeave() {
    this.setCache(false); // clear catch
  }
}
