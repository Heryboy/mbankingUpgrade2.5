export type CardSegmentValue = 'tab_my_cards' | 'tab_recent' | 'tab_my_point';
