import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE, CHANNEL } from 'src/app/shared/constants/common.const';
import { Router } from '@angular/router';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { CAR12433000Component } from '../car12433000/car12433000.component';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB8122Req } from 'src/app/shared/TRClass/CEB8122-req';
import { CEB8122Res } from 'src/app/shared/TRClass/CEB8122-res';
import { CardService } from 'src/app/shared/services/card.service';
import * as moment from 'moment';

@Component({
  selector: 'app-car12432000',
  templateUrl: './car12432000.component.html',
  styleUrls: ['./car12432000.component.scss'],
})
export class CAR12432000Component implements OnInit {
  cardNo: string;
  cardId: string;
  accountNoSvbo: string;
  cardNickName: string;
  cardHolderName: string;
  paymentAmount: number;
  currencyCode: string;
  currentDate: string;
  fullPartialPaymentObj;
  constructor(
    private modalService: ModalService,
    private router: Router,
    private bizServer: BizserverService,
    private authTranService: AuthTransactionService,
    private cardService: CardService
  ) { }

  ngOnInit() {
    console.log(this.fullPartialPaymentObj); 
    this.currentDate = moment(new Date()).format('YYYY-MM-DD');
    this.currentDate = this.cardService.formatDateYYYYMMDD2( this.currentDate );  
    if (this.fullPartialPaymentObj) {
      this.cardNickName = this.fullPartialPaymentObj.cardNickname;
      this.cardHolderName =  this.fullPartialPaymentObj.cardHolderName;
      this.cardNo = this.fullPartialPaymentObj.cardNo;
      this.cardId = this.fullPartialPaymentObj.cardId;
      this.accountNoSvbo = this.fullPartialPaymentObj.accountNoSvbo;
      this.paymentAmount = this.fullPartialPaymentObj.paymentAmount;
      this.currencyCode  = this.fullPartialPaymentObj.currencyCode;
    }
  }

  onClickNo() {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }

  onClickYes() {
    this.checkAuthentication();
  }

  checkAuthentication() {
    this.authTranService.reqestAuthCode({ callback: (auth) => {
      this.doRequestForPrepay( auth );
    }});
  }

  toCompleteSreen() {
    this.modalService.modal({
      component: CAR12433000Component,
      componentProps: []
    }).then(res => {
      console.log(res);
      if (res.role === BUTTON_ROLE.APPLY) {
        console.log(res, this.fullPartialPaymentObj);
        this.modalService.dismissAll({
          role: BUTTON_ROLE.BACKDROP,
          data: this.fullPartialPaymentObj
        });
      }
    });
    // const data = {
    //   cardNickname: this.cardNickName,
    //   cardProductName: this.cardNickName,
    //   cardSubjectTypeCode: this.fullPartialPaymentObj.cardSubjectTypeCode,
    //   cardScheme: this.fullPartialPaymentObj.cardScheme,
    //   cardNo: this.cardNo
    // };
    // DataCenter.set('card', 'card', data);
    // this.router.navigate(['/card/complete-pre-pay']);
    // this.modalService.dismissAll({
    //   role: BUTTON_ROLE.CLOSE
    // });
  }

  doRequestForPrepay(auth?: any) {
    let authTransactionID       = 0;
    let authenticationCode      = '';
    let authTransactionDate     = '';
    if (auth) {
      authTransactionID      = auth.transactionID;
      authenticationCode     = auth.authenticationCode;
      authTransactionDate    = auth.transactionDate;
    }
    const reqTr = new CEB8122Req(); 
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.authTransactionID = authTransactionID;
    reqTr.body.authenticationCode = authenticationCode;
    reqTr.body.authTransactionDate = authTransactionDate; 
    reqTr.body.cardId = this.cardId;
    reqTr.body.paymentAmount = Number(this.paymentAmount);
    reqTr.body.currencyCode = 'USD';
    reqTr.body.accountNo = this.cardService.addFormatAccNumber(this.accountNoSvbo, 16);  // account Svbo   
    reqTr.body.paymentDate = this.currentDate;
    this.bizServer.bizMOBPost('CEB8122', reqTr).then(data => {
      const resTr = data as CEB8122Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.toCompleteSreen();
      }
    });
  }
}
