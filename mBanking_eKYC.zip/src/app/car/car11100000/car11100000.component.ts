import { Component, OnInit, ViewChild } from '@angular/core';
import { IonInfiniteScroll } from '@ionic/angular';
import { BUTTON_ROLE, CARD_SUBJECT_TYPE_CODE, REGION_CODE, SV_CURRENCY_NAME, SV_CURRENCY_CODE, CHANNEL } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Utils } from 'src/app/shared/utils/utils.static';
import { BizserverService } from '../../shared/services/bizserver.service';
import { DataformatService } from '../../shared/services/dataformat.service';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res';
import { CEB8016Req } from '../../shared/TRClass/CEB8016-req';
import { CEB8016Res } from '../../shared/TRClass/CEB8016-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { DateUtils } from '../../shared/utils/date-utils.static';
import { CAR11210000Component } from '../car11210000/car11210000.component';
import { CardFilter } from '../car11210000/car11210000.model';
import { CAR11300000Component } from '../car11300000/car11300000.component';
import { TranslateService } from '@ngx-translate/core';
import { DateRange } from 'src/app/shared/component/filter/filter.model';

export type CardTypeSegmentValue = 'tab_credit_card' | 'tab_debit_card';

@Component({
  selector    : 'app-car11100000',
  templateUrl : './car11100000.component.html',
  styleUrls   : ['./car11100000.component.scss'],
})
export class CAR11100000Component implements OnInit {
  cardType = '';
  items: any;
  transactionList: any[]; 
  creditCardFilter  = new CardFilter();
  debitCardFilter   = new CardFilter();
  totalCurrencyKhr: any = 0;
  totalCurrencyUsd: any = 0;
  totalTransaction: any = 0; 
  cardTypeFeature: any = 'CFCHDEBT';
  tabValue: CardTypeSegmentValue = 'tab_debit_card'; 
  reqTr: CEB8016Req;
  noHistory: boolean;
  cardList: CEB8012ItemsRes[];
  creditCard = CARD_SUBJECT_TYPE_CODE.CREDIT;
  debitCard = CARD_SUBJECT_TYPE_CODE.DEBIT;
  svCurrencyUSD = SV_CURRENCY_NAME.USD;
  svCurrencyKHR = SV_CURRENCY_NAME.KHR; 
  transactionTypeCode: any = '01,03';
  translateTransaction: string; 
  inCurrenyUSD = SV_CURRENCY_CODE.USD;
  fromDate: string;
  toDate: string; 
  search: string;  
  cardTypeFilter = 'cardFilter';
  @ViewChild(IonInfiniteScroll, { static: true }) ionInfiniteScroll: IonInfiniteScroll;

  constructor(
    private modalService: ModalService, 
    private bizServer: BizserverService, 
    private dataFormatService: DataformatService,
    private translate: TranslateService,
  ) {
    this.creditCardFilter.isShowAccountCard = true;
    this.debitCardFilter.isShowAccountCard = true; 
    this.reqTr = new CEB8016Req();
    this.setRequestBody(true);
  }

  ngOnInit() {
    this.search = ''; 
    this.creditCardFilter.isCreditCard = true;
    this.cardList = DataCenter.get('CAR12000000', 'cardList', false) as CEB8012ItemsRes[];
    // to check and set if there is only one card
    if (this.cardList.length === 1) {
      if (this.cardList[0].cardTypeFeature as any === this.creditCard) {
          this.tabValue = 'tab_credit_card';
          this.cardTypeFeature = 'CFCHCRDT';
          this.cardType = this.creditCard; 
          this.transactionTypeCode = '01,02,03'; 
        } else {
          this.cardType = this.debitCard;
          this.transactionTypeCode = '01,03'; 
      }
    } 
    // to set start date and end date with 1 week from now
    this.fromDate  = this.dataFormatService.unFormatAccountNumber(DateUtils.getStartDatePeriodAsString('tab_1w'));
    this.toDate    = this.dataFormatService.unFormatAccountNumber(DateUtils.getCurrentDateTime());   
  } 

  filterByCardType(type?) {
    this.cardType = type;
    if (type === CARD_SUBJECT_TYPE_CODE.CREDIT) { 
      this.cardTypeFeature = 'CFCHCRDT'; 
      this.transactionTypeCode = '01,02,03'; 
    } else if (type === CARD_SUBJECT_TYPE_CODE.DEBIT) { 
      this.cardTypeFeature = 'CFCHDEBT';
      this.transactionTypeCode = '01,03'; 
    }
    this.clearTransactionList();
    this.requestData(false);
  }

  setRequestBody(init?: boolean) {
    this.reqTr.header.screenID = 'CAR11100000'; // your screenID
    if (init) {
      Utils.setUserInfoTo(this.reqTr.body);  
      this.reqTr.body.transactionTypeCode =  this.transactionTypeCode;
      this.reqTr.body.cardTypeFeature = this.cardTypeFeature;   
      this.reqTr.body.countryCode = '';              
      this.reqTr.body.fromDate = this.fromDate;
      this.reqTr.body.toDate = this.toDate;     
      this.reqTr.body.channelTypeCode = CHANNEL.MOB; 
    } else { 
      this.reqTr.body.cardTypeFeature = this.cardTypeFeature;       
      this.reqTr.body.transactionTypeCode = this.transactionTypeCode; 
      this.reqTr.body.fromDate = this.fromDate;
      this.reqTr.body.toDate = this.toDate; 
      this.reqTr.body.searchKeyword = this.search;
      this.reqTr.body.channelTypeCode = CHANNEL.MOB; 
    }
  }

  requestData(showLoading: boolean, refresh?: boolean, event?: any) {
    this.noHistory = false;
    this.setRequestBody(refresh);
    this.bizServer.bizMOBPost('CEB8016', this.reqTr, showLoading).then(data => {
      const resTr = data as CEB8016Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.items = resTr.body.items;   
        this.totalTransaction += resTr.body.items.length;
        this.items.forEach(element => {
          if (element.currencyName === 'USD') {
            this.totalCurrencyUsd += element.cardTransactionAmount;
          } else {
            this.totalCurrencyKhr += element.cardTransactionAmount;
          }
        });
        this.setTransactionList(resTr.body.items as any); 
      }
      if (refresh) {
        event.target.complete();  
      } else {
        this.ionInfiniteScroll.complete();  
      } 
      if ( this.items.length < this.reqTr.body.pageSize ) { 
        if ( this.fromDate <= '20210525' || this.toDate <= '20210525' ) { 
          this.modalService.alert({
            content: this.translate.instant('CAR11100000.LABEL.TRANSACTION_NOTED'),
            btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
            callback: (res: any) => {
              if (res) {
                console.log(res);
              }
            }
          });
        }
      } 
    });
  }

  setTransactionList(list: []) {
    if (list.length === 0) {
      this.ionInfiniteScroll.disabled = true;
      if (this.transactionList.length === 0) {
        this.noHistory = true;
      }
      return;
    } else if (list.length < this.reqTr.body.pageSize) { // last records.
      this.ionInfiniteScroll.disabled = true;
    }
    this.transactionList = [...this.transactionList, ...list] as any;
    this.reqTr.body.pageNumber++;
  }

  clearTransactionList() {
    this.transactionList = [];
    this.reqTr.body.pageNumber = 1;
    this.reqTr.body.countryCode = '';
    this.reqTr.body.pageSize = 20;
    this.ionInfiniteScroll.disabled = false;
    this.totalTransaction = 0;
    this.totalCurrencyUsd = 0;
    this.totalCurrencyKhr = 0;
  }

  filterClicked() {
    this.modalService.open({
      content: CAR11210000Component,
      message: { data: this.cardType === CARD_SUBJECT_TYPE_CODE.CREDIT ? this.creditCardFilter : this.debitCardFilter},
      modalClass: ['pop_top'],
      callback: (result) => {
        if (result.role === BUTTON_ROLE.APPLY) {
          this.totalCurrencyKhr = 0;
          this.totalCurrencyUsd = 0;
          this.totalTransaction = 0;
          if (this.cardType === CARD_SUBJECT_TYPE_CODE.CREDIT) {
            this.creditCardFilter = result.data;
            this.creditCardFilter.isCreditCard = true;
          } else {
            this.debitCardFilter = result.data;
          }
          console.log(result.data);

          if (result.data.cardTransactionType[0] === true && result.data.cardTransactionType[1] === true && result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '01,02,03';
          } else if (result.data.cardTransactionType[0] === true && result.data.cardTransactionType[1] === true) { 
            this.transactionTypeCode = '01,02';
          } else if (result.data.cardTransactionType[0] === true && result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '01,03';
          } else if (result.data.cardTransactionType[1] === true && result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '02,03';
          } else if (result.data.cardTransactionType[0] === true) { 
            this.transactionTypeCode = '01';
          } else if (result.data.cardTransactionType[1] === true) { 
            this.transactionTypeCode = '02';
          } else if (result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '03';
          }

          this.reqTr.body.cardNumber = result.data.card.cardNo;
          if (this.reqTr.body.cardNumber === 'all') { 
            this.reqTr.body.cardNumber = '';
          }

          // this.reqTr.body.searchKeyword = result.data.search;        // searchKeyword
          // this.reqTr.body.fromDate = this.dataFormatService.unFormatAccountNumber(result.data.dateRange.fromDate);
          // this.reqTr.body.toDate = this.dataFormatService.unFormatAccountNumber(result.data.dateRange.toDate);

          let regionTypeCode = '';
          if (result.data.regionTypeCode === REGION_CODE.ALL) {
            regionTypeCode = '';
          } else {
            regionTypeCode = result.data.regionTypeCode;
          }
          this.clearTransactionList();
          this.reqTr.body.countryCode = regionTypeCode;       
          this.requestData(false, false, event);
        }
      }
    });
  }

  scrollLoadData(event) {
    this.requestData(true, true, event);
  }

  transactionClickDetail(item) {
    this.modalService.modal({
      component       : CAR11300000Component,
      componentProps  : { 
        selectedItem  : item,
        cardNumber    : ''
      }
    });
  }

  searchValued(event) {
    this.search = event;
    this.clearTransactionList();
    this.requestData(false, false, event); 
  }

  dateFilterChanged(dateRange: DateRange) { 
    this.fromDate = dateRange.fromDateAsServerFormat;
    this.toDate = dateRange.toDateAsServerFormat; 
    this.clearTransactionList();
    this.requestData(false, false, event);
  } 

}
