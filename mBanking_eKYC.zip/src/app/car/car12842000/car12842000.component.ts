import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BUTTON_ROLE, RECEIVE_TYPE, CHANNEL } from 'src/app/shared/constants/common.const';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB8024Res } from 'src/app/shared/TRClass/CEB8024-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { CEB8024Req } from 'src/app/shared/TRClass/CEB8024-req';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { BackService } from 'src/app/shared/services/back.service';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { CEB8222AddressListRes } from 'src/app/shared/TRClass/CEB8222-res';
import { PPCB0160BranchListRes } from 'src/app/shared/TRClass/PPCB0160-res';
import { DataformatService } from 'src/app/shared/services/dataformat.service';
import { CEB8027Req } from 'src/app/shared/TRClass/CEB8027-req';
import { CEB8027Res } from 'src/app/shared/TRClass/CEB8027-res';

@Component({
  selector: 'app-car12842000',
  templateUrl: './car12842000.component.html',
  styleUrls: ['./car12842000.component.scss'],
})
export class CAR12842000Component implements OnInit {
  card = new  CEB8012ItemsRes();
  receiveType = '';
  receiveAddress = '';
  branchCode = '';
  amendAvailableYN: string;
  // This object, passed from Screen CAR12841000Component (Reissue Card)
  reissueCardInfo = {
    deliverAddress: new CEB8222AddressListRes(),
    receiveOptionCode: RECEIVE_TYPE.DELIVERY,
    selectedBranch: new PPCB0160BranchListRes(),
    card: {
      cardNumber: ''
    },
    product: {
      productNum: '',
      productName: ''
    },
    productReIssue: {
      productNum: '',
      productName: ''
    }
  };
  // New Request Re-IssueCard  
  accountNo: string;    
  resultSubstring: string; 
  transactionID: number;
  authenticationCode: string;
  transactionDate: string; 
  feeAmount = new CEB8027Res().body;
  feeCharge: number;
  constructor(
    private route: Router,
    private translate: TranslateService,
    private modalService: ModalService,
    private authTranService: AuthTransactionService,
    private bizServer: BizserverService,
    private backService: BackService,
    private accountFormat: DataformatService,
  ) { }

  ngOnInit() {
    this.getData(); 
    this.SubStringPaymentAccountNo(); 
    console.log('this.reissueCardInfo >> ', this.reissueCardInfo); 
    this.getFeeAmount();
    this.noteDetail();
  }

  getData() {
    if (this.reissueCardInfo) {
      this.card = DataCenter.get('card', 'card', false);
      switch ( this.reissueCardInfo.receiveOptionCode ) {
       case RECEIVE_TYPE.DELIVERY: {
         this.receiveType = this.translate.instant('CAR12842000.LABEL.DELIVERY_ADDRESS');
         this.receiveAddress = this.reissueCardInfo.deliverAddress.street; 
         this.accountNo = this.card.accountNo;  
         break;
       }
      case RECEIVE_TYPE.BRANCH: {
        this.receiveType = this.translate.instant('CAR12842000.LABEL.PICK_UP_FROM_BRANCH');
        this.receiveAddress = this.reissueCardInfo.selectedBranch.branchNameEn;
        this.branchCode = this.reissueCardInfo.selectedBranch.branchCode;
        break;
      }
     }
   }
  } 

  // Check Paymentaccount and SubString Data
  SubStringPaymentAccountNo() {  
    if ( this.card.accountNo.length == 16 ) {
      this.resultSubstring = this.card.accountNo.substring(4 , 16);
      this.accountNo = this.accountFormat.formatAccountNumber(this.resultSubstring);
    } else {
      this.resultSubstring = this.card.accountNo;
      this.accountNo = this.accountFormat.formatAccountNumber(this.resultSubstring);
    }
  }

  onClickNo() {
    this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
  }

  onClickYes() {
    this.requestAuthentication();
  }

  // request auth code
  async requestAuthentication() {
    await this.backService.modalService.modal({
      component: SmsAuthenticationComponent,
      componentProps: {
        callback: (res) => {
          if (res) {
            this.transactionID      = res.transactionID;
            this.authenticationCode = res.authenticationCode;
            this.transactionDate    = res.transactionDate;
            this.checkAuthentication();
          }
        }
      }
    });
  }

  // verify whether the code (6 digits) correct or not
  checkAuthentication() {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID   = this.transactionID;               // authTransactionID
    reqTr.body.authenticationCode  = this.authenticationCode;          // authenticationCode
    reqTr.body.authTransactionDate = this.transactionDate;             // authTransactionDate
    reqTr.body.channelTypeCode     = CHANNEL.MOB;                      // channelTypeCode
    reqTr.body.customerNo          = Utils.getUserInfo().customerNo;   // customerNo
    reqTr.body.userID              = Utils.getUserInfo().userID;       // userID
    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.doRequestToServer();
      }
    });
  } 

  /*Prepare Datas request to server BizMOB after that, bizMob call API to CBS*/
  doRequestToServer() {
    const reqTr = new CEB8024Req();
    reqTr.body.authTransactionID = this.transactionID;
    reqTr.body.authenticationCode = this.authenticationCode;
    reqTr.body.authTransactionDate = this.transactionDate;
    reqTr.body.cardId  = this.card.cardIDSvfe;
    reqTr.body.deliveryAddressTypeCode = this.reissueCardInfo.receiveOptionCode; 
    reqTr.body.deliveryAddressDescription = this.receiveAddress;
    reqTr.body.cardProductName =  this.card.productName;
    reqTr.body.cardExpiryDate = this.card.expireDateSvfe;
    reqTr.body.accountNo = this.card.accountNo;
    reqTr.body.cardFeatureTypeCode = this.card.cardFeatureCode;
    if (reqTr.body.cardFeatureTypeCode == 'CFCHDEBT') { // Debit
      reqTr.body.cardFeatureTypeCode = '01';
    } else { // Credit
      reqTr.body.cardFeatureTypeCode = '02';
    }
    reqTr.body.cardSchemeTypeCode = this.card.cardNetName;
    if ( reqTr.body.cardSchemeTypeCode == 'VISA' ){
        reqTr.body.cardSchemeTypeCode = '01'
    } else if ( reqTr.body.cardSchemeTypeCode == 'DINNERSCLUB' ) {
        reqTr.body.cardSchemeTypeCode = '05'
    } else if ( reqTr.body.cardSchemeTypeCode == 'LOCAL NETWORK' ) {
        reqTr.body.cardSchemeTypeCode = '06'
    } else {}
    reqTr.body.productCode = this.card.productNum;
    reqTr.body.customerName = this.card.cardholderName;
    reqTr.body.cardNumber = this.card.cardNumber;
    reqTr.body.customerNo = this.card.customerNo;
    reqTr.body.reIssueCardNumber = this.card.cardNumber;
    reqTr.body.reIssueReasonCode = this.reissueCardInfo.productReIssue.productNum;
    reqTr.body.cardHolderNumber = this.card.cardHolderNumber;
    reqTr.body.secretQuestionCode = '';
    reqTr.body.secretAnswer = '';
    reqTr.body.branchCode = this.branchCode;
    this.bizServer.bizMOBPost('CEB8024', reqTr).then(data => { 
      const resTr = data as CEB8024Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        if (resTr.body.successYN === 'N') { 
          this.modalService.alert({
            content:  resTr.body.description,
            btnText: this.translate.instant('COMMON.BUTTON.OK'),
            callback: () => { }
          });
        } else { 
          this.toCompleteScreen();  
        }
      }
    });
  }

  toCompleteScreen() {
    DataCenter.set('amendAvailableYN', 'amendAvailableYN',  this.amendAvailableYN);
    this.modalService.dismissAll({ role: BUTTON_ROLE.CLOSE });
    this.route.navigateByUrl('card/re-issue-card/result');
  }

  async getFeeAmount() {
    const reqTr = new CEB8027Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.productNo = this.card.productNum;
    reqTr.body.feeAttributeCode = 'FETP0109';
    await this.bizServer.bizMOBPost('CEB8027', reqTr).then(data => {
      const resTr = data as CEB8027Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.feeAmount = resTr.body;  
        this.feeCharge = this.feeAmount.feeAmount as any;
      }
    });
  }

  noteDetail() : boolean { 
    if ( this.card.cardTypeFeature === 'Credit' as any ) { 
      return true; 
    } else { 
      return false; 
    }  
  }

  checkexpDate(): boolean {  
    if ( this.amendAvailableYN === 'Y' as any || this.amendAvailableYN === 'B1' as any ) { 
      this.feeCharge = 0;
      return true;
    } else { 
      return false;
    } 
  }
  
}


