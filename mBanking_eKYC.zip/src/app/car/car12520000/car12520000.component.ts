import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BUTTON_ROLE, CHANNEL } from 'src/app/shared/constants/common.const';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BackService } from 'src/app/shared/services/back.service';
import { NavController } from '@ionic/angular';
import { CEB8033Req } from 'src/app/shared/TRClass/CEB8033-req';
import { CEB8033Res } from 'src/app/shared/TRClass/CEB8033-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { CEB8231Req } from 'src/app/shared/TRClass/CEB8231-req';
import { CEB8231Res } from 'src/app/shared/TRClass/CEB8231-res';

@Component({
  selector: 'app-car12520000',
  templateUrl: './car12520000.component.html',
  styleUrls: ['./car12520000.component.scss'],
})
export class CAR12520000Component implements OnInit {
  authenticationCode: string;
  transactionID: number;
  transactionDate: string;
  data;
  card = new CEB8012ItemsRes();
  monthSubstr: any;
  yearSubstr: any;
  validThru: any;
  expDate: any;
  constructor(
    private modalService: ModalService,
    private bizServer: BizserverService,
    private authTranService: AuthTransactionService,
    public navCtrl: NavController,
    private backService: BackService,
  ) { }

  ngOnInit() {
    this.card = DataCenter.get('card', 'card' , false);
    console.log('Card Data for activate', this.card);
    console.log('Data for activate', this.data);

    this.validThru   = this.data.validThruYY + this.data.validThruMM;
    this.monthSubstr = this.validThru.substring(this.validThru.length - 2);
    this.yearSubstr  = this.validThru.substring(2 , 4);
    this.expDate     = this.monthSubstr + '/' + this.yearSubstr as any;
  }

  onClickNo() {
    // this.backser.my_card();
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

  onClickYes() {
    this.requestAuthentication();
  }

  // request auth code
  async requestAuthentication() {
    await this.backService.modalService.modal({
      component: SmsAuthenticationComponent,
      componentProps: {
        callback: (res) => {
          if (res) {
            this.transactionID      = res.transactionID;
            this.authenticationCode = res.authenticationCode;
            this.transactionDate    = res.transactionDate;
            this.checkAuthentication();
          }
        }
      }
    });
  }

  // verify whether the code (6 digits) correct or not
  checkAuthentication() {
    const reqTr = new CEB0812Req();

    reqTr.body.authTransactionID   = this.transactionID;               // authTransactionID
    reqTr.body.authenticationCode  = this.authenticationCode;          // authenticationCode
    reqTr.body.authTransactionDate = this.transactionDate;             // authTransactionDate
    reqTr.body.channelTypeCode     = CHANNEL.MOB;                      // channelTypeCode
    reqTr.body.customerNo          = Utils.getUserInfo().customerNo;   // customerNo
    reqTr.body.userID              = Utils.getUserInfo().userID;       // userID

    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) { 
        this.doRequestPost();
      }
    });
  }

  doRequestPost() {
    const reqTr                     = new CEB8033Req();
    reqTr.body.authTransactionID    = this.transactionID;
    reqTr.body.authenticationCode   = this.authenticationCode;
    reqTr.body.authTransactionDate  = this.transactionDate;

    reqTr.body.cardNumber           = this.card.cardNumber;
    reqTr.body.cardId               = this.card.cardIDSvfe;
    reqTr.body.cardNickName         = this.data.cardNickName; 
    reqTr.body.cvv                  = this.data.CVVCode;
    reqTr.body.validThru            = this.expDate;
    reqTr.body.cardPinValue         = this.data.PIN;

    this.bizServer.bizMOBPost('CEB8033', reqTr).then(data => {
      //TODO: Uncomment it when BPC finish Activate Card SVIG
      const resTr = data as CEB8033Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.changeCardNickname();
        this.toCompleteScreen();
      }
    });
  }

  changeCardNickname() {
    const reqTr = new CEB8231Req();
    Utils.setUserInfoTo(reqTr.body);
    // reqTr.header.screenID               = 'MAC1163A000'; // your screenID
    reqTr.body.cardProductID            =  this.data.productId;        // cardProductID
    reqTr.body.cardNickName             = this.data.cardNickname;        // cardNickName
    reqTr.body.svCardID                 = this.data.cardId;        // svCardID
    reqTr.body.deliveryAddressTypeCode  = '';        // deliveryAddressTypeCode
    reqTr.body.deleteYN                 = '';        // deleteYN
    reqTr.body.deliveryAddress          = '';        // deliveryAddress
    this.bizServer.bizMOBPost('CEB8231', reqTr).then(data => {
      const resTr = data as CEB8231Res;
      if (this.bizServer.checkResponse(resTr.header)) {
      }
    });
  }

  toCompleteScreen() {
    this.modalService.dismissAll({
      role: BUTTON_ROLE.CLOSE
    });
    this.navCtrl.navigateRoot('/card/complete-activation');
  //   this.modalService.modal({
  //     component: CAR12530000Component,
  //     componentProps: {}
  // }).then((result) => {
  //   console.log(result);
  //   if (result.role === BUTTON_ROLE.BACKDROP) {
  //     this.modalService.dismissAll();
  //     this.backser.my_card();
  //     this.router.navigate(['/card/car-main']);
  //     // this.navCtrl.navigateRoot('/card/car-main');
  //   }
  // });
    // this.router.navigate(['/card/complete-activation']);
  }

}
