import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BlockUnblockCardData } from 'src/app/shared/TRClass/CEB8131-req';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { CARD_SUBJECT_TYPE_CODE, CMS_SCREEN_FOR_ROUTE, BUTTON_ROLE } from '../../shared/constants/common.const';
import { ModalService } from '../../shared/services/modal.service';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res'; 

@Component({
  selector    : 'app-car12810000',
  templateUrl : './car12810000.component.html',
  styleUrls   : ['./car12810000.component.scss'],
})
export class CAR12810000Component implements OnInit {
  modal: any;
  card: CEB8012ItemsRes;
  credit = CARD_SUBJECT_TYPE_CODE.CREDIT;
  debit = CARD_SUBJECT_TYPE_CODE.DEBIT;   
  previouScreen = '';
  reissueTranslate: string;
  constructor(
    private modalService: ModalService,
    private route: Router,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.card           = this.modal.message.card;
    this.previouScreen  = this.modal.message.previouScreen; 
    // if (this.card.cardTypeFeature === '' || this.card.cardTypeFeature === null ||
    //     this.card.cardTypeFeature === undefined) {
    //       const re = /credit/gi;
    //       const str = this.card.productName;
    //       if (str.search(re) === -1 ) {
    //         this.card.cardTypeFeature  = 'Debit' as any;
    //       } else {
    //         this.card.cardTypeFeature = 'Credit'  as any;
    //       }
    //     }
    DataCenter.set('card', 'card', this.card);
  }

  onClosePopup(): void {
    this.modalService.close();
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

  clickCardInformation() {
    this.onClosePopup();  
    const isMyCard = DataCenter.get('my_card', 'my_card');
    const isTransaction = DataCenter.get('card_transaction', 'card_transaction');
    const isBilling = DataCenter.get('card_billing', 'card_billing');
    if ( isMyCard ) { // Click from card list
      DataCenter.set('my_card', 'my_card', true);
      this.goToCardDetailInfo(); 
    } else if ( isTransaction ) { // click from card_transaction by card  
      DataCenter.set('card_transaction', 'card_transaction', true);
      this.goToCardDetailInfo();
    } else if ( isBilling ) { // click from billing   
      DataCenter.set('card_billing', 'card_billing', true); 
      this.goToCardDetailInfo();
    }
  }

  goToCardDetailInfo() {
    if (this.card.cardTypeFeature as any === this.credit ) {
      this.route.navigate([CMS_SCREEN_FOR_ROUTE.CARD_INFO_CREDIT], {replaceUrl: true});
    } else {
      this.route.navigate([CMS_SCREEN_FOR_ROUTE.CARD_INFO_DEBIT], {replaceUrl: true});
    }
  }

  clickBlock() {
    this.onClosePopup();
    this.requetBlockUnblockCard(true);
  }

  clickUnblock() {
    this.onClosePopup();
    const data   = new BlockUnblockCardData();
    data.card    = this.card;
    data.blockYN = false;
    if (this.card.unblockImpossibilityYN as any === 'Y') {
      this.unblockImpossibility();
    } else {
      DataCenter.set('CAR12810000', 'blockUnblockCardData', data);
      this.route.navigate(['/card/block-card-confirm']);
      // this.modalService.modal({
      //   component       : CAR12821000Component,
      //   componentProps  : { toBlockCard: false  }
      // });
    }
  }

  requetBlockUnblockCard(blockYN: boolean) {
    const data = new BlockUnblockCardData();
    data.card = this.card;
    data.previouScreen = this.previouScreen;
    data.blockYN = blockYN;
    DataCenter.set('CAR12810000', 'blockUnblockCardData', data);
    this.route.navigate(['/card/block-card-confirm']);
    // this.modalService.modal({
    //   component       : CAR12821000Component,
    //   componentProps  : { toBlockCard: true  }
    // });
    // this.route.navigateByUrl(CMS_SCREEN_FOR_ROUTE.BLOCK_CARD_CONFIRM); // to screen CAR12821000Component
  }

  unblockImpossibility() {
    this.modalService.alert({
      content: this.translate.instant('CAR12000000.LABEL.UNBLOCK_IMPOSSIBILITY'),
      btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
      callback: (res: any) => {
        if (res) {
          console.log('confirm');
        }
      }
    });
  }

  clickReIssueCard( card: CEB8012ItemsRes ) {
    if ( card.reissueYN === 'Y' as any ) {
      this.modalService.alert({
          content: this.translate.instant('CAR12000000.LABEL.CANNOT_REISSUE_CARD'),
          btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
          callback: (res: any) => {
            if (res) {
              console.log(res);
            }
          }
      });
    } else {
      this.onClosePopup();
      this.route.navigateByUrl('card/re-issue-card');
    }
  }

  // TODO: Not sure which status that we can reissue card
  reissuePossibleYN(card: CEB8012ItemsRes) {
    // new condition from digital team (Mr. Sambo)
    if ( card.amendAvailableYN === 'Y' as any || card.amendAvailableYN === 'B1' as any ) { 
      // check for one card can re-issue only one time based on this code from CBS
      if ( card.reissueYN === 'Y' as any ) {
        // return;
        return this.reissueTranslate = this.translate.instant('CAR12720000.LABEL.RENEWAL');
      } else {
        return this.reissueTranslate = this.translate.instant('CAR12720000.LABEL.RENEWAL');
      }
    } else if (card.cardActivateYN === 'Y' as any || card.blockPossibleYN === 'Y' as any || card.unblockImpossibilityYN === 'Y' as any || card.cardBlockYN === 'Y' as any) { 
      // check for one card can re-issue only one time based on this code from CBS
      if ( card.reissueYN === 'Y' as any ) {
        // valid card cannot reissue card
        if ( card.cardStatusCodeSvfe === 0 )
          return;
        }
        return this.reissueTranslate = this.translate.instant('CARD_COMMON.LABEL.RE_ISSUE_CARD');
      } else if ( card.cardStatusCodeSvfe === 0 || card.cardStatusCodeSvfe === 14 ) {
        return;
      } else {
        return this.reissueTranslate = this.translate.instant('CARD_COMMON.LABEL.RE_ISSUE_CARD');
      }
    }

  cardBlockYN(): boolean {
    if ( this.card.cardStatusCodeSvfe === 0 && this.card.amendAvailableYN !== 'Y' as any ) {
      return this.card.cardBlockYN === 'N' as any;
    } else if (this.card.cardStatusCodeSvfe === 12 as any || 14 as any) {
      return;
    } else if ( this.card.amendAvailableYN === 'Y' as any ) {
      return;
    }
  }

  cardUnBlockYN(): boolean {
    return this.card.cardBlockYN === 'Y' as any;
  }

}
