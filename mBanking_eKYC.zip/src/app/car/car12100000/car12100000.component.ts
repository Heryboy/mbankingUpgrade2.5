import { Component, OnInit, ViewChild } from '@angular/core';
import { IonInfiniteScroll } from '@ionic/angular';
import { BUTTON_ROLE, CARD_SUBJECT_TYPE_CODE, CMS_SCREEN_FOR_ROUTE, REGION_CODE, SV_CURRENCY_NAME, CARD_PRODUCT_NAME, CHANNEL } from '../../shared/constants/common.const';
import { BackService } from '../../shared/services/back.service';
import { BizserverService } from '../../shared/services/bizserver.service';
import { ModalService } from '../../shared/services/modal.service';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { Utils } from '../../shared/utils/utils.static';
import { CAR11210000Component } from '../car11210000/car11210000.component';
import { CardFilter } from '../car11210000/car11210000.model';
import { CAR11300000Component } from '../car11300000/car11300000.component';
import { DataformatService } from 'src/app/shared/services/dataformat.service';
import { DateUtils } from 'src/app/shared/utils/date-utils.static';
import { Router } from '@angular/router';
import { CardService } from 'src/app/shared/services/card.service';
import { CEB8014Req } from 'src/app/shared/TRClass/CEB8014-req';
import { CEB8014Res } from 'src/app/shared/TRClass/CEB8014-res';
import { CEB8016Res } from 'src/app/shared/TRClass/CEB8016-res';
import { CEB8016Req } from 'src/app/shared/TRClass/CEB8016-req';
import { DateRange } from 'src/app/shared/component/filter/filter.model'; 
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector    : 'app-car12100000',
  templateUrl : './car12100000.component.html',
  styleUrls   : ['./car12100000.component.scss'],
})

export class CAR12100000Component implements OnInit {
  items: any;
  cardType = '';
  cardTypeFeature: any = 'CFCHDEBT'; 
  creditCard = CARD_SUBJECT_TYPE_CODE.CREDIT;
  debitCard = CARD_SUBJECT_TYPE_CODE.DEBIT;     
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS;
  filter = new CardFilter();
  data: any;
  transactionList: any = []; 
  noHistory: boolean;
  totalCurrencyKhr: any = 0;
  totalCurrencyUsd: any = 0;
  totalTransaction: any = 0;
  reqTr: CEB8016Req; 
  init = true;
  event;
  creditLimit = new CEB8014Res().body; 
  card = new CEB8012ItemsRes();
  transactionTypeCode: any;
  svCurrencyUSD = SV_CURRENCY_NAME.USD;
  svCurrencyKHR = SV_CURRENCY_NAME.KHR;  
  fromDate: string;
  toDate: string; 
  search: string;  
  cardTypeFilter = 'cardFilter';
  @ViewChild(IonInfiniteScroll, { static: true }) ionInfiniteScroll: IonInfiniteScroll;
  constructor(
    private backService: BackService,
    private bizServer: BizserverService,
    private modalService: ModalService,
    private dataFormatService: DataformatService,
    private route: Router,
    private cardService: CardService, 
    private translate: TranslateService,
  ) {
    this.reqTr = new CEB8016Req();
  }

  ngOnInit() {
    this.search = ''; 
    this.card = DataCenter.get('card', 'card') as CEB8012ItemsRes; 
    this.filter.isShowAccountCard = false;
    this.filter.isCreditCard = false; 
    if ( this.creditCard === this.card.cardTypeFeature as any ) {
      this.firstLoad();
    }
     else {  
      this.transactionTypeCode = '01,03';
    } 
    // to set start date and end date with 1 week from now
    this.fromDate = this.dataFormatService.unFormatAccountNumber(DateUtils.getStartDatePeriodAsString('tab_1w'));
    this.toDate = this.dataFormatService.unFormatAccountNumber(DateUtils.getCurrentDateTime());
    // this.onGetRecentData(false);
    this.transactionList = this.filterByCardType( this.data);
    console.log(this.transactionList.length);   
  }

  firstLoad() { 
    this.filter.isCreditCard = true;
    this.cardTypeFeature = 'CFCHCRDT';
    this.transactionTypeCode = '01,02,03'; 
    this.getCreditCardLimit();
  }

  ionViewWillEnter() {
    if ( this.card ) {  
      this.backService.subscribe('my_card');
    } else { 
      debugger;
      this.backService.subscribe('card_transaction'); 
    }
  }

  onOpenOverflow() {
    DataCenter.set('card_transaction', 'card_transaction', true); 
    this.cardService.openOverflow( this.card, this.modalService, CMS_SCREEN_FOR_ROUTE.TRANSACTION );
  }

  getCreditCardLimit() {
    const reqTr = new CEB8014Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.cardNumber = this.card.cardNumber;
    this.bizServer.bizMOBPost('CEB8014', reqTr).then(data => {
      const resTr = data as CEB8014Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.creditLimit = resTr.body; 
      }
    });
  }

  setRequestBody(refresh?: boolean) {
    this.reqTr.header.screenID   = 'CAR12100000'; // your screenID
    Utils.setUserInfoTo(this.reqTr.body); 
    this.reqTr.body.cardNumber = this.card.cardNumber
    this.reqTr.body.cardTypeFeature = this.cardTypeFeature;
    this.reqTr.body.transactionTypeCode = this.transactionTypeCode;  
    this.reqTr.body.fromDate = this.fromDate;
    this.reqTr.body.toDate = this.toDate; 
    this.reqTr.body.searchKeyword = this.search;
    this.reqTr.body.channelTypeCode = CHANNEL.MOB; 
  }

  onGetRecentData(showLoading: boolean, refresh?: boolean, event?: any) {
    this.noHistory = false;
    this.setRequestBody(refresh);
    this.bizServer.bizMOBPost('CEB8016', this.reqTr, showLoading).then(data => {
      const resTr = data as CEB8016Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.items = resTr.body.items; 
        this.totalTransaction += resTr.body.items.length;
        this.items.forEach(element => {
          if (element.currencyName as any === 'USD') {
            this.totalCurrencyUsd += element.cardTransactionAmount;
          } else {
            this.totalCurrencyKhr += element.cardTransactionAmount;
          }
        });
        this.setTransactionList(resTr.body.items as any); 
      }
      if (refresh) {
        event.target.complete();
      } else {
        this.ionInfiniteScroll.complete();
      }
      if ( this.items.length < this.reqTr.body.pageSize ) { 
        if ( this.fromDate <= '20210525' || this.toDate <= '20210525' ) { 
          this.modalService.alert({
            content: this.translate.instant('CAR11100000.LABEL.TRANSACTION_NOTED'),
            btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
            callback: (res: any) => {
              if (res) {
                console.log(res);
              }
            }
          });
        }
      }  
    });
  }

  filterByCardType(list) {
    if (!list) {
      list = this.transactionList;
    }
    const result = list.filter(item => {
        item.cardNo = Utils.removeSpaceFromValue(item.cardNo);
        item.cardNo = Utils.getLast4Digits(item.cardNo);
        return item;
    });
    return result;
  }

  loadData(event) {
    this.onGetRecentData(true, true, event);
  }

  setTransactionList(list: []) { 
    if (list.length === 0) {
      this.ionInfiniteScroll.disabled = true;
      if (this.transactionList.length === 0) {
        this.noHistory = true;
      }
      return;
    } else if (list.length < this.reqTr.body.pageSize) { // last records.
      this.ionInfiniteScroll.disabled = true;
    }
    this.transactionList = [...this.transactionList, ...list] as any;
    this.reqTr.body.pageNumber++;
  }

  filterClicked() {
    this.modalService.open({
      content: CAR11210000Component,
      message: { data: this.filter },
      modalClass: ['pop_top'],
      callback: (result) => {
        if (result.role === BUTTON_ROLE.APPLY) {
          this.totalCurrencyKhr   = 0;
          this.totalCurrencyUsd   = 0;
          this.totalTransaction   = 0;
          if ( this.cardType === this.creditCard) {
            this.filter = result.data;
            this.filter.isCreditCard = true;
          } else {
            this.filter = result.data;
          } 
          console.log(result.data);

          if (result.data.cardTransactionType[0] === true && result.data.cardTransactionType[1] === true && result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '01,02,03';
          } else if (result.data.cardTransactionType[0] === true && result.data.cardTransactionType[1] === true) { 
            this.transactionTypeCode = '01,02';
          } else if (result.data.cardTransactionType[0] === true && result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '01,03';
          } else if (result.data.cardTransactionType[1] === true && result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '02,03';
          } else if (result.data.cardTransactionType[0] === true) { 
            this.transactionTypeCode = '01';
          } else if (result.data.cardTransactionType[1] === true) { 
            this.transactionTypeCode = '02';
          } else if (result.data.cardTransactionType[2] === true) { 
            this.transactionTypeCode = '03';
          }

          // this.reqTr.body.searchKeyword   = result.data.search;
          // this.reqTr.body.fromDate        = this.dataFormatService.unFormatAccountNumber(result.data.dateRange.fromDate);
          // this.reqTr.body.toDate          = this.dataFormatService.unFormatAccountNumber(result.data.dateRange.toDate);

          let regionTypeCode = '';
          if (result.data.regionTypeCode === REGION_CODE.ALL) {
            regionTypeCode = '';
          } else {
            regionTypeCode = result.data.regionTypeCode;
          }
          this.clearTransactionList();
          this.reqTr.body.countryCode   = regionTypeCode;        // countryCode
          this.onGetRecentData(false, false, event);
        }
      }
    });
  }
 
  goBack() {
     this.backService.fire();
  }

  clearTransactionList() {
    this.transactionList            = [];
    this.reqTr.body.pageNumber      = 1;
    this.reqTr.body.countryCode     = '';
    this.reqTr.body.pageSize        = 20;
    this.ionInfiniteScroll.disabled = false;
    this.totalTransaction           = 0;
    this.totalCurrencyUsd           = 0;
    this.totalCurrencyKhr           = 0;
  }

  transactionClickDetail(item) {
    this.modalService.modal({
      component       : CAR11300000Component,
      componentProps  : { 
        selectedItem  : item,
        cardNumber    : item.cardNumber
      }
    });
  } 

  goToBilling() {
    DataCenter.set('card_billing', 'card_billing', this.card);
    this.route.navigate(['card/billing'], {replaceUrl: true});
  }

  searchValued(event) {
    this.search = event;
    this.clearTransactionList();
    this.onGetRecentData(false, false, event); 
  }

  dateFilterChanged(dateRange: DateRange) { 
    this.fromDate = dateRange.fromDateAsServerFormat;
    this.toDate = dateRange.toDateAsServerFormat; 
    this.clearTransactionList();
    this.onGetRecentData(false, false, event);
  }

  imageVisaForHansarangYN() : boolean {
    if ( this.card.cardProductName === 'VisaHansarang' as any ) { 
      return true;
    } else { 
      return false;
    }
  }

  imagePPCBYN() : boolean { 
    if ( this.card.cardProductName === 'Nobless' as any || this.card.cardProductName === 'VisaHansarang' as any) {
      return true; 
    } else { 
      return false;
    }
  }

}

