import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car11200000',
  templateUrl: './car11200000.component.html',
  styleUrls: ['./car11200000.component.scss'],
})
export class CAR11200000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
