import { Component, OnInit } from '@angular/core'; 
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { CEB8013Req } from 'src/app/shared/TRClass/CEB8013-req';
import { CEB8013LimitAmount, CEB8013Res } from 'src/app/shared/TRClass/CEB8013-res';
import { Utils } from 'src/app/shared/utils/utils.static';
import { MAC1163A000Component } from '../../opn/mac1163-a000/mac1163-a000.component';
import { BUTTON_ROLE, CARD_TYPE, CHANNEL, CARD_PRODUCT_NAME } from '../../shared/constants/common.const';
import { BackService } from '../../shared/services/back.service';
import { ModalService } from '../../shared/services/modal.service';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { CAR12813000Component } from '../car12813000/car12813000.component';
import { CAR12814100Component } from '../car12814100/car12814100.component';
import { CAR12815100Component } from '../car12815100/car12815100.component';
import { CAR12816100Component } from '../car12816100/car12816100.component'; 
import { CardService } from 'src/app/shared/services/card.service';
import { TranslateService } from '@ngx-translate/core'; 

@Component({
  selector    : 'app-car12811000',
  templateUrl : './car12811000.component.html',
  styleUrls   : ['./car12811000.component.scss'],
})

export class CAR12811000Component implements OnInit { 
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  card  = new CEB8012ItemsRes(); 
  dailyTransactionLimit = new CEB8013Res().body;
  purchaseDailyLimit = new CEB8013LimitAmount();
  transferDailyLimit = new CEB8013LimitAmount();
  withdrawalDailyLimit = new CEB8013LimitAmount();   
  annualFee: string; 
  virtualCard = CARD_TYPE.VIRTUAL;  
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS; 
  constructor(
    private modalService: ModalService,
    private backService: BackService, 
    private bizServer: BizserverService,
    private translate: TranslateService,
    private cardService: CardService,
  ) { 
    this.purchaseDailyLimit.amount = 0;
    this.withdrawalDailyLimit.amount = 0;
    this.transferDailyLimit.amount = 0;  
  }
  
  async ngOnInit() {
    this.card = DataCenter.get('card', 'card', true);  
    // this.dateAfterConverted = this.cardService.formatDateYYYYMM( this.card.expireDateSvfe );    
    this.annualFee = this.translate.instant('CAR12811000.LABEL.FREETC');  
  }

  ionViewDidEnter() { 
    const isMyCard = DataCenter.get('my_card', 'my_card');
    const isTransaction = DataCenter.get('card_transaction', 'card_transaction');
    if ( isMyCard ) { // click from card list 
      this.backService.subscribe('my_card'); 
    } else if ( isTransaction ) {  // click from transaction by card
      DataCenter.set('card', 'card', this.card);
      this.backService.subscribe('card_transaction');  
    } 
    this.getDailyTransactionLimits(); 
  } 

  // Inquire Daily Transaction Limit of Debit Card(Cash WithdrawalLimit /Fund TransferLimit /PurchaseLimit)
  async getDailyTransactionLimits() {
    const reqTr = new CEB8013Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.cardNumber = this.card.cardNumber;
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    await this.bizServer.bizMOBPost('CEB8013', reqTr).then(data => {
      const resTr = data as CEB8013Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.dailyTransactionLimit = resTr.body;
        this.purchaseDailyLimit    = this.dailyTransactionLimit.purchaseLimitAmount; 
        this.transferDailyLimit    = this.dailyTransactionLimit.transferLimitAmount;
        this.withdrawalDailyLimit  = this.dailyTransactionLimit.withdrawalLimitAmount;
      }
    });
  }

  async doChangeNickname() {
    const myAccount = {
      cardId          : this.card.cardIDSvfe,
      cardNickName    : this.card.cardNickName,
      mode            : 'card',
      cardProductID   : this.card.productId
    };
    const result = await this.modalService.modal({
      component: MAC1163A000Component,
      componentProps: { data: myAccount }
    });
    if (result.role === BUTTON_ROLE.APPLY) {
      this.card.cardNickName = result.data;
    }
  }

  onChangeDailyTransactionLimit() {
    this.modalService.modal({
      component: CAR12814100Component,
      componentProps: {
        data: this.dailyTransactionLimit,
        card: this.card 
      }
    }).then((result) => {
      if (result.role === BUTTON_ROLE.CANCEL) { 
        this.getDailyTransactionLimits();
      }
    });
  }

  toChangePin() { 
    if ( this.card.cardStatusCodeSvfe === 0 || this.card.cardStatusCodeSvfe === 14 ) { 
      DataCenter.set('card', 'card', this.card);
      this.modalService.modal({
        component: CAR12815100Component,
        componentProps: {
          data: this.card
        }
      }).then((result) => {
      });
    } else { 
      this.cardService.disabledGeneratePIN();
    }
  }

  toViewBenefit() {
    const dataBenefit = {
      cardProductName : this.card.productName,
      cardTypeCode    : this.card.cardTypeCode
    };
    this.modalService.modal({
     component       : CAR12813000Component,
     componentProps  : { card: dataBenefit }
   });
  }

  onClickToResetPIN() { 
    if ( this.card.cardStatusCodeSvfe === 0 || this.card.cardStatusCodeSvfe === 14 ) { 
      this.toCompleteScreen(); 
    } else  {
      this.cardService.disabledGeneratePIN();
    }
  }

  toCompleteScreen() { 
    DataCenter.set('card', 'card', this.card);
    this.modalService.modal({
      component: CAR12816100Component,
      componentProps: {
        data: this.card
      }
    }).then((result) => {
    }); 
  }  

  clickBack() {
    // this.cardService.routeToCMSPreviousScreen(this.card);
    this.backService.fire();
  }

  // cardVirtualYN(): boolean { 
  //   return this.card.isVirtual === 'Y' as any;
  // } 

}
