import { Component, OnInit } from '@angular/core';
import { BackService } from 'src/app/shared/services/back.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';

@Component({
  selector: 'app-car12530000',
  templateUrl: './car12530000.component.html',
  styleUrls: ['./car12530000.component.scss'],
})
export class CAR12530000Component implements OnInit {

  constructor(
    private backSerive: BackService,
    private modalService: ModalService,
  ) { }

  ngOnInit() {
    this.backSerive.subscribe('my_card');
  }

  ionViewEnter() {
    this.backSerive.subscribe('my_card');
  }

  onClickOk() {
    this.backSerive.my_card();
    // this.modalService.dismiss({role: BUTTON_ROLE.BACKDROP});
  }
}
