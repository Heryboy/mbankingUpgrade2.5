import { Component, OnInit } from '@angular/core'; 
import { BackService } from 'src/app/shared/services/back.service';
import { DataCenter } from '../../shared/utils/data-center.static';

@Component({
  selector: 'app-car12843000',
  templateUrl: './car12843000.component.html',
  styleUrls: ['./car12843000.component.scss'],
})
export class CAR12843000Component implements OnInit {

  amendAvailableYN: string;
  constructor(private backService: BackService) { }
  ngOnInit() {
    this.amendAvailableYN = DataCenter.get('amendAvailableYN', 'amendAvailableYN'); 
  }

  checkexpDate(): boolean {  
    if ( this.amendAvailableYN === 'Y' as any || this.amendAvailableYN === 'B1' as any ) {  
      return true;
    } else { 
      return false;
    } 
  }

  ionViewWillEnter() {
    let subscribe = DataCenter.get('overflow', 'overflow');
    console.log(subscribe);
    const card = DataCenter.get('card', 'card');
    if (subscribe === 'card_transaction') {
      DataCenter.set('card', 'card', card);
    } else {
      subscribe = 'my_card';
    }
    this.backService.subscribe(subscribe);
  }

  onClickOk() {
   this.backService.fire();
  }

}
