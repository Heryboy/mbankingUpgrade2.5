import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';

@Component({
  selector: 'app-car12815300',
  templateUrl: './car12815300.component.html',
  styleUrls: ['./car12815300.component.scss'],
})
export class CAR12815300Component implements OnInit {

  constructor(
    private modalService: ModalService,
  ) { }

  ngOnInit() {}

  onClickOk() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.APPLY
    });
  }

}
