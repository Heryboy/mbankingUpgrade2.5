import { Component, OnInit } from '@angular/core';
import { BUTTON_ROLE, LOCAL_STORAGE, CHANNEL } from 'src/app/shared/constants/common.const';
import { ModalService } from '../../shared/services/modal.service';
import { Router } from '@angular/router';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service'; 
import { CEB8031Req } from 'src/app/shared/TRClass/CEB8031-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB8031Res } from 'src/app/shared/TRClass/CEB8031-res';
import { Util } from 'src/app/shared/util'; 
import { BackService } from 'src/app/shared/services/back.service';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';

@Component({
  selector: 'app-car12816200',
  templateUrl: './car12816200.component.html',
  styleUrls: ['./car12816200.component.scss'],
})
export class CAR12816200Component implements OnInit {
  data; 
  util = new Util();
  userInfo;
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  constructor(
    private modalService: ModalService,
    private router: Router,
    private authTranService: AuthTransactionService,
    private bizServer: BizserverService,
    private backService: BackService
  ) { }

  ngOnInit() {}

  onClickYes() { 
    this.requestAuthentication();
  }

  async requestAuthentication() {
    await this.backService.modalService.modal({
      component: SmsAuthenticationComponent,
      componentProps: {
        callback: (res) => {
          if (res) {
            this.transactionID      = res.transactionID;
            this.authenticationCode = res.authenticationCode;
            this.transactionDate    = res.transactionDate;
            this.checkAuthentication();
          }
        }
      }
    });
  }

  checkAuthentication() {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID   = this.transactionID;               // authTransactionID
    reqTr.body.authenticationCode  = this.authenticationCode;          // authenticationCode
    reqTr.body.authTransactionDate = this.transactionDate;             // authTransactionDate
    reqTr.body.channelTypeCode     = CHANNEL.MOB;                      // channelTypeCode
    reqTr.body.customerNo          = Utils.getUserInfo().customerNo;   // customerNo
    reqTr.body.userID              = Utils.getUserInfo().userID;       // userID
    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.doRequestToServer();
      }
    });
  }

  // do request to Generate PIN
  doRequestToServer() {
    const reqTr = new CEB8031Req();
    reqTr.body.authenticationCode = this.authenticationCode;       
    reqTr.body.authTransactionDate = this.transactionDate;           
    reqTr.body.authTransactionID = this.transactionID;          
    this.userInfo = this.util.getSecureStorage(LOCAL_STORAGE.USER_INFO);
    reqTr.body.userID = this.userInfo.userID;
    reqTr.body.customerNo = this.userInfo.customerNo;
    reqTr.body.phoneNumber = this.userInfo.phoneNo;
    reqTr.body.validThru = this.data.month + '/' + this.data.year;         // validThru mm/yy >> convert to YYYYMM in server
    reqTr.body.cvv = this.data.cVVCode;
    reqTr.body.pin = this.data.PIN;
    reqTr.body.cardNumber = this.data.cardNumber;     
    this.bizServer.bizMOBPost('CEB8031', reqTr).then(data => { 
      const resTr = data as CEB8031Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header) && resTr.body.resultYN === 'Y') {
        this.toCompleteScreen();
      } 
    });
  }

  toCompleteScreen() {
    this.router.navigate(['/card/result-reset-PIN']);
    this.modalService.dismissAll({
      role: BUTTON_ROLE.CLOSE
    });
  } 

  onClickNo() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CANCEL
    });
  }

}
