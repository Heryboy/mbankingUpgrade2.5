import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12816200Component } from './car12816200.component';

describe('CAR12816200Component', () => {
  let component: CAR12816200Component;
  let fixture: ComponentFixture<CAR12816200Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12816200Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12816200Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
