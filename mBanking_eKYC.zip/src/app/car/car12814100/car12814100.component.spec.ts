import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12814100Component } from './car12814100.component';

describe('CAR12814100Component', () => {
  let component: CAR12814100Component;
  let fixture: ComponentFixture<CAR12814100Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12814100Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12814100Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
