import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CMS_SCREEN_FOR_ROUTE, CARD_SUBJECT_TYPE_CODE, CARD_PRODUCT_NAME, LANGUAGE, LOCAL_STORAGE, BUTTON_ROLE } from 'src/app/shared/constants/common.const'; 
import { CardService } from 'src/app/shared/services/card.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { CEB8113Req } from 'src/app/shared/TRClass/CEB8113-req';
import { CEB8113ItemsRes } from 'src/app/shared/TRClass/CEB8113-res'; 
import { CEB8115Res } from 'src/app/shared/TRClass/CEB8115-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { Utils } from 'src/app/shared/utils/utils.static';
import { BackService } from '../../shared/services/back.service'; 
import { CAR12410000Component } from '../car12410000/car12410000.component';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { CEB8115Req } from 'src/app/shared/TRClass/CEB8115-req'; 
import { DateTimeFormatService } from 'src/app/shared/services/date-time.service'; 
import { Util } from 'src/app/shared/util';
import { CAR12431000Component } from '../car12431000/car12431000.component';

@Component({
  selector    : 'app-car12400000',
  templateUrl : './car12400000.component.html',
  styleUrls   : ['./car12400000.component.scss'],
})

export class CAR12400000Component implements OnInit {  
  dueDate: string; 
  card = new CEB8012ItemsRes();
  paymentDueDateInfo = new CEB8113ItemsRes();
  paymentInfo = new CEB8115Res().body;
  dueDateAfterConvert: any;
  billingPeriod: string;
  customerName: string;
  disabled: boolean;
  creditCard = CARD_SUBJECT_TYPE_CODE.CREDIT; 
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS;
  accountNickName: string;
  accounNo: string;
  private _language: string;
  private util = new Util();
  set language(value: string) {
    this._language = value;
  }
  get language(): string {
      return this._language = this.util.getSecureStorage(LOCAL_STORAGE.I18N);
  }

  constructor(
    private translate: TranslateService,
    private backService: BackService,
    private modalService: ModalService, 
    private cardService: CardService, 
    private bizServer: BizserverService,
    private dateTimeFormat: DateTimeFormatService, 
  ) {}

  async ngOnInit() {
  } 

  ionViewWillEnter() {
    const isCard = DataCenter.get('card', 'card', false);
    const isBilling = DataCenter.get('card_billing', 'card_billing', false);
    if ( isCard ) { // click from card list 
      this.card = isCard; 
      this.backService.subscribe('my_card'); 
    } else { // click from transaction by card 
      this.card = isBilling; 
      DataCenter.set('card', 'card', this.card);
      this.backService.subscribe('card_transaction');  
    }
  }

  onClickPaymentDueDate() {
    const reqTr = new CEB8113Req();
    const userInfo = Utils.getUserInfo();
    reqTr.body.customerNo = userInfo.customerNo;
    reqTr.body.userID = Utils.getUserInfo().userID; 
    reqTr.body.accountID = this.card.accountID;
    reqTr.body.cardNumber = this.card.cardNumber;   
    this.cardService.selectCreditCardDueDate(reqTr, this.translate.instant('CAR12400000.LABEL.CHOOSE_DUE_DATE'), this.paymentDueDateInfo.dueDate).then(res => {
      this.paymentDueDateInfo = res;  
      this.getPaymentInformationBasedOnPaymentDueDate();   
    }).catch( err => {
      // handle error here
    });
  } 

  async getPaymentInformationBasedOnPaymentDueDate() {
    const reqTr = new CEB8115Req();
    Utils.setUserInfoTo(reqTr.body); 
    reqTr.body.accountID = this.card.accountID;
    reqTr.body.cardNumber = this.card.cardNumber;  
    if (  this.isKOoRJAoRZH() ) {  
      this.dueDateAfterConvert = this.cardService.formatDateYYYYMMDD2(this.paymentDueDateInfo.dueDate); 
    } else { 
      this.dueDateAfterConvert = this.cardService.formatDateYYYYMMDD(this.paymentDueDateInfo.dueDate);
    } 
    reqTr.body.dueDate =  this.dueDateAfterConvert; 
    await this.bizServer.bizMOBPost('CEB8115', reqTr).then(data => {
      const resTr = data as CEB8115Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.paymentInfo = resTr.body;
        this.billingPeriod = this.dateTimeFormat.getDateTimeFormat(this.paymentInfo.startDate, 'yyyymmdd') 
                        + ' - '  + this.dateTimeFormat.getDateTimeFormat(this.paymentInfo.endDate, 'yyyymmdd');
        this.accountNickName = this.card.accountNickName; 
        this.accounNo = this.card.accountNo;
      }
    });
  }

  onOpenOverflow(card: CEB8012ItemsRes) {
    DataCenter.set('card_billing', 'card_billing', true); 
    this.cardService.openOverflow(card, this.modalService, CMS_SCREEN_FOR_ROUTE.CREDIT_CARD_BILLING);
  }
  
  onClickPaymentHistory() {
    this.modalService.modal({
      component: CAR12410000Component
    }).then( res => {
    });
  }

  onClickFullPartialPaymentNow() {

    // this.modalService.alert({
    //   content: this.translate.instant('CAR12400000.LABEL.THIS_SERVICE_NOT_AVAILABLE'),
    //   btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
    //   callback: (res: any) => {
    //     if (res) {
    //       console.log(res);
    //     }
    //   }
    // });

    const fullPartialPaymentObj = {
      fullPayment: this.paymentInfo.amountTAD,
      minimumPayment: this.paymentInfo.amountMAD,
      currencyCode: this.card.currencyCode,
      cardNickname: this.card.cardNickName,
      cardHolderName: this.card.cardholderName,
      productName: this.card.productName, 
      cardProductName: this.card.cardProductName, 
      cardScheme: this.card.cardNetName,
      cardNo: this.card.cardNumber,
      cardId: this.card.cardId,
      accountNoSvbo: this.card.accountNo,
      cardTypeFeature: this.card.cardTypeFeature
    }; 
    this.modalService.modal({
      component: CAR12431000Component,
      componentProps: {
        fullPartialPaymentObj
      },
      handler: (res) => {
      }
    }).then( res => {
      if ( res.role === BUTTON_ROLE.BACKDROP) {
        // do requestData Again
        console.log('Do request data again');
      }
    });

  }

  goBack() { 
    this.backService.fire();
  }

  private isKOoRJAoRZH(): boolean {
    if (
      this.language === LANGUAGE.I18N_KO ||
      this.language === LANGUAGE.I18N_JA ||
      this.language === LANGUAGE.I18N_ZH 
    ) {
      return true;
    }
    return false;
  }

  // initPaymentInfo() {
  //   this.cardBillingInfo = this.paymentInfo.body.items.length ? this.paymentInfo.body.items[0] : this.cardBillingInfo;
  //   this.cardBillingInfo.dueDate = this.cardBillingInfo.dueDate ?
  //                                  this.dateTimeFormat.getDateTimeFormat(this.cardBillingInfo.dueDate, 'yyyymmdd') as any
  //                                  : this.cardBillingInfo.dueDate;
  // }

}
