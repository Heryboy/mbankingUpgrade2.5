import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../shared/services/modal.service';
import { BUTTON_ROLE, CHANNEL, SVFE_LIMIT_TYPE_BO_CODE, SV_CURRENCY_CODE } from 'src/app/shared/constants/common.const';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { DataCenter } from '../../shared/utils/data-center.static';
import { Router } from '@angular/router';
import { BackService } from 'src/app/shared/services/back.service';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { CEB8034Req } from 'src/app/shared/TRClass/CEB8034-req';
import { CEB8034Res } from 'src/app/shared/TRClass/CEB8034-res';

@Component({
  selector: 'app-car12814200',
  templateUrl: './car12814200.component.html',
  styleUrls: ['./car12814200.component.scss'],
})
export class CAR12814200Component implements OnInit {
  purchaseLimit: number;
  withdrawalLimit: number;
  transferLimit: number;
  currencyCode: string;
  expDate: string;
  data;
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  constructor(
    private modalService: ModalService,
    private router: Router,
    private authTranService: AuthTransactionService,
    private bizServer: BizserverService,
    private backService: BackService
  ) {}

  ngOnInit() {
    // console.log('this.data', this.data);
    if (this.data) {
      this.currencyCode    = this.data.currencyCode;
      this.expDate         = this.data.expDate;
      this.purchaseLimit   = this.data.purchaseLimit;
      this.withdrawalLimit = this.data.withdrawalLimit;
      this.transferLimit   = this.data.transferLimit;
    }
  }

  onClickNo() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CANCEL
    });
  }

  onClickYes() {
    this.requetAuthentication();
  }

  async requetAuthentication() {
    await this.backService.modalService.modal({
      component: SmsAuthenticationComponent,
      componentProps: {
        callback: (res) => {
          if (res) {
            this.transactionID      = res.transactionID;
            this.authenticationCode = res.authenticationCode;
            this.transactionDate    = res.transactionDate;
            this.checkAuthentication();
          }
        }
      }
    });
  }

  checkAuthentication() {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID   = this.transactionID;               // authTransactionID
    reqTr.body.authenticationCode  = this.authenticationCode;          // authenticationCode
    reqTr.body.authTransactionDate = this.transactionDate;             // authTransactionDate
    reqTr.body.channelTypeCode     = CHANNEL.MOB;                      // channelTypeCode
    reqTr.body.customerNo          = Utils.getUserInfo().customerNo;   // customerNo
    reqTr.body.userID              = Utils.getUserInfo().userID;       // userID
    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.toCompleteScreen();
      }
    });
  }

  toChangeTransactionLimit() {
    const reqTr = new CEB8034Req();
    reqTr.body.cardId = this.data.cardIDSvfe;
    reqTr.body.validThru = this.expDate;
    reqTr.body.purchaseLimitAmount = this.purchaseLimit;
    reqTr.body.withdrawalLimitAmount = this.withdrawalLimit;
    reqTr.body.transferLimitAmount = this.transferLimit;
    reqTr.body.currencyCode = this.data.currencyCode; 
    reqTr.body.purchaseLimitTypeCode = this.data.purchaseLimitTypeCode;
    reqTr.body.withdrawalLimitTypeCode = this.data.withdrawalLimitCode;;
    reqTr.body.transferLimitTypeCode = this.data.transferLimitTypeCode;;
    this.bizServer.bizMOBPost('CEB8034', reqTr).then(data => {
      const resTr = data as CEB8034Res;
      this.authTranService.transactionResult(resTr.header);
      console.log('resTr', resTr);
      if (this.bizServer.checkResponse(resTr.header)) {
        if (resTr.body.returnYN === 'Y') {
          // this.toCompleteScreen();
        }
      }
    });
  }

  toCompleteScreen() {
    const data = { 
      currencyCode    : this.currencyCode, 
      purchaseLimit   : this.purchaseLimit,
      withdrawalLimit : this.withdrawalLimit,
      transferLimit   : this.transferLimit
    };
    DataCenter.set('CAR12814200', 'CAR12814200', data);
    this.modalService.dismissAll({
      role: BUTTON_ROLE.CLOSE,
    });

    // to modify Purchase Limit, Withdrawal Limit, and transfer Limit
    this.toChangeTransactionLimit();

    this.router.navigate(['card/result-change-transaction-limit']);
  }

}
