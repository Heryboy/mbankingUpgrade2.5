import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12814200Component } from './car12814200.component';

describe('CAR12814200Component', () => {
  let component: CAR12814200Component;
  let fixture: ComponentFixture<CAR12814200Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12814200Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12814200Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
