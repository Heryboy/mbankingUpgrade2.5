import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { PopoverController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { BUTTON_ROLE, FACILITY_CODE, LANGUAGE, LOCAL_STORAGE } from 'src/app/shared/constants/common.const';
import { BackService } from 'src/app/shared/services/back.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { MapsService } from 'src/app/shared/services/maps.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PPCB0160Req } from 'src/app/shared/TRClass/PPCB0160-req';
import { PPCB0160Res } from 'src/app/shared/TRClass/PPCB0160-res';
import { Util } from 'src/app/shared/util';

export type ButtonCardRole = 'btn_call' | 'btn_share' | 'btn_directions';
@Component({
  selector: 'app-car12841100',
  templateUrl: './car12841100.component.html',
  styleUrls: ['./car12841100.component.scss'],
})
export class CAR12841100Component implements OnInit {

  branchList: any[];
  default = '0';
  sortSelected: SelectBoxOptionModel;
  hideList = true;

  facilityCode =  FACILITY_CODE;
  appLanguageModel = {
    en: LANGUAGE.I18N_EN,
    ja: LANGUAGE.I18N_JA,
    km: LANGUAGE.I18N_KM,
    ko: LANGUAGE.I18N_KO,
    zh: LANGUAGE.I18N_ZH
  };
  appLanguage: string;
  currentLocation: any;

  durations: Array<any>;
  constructor(
    public mapService: MapsService,
    public bizServer: BizserverService,
    private translate: TranslateService,
    private modalService: ModalService,
    public popoverController: PopoverController,
    public callNumber: CallNumber,
    public socialShare: SocialSharing,
    private backService: BackService,
    private routeState: ActivatedRoute,
  ) {}

  ngOnInit() {
    this.backService.subscribe();
  }

  ionViewWillEnter() {
    this.appLanguage = (new Util()).getSecureStorage(LOCAL_STORAGE.I18N);

    this.translate.get('BFS12100000').subscribe((res) => {
      this.sortSelected = {
        title: res.TITLE.SORT,
        selectedTab: 1,
        selectedTabValue: res.LABEL.BY_DISTANCE,
        items: [
          {
            title: res.TITLE.SORT,
            itemValueField: 'value',
            itemTextField: 'text',
            seletedOpt: '0',
            option: [
              {
                text: res.LABEL.BY_DISTANCE,
                value: '0'
              },
              {
                text: res.LABEL.BY_NAME,
                value: '1'
              }
            ]
          },
        ]
      };

    });

    this.onShowList();
  }

  onClose() {
    this.modalService.dismiss({role: BUTTON_ROLE.CLOSE});
  }

  onSelectBranch(branch) {
    this.modalService.dismiss({role: BUTTON_ROLE.OK, data: branch});
  }

  onClickSortBy() {
    switch (this.default) {
      case '0':
        this.sortBy('0');
        break;
      case '1':
        this.sortBy('1');
        break;
    }
  }

  sortBy(type: string) {
    switch (type) {
      case '0':
        if (this.branchList.length > 0) {
          this.branchList = this.branchList.sort((a: any, b: any) => a.distance - b.distance);
        }
        break;
      case '1':
        if (this.branchList.length > 0) {
          this.branchList.sort((a: any, b: any) => ((
            this.appLanguage === this.appLanguageModel.en ? a.branchNameEn :
            this.appLanguage === this.appLanguageModel.ja ? a.branchNameJp :
            this.appLanguage === this.appLanguageModel.ko ? a.branchNameKr :
            this.appLanguage === this.appLanguageModel.km ? a.branchNameKh :
            this.appLanguage === this.appLanguageModel.zh ? a.branchNameCn :
            a.branchNameEn) >
            (this.appLanguage === this.appLanguageModel.en ? b.branchNameEn :
            this.appLanguage === this.appLanguageModel.ja ? b.branchNameJp :
            this.appLanguage === this.appLanguageModel.ko ? b.branchNameKr :
            this.appLanguage === this.appLanguageModel.km ? b.branchNameKh :
            this.appLanguage === this.appLanguageModel.zh ? b.branchNameCn :
            b.branchNameEn
            )) ? 1 : (((
              this.appLanguage === this.appLanguageModel.en ? b.branchNameEn :
              this.appLanguage === this.appLanguageModel.ja ? b.branchNameJp :
              this.appLanguage === this.appLanguageModel.ko ? b.branchNameKr :
              this.appLanguage === this.appLanguageModel.km ? b.branchNameKh :
              this.appLanguage === this.appLanguageModel.zh ? b.branchNameCn :
              b.branchNameEn) >
              (this.appLanguage === this.appLanguageModel.en ? a.branchNameEn :
              this.appLanguage === this.appLanguageModel.ja ? a.branchNameJp :
              this.appLanguage === this.appLanguageModel.ko ? a.branchNameKr :
              this.appLanguage === this.appLanguageModel.km ? a.branchNameKh :
              this.appLanguage === this.appLanguageModel.zh ? a.branchNameCn :
              a.branchNameEn
              )) ? -1 : 0));
        }
        break;
    }
  }

  onShowList(): void {
    this.hideList = false;
    this.getBranchList();
  }

  async getBranchList() {
    this.currentLocation = await this.mapService.getCurrentLocation().catch( error => console.log(error));
    this.branchList = [];
    const reqTr = new PPCB0160Req();
    const branchOptionCode = '01';
    reqTr.body.branchOptionCode = branchOptionCode;
    reqTr.body.userID = new Util().getSecureStorage( LOCAL_STORAGE.GUESS_USER_ID );

    const resTr = await this.bizServer.bizMOBPost('PPCB0160', reqTr) as PPCB0160Res;
    const resultSuccess = this.bizServer.checkResponse(resTr.header);
    if (resultSuccess) {
      this.branchList = resTr.body.branchList;
      if (this.currentLocation) {
        this.branchList = this.branchList.map((branch: any) => {
            const destination = {lat: branch.latitude, lng: branch.longitude};
            const distance = this.mapService.calculateDirectDistanceFromUser(destination, this.currentLocation);
            const branchObject = {...branch, distance, userLocation: this.currentLocation};
            return branchObject;
        });
        this.branchList = this.branchList.sort((a: any, b: any) => a.distance - b.distance);
      }
      return this.branchList;
    }
  }

}
