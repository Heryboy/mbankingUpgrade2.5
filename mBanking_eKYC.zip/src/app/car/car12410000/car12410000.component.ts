import { Component, OnInit, ViewChild } from '@angular/core'; 
import { BUTTON_ROLE, CARD_PRODUCT_NAME, SV_CURRENCY_NAME } from 'src/app/shared/constants/common.const'; 
import { BizserverService } from 'src/app/shared/services/bizserver.service';  
import { ModalService } from 'src/app/shared/services/modal.service';
import { CAR12810000Component } from '../car12810000/car12810000.component'; 
import { CEB8112Req } from '../../shared/TRClass/CEB8112-req';
import { Utils } from '../../shared/utils/utils.static';
import { CEB8112Res, CEB8112ItemsRes } from '../../shared/TRClass/CEB8112-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res';
import { DateRange } from 'src/app/shared/component/filter/filter.model';
import { DataformatService } from 'src/app/shared/services/dataformat.service';
import { IonInfiniteScroll } from '@ionic/angular';
import { DateUtils } from 'src/app/shared/utils/date-utils.static';
@Component({
  selector: 'app-car12410000',
  templateUrl: './car12410000.component.html',
  styleUrls: ['./car12410000.component.scss'],
})
export class CAR12410000Component implements OnInit { 
  response: CEB8112ItemsRes[];
  card: CEB8012ItemsRes; 
  totalItem: number;
  totalPaymentAmountUsd: number;
  totalPaymentAmountKhr: number;
  length: number;
  currencyCode: string; 
  src: string;
  noHistory: boolean; 
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS; 
  fromDate: string;
  toDate: string; 
  search: string;
  reqTr: CEB8112Req; 
  disabledTab_1w = 'disabled';
  svCurrencyKHR = SV_CURRENCY_NAME.KHR;  
  @ViewChild(IonInfiniteScroll, { static: true }) ionInfiniteScroll: IonInfiniteScroll;
  constructor(
    private bizServer: BizserverService,
    private modalService: ModalService,
    private dataFormatService: DataformatService,
  ) { 
    this.reqTr = new CEB8112Req();
  }

  ngOnInit() { 
    this.card = DataCenter.get('card', 'card', false); 
    this.currencyCode = 'USD';
    this.totalItem = 0;
    this.totalPaymentAmountUsd = 0;
    this.totalPaymentAmountKhr = 0;
    this.fromDate = this.dataFormatService.unFormatAccountNumber(DateUtils.getStartDatePeriodAsString('tab_1m'));
    this.toDate = this.dataFormatService.unFormatAccountNumber(DateUtils.getCurrentDateTime());
  }

  doRequestPaymentHistory(isScroll: boolean, loading: boolean) {
    this.noHistory = false;
    Utils.setUserInfoTo(this.reqTr.body);                 
    this.reqTr.body.cardNumber = this.card.cardNumber;
    this.reqTr.body.fromDate = this.fromDate;
    this.reqTr.body.toDate = this.toDate;    
    this.bizServer.bizMOBPost('CEB8112',  this.reqTr, loading).then(data => {
      const resTr = data as CEB8112Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.length = resTr.body.items.length;
        if (isScroll === false) {
          this.response = resTr.body.items;
          if (this.length === 0) { 
            this.noHistory = true;
          }
        } else if (isScroll === true && this.length > 0) {
          this.response = this.response.concat(resTr.body.items); 
        }
        this.totalItem = 0;
        this.totalPaymentAmountUsd = 0;
        this.totalPaymentAmountKhr = 0;
        this.totalItem = this.response.length;
        if (this.response) {
          this.response.forEach(element => {
            if ( element.currencyCode as any === 'USD' ) { 
              this.totalPaymentAmountUsd += element.cardTransactionAmount;
            } else { 
              this.totalPaymentAmountKhr += element.cardTransactionAmount;
            } 
          });
        }  
      }
    });
  }

  scrollLoadData(event) {
    this.reqTr.body.pageNumber++;
    this.doRequestPaymentHistory(true, true);
    if (event) {
      event.target.complete();
    } else {
      this.ionInfiniteScroll.complete();
    }
    if (this.length === 0) {
      event.target.disabled = true;
    }
  }

  searchValued(event) {
    this.search = event;
    this.clearTransactionList();
    this.doRequestPaymentHistory(false, false);
  }

  dateFilterChanged(dateRange: DateRange) { 
    this.fromDate = dateRange.fromDateAsServerFormat;
    this.toDate = dateRange.toDateAsServerFormat; 
    this.clearTransactionList();
    this.doRequestPaymentHistory(false, false);
  } 

  clearTransactionList() {
    this.response = [];
    this.reqTr.body.pageNumber = 1;
    this.reqTr.body.pageSize = 10;
    this.ionInfiniteScroll.disabled = false;
    this.totalItem = 0;
    this.totalPaymentAmountUsd = 0; 
    this.totalPaymentAmountKhr = 0;
  }

  onClickOverflow() {
    console.log(this.card);
    this.modalService.open({
      content: CAR12810000Component,
      modalClass: ['pop_bottom'],
      message: this.card,
      callback: res => {
        this.modalService.dismissAll({
          role: BUTTON_ROLE.CLOSE
        });
     }
    });
  }

  onClickBack() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

}
