import { Component, OnInit } from '@angular/core';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BlockUnblockCardData } from 'src/app/shared/TRClass/CEB8131-req';
import { BackService } from 'src/app/shared/services/back.service';
import { DataCenter } from 'src/app/shared/utils/data-center.static';

@Component({
  selector: 'app-car12822000',
  templateUrl: './car12822000.component.html',
  styleUrls: ['./car12822000.component.scss'],
})
export class CAR12822000Component implements OnInit {
  
  content = '';
  data : BlockUnblockCardData;
  constructor(
    private modalService: ModalService,
    private backSerive: BackService,
  ) { }

  ngOnInit() {
    // this.content = this.data.completeScreenConten;
    this.content = DataCenter.get('data', 'data', false);
    this.backSerive.subscribe('my_card');
  }

  ionViewEnter() {
    this.backSerive.subscribe('my_card');
  }

  onClickOk() {
    this.backSerive.my_card();
    // this.modalService.dismissAll({role: BUTTON_ROLE.OK});
  }
}
