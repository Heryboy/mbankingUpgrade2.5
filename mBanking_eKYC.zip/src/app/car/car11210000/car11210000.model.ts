import { DateRange } from '../../shared/component/filter/filter.model';

export class CardFilter {
  regionTypeCode: any;
  dateRange: DateRange;
  search: string;
  cardTransactionType: any;
  isShowAccountCard: boolean;
  card: any;
  isCreditCard: boolean;
}
