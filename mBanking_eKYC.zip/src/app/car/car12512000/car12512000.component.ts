import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car12512000',
  templateUrl: './car12512000.component.html',
  styleUrls: ['./car12512000.component.scss'],
})
export class CAR12512000Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
