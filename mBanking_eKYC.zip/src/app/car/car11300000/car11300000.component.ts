import { Component, OnInit } from '@angular/core';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { TranslateService } from '@ngx-translate/core';
import { BUTTON_ROLE, SV_CURRENCY_NAME } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BizserverService } from '../../shared/services/bizserver.service';
import { CEB8017Req } from '../../shared/TRClass/CEB8017-req';
import { CEB8017Res } from '../../shared/TRClass/CEB8017-res';
import { Utils } from '../../shared/utils/utils.static';

@Component({
  selector: 'app-car11300000',
  templateUrl: './car11300000.component.html',
  styleUrls: ['./car11300000.component.scss'],
})

export class CAR11300000Component implements OnInit {
  transactionDetailBySvCardID = new CEB8017Res().body;
  transactionDetail;
  cardNumber;
  selectedItem;
  isShowMerchantAddress: boolean;
  isShowAmountDetail: boolean;
  svCurrencyKHR = SV_CURRENCY_NAME.KHR;
  constructor(
    private modalService: ModalService,
    private callNumber: CallNumber,
    private translate: TranslateService,
    private bizServer: BizserverService
  ) { }

  ngOnInit() {
    // this.transactionDetail = this.getTransactionDetail(this.selectedItem);
    this.transactionDetail = this.selectedItem;
    this.cardNumber = this.cardNumber; 
    this.getTransactionDetail(); 
  } 

  onBack() {
    this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
  }

  getTransactionDetail() {
    const reqTr = new CEB8017Req();
    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.svCardID = this.transactionDetail.svCardID;
    reqTr.body.cardNumber = this.cardNumber;
    this.bizServer.bizMOBPost('CEB8017', reqTr).then(data => {
      const resTr = data as CEB8017Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        this.transactionDetailBySvCardID = resTr.body; 
      } 
    });
  }

  callMerchant(phoneNumber) {
    if (!phoneNumber) {
      this.modalService.alert({
        content: 'This merchant has no phone number',
        btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
        modalClass: ['pop_alert'],
      });
    } else {
      this.callNumber.callNumber(phoneNumber, true)
        .then(res => console.log('Launched dialer!', res))
        .catch(err => console.log('Error launching dialer', err));
    }
  }

  showHideMerchantAddress() {
    if (this.isShowMerchantAddress) {
      this.isShowMerchantAddress = false;
    } else {
      this.isShowMerchantAddress = true;
    }
  }

  showHideAmountDetail() {
    if (this.isShowAmountDetail) {
      this.isShowAmountDetail = false;
    } else {
      this.isShowAmountDetail = true;
    }
  }
  
}
