import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core'; 
import { MONTH_KEY_VALUE } from 'src/app/shared/common/data.common';
import { SelectBoxOptionModel } from 'src/app/shared/component/select-option/select-option.model';
import { BackService } from 'src/app/shared/services/back.service';
import { DataCardReqService } from 'src/app/shared/services/data-card-req.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { SelectService } from 'src/app/shared/services/select.service';
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { DataCenter } from 'src/app/shared/utils/data-center.static';
import { CAR12520000Component } from '../car12520000/car12520000.component';
import { CardService } from 'src/app/shared/services/card.service';
import { CARD_PRODUCT_NAME } from 'src/app/shared/constants/common.const';

enum reissueYN {
  Y = 'Y',
  N = 'N'
}

@Component({
  selector: 'app-car12511000',
  templateUrl: './car12511000.component.html',
  styleUrls: ['./car12511000.component.scss'],
})
export class CAR12511000Component implements OnInit {
  done1: string;
  done2: string;
  done3: string;
  done4: string;
  done5: string; 
  btnNext: string;
  disabled: boolean;
  disabledToNext: boolean;
  mMtext: string;
  mMvalue: string;
  yYtext: string;
  cVVCode: string;
  cVVCodeFeedback: string;
  PIN: string;
  confirmPIN: string;
  confirmPINFeedback: string;
  cardNickname: string;
  cardNicknameFeedback: string;
  MMObj: SelectBoxOptionModel;
  YYObj: SelectBoxOptionModel;
  card = new CEB8012ItemsRes(); 
  PinHolder: string;
  PinTranslate: string;
  PinCodeIsIncorrect: string;
  readonly: boolean;
  isKeyboardUp: boolean;
  translateCardTypeFeature: string;
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS;
  @ViewChild('cVVCodeInput', {static: true}) cVVCodeInput;
  @ViewChild('currentPIN', {static: true}) currentPIN;
  @ViewChild('inputCardNickName', {static: true}) inputCardNickName;
  @ViewChild('confirmCurtPIN', {static: true}) confirmCurtPIN;

  constructor(
    private modalService: ModalService,
    private selectService: SelectService,
    private translate: TranslateService,
    private cardReqService: DataCardReqService,
    private backService: BackService,
    private cardService: CardService
  ) { }

  ngOnInit() {
    this.card = DataCenter.get('card', 'card' , false);
    this.btnNext = this.translate.instant('CAR12511000.BUTTON.NEXT');
    this.disabledToNext = false;
    this.done1 = '';
    this.done2 = '';
    this.done3 = '';
    this.done4 = '';
    this.done5 = ''; 
    this.disabled = true;
    this.readonly = true;
    this.checkCardTypeFeature();
    // if (this.card) {
    //   this.checkPinTextAndHolderTranslate(String(this.card.reissueYN));
    // }
  }

  ionViewWillEnter() {
    this.backService.subscribe('my_card');
  }

   // set button to full screen when users put cursor in textfields
   onFocus(): void {
    this.isKeyboardUp = true;
  }

  // set button to not full screen when users do not put cursor in textfields
  onBlur(): void {
    this.isKeyboardUp = false;
  }

  checkPinTextAndHolderTranslate(val: string) {
    if (val === reissueYN.Y) {
      this.PinHolder = this.translate.instant('CAR12511000.PLACE_HOLDER.ENTER_CURRENT_PIN');
      this.PinTranslate       = this.translate.instant('CAR12511000.LABEL.CURRENT_PIN');
    } else if (val === reissueYN.N) {
      this.PinHolder = this.translate.instant('CAR12511000.PLACE_HOLDER.ENTER_PIN');
      this.PinTranslate       = this.translate.instant('CAR12511000.LABEL.PIN');
    }
  }

  onClickCancel() {
    this.backService.fire();
  }

  ionChangeCVVCode(event) {
    if (event) {
      event.target.value = String(event.target.value).substr(0, 3);
      if (String(event.target.value).length === 3) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    }
  }

  ionChangePIN(event) {
    console.log(event.target.value);
    if (event) {
      event.target.value = String(event.target.value).substr(0, 6);
      if (String(event.target.value).length === 6) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    }
  }

  ionChangeConfirmPIN(event) {
    if (event) {
      event.target.value = String(event.target.value).substr(0, 6);
      if (String(event.target.value).length === 6) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    }
  }

  ionChangeCardNickname(event) {
    if (event.target.value) {
      this.disabled = false;
      this.disabledToNext = true;
      this.cardNickname = event.target.value; 
    } else {
      this.disabled = false;
      this.disabledToNext = true;
      // this.disabled = true;
      // this.disabledToNext = false; 
    }
  }

  onClickDone(note: string) {
    switch (note) {
      case 'Select_Vaild_Thru_MM':
        this.done1 = '';
        this.done2 = '';
        this.done3 = '';
        this.done4 = '';
        this.done5 = '';
        this.onClickMM();
        break;
      case 'Select_Vaild_Thru_YY':
        this.done1 = '';
        this.done2 = '';
        this.done3 = '';
        this.done4 = '';
        this.done5 = '';
        this.onClickYY();
        break;
      case 'CVV_Code':
        this.done1 = 'done';
        this.done2 = '';
        this.done3 = '';
        this.done4 = '';
        this.done5 = '';  
        this.cVVCodeInput.setFocus();
        break;
      case 'PIN':
        this.done1 = 'done';
        this.done2 = 'done';
        this.done3 = '';
        this.done4 = '';
        this.done5 = ''; 
        this.currentPIN.setFocus();
        break;
      case 'Confirm_PIN':
        this.done1 = 'done';
        this.done2 = 'done';
        this.done3 = 'done';
        this.done4 = '';
        this.done5 = ''; 
        this.confirmCurtPIN.setFocus();
        break;
      case 'Card_Nickname':
        this.done1 = 'done';
        this.done2 = 'done';
        this.done3 = 'done';
        this.done4 = 'done';
        this.done5 = ''; 
        this.inputCardNickName.setFocus();
        break;
    }
    this.disabled = false;
    this.disabledToNext   = false;
    this.btnNext = this.translate.instant('CARD_COMMON.BUTTON.CONFIRM');
    console.log(note);
  }

  onClickNext() {
    this.nextRole();
  }

  async onClickMM() {
    let optMMList:any[] = [];
    MONTH_KEY_VALUE.forEach(element => {
      optMMList.push({
        text: this.translate.instant(element.key),
        key: this.translate.instant(element.text),
        value: element.value
      });
    });
    const MMObj: SelectBoxOptionModel = {
      title: 'Month', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      ngClass: 'holder',
      items: [
        {
          title: '',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.mMvalue,
          option: optMMList
        }
      ]
    };
    const result = await this.selectService.present(MMObj);
    console.log(result);
    if (result) {
      this.mMtext = result.text;
      this.mMvalue = result.value;
      if (this.yYtext) {
        this.disabled = false;
      }
    }

  }

  async onClickYY() {
    const yy  = this.cardService.formatDateYYYY();
    let optYYList: any[] = [];
    for (let i = 0; i <= 10; i++) {
      optYYList.push({
        text: String(yy + i),
        value: String(yy + i)
      });
    }
    const YYObj: SelectBoxOptionModel = {
      title: 'Year', // sort text
      selectedTab: 0,
      selectedTabValue: '',
      ngClass: 'holder',
      items: [
        {
          title: '',
          itemValueField: 'value',
          itemTextField: 'text',
          seletedOpt: this.yYtext,
          option: optYYList
        }
      ]
    };
    const result = await this.selectService.present(YYObj);
    console.log(result);
    if (result) {
        this.yYtext = result.text;
        if (this.mMvalue) {
          this.disabled = false;
        }
    }
  }

  nextRole (){
    this.btnNext= this.translate.instant ("CAR12511000.BUTTON.NEXT");
      if (this.yYtext && this.mMvalue) {
        this.done1 = "done";
        this.disabled = true;
        this.cVVCodeInput.setFocus();
        this.readonly = false; 
        if (this.cVVCode) {
            this.cVVCodeFeedback = undefined;
            this.done2 = "done";
            this.disabled = false;
            if (this.PIN === "" || this.PIN === undefined || this.PIN === null) {
              this.currentPIN.setFocus();
            }
            if (this.PIN) {   // Check PIN Condition
              this.done3 = "done";
              this.disabled = true;
              this.confirmCurtPIN.setFocus();

              if (this.confirmPIN) {
                if (this.checkCurrntPINNewCard() === true) {
                  this.done4 = "done";
                  // this.disabled = true;
                  this.disabled = false;
                  this.disabledToNext = true;
                  this.cardNickname = '';
                  this.inputCardNickName.setFocus();

                  if (this.cardNickname) {
                    this.done5 = "done";
                    this.disabled = false;
                    this.disabledToNext = true;
                } // End Check CardNickName               
              } // End check CurPIN and CfPIN
            } // End CheckComfirm PIN Condition  
          } //End Check PIN Condition  
        } //End Condition Check CVV Code
      }// End Condition YY and MM
  }// End of Next Role

  toNextStep() {
    this.doRequestCheckCardNickName().then( res => {
      if (res === true) {
        const data = {
          cardId: this.card.cardIDSvfe,
          productId: this.card.productId,
          cardNickname: this.cardNickname.trim(),
          cardHolderName: this.card.cardholderName,
          validThruMM: this.mMvalue,
          validThruYY: this.yYtext,
          CVVCode: this.cVVCode,
          PIN: this.PIN
        };
        this.modalService.modal({
          component: CAR12520000Component,
          componentProps: {
            data
          }
      }).then((result) => {});
      }
    });
  }

  doRequestCheckCardNickName(): Promise<boolean> {
    return new Promise( resolve => {
      console.log(this.cardNickname);
      this.cardReqService.checkCardNickName(String(this.cardNickname.trim())).then(res => {
        if (res.resultYN === 'Y') {
          this.cardNicknameFeedback = this.translate.instant('CAR12511000.LABEL.NICKNAME_ALREADY');
          resolve(false);
        } else {
          this.cardNicknameFeedback = undefined;
          resolve(true);
        }
      });
    });
  }

  checkCurrntPINNewCard(): boolean {
    if (this.PIN === this.confirmPIN) {
      this.confirmPINFeedback = undefined;
      return true;
    }
    this.confirmPINFeedback = this.translate.instant('CAR12511000.LABEL.PIN_CODE_INVALID');
    this.disabled = false;
    return false;
  }  
    
  checkCardTypeFeature() { 
    if ( this.card.productNum === '10' as any || this.card.productNum === '20' as any) { 
      return this.translateCardTypeFeature = this.translate.instant('CAR12000000.LABEL.CREDIT');
    } else if ( this.card.productNum != '10' as any && this.card.productNum != '20' as any ) { 
      return this.translateCardTypeFeature = this.card.cardTypeFeature;
    }
  }

  checkHansuang() : boolean { 
    if ( this.card.cardProductName == 'VisaHansarang' as any ) { 
      return true;
    } else { 
      return false;
    }
  }

}
