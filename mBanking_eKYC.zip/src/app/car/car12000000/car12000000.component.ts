import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CardService } from 'src/app/shared/services/card.service';
import { CARD_SCHEME_TYPE_CODE, CARD_SUBJECT_TYPE_CODE, CARD_TYPE, CMS_SCREEN_FOR_ROUTE, CARD_PRODUCT_NAME, CHANNEL } from '../../shared/constants/common.const';
import { BackService } from '../../shared/services/back.service';
import { DataformatService } from '../../shared/services/dataformat.service';
import { ModalService } from '../../shared/services/modal.service';
import { CEB8012Req } from '../../shared/TRClass/CEB8012-req';
import { CEB8012ItemsRes } from '../../shared/TRClass/CEB8012-res';
import { DataCenter } from '../../shared/utils/data-center.static';
import { Utils } from '../../shared/utils/utils.static';
import { CAR12310000Component } from '../car12310000/car12310000.component'; 
import { BlockUnblockCardData } from 'src/app/shared/TRClass/CEB8131-req';

@Component({
  selector    : 'app-car12000000',
  templateUrl : './car12000000.component.html',
  styleUrls   : ['./car12000000.component.scss'],
})

/* card list screen */
export class CAR12000000Component implements OnInit {
  cardList: Array<CEB8012ItemsRes>;
  card = new CEB8012ItemsRes();
  monthSubstr: any;
  yearSubstr: any;   
  creditCard = CARD_SUBJECT_TYPE_CODE.CREDIT;
  debitCard = CARD_SUBJECT_TYPE_CODE.DEBIT;     
  cardDinersClub = CARD_SCHEME_TYPE_CODE.DINERS_CLUB;
  virtulaCard = CARD_TYPE.VIRTUAL; 
  reissueTranslate: string;
  unBlockTranslate: string;
  renewalNowTranslate: string; 
  visaClassicDebit = CARD_PRODUCT_NAME.VISA_CLASSIC_DEBIT;
  visaClassicCredit = CARD_PRODUCT_NAME.VISA_CLASSIC_CREDIT;
  visaHansarang = CARD_PRODUCT_NAME.VISA_HANSARANG;
  visaGoldCredit = CARD_PRODUCT_NAME.VISA_GOLD_CREDIT;
  visaBusinessCredit = CARD_PRODUCT_NAME.VISA_BUSINESS_CREDIT;
  Nobless = CARD_PRODUCT_NAME.NOBLESS;
  prestiguePlus = CARD_PRODUCT_NAME.PRESTIGUE_PLUS;
  noCard: boolean;
  constructor(
    private modalService: ModalService,
    private backService: BackService,
    private translate: TranslateService,
    private route: Router,
    private formatter: DataformatService,
    private cardService: CardService,
    private accountFormat: DataformatService,
  ) {
   }

  async ngOnInit() {
    await this.getCards();
    this.backService.subscribe('logged_out',
    {
      title   : this.translate.instant('COMMON.MESSAGE.LOGOUT'),
      content : this.translate.instant('COMMON.MESSAGE.DO_YOU_REALLY_WANT_TO_LOGOUT')
    });
  }

  async getCards() {
    this.noCard = false;
    const reqTr = new CEB8012Req();
    Utils.setUserInfoTo(reqTr.body);    
    reqTr.body.channelTypeCode = CHANNEL.MOB;
    await this.cardService.getCardListByCustomerNo(reqTr).then( res => {
      this.cardList = res;  
      this.cardList.forEach(element => { 
        this.monthSubstr = element.expireDateSvfe.substring(element.expireDateSvfe.length - 2);
        this.yearSubstr = element.expireDateSvfe.substring(2 , 4);
        element.expireDateSvfe = this.monthSubstr + '/' + this.yearSubstr as any;
      }); 
      // check when customers do not have card 
      if ( this.cardList.length === 0 ) { 
        this.noCard = true; 
      }
      // console.log('this.cardList',  this.cardList);
      DataCenter.set('CAR12000000', 'cardList', this.cardList , true); 
    }).catch(err => {
      // handle error here.
    });;
  }

  onOpenOverflow(card: CEB8012ItemsRes ) { 
    DataCenter.set('my_card', 'my_card', true);
    this.cardService.openOverflow(card, this.modalService, CMS_SCREEN_FOR_ROUTE.MY_CARD);
  }

  toTransaction(card) {
    DataCenter.set('card', 'card', card);
    this.route.navigate(['card/transaction'], {replaceUrl: true});
  }

  toCashadvance(card: CEB8012ItemsRes) {
    this.modalService.modal({
      component     : CAR12310000Component,
      componentProps: {
        card
      }
    }).then((result) => { }); 
  }

  toBilling( card : CEB8012ItemsRes ) {
    DataCenter.set('card', 'card', card); 
    this.route.navigate(['card/billing'], {replaceUrl: true});
  }

  unblockImpossibility() {
    this.modalService.alert({
      content: this.translate.instant('CAR12000000.LABEL.UNBLOCK_IMPOSSIBILITY'),
      btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
      callback: (res: any) => {
        if (res) {
          console.log(res);
        }
      }
    });
  }

  unBlock(card: CEB8012ItemsRes) {
    const data   = new BlockUnblockCardData();
    data.card    = card;
    data.blockYN = false;
    if (card.unblockImpossibilityYN as any === 'Y') {
      this.unblockImpossibility();
    } else {
      DataCenter.set('CAR12810000', 'blockUnblockCardData', data);
      this.route.navigate(['/card/block-card-confirm']); 
    }
  }

  reIssue(card: CEB8012ItemsRes) {
    if ( card.reissueYN === 'Y' as any ){
      this.modalService.alert({
        content: this.translate.instant('CAR12000000.LABEL.CANNOT_REISSUE_CARD'),
        btnText: this.translate.instant('CARD_COMMON.BUTTON.CONFIRM'),
        callback: (res: any) => {
          if (res) {
            console.log(res);
          }
        }
      });
    } else {
      DataCenter.set('card', 'card', card);
      this.route.navigateByUrl('card/re-issue-card');
    } 
  }

  onClickActivate(card: CEB8012ItemsRes) {
    DataCenter.set('card', 'card', card);
    this.route.navigate(['/card/activation-card']);
  }

  onClickAddVirtualCard() {
    this.route.navigate(['card/intro-virtual-card']);
  }

  checkBalance(card: CEB8012ItemsRes) {
    // set cardholderName to accountNickName only whenever customer doesn't have accountNickName
    if (card.accountNickName === '' || card.accountNickName === undefined) { 
      card.accountNickName = card.cardholderName;
    } 
    const checkBlanceTxt = this.translate.instant('CARD_COMMON.LABEL.CHECK_BALANCE');  
    const availableBalanceTxt = this.translate.instant('CAR12000000.LABEL.AVAILABLE_BALANCE');
    const nickname = card.accountNickName;
    const accountNo =  this.accountFormat.formatAccountNumber(card.accountNo);
    const currencyName =  card.currencyCode;
    const balance = this.formatter.formatMoney(card.availableBalance, currencyName);
    const currencyCode = currencyName;
    const contentModal = '<h1>' + checkBlanceTxt + '</h1><span><br/>' + nickname + '<br/>' + accountNo + '<br/><br/>'
                  + availableBalanceTxt + '<br/></span><h1>' + balance + ' ' + currencyCode + '</h1>';
    this.modalService.confirm({
      content   : contentModal,
      width     : 300,
      modalClass: ['pop_confirm'],
      lBtn      : {
                  btnText : this.translate.instant('CARD_COMMON.BUTTON.ACCOUNT_INQUIRY'),
                  callback: () => {  
                    let path: string;
                    const dsc: string = card.depositSubjectCode; 
                    path = (dsc === '110' || dsc === '120') ? 'saving' : 'deposit'; 
                    DataCenter.set('my-card', 'card', card);
                    this.route.navigate(['/acc/account-inquiry', path]);    
                  }
      },
      rBtn      : {
                    btnText :  this.translate.instant('COMMON.BUTTON.OK'),
                    callback: () => {
                      console.log('ok');
                  }
      },
    });
  }
  
  normalCardYN (card: CEB8012ItemsRes): boolean { 
    return (card.cardActivateYN === 'Y' as any? true : false)
  }

  needToBeActivatedYN (card: CEB8012ItemsRes): boolean {
    return (card.cardActivatePossibleYN === 'Y' as any? true : false)
  }

  cardBlockYN (card: CEB8012ItemsRes): boolean {
    return (card.cardBlockYN === 'Y' as any? true : false)
  } 

  cardExpiredYN( card: CEB8012ItemsRes ) { 
    if ( card.cardBlockYN === 'N' as any && card.amendAvailableYN === 'Y' as any ) { 
      return this.renewalNowTranslate = this.translate.instant('CAR12000000.LABEL.THIS_CARD_HAS_EXPIRED');
    }
  }

  cardExpiredBefore1monthYN( card: CEB8012ItemsRes ) : boolean {  
    if ( card.amendAvailableYN === 'B1' as any ) { 
      return true;
    }
  }
 
  reissueYN(card: CEB8012ItemsRes) {
    if ( card.amendAvailableYN === 'Y' as any ) {  
      /* expire card show renewal button */
      return this.reissueTranslate = this.translate.instant('CAR12720000.LABEL.RENEWAL');  
    } else if ( card.amendAvailableYN === 'B1' as any ) {
      /* 1 month before expire card show renewal button */
      this.reissueTranslate = this.translate.instant('CAR12720000.LABEL.RENEWAL'); 
      this.unBlockTranslate = this.translate.instant('CARD_COMMON.LABEL.UN_BLOCK');
      return this.reissueTranslate && this.unBlockTranslate;  
    } else { 
      /* when card is block, show only re-issue & unblock button for users to click */
      // reissueYN : Y - check for one card can re-issue only one time based on this code from CBS 
      if ( card.reissueYN === 'Y' as any && card.cardBlockYN === 'Y' as any ) {  
        this.reissueTranslate = this.translate.instant('CARD_COMMON.LABEL.RE_ISSUE') ;
        this.unBlockTranslate = this.translate.instant('CARD_COMMON.LABEL.UN_BLOCK');
        return this.reissueTranslate &&  this.unBlockTranslate;
      } else if ( card.reissueYN != 'Y' as any && card.cardBlockYN === 'Y' as any ) { 
        this.reissueTranslate = this.translate.instant('CARD_COMMON.LABEL.RE_ISSUE') ;
        this.unBlockTranslate = this.translate.instant('CARD_COMMON.LABEL.UN_BLOCK');
        return this.reissueTranslate &&  this.unBlockTranslate;
      }
    }
  } 

  disabledCashAdvance( card: CEB8012ItemsRes ) : boolean { 
    /* busniess card cannot do cash advance */
    if ( card.productNum === 'P0110201000001' as any || card.productNum === 'P0110201000201' as any ) {  
      return false;
    } else if ( card.amendAvailableYN === 'Y' as any || card.amendAvailableYN === 'B1' as any ) { /* expire card or 1 month before expire card cannot do cash advance */
      return false;
    } else {
      return true;
    }
  }

  displayCreditButton( card: CEB8012ItemsRes ) : boolean { 
    const cardFeature = (card.cardTypeFeature === this.creditCard as any);
    if ( cardFeature && this.normalCardYN(card) && (card.cardNetName != this.cardDinersClub as any) ) { 
      return true;
    } 
  }

  disabledCheckBalance ( card: CEB8012ItemsRes ) : boolean { 
    if ( card.amendAvailableYN === 'Y' as any ) { /* expire card cannot go to check balance */
      return false;
    } else {
      return true;
    }
  }

}
