import { Component, OnInit } from '@angular/core';
import { loyalPointList, newLoyalPoints } from '../car11100000/data';
import { LOYALPOINT_TYPE } from 'src/app/shared/constants/common.const';
import { CEB8114Req } from '../../shared/TRClass/CEB8114-req';
import { CEB8114Res } from '../../shared/TRClass/CEB8114-res';
import { BizserverService } from '../../shared/services/bizserver.service';
import { Utils } from '../../shared/utils/utils.static';

@Component({
  selector: 'app-car13000000',
  templateUrl: './car13000000.component.html',
  styleUrls: ['./car13000000.component.scss'],
})
export class CAR13000000Component implements OnInit {
  loyalPointList: any;
  newLoyalPointList: any[];
  savePointList: any[];
  cashBackList: any[];
  loyalPointType: string;
  storage: any[]; 
  date: string;
  constructor(private bizServer: BizserverService) {
    // Deep Copy
    this.loyalPointList  = loyalPointList;
    this.newLoyalPointList = newLoyalPoints;
    this.storage = loyalPointList.loyalPointList;
    // this.savePointList = this.loyalPointList.loyalPointList;
    // this.cashBackList = this.loyalPointList.loyalPointList;
  }
  
  ngOnInit() {
    this.getData();
    this.date = "";
  }

  getData() {
    const reqTr = new CEB8114Req();

    Utils.setUserInfoTo(reqTr.body);
    reqTr.body.userID       = Utils.getUserInfo().userID;
    reqTr.body.customerNo   = '99000001';
    // reqTr.body.cardId      = '7';                       // cardId

    this.loyalPointList  = {currentCashbackAmount: 0, nextCashbackAmount: 0, currencyCode: 'USD'};

    this.bizServer.bizMOBPost('CEB8114', reqTr).then(data => {
      const resTr = data as CEB8114Res;
      if (this.bizServer.checkResponse(resTr.header)) {
        //Success To-Do
        this.loyalPointList  = resTr.body;
        // this.newLoyalPointList = newLoyalPoints;
        this.storage = resTr.body.items;
        // xxx = resTr.body.items;        // items
        // xxx = resTr.body.currencyCode;        // currencyCode
        // xxx = resTr.body.currentCashbackAmount;        // currentCashbackAmount
        // xxx = resTr.body.nextCashbackAmount;        // nextCashbackAmount
        console.log('my requested data from server >> ', this.loyalPointList);
      } else {
        //Fail To-Do
      }
    });
  }

  onSegmentChange(evt) {
    if (evt.target) {
      const segment = evt.target.value;
      if (segment === 'all') {
        if (this.loyalPointType) {
          this.loyalPointList.items = this.storage;
        }
        this.loyalPointType = '';
      } else if (segment === 'saved') {
        if (this.loyalPointType === LOYALPOINT_TYPE.CASH_BACK) {
          this.storage = [...this.loyalPointList.items, ...this.savePointList];
        } else {
          this.storage = this.loyalPointList.items;
        }
        this.loyalPointList.items = this.storage;
        const list = this.filterByLoyalPointType(this.loyalPointList.items, LOYALPOINT_TYPE.SAVED_POINT);
        this.loyalPointList.items = list[1];
        this.loyalPointType = LOYALPOINT_TYPE.SAVED_POINT;

      } else if (segment === 'cashback') {
        this.loyalPointList.items = this.storage;
        const list = this.filterByLoyalPointType(this.loyalPointList.items, LOYALPOINT_TYPE.CASH_BACK);
        this.loyalPointList.items = list[1];
        this.savePointList = list[2];
        this.loyalPointType = LOYALPOINT_TYPE.CASH_BACK;
      }
    }
  }

  scrollLoadData(event) {
    setTimeout(() => {
      this.doRequest().then(response => {
        if (response === true) {
          event.target.complete();
        }
      });
    }, 500);
  }

  doRequest(type?: string): Promise<boolean> {
    return new Promise( (resolve) => {
      // do logic request to server
      // if (this.loyalPointType === LOYALPOINT_TYPE.SAVED_POINT) {
      //   const list = this.filterByLoyalPointType(this.savePointList, LOYALPOINT_TYPE.SAVED_POINT);
      //   this.savePointList = list[1];
      //   this.cashBackList = list[2];
      //   this.loyalPointList.loyalPointList = this.savePointList;

      // } else if (this.loyalPointType === LOYALPOINT_TYPE.CASH_BACK) {
      //   const list = this.filterByLoyalPointType(this.cashBackList, LOYALPOINT_TYPE.CASH_BACK);
      //   this.cashBackList = list[1];
      //   this.savePointList = list[2];
      //   this.loyalPointList.loyalPointList = this.cashBackList;

      // } else {
      //   this.loyalPointList.loyalPointList = [ ...this.savePointList, ...this.cashBackList, ...this.newLoyalPointList ];
      // }
      resolve(true);
    });
  }

  filterByLoyalPointType(list: any[], loyalPointType? ): any[] {
    let resultThisType;
    let resultOtherType;
    if ( loyalPointType ) {
      resultThisType = list.filter(item => {
        if (item.loyalPointTypeCode === loyalPointType) {
          return item;
        }
      });
      resultOtherType = list.filter(item => {
        if (item.loyalPointTypeCode !== loyalPointType) {
          return item;
        }
      });
    } else {
      resultThisType = list;
      resultOtherType = list;
    }
    return [list, resultThisType, resultOtherType];
  }
}
