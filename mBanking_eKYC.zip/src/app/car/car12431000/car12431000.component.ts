import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { DataformatService } from 'src/app/shared/services/dataformat.service';
import { FormatterService } from 'src/app/shared/services/formatter.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { CAR12432000Component } from '../car12432000/car12432000.component';

@Component({
  selector: 'app-car12431000',
  templateUrl: './car12431000.component.html',
  styleUrls: ['./car12431000.component.scss'],
})
export class CAR12431000Component implements OnInit {
  fullPartialPaymentObj;
  keyboardup: string;
  cardNickname: string;
  cardNo: string;
  cardId: string;
  accountNoSvbo: string;
  productName: string;
  cardProductName: string;
  cardScheme: string;
  fullPayment: number;
  minimumPayment: number;
  currencyCode: string;
  cardTypeFeature: string;
  segmentValue: string;
  amountText: string;
  hidden: boolean;
  disabled: boolean;
  feedBack: string;
  disabledInput: boolean;
  cardHolderName: string;
  constructor(
    private modalService: ModalService,
    private formatterService: FormatterService,
    private translate: TranslateService,
    private dataformatService: DataformatService
  ) { }

  @ViewChild('paymentAmountInput', {static: true}) paymentAmountInput;

  ngOnInit() {
    this.segmentValue = 'full';
    this.hidden = true;
    this.disabled = true;
    this.disabledInput = true;
    this.setObject();
    setTimeout(() => {
      this.paymentAmountInput.setFocus();
    }, 100);
  }

  setObject() {
    if (this.fullPartialPaymentObj) {
      this.cardNickname = this.fullPartialPaymentObj.cardNickname;
      this.cardHolderName = this.fullPartialPaymentObj.cardHolderName;
      this.cardNo = this.fullPartialPaymentObj.cardNo;
      this.cardId = this.fullPartialPaymentObj.cardId;
      this.accountNoSvbo = this.fullPartialPaymentObj.accountNoSvbo;
      this.productName = this.fullPartialPaymentObj.productName;
      this.cardProductName = this.fullPartialPaymentObj.cardProductName;
      this.cardScheme = this.fullPartialPaymentObj.cardScheme;
      this.fullPayment = this.fullPartialPaymentObj.fullPayment;
      this.minimumPayment = this.fullPartialPaymentObj.minimumPayment;
      this.currencyCode = this.fullPartialPaymentObj.currencyCode;
      this.cardTypeFeature = this.fullPartialPaymentObj.cardTypeFeature;
      if (this.segmentValue === 'full') {
        this.amountText = this.dataformatService.formatMoney(this.fullPayment, this.currencyCode );
        this.keyboardup = 'keyboardup';
      }
      this.checkAmount( this.fullPayment );
    }
  }

  segmentChanged(event) {
    if (event) {
      this.segmentValue = event.target.value;
      this.feedBack = '';
      switch (event.target.value) {
        case 'full':
          this.amountText = this.dataformatService.formatMoney(this.fullPayment, this.currencyCode );
          this.disabledInput = true;
          this.keyboardup = 'keyboardup';
          this.checkAmount( Number(this.amountText) );
          break;
        case 'minimum':
          this.amountText = this.dataformatService.formatMoney(this.minimumPayment, this.currencyCode );
          this.disabledInput = true;
          this.keyboardup = 'keyboardup';
          this.checkAmount( Number(this.amountText) );
          break;
        case 'direct':
          this.amountText = undefined;
          this.disabledInput = false;
          this.keyboardup = 'keyboardup'; 
          break;
      }
      this.paymentAmountInput.setFocus();
    }
    // this.disable = false;
  }

  toConfirmScreen() {
    const fullPartialPaymentObj = {
      cardNickname: this.cardNickname,
      cardHolderName: this.cardHolderName,
      cardNo: this.cardNo,
      cardId: this.cardId,
      accountNoSvbo: this.accountNoSvbo,
      productName: this.productName,
      cardScheme: this.cardScheme,
      fullPayment: this.fullPayment,
      minimumPayment: this.minimumPayment,
      currencyCode: this.currencyCode,
      paymentAmount: this.formatterService.unformatInputNumber(this.amountText)
    };
    this.modalService.modal({
      component: CAR12432000Component,
      componentProps: {
        fullPartialPaymentObj
      }
    }).then( res => {});
  }

  onClickNext() {
    if (Number(this.formatterService.unformatInputNumber(this.amountText)) > this.fullPayment) {
      this.hidden = false;
      this.feedBack = this.translate.instant(
        'CAR12431000.LABEL.MAXIMUM_PAYMENT_AMOUNT', {
          maximumPayment: this.dataformatService.formatMoney(this.fullPayment, this.currencyCode),
          currencyCode: this.currencyCode
      });
    } else if (Number(this.formatterService.unformatInputNumber(this.amountText)) < this.minimumPayment){
      this.hidden = false;
      this.feedBack = this.translate.instant(
        'CAR12431000.LABEL.MINIMUM_PAYMENT_AMOUNT', {
          minimumPayment: this.dataformatService.formatMoney(this.minimumPayment, this.currencyCode),
          currencyCode: this.currencyCode
      });
    } else {
      this.toConfirmScreen();
    }
  }

  ionChangePaymentAmount(event) {
    event.preventDefault();
    this.formatterService.formateInputAmount(event, 'input', 'USD');
    if(this.amountText) {
      this.disabled = false;
    }
  }

  ionFocus(event) {
    this.formatterService.formateInputAmount(event, 'focus', 'USD');
  }

  ionBlur(event) {
    this.formatterService.formateInputAmount(event, 'blur', 'USD');
  }
  
  checkAmount ( amount: number ) {
    if ( amount > 0 ) { 
      this.disabled = false; // Button Next enabled for user to go next screen
    } else if ( amount <= 0 ) { 
      this.disabled = true;     
    }
  }

  onClickCancel() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

}
