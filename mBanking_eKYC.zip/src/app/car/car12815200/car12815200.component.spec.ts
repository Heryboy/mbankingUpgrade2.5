import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12815200Component } from './car12815200.component';

describe('CAR12815200Component', () => {
  let component: CAR12815200Component;
  let fixture: ComponentFixture<CAR12815200Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12815200Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12815200Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
