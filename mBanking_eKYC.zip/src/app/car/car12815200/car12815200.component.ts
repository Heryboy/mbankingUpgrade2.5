import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../shared/services/modal.service';
import { BUTTON_ROLE, CHANNEL } from 'src/app/shared/constants/common.const';
import { CAR12815300Component } from '../car12815300/car12815300.component';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { CEB8032Req } from 'src/app/shared/TRClass/CEB8032-req';
import { CEB8032Res } from 'src/app/shared/TRClass/CEB8032-res';
import { SmsAuthenticationComponent } from 'src/app/shared/component/sms-authentication/sms-authentication.component';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { BackService } from 'src/app/shared/services/back.service';

@Component({
  selector: 'app-car12815200',
  templateUrl: './car12815200.component.html',
  styleUrls: ['./car12815200.component.scss'],
})
export class CAR12815200Component implements OnInit {
  data;
  transactionID: number;
  authenticationCode: string;
  transactionDate: string;
  constructor(
    private modalService: ModalService,
    private authTranService: AuthTransactionService,
    private bizServer: BizserverService,
    private backService: BackService
  ) { }

  ngOnInit() {
  } 

  onClickYes() {
    this.requestAuthentication();
  } 

  async requestAuthentication() {
    await this.backService.modalService.modal({
      component: SmsAuthenticationComponent,
      componentProps: {
        callback: (res) => {
          if (res) {
            this.transactionID      = res.transactionID;
            this.authenticationCode = res.authenticationCode;
            this.transactionDate    = res.transactionDate;
            this.checkAuthentication();
          }
        }
      }
    });
  }
 
  checkAuthentication() {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID = this.transactionID;               
    reqTr.body.authenticationCode = this.authenticationCode;         
    reqTr.body.authTransactionDate = this.transactionDate;           
    reqTr.body.channelTypeCode = CHANNEL.MOB;                      
    reqTr.body.customerNo = Utils.getUserInfo().customerNo;   
    reqTr.body.userID = Utils.getUserInfo().userID;     
    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.doRequestToServer();
      }
    });
  }

  // do request to Generate PIN
  doRequestToServer() {
    const reqTr = new CEB8032Req();
    reqTr.body.authTransactionID = this.transactionID;
    reqTr.body.authenticationCode = this.authenticationCode;
    reqTr.body.authTransactionDate = this.transactionDate;
    reqTr.body.cardNumber = this.data.cardNumber;
    reqTr.body.cardId = this.data.cardId;
    reqTr.body.cvv = this.data.cvv;
    reqTr.body.validThru = this.data.validThru;
    reqTr.body.currentPIN = this.data.currentPIN;
    reqTr.body.newPIN = this.data.newPIN; 
    this.bizServer.bizMOBPost('CEB8032', reqTr).then(data => { 
      const resTr = data as CEB8032Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.toCompleteScreen();
      }
    });
  }

  toCompleteScreen() {
    this.modalService.modal({
      component: CAR12815300Component,
      componentProps: this.data
    }).then((result) => {
      if (result.role === BUTTON_ROLE.APPLY) {
        this.modalService.dismissAll({
          role: BUTTON_ROLE.BACKDROP,
          data: this.data
        });
      }
    });
  }

  onClickNo() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CANCEL
    });
  }

}
