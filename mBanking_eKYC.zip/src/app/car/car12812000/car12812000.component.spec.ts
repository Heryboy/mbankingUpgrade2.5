import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12812000Component } from './car12812000.component';

describe('CAR12812000Component', () => {
  let component: CAR12812000Component;
  let fixture: ComponentFixture<CAR12812000Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12812000Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12812000Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
