import { Component, OnInit } from '@angular/core';
import { BUTTON_ROLE } from '../../shared/constants/common.const';
import { ModalService } from '../../shared/services/modal.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector    : 'app-car12813000',
  templateUrl : './car12813000.component.html',
  styleUrls   : ['./car12813000.component.scss'],
})

export class CAR12813000Component implements OnInit {
  card: any;
  benefitsInfo: string;
  constructor(
    private modalService: ModalService,
    private translate: TranslateService,
  ) { }

  ngOnInit() {
    this.checkCardType();
  }

  checkCardType() { 
    if ( this.card.cardTypeCode === '01' ) { // 01 : DCI Card 
      this.benefitsInfo = this.translate.instant('CAR12813000.LABEL.DCI_INFO'); 
    } else { 
      this.benefitsInfo = this.translate.instant('CAR12813000.LABEL.OTHER_INFO');
    }
  }

  clickClose() {
    this.modalService.dismiss({ role: BUTTON_ROLE.CLOSE });
  }

}
