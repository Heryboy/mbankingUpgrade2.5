import { Component, OnInit } from '@angular/core';
import { BackService } from 'src/app/shared/services/back.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';

@Component({
  selector: 'app-car12433000',
  templateUrl: './car12433000.component.html',
  styleUrls: ['./car12433000.component.scss'],
})
export class CAR12433000Component implements OnInit {
  constructor(
    // private backService: BackService
    private modalService: ModalService
  ) { }

  ngOnInit() {}
  ionViewWillEnter() {
    // this.backService.subscribe();
  }
  onClickOk() {
    // this.backService.fire();
    this.modalService.dismiss({
      role: BUTTON_ROLE.APPLY
    });
  }

}
