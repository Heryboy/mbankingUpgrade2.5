import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CAR12000000aComponent } from './car12000000a.component';

describe('CAR12000000aComponent', () => {
  let component: CAR12000000aComponent;
  let fixture: ComponentFixture<CAR12000000aComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CAR12000000aComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CAR12000000aComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
