import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car12000000a',
  templateUrl: './car12000000a.component.html',
  styleUrls: ['./car12000000a.component.scss'],
})
export class CAR12000000aComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
