import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BUTTON_ROLE, CHANNEL } from 'src/app/shared/constants/common.const';
import { AuthTransactionService } from 'src/app/shared/services/authtransaction.service';
import { BizserverService } from 'src/app/shared/services/bizserver.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { Utils } from 'src/app/shared/utils/utils.static';
import { CEB0812Req } from 'src/app/shared/TRClass/CEB0812-req';
import { CEB0812Res } from 'src/app/shared/TRClass/CEB0812-res';
import { CEB8026Req } from 'src/app/shared/TRClass/CEB8026-req';
import { CEB8026Res } from 'src/app/shared/TRClass/CEB8026-res';

@Component({
  selector: 'app-car12730000',
  templateUrl: './car12730000.component.html',
  styleUrls: ['./car12730000.component.scss'],
})
export class CAR12730000Component implements OnInit {
  data;

  accNumber: string;
  cardNickName: string;
  accountName: string;
  accountNickName: string;
  mMtext: string;
  validThruMM: string;
  validThruYY: string;
  cardProductId: string;
  cardProductValue: string;
  cardProductText: string;
  cardProductType: string;
  amount: number;
  cardId: string;
  currencyCode: string;
  constructor(
    private modalService: ModalService,
    private bizServer: BizserverService,
    private router: Router,
    private authTranService: AuthTransactionService
  ) { }

  ngOnInit() {
    console.log(this.data);
    if (this.data) {
      this.accNumber        = this.data.accNumber;
      this.accountName      = this.data.accountName;
      this.cardNickName     = this.data.cardNickname;
      this.validThruMM      = this.data.validThruMM;
      this.mMtext           = this.data.validThruMM;
      this.validThruYY      = this.data.validThruYY;
      this.cardProductId    = this.data.cardProductId;
      this.cardProductValue = this.data.cardProductValue;
      this.cardProductText  = this.data.cardProductText;
      this.accountNickName  = this.data.accountNickName;
      this.amount           = this.data.fee;
      this.cardProductType  = this.data.cardProductType;
      this.currencyCode     = this.data.currencyCode;
      if (this.data.accountNickName === null) {
        this.accountNickName = this.data.accountName;
      }
    }
  }

  onClickNo() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CLOSE
    });
  }

  onClickYes() {
    this.callAuthenticationSMS();
  }

  doRequestPost() {
    const reqTr = new CEB8026Req();
    reqTr.body.accountNo            = this.accNumber;
    reqTr.body.amount               = this.amount;
    reqTr.body.cardNickName         = this.cardNickName;
    reqTr.body.currencyCode         = this.currencyCode;
    reqTr.body.productType          = this.cardProductType;
    reqTr.body.validThru            = this.data.validThruYY + this.data.validThruMM;


    this.bizServer.bizMOBPost('CEB8026', reqTr).then(data => {
      const resTr = data as CEB8026Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        if (resTr.body.resultYN === 'Y') {
          this.toCompleteSreen();
        }
      }
    });
  }

  toCompleteSreen() {
    this.modalService.dismissAll({
      role: BUTTON_ROLE.CLOSE
    });
    this.router.navigate(['/card/complete-add-virtual-card']);
  }

  callAuthenticationSMS() {
    this.authTranService.reqestAuthCode({ callback: (auth) => {
      this.checkAuthentication(auth);
    }});
  }

  checkAuthentication(auth) {
    const reqTr = new CEB0812Req();
    reqTr.body.authTransactionID = auth.transactionID;        // authTransactionID
    reqTr.body.authenticationCode = auth.authenticationCode;        // authenticationCode
    reqTr.body.authTransactionDate = auth.transactionDate;        // authTransactionDate
    reqTr.body.channelTypeCode = CHANNEL.MOB;        // channelTypeCode
    reqTr.body.customerNo = Utils.getUserInfo().customerNo;        // customerNo
    reqTr.body.userID = Utils.getUserInfo().userID;        // userID
    this.bizServer.bizMOBPost('CEB0812', reqTr).then(data => {
      const resTr = data as CEB0812Res;
      this.authTranService.transactionResult(resTr.header);
      if (this.bizServer.checkResponse(resTr.header)) {
        this.doRequestPost();
      }
    });
  }
}
