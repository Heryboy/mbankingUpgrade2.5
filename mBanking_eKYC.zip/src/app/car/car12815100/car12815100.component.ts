import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core'; 
import { BUTTON_ROLE } from 'src/app/shared/constants/common.const';
import { ModalService } from 'src/app/shared/services/modal.service'; 
import { CEB8012ItemsRes } from 'src/app/shared/TRClass/CEB8012-res';
import { Utils } from 'src/app/shared/utils/utils.static'; 
import { BizserverService } from '../../shared/services/bizserver.service';
import { CAR12815200Component } from '../car12815200/car12815200.component';
import { CAR12816100Component } from '../car12816100/car12816100.component';
import { CEB8035Req } from 'src/app/shared/TRClass/CEB8035-req';
import { CEB8035Res } from 'src/app/shared/TRClass/CEB8035-res';
import { LimitHTMLClass } from '../car12814100/car12814100.component';

export enum CardChangePIN { 
  CURRENT_PIN     = 'Current PIN',
  CVV_CODE        = 'CVV Code',
  NEW_PIN         = 'New PIN',
  CONFIRM_NEW_PIN = 'Confirm New PIN'
}

export enum DoneClass {
  DONE    = 'done'
}

@Component({
  selector: 'app-car12815100',
  templateUrl: './car12815100.component.html',
  styleUrls: ['./car12815100.component.scss'],
})
/*****
Screen : Change PIN
*****/
export class CAR12815100Component implements OnInit {
  card: CEB8012ItemsRes;
  CardChangePIN = CardChangePIN;
  pinLength = 6;
  cvvLength = 3;
  doneCurrentPIN: string;
  doneCvvCode: string;
  doneNewPIN: string;
  doneConfirmNewPIN: string;
  showConfirmBtnYN = false;
  enableNextBtn = true;
  enableConfirmBtn = false;
  cVVCode = '';
  cVVCodeFeedback = '';
  currentPIN = '';
  currentPINFeedBack = '';
  newPIN = '';
  newPINFeedBack = '';
  confirmPIN = '';
  confirmPINFeedback = '';
  btnNext: string;
  isKeyboardUp: boolean;   
  correctCurrentPIN = false;
  data;
  @ViewChild('cvvCODEInput'   ,   {static: true}) cvvCODEInput;
  @ViewChild('currentPINInput',   {static: true}) currentPINInput;
  @ViewChild('newPINInput'    ,   {static: true}) newPINInput;
  @ViewChild('confirmPINInput',   {static: true}) confirmPINInput;
  constructor(
    private modalService: ModalService, 
    private translate: TranslateService, 
    private bizServer: BizserverService,
  ) {}

  ngOnInit() {
    this.doneCurrentPIN    = '';
    this.doneCvvCode       = '';
    this.doneNewPIN        = '';
    this.doneConfirmNewPIN = '';
    // set button to full screen
    this.isKeyboardUp = true;
    this.validate(this.currentPIN, 6); 
  }

  ionViewWillEnter() {
    setTimeout(() => {
      this.currentPINInput.setFocus();
    }, 30);
  }

  // set button to full screen when users put cursor in textfields
  onFocus(): void {
    this.isKeyboardUp = true;
  }

  // set button to not full screen when users do not put cursor in textfields
  onBlur(): void {
    this.isKeyboardUp = false;
  }

  onClickCancel() {
    this.modalService.dismiss({
      role: BUTTON_ROLE.CANCEL
    });
  }

  checkNumberYN(str: string) {
    let code: number, i: number, len: number;
    for (i = 0, len = str.toString().length; i < len; i++) {
      code = str.charCodeAt(i);
      if (!(code > 47 && code < 58)) {
        return false;
      }
    } // numeric (0-9)
    return true;
    // this.formatterService.isNumeric(char);
  }

  //Params description
  /**
   * textInput: text for do validate
   * requireDigitLength: require length, Example: Pin require 6 digits, CVV require 3 digits
   * confirmPinYN: (Optional) if calling this function from input of Confirm PIN
   */

  validate(textInput: string, requireDigitLength: number, confirmPinYN?: boolean): string {
    let errorFeedback = '';
    let enableNextBtnYN = false;
    if (this.checkNumberYN(textInput)) {
      if (textInput.length === requireDigitLength) {
        enableNextBtnYN = true;
      }
    } else {
      errorFeedback = this.translate.instant('CAR12815100.LABEL.ENTER_FOUR_DIGITS_PIN_CODE');
    }

    // Check when confirm PIN input
    if (!errorFeedback && confirmPinYN){
      errorFeedback = textInput.length === requireDigitLength ? this.checkMatchPIN() : errorFeedback;
      const enableConfirmBtn = (errorFeedback || textInput.length !== requireDigitLength) ? false : true;
      enableNextBtnYN = errorFeedback ? false : true;
      this.showButtonConfirmFunction(true, enableConfirmBtn, false);
    } else { 
      // this happen beside confirm PIN input
      this.showButtonConfirmFunction(false, false, enableNextBtnYN);
    }
    return errorFeedback;
  }

  onClickDone(cardChangePIN: CardChangePIN) {
    switch (cardChangePIN) {
      case CardChangePIN.CURRENT_PIN:
        this.validate(this.currentPIN, 6);
        this.doneCurrentPIN    = '';
        this.doneCvvCode       = '';
        this.doneNewPIN        = '';
        this.doneConfirmNewPIN = '';
        this.currentPINInput.setFocus();
        break;
      case CardChangePIN.CVV_CODE:
        this.validate(this.cVVCode, 3);
        this.doneCurrentPIN    = DoneClass.DONE;
        this.doneCvvCode       = '';
        this.doneNewPIN        = '';
        this.doneConfirmNewPIN = '';
        this.cvvCODEInput.setFocus();
        break;
      case CardChangePIN.NEW_PIN:
        this.confirmPIN        = '';
        this.validate(this.newPIN, 6);
        this.doneCurrentPIN    = DoneClass.DONE;
        this.doneCvvCode       = DoneClass.DONE;
        this.doneNewPIN        = '';
        this.doneConfirmNewPIN = '';
        this.newPINInput.setFocus();
        break;
      case CardChangePIN.CONFIRM_NEW_PIN:
        this.validate(this.confirmPIN, 6, true);
        this.doneCurrentPIN    = DoneClass.DONE;
        this.doneCvvCode       = DoneClass.DONE;
        this.doneNewPIN        = DoneClass.DONE;
        this.doneConfirmNewPIN = '';
        this.confirmPINInput.setFocus();
        break;
    }
    // this.showConfirmBtnYN = true;
    // this.enableNextBtn = false;
    // this.btnNext = this.translate.instant('CARD_COMMON.BUTTON.CONFIRM');
  } 

  toNextStep() {
    const data = {                      
      cardId     : this.data.cardIDSvfe,            
      cardNumber : this.data.cardNumber,  
      validThru  : this.data.expireDateSvfe,       
      currentPIN : this.currentPIN,
      cvv        : this.cVVCode,                        
      newPIN     : this.newPIN,
      confirmPIN : this.confirmPIN
    };
    this.modalService.modal({
      component: CAR12815200Component,
      componentProps: {
        data
      }
    });
  }

  async checkCurrentPinYN () {
    let correctCurrentPIN = false;
    if (this.doneCurrentPIN !== LimitHTMLClass.DONE) {
      await this.doRequestCheckCurrentPIN().then(res => {
        correctCurrentPIN = res;
      });      
    }
    return correctCurrentPIN;
  }

  // Checking on Current-PIN whether it matches or not
  async doRequestCheckCurrentPIN(): Promise<boolean> {
      let correctCurrentPIN = false;
      const reqTr            = new CEB8035Req();
      const userInfo         = Utils.getUserInfo();
      reqTr.body.customerNo  = userInfo.customerNo;
      reqTr.body.userID      = userInfo.userID;
      reqTr.body.cardId      = this.data.cardIDSvfe;
      reqTr.body.currentPIN  = this.currentPIN;  
    return new Promise(async (resolve, reject) => {
      await this.bizServer.bizMOBPost('CEB8035', reqTr).then(data => { 
        const resTr = data as CEB8035Res;
        // if (this.bizServer.checkResponse(resTr.header)) {
        if (!resTr.header.error_code) {
          correctCurrentPIN = true;
        } else {
          correctCurrentPIN = false;
        }
        resolve(correctCurrentPIN)
      });
    });
  }

  // Checking on New-PIN & Confirm-PIN whether they match together or not
  // if the passwords match with each other : let user to next step
  checkMatchPIN(): string {
    let errorFeedback = '';
    if (this.newPIN === this.confirmPIN) {
      errorFeedback = '';
    } else {
    // Show the result of Confirm-New-PIN whenever it does not match with New-PIN
    // Result : PIN code does not match. Please try again.
    errorFeedback = this.translate.instant('CAR12815100.LABEL.CONFIRM_PIN_VALID');
    }
    return errorFeedback;
  }

  onClickToResetPIN() {
    this.toCompleteScreen(); 
  } 

  toCompleteScreen() {
    // this.router.navigate(['/card/reset-PIN']);
    this.modalService.modal({
      component: CAR12816100Component,
      componentProps: {
        data: this.data
      }
    }).then((result) => {
    });
  }

  onClickToNextInput() {
    if(this.doneCurrentPIN !== DoneClass.DONE) {
      this.checkDoneCurrentPinYN();
    } 
    
    if (this.doneCurrentPIN === DoneClass.DONE 
      && this.doneCvvCode !== DoneClass.DONE) {
      this.checkDoneCvvYN();
    }
    
    if (this.doneCvvCode === DoneClass.DONE 
      && this.doneNewPIN !== DoneClass.DONE) {
      this.checkDoneNewPinYN();
    }

    if (this.doneNewPIN === DoneClass.DONE
      && this.doneConfirmNewPIN !== DoneClass.DONE) {
      this.checkDoneConfrimPinYN();    
    }    
  }

  async checkDoneCurrentPinYN() {
    this.validate(this.currentPIN, 6);
    if (await this.checkCurrentPinYN()) {
      this.doneCurrentPIN = DoneClass.DONE; 
      setTimeout(() => {
        this.cvvCODEInput.setFocus();
      }, 150);
      this.currentPINFeedBack = '';
      return true;
    } else {
      this.doneCurrentPIN = '';
      this.currentPINFeedBack = this.translate.instant('CAR12815100.LABEL.CURRENT_PIN_INVALID'); 
      setTimeout(() => {
        this.currentPINInput.setFocus();
      }, 150);
      return false;
    }
  }

  checkDoneCvvYN(): boolean{
    this.validate(this.cVVCode, 3);
    if (this.doneCurrentPIN == DoneClass.DONE && this.cVVCode) {
      this.doneCvvCode = DoneClass.DONE;
      this.newPINInput.setFocus();
      return true;
    } else {
      this.doneCvvCode = '';
      this.cvvCODEInput.setFocus();
      return false;
    }
  }

  // we show button next when the last input (TransferLimit) have valid data
  checkDoneNewPinYN(): boolean{
    this.validate(this.newPIN, 6);
    if (this.doneCvvCode == DoneClass.DONE && this.newPIN) {
      this.doneNewPIN = DoneClass.DONE;
      this.confirmPINInput.setFocus();
      return true;
    } else {
      this.doneNewPIN = '';
      this.newPINInput.setFocus();
      return false;
    }
  }

  checkDoneConfrimPinYN(){
    this.validate(this.confirmPIN, 6, true);
    let completeInputConfirmPIN = (this.doneNewPIN === DoneClass.DONE);
    // this.doneConfirmNewPIN = DoneClass.DONE;
    this.doneConfirmNewPIN = '';
    return completeInputConfirmPIN;
  }

  enableBtnNextFunction(enableYN: boolean) {
    this.enableNextBtn = enableYN;
  }

  showButtonConfirmFunction(showBtnConfirmYN: boolean, enableBtnConfirmYN: boolean, enableBtnNextYN: boolean) {
    this.enableNextBtn    = enableBtnNextYN;
    this.showConfirmBtnYN = showBtnConfirmYN;
    this.enableConfirmBtn = enableBtnConfirmYN;
  }
  
}
