import { Injectable } from '@angular/core';
import { BizWaveAppIron } from '@ionic-native/bizwave-plugin-appiron/ngx';
import { BizWaveCheckProxy } from '@ionic-native/bizwave-plugin-checkproxy/ngx';
import { BizWaveDeviceInfo } from '@ionic-native/bizwave-plugin-deviceinfo/ngx';
import { Platform } from '@ionic/angular';
import { environment } from 'src/environments/environment';
import { LOCAL_STORAGE } from '../shared/constants/common.const';
import { BizserverService } from '../shared/services/bizserver.service';
import { Util } from '../shared/util';
import { AppIronParam } from './classes/app-iron-param';
import { AppPatchParam } from './classes/app-patch-param';
import { ChkProxyParam } from './classes/chk-proxy-param';
import { DeviceInfoParam } from './classes/device-info-param';
import { UpdateParam } from './classes/update-param';
import { LogService } from '../shared/services/log.service';
import { BizWaveUpdateBizportal } from '@ionic-native/bizwave-plugin-update-bizportal/ngx';
import { BizWaveCheckRooting } from '@ionic-native/bizwave-plugin-checkrooting/ngx';
import { AppRootingParam } from './classes/app-rooting-param';
import { BizWaveContentsIntegrity } from '@ionic-native/bizwave-plugin-checkintegrity/ngx';
import { CheckContentsParam } from './classes/check-contents-param';
import { BackService } from '../shared/services/back.service';


@Injectable({
  providedIn: 'root'
})
export class InitializeService {

  private responseObj = {
    body: {
      isLatest: false
    },
    header: {
      result: false,
      apiName: '',
      language: '',
      osType: '',
      displayType: '',
      errorCode: '',
      errorText: ''
    }
  };

  constructor(
    private platform: Platform,
    private appIron: BizWaveAppIron,
    private deviceInfo: BizWaveDeviceInfo,
    private checkProxy: BizWaveCheckProxy,
    private bizServer: BizserverService,
    private updateManager: BizWaveUpdateBizportal,
    private logger: LogService,
    private checkRooting: BizWaveCheckRooting,
    private checkContents: BizWaveContentsIntegrity,
    private backService: BackService
  ) { }

  util = new Util();

  initUpdate(progressOption: any): Promise<any> {

    const promiseReturn = new Promise((resolve, reject) => {
      this.logger.log('this.platform.is(\'cordova\')>>>>' + this.platform.is('cordova'));
      this.logger.log('environment.appAutoUpdate >>>>' + environment.appAutoUpdate);
      if (!this.platform.is('cordova')) {

        // Not contents update in web
        this.responseObj.header.apiName = 'APPLICATION_UPDATE';
        this.responseObj.header.result = true;
        this.responseObj.body.isLatest = true;
        resolve(this.responseObj);

      } else {

        const param = new DeviceInfoParam();

        this.deviceInfo.getDeviceInfo(param).then(
          (res) => {
            // localStorage.setItem( LOCAL_STORAGE.DEVICE_INFO, res.body);
            this.util.setSecureStorage(LOCAL_STORAGE.DEVICE_INFO, res.body);

            const appVersion = this.stringToNumberArray(res.body.appVersion); // '1.0.0'
            this.logger.log(appVersion);
            const contentsVersion = this.stringToNumberArray(res.body.contentsVersion);
            this.logger.log(contentsVersion);
            const osType = res.body.osType;
            this.logger.log(osType);
            const requiredVersion = this.stringToNumberArray(environment.appRequiredVer[osType]);
            this.logger.log(requiredVersion);
            const osVersion = res.body.osVersion;
            const displayType = 'PHONE';
            // NOTED: check app version updated 2020-03-05
            const currentAppVersion = appVersion.join().replace(/\,/g, '');
            const requiredAppVersion = requiredVersion.join().replace(/\,/g, '');
            this.logger.log(requiredAppVersion + ' > ' + currentAppVersion);
            // const currentAppMajorVersion = Number(appVersion[0]);
            // const currentAppMinorVersion = Number(appVersion[1]);
            // const currentAppBuildVersion = Number(appVersion[2]);
            let isCreateContentsIntegrity = this.util.getSecureStorage(LOCAL_STORAGE.IS_CREATE_CONTENTS_INTEGRITY);
            this.logger.log('[Storage isCreateContentsIntegrity] ' + isCreateContentsIntegrity);
            if (isCreateContentsIntegrity === null) {
              isCreateContentsIntegrity = false;
            }
            this.logger.log('[isCreateContentsIntegrity] ' + isCreateContentsIntegrity);



            if (requiredAppVersion > currentAppVersion) {
              this.responseObj.header.apiName = 'APP_UPDATE';
              this.responseObj.header.errorText = environment.appRequiredVer[osType];
              this.responseObj.header.result = true;
              resolve(this.responseObj);
            } else {
              this.logger.log('[isCreateContentsIntegrity] ' + isCreateContentsIntegrity);
              this.logger.log('[DeviceInfo contentsVersion] ' + res.body.contentsVersion);
              if (!isCreateContentsIntegrity && res.body.contentsVersion === '1.0') {

                const checkContentsParam = new CheckContentsParam('new');

                this.logger.log('[Native] Contents origin data creating...');
                this.checkContents.checkIntegrity(checkContentsParam).then(
                  (checkContentsRes) => {
                    this.logger.log('[Native] Contents origin data created successfully.');
                    this.util.setSecureStorage(LOCAL_STORAGE.IS_CREATE_CONTENTS_INTEGRITY, true);
                    // resolve(this.responseObj);
                    this.backService.restart();
                  },
                  (checkContentsErr) => {
                    this.logger.log('[Native]Contents origin data creating failed.');
                    this.logger.log(JSON.stringify(checkContentsErr));
                    reject(checkContentsErr);
                  }
                );

              } else {

                if (!environment.appAutoUpdate) {
                  this.logger.warn('[Native] Contents Update set false.');
                  this.responseObj.header.apiName = 'APPLICATION_UPDATE';
                  this.responseObj.header.result = true;
                  this.responseObj.body.isLatest = true;
                  resolve(this.responseObj);
                } else {
                  this.logger.log('[Native] Contents need to update.');
                  const ZZ0006Req = new UpdateParam(
                    environment.appKey[osType],
                    osType,
                    osVersion,
                    appVersion,
                    contentsVersion,
                    displayType);

                  this.getCurrentInfo(ZZ0006Req).then((ZZ0006Res) => {

                    this.logger.log('ZZ0006 : ' + JSON.stringify(ZZ0006Res));


                    if (ZZ0006Res.header.result) {

                      // const currentAppVersion = [
                      //   ZZ0006Res.body.app_major_version,
                      //   ZZ0006Res.body.app_minor_version,
                      //   ZZ0006Res.body.app_build_version];
                      const currentContentsVersion = [ZZ0006Res.body.content_major_version, ZZ0006Res.body.content_minor_version];
                      const strCurrentContentsVersion = ZZ0006Res.body.content_major_version + '.' + ZZ0006Res.body.content_minor_version;

                      if (ZZ0006Res.body.app_result) {
                        // App update
                        this.logger.log('[Native]App updated successfully.');
                      } else {
                        // check contents update
                        if (ZZ0006Res.body.content_result) {
                          // update contents
                          // alert(1);
                          const serverUrl = this.bizServer.getServerURI();
                          const patchParam = new AppPatchParam('contents',
                          serverUrl,
                          strCurrentContentsVersion,
                          ZZ0006Res.body.app_filename,
                          ZZ0006Res.body.content_major_filename,
                          ZZ0006Res.body.content_minor_filename,
                          progressOption, true);
                          this.logger.log('Update Param ');
                          this.logger.log(patchParam);
                          this.updateManager.update(patchParam).then(
                            (resUp) => {
                              this.logger.log('[Native]Contents updated successfully:' + resUp);
                              this.logger.log('[Native]Contents updated successfully.');
                              resolve(this.responseObj);
                            }, (err) => {
                              this.logger.log('[Native]Contents Patch Error');
                              this.logger.log(JSON.stringify(err));
                              reject(err);
                            }
                          );

                        } else {

                          // alert(2);
                          this.responseObj.header.apiName = 'APPLICATION_UPDATE';
                          this.responseObj.header.result = true;
                          this.responseObj.body.isLatest = true;
                          resolve(this.responseObj);
                        }
                      }
                    } else {
                      this.logger.log('[ZZ0006]Update version Checking Error');
                      this.logger.log(JSON.stringify(ZZ0006Res));
                      reject(ZZ0006Res);
                    }
                  },
                    (ZZ0006Err) => {
                      this.logger.log('[ZZ0006]Update version Checking Error');
                      this.logger.log(JSON.stringify(ZZ0006Err));
                      reject(ZZ0006Err);
                    });

                }

              }

            }


          },
          (err) => {
            this.logger.log('[Native]DEVICE_INFO  Error');
            this.logger.log(JSON.stringify(err));
            this.responseObj.header.apiName = 'DEVICE_INFO';
            this.responseObj.header.result = false;
            this.responseObj.header.errorCode = err.header.errorCode;
            this.responseObj.header.errorText = err.body.errorText;

            reject(this.responseObj);

          });

      }

    });

    return promiseReturn;
  }

  checkVersion(deviceVer: Array<number>, currentVer: Array<number>) {

    let floatStrDeviceVer: string;
    let floatStrCurrentVer: string;

    deviceVer.forEach((val, idx) => {
      if (idx === 1) {
        floatStrDeviceVer += '.' + deviceVer[idx];
      } else {
        floatStrDeviceVer += deviceVer[idx];
      }
    });

    currentVer.forEach((val, idx) => {
      if (idx === 1) {
        floatStrCurrentVer += '.' + currentVer[idx];
      } else {
        floatStrCurrentVer += currentVer[idx];
      }
    });

    let checkResult: boolean;
    // alert(parseFloat(floatStrCurrentVer));
    // alert(parseFloat(floatStrDeviceVer));

    if (parseFloat(floatStrCurrentVer) > parseFloat(floatStrDeviceVer)) {
      checkResult = true;
    }

    return checkResult;

  }

  stringToNumberArray(version: string) {

    const retArray: Array<number> = new Array();

    const versionstrArr = version.split('.');

    // tslint:disable-next-line: only-arrow-functions
    versionstrArr.forEach(function(value) {
      retArray.push(Number(value));
    });

    return retArray;

  }

  getCurrentInfo(param): Promise<any> {

    return this.bizServer.bizMOBContent(param).toPromise();
  }

  getDeviceInfo(): Promise<any> {

    const promiseReturn = new Promise((resolve, reject) => {

      const param = new DeviceInfoParam();

      this.deviceInfo.getDeviceInfo(param).then(
        (res) => {
          resolve(res);
        },
        (err) => {
          this.logger.log('DEVICE_INFO Error');
          this.logger.log(JSON.stringify(err));
          this.responseObj.header.apiName = 'DEVICE_INFO';
          this.responseObj.header.result = false;
          this.responseObj.header.errorCode = err.header.errorCode;
          this.responseObj.header.errorText = err.body.errorText;

          reject(this.responseObj);

        });

    });

    return promiseReturn;
  }


  initSecurity(): Promise<any> {

    const promiseReturn = new Promise((resolve, reject) => {

      const appIronParam = new AppIronParam();
      const appRootingParam = new AppRootingParam();


      if (!this.platform.is('cordova') || !environment.checkAppIron) {

        this.responseObj.header.apiName = 'SECURITY_CHECK';
        this.responseObj.header.result = true;
        resolve(this.responseObj);

      } else {

        this.checkRooting.check(appRootingParam).then(
          (rootRes) => {
            if (rootRes.header.result) {

              if (!rootRes.body.isRooting) {

                this.logger.log('Non-Rooting Device detected.');
                this.logger.log(JSON.stringify(rootRes));

                this.appIron.checkAppIron(appIronParam).then(
                  (iornRes) => {

                    if (iornRes.header.result) {
                      const param = new ChkProxyParam();

                      this.checkProxy.checkProxy(param).then(
                        (proxyRes) => {
                          if (!proxyRes.body.isProxy) {
                            this.responseObj.header.apiName = 'SECURITY_CHECK';
                            this.responseObj.header.result = true;

                            resolve(this.responseObj);
                          } else {

                            this.logger.log('check Proxy Error');
                            this.logger.log(JSON.stringify(proxyRes));
                            this.responseObj.header.apiName = 'CHECK_PROXY';
                            this.responseObj.header.result = false;
                            this.responseObj.header.errorCode = 'CP0000';
                            this.responseObj.header.errorText = 'Connected through proxy server detected.',

                              reject(this.responseObj);
                          }

                        }, (err) => {
                          this.logger.log('App Iorn Error');
                          this.logger.log(JSON.stringify(err));
                          this.responseObj.header.apiName = 'CHECK_PROXY';
                          this.responseObj.header.result = false;
                          this.responseObj.header.errorCode = err.header.errorCode;
                          this.responseObj.header.errorText = err.body.errorText;

                          reject(this.responseObj);
                        }
                      );
                    } else {

                      this.logger.log('App Iorn Error');
                      this.logger.log(JSON.stringify(iornRes));
                      this.responseObj.header.apiName = 'APP_IRON';
                      this.responseObj.header.result = false;
                      this.responseObj.header.errorCode = iornRes.body.appIronCode;
                      this.responseObj.header.errorText = iornRes.body.appIronErrorMsg;

                      reject(this.responseObj);

                    }

                  },
                  (err) => {
                    this.logger.log('App Iorn Error');
                    this.logger.log(JSON.stringify(err));
                    this.responseObj.header.apiName = 'APP_IRON';
                    this.responseObj.header.result = false;
                    this.responseObj.header.errorCode = err.header.errorCode;
                    // this.responseObj.header.errorText = err.header.errorText;
                    this.responseObj.header.errorText = 'Network problem occured.';

                    reject(this.responseObj);
                  }
                );

              } else {
                this.logger.log('App CheckRooting Detected.');
                this.logger.log(JSON.stringify(rootRes));
                this.responseObj.header.apiName = 'APP_ROOTING';
                this.responseObj.header.result = false;
                this.responseObj.header.errorCode = rootRes.header.errorCode;
                this.responseObj.header.errorText = rootRes.header.errorText;

                reject(this.responseObj);
              }


            } else {

              this.logger.log('App CheckRooting Error');
              this.logger.log(JSON.stringify(rootRes));
              this.responseObj.header.apiName = 'APP_ROOTING';
              this.responseObj.header.result = false;
              this.responseObj.header.errorCode = rootRes.header.errorCode;
              this.responseObj.header.errorText = rootRes.header.errorText;

              reject(this.responseObj);
            }

          },
          (err) => {
            this.logger.log('App CheckRooting Error');
            this.logger.log(JSON.stringify(err));
            this.responseObj.header.apiName = 'APP_ROOTING';
            this.responseObj.header.result = false;
            this.responseObj.header.errorCode = err.header.errorCode;
            this.responseObj.header.errorText = err.header.errorText;

            reject(this.responseObj);
          }
        );


      }

    });

    return promiseReturn;
  }

}
