import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BizWavePush } from '@ionic-native/bizwave-plugin-bizpush/ngx';


@NgModule({
  declarations: [],
  providers : [
    BizWavePush
  ],
  imports: [
    CommonModule
  ]
})
export class BizmobModule { }
