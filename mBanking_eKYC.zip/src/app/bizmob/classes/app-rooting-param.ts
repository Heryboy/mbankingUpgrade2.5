export class BaseHeader {

    public result:boolean = false;
    public apiName:string = 'check';
    public language:string = '';
    public osType:string = '';
    public displayType:string = '';
    public errorCode:string = '';
    public errorText:string = '';
}

export class AppRootingBody {

    constructor() {
    }

}

export class AppRootingParam {

    header : BaseHeader;
    body: AppRootingBody;

    constructor( ){
        this.header = new BaseHeader();
        this.body = new AppRootingBody();
    }

}
