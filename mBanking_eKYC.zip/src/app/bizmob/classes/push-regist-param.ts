import { environment } from 'src/environments/environment';

export class PushRegistBody {
    // public pushUrl: string = environment.bizPushServer.URL;
    // public pushKey = '';
    // public userId = '';
    // public deviceId = '';
    // public appName: string = environment.appName;
    // public channelId = '';
    // public channelName = '';
    // public channelDescription = '';
    // public notiImportance = 'high';

    //pushUrl is old parameter
    //it is not used in iOS; however, it is still used in Android but it is not necessary
    // public pushUrl: string = environment.bizPushServer.URL;
    //url and path are new parameters
    //they are used to replace pushUrl
    public pushUrl: string = environment.bizPushServer.bigPictureUrl;
    public url: string = environment.bizPushServer.pushDomain;
    public path: string = environment.bizPushServer.pathRegisterNotification;

    public pushKey = '';
    public userId = '';
    public deviceId = '';
    public appName: string = environment.appName;
    public channelId = '';
    public channelName = '';
    public channelDescription = '';
    public notiImportance = 'high';

    constructor(userId: string, deviceId: string) {
        this.userId = userId;
        this.deviceId = deviceId;
    }
}

export class BaseNativeHeader {
    public result = false;
    public apiName = 'PUSH_REGISTRATION';
    public language = '';
    public osType = '';
    public displayType = '';
    public errorCode = '';
    public errorText = '';
}

export class PushRegistParam {
    body: PushRegistBody;
    header: BaseNativeHeader;

    constructor(userId: string, deviceId: string) {
        this.header = new BaseNativeHeader();
        this.body = new PushRegistBody(userId, deviceId);
    }
}
