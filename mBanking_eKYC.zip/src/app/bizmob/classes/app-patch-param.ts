export class appPatchBody {

    public type: string = "";
    public url: string = "";
    public fileName = {
        "app" : "",
        "cMajor" : "",
        "cMinor" : ""
    };
    public contentsVersion: string = "";
    public integrity = true;
    public progress = {
        "show" : true,
        "title" : "",
        "message" : ""
    };

    constructor(update_type: string, serverUrl:string, current_contents_version: string , app_filename: string , contents_major_filename: string , contents_minor_filename: string , progress_options: any, integrity: boolean) {

        this.type = update_type;
        this.url = serverUrl;
        this.contentsVersion = current_contents_version;
        if (!integrity) {
            this.integrity = integrity;
        }
        this.fileName.app = app_filename;
        this.fileName.cMajor = contents_major_filename;
        this.fileName.cMinor = contents_minor_filename;
        this.progress = progress_options;
    }

}


export class BaseHeader {

    public result:boolean = false;
    public apiName:string = "UPDATE";
    public language:string = "";
    public osType:string = "";
    public displayType:string = "";
    public errorCode:string = "";
    public errorText:string = "";
  
}


export class AppPatchParam {
    header : BaseHeader;
    body: appPatchBody;

    constructor( update_type: string, serverUrl:string, current_contents_version: string , app_filename: string , contents_major_filename: string , contents_minor_filename: string , progress_options: any , integrity?: boolean){
        this.header = new BaseHeader();
        this.body = new appPatchBody(update_type, serverUrl, current_contents_version, app_filename, contents_major_filename, contents_minor_filename, progress_options, integrity);
    }
}
