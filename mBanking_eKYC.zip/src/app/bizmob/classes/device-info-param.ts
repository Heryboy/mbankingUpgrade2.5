export class DeviceInfoParam {
    body : {};
    header : BaseNativeHeader;

    constructor() {
        this.header = new BaseNativeHeader();
    }
}

export class BaseNativeHeader {
 
  public result:boolean = false;
  public apiName:string = "getDeviceInfo";
  public language:string = "";
  public osType:string = "";
  public displayType:string = "";
  public errorCode:string = "";
  public errorText:string = "";

}


