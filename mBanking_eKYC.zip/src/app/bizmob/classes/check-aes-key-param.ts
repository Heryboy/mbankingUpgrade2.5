export class BaseNativeHeader {
    public result: boolean = false;
    public apiName: string = 'decryptAES';
    public language: string = '';
    public osType: string = '';
    public displayType: string = '';
    public errorCode: string = '';
    public errorText: string = '';
}

export class CheckAESKeyParam {
    body: {};
    header: BaseNativeHeader;

    constructor() {
        this.header = new BaseNativeHeader();
    }
}
