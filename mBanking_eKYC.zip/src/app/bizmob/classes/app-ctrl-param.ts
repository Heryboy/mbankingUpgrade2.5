
export class BaseNativeHeader {
   
    public result:boolean = false;
    public apiName:string = "applicationExit";
    public language:string = "";
    public osType:string = "";
    public displayType:string = "";
    public errorCode:string = "";
    public errorText:string = "";
  
}

export class AppCtrlParam {
    body : {};
    header : BaseNativeHeader;

    constructor() {
        this.header = new BaseNativeHeader();
    }
}

