export class CheckContentsBody {

    public type = '';

    constructor(generateType: string) {
        this.type = generateType;
    }

}

export class BaseNativeHeader {

    public result = false;
    public apiName = 'checkIntegrity';
    public language = '';
    public osType = '';
    public displayType = '';
    public errorCode = '';
    public errorText = '';

}

export class CheckContentsParam {

    body: CheckContentsBody;
    header: BaseNativeHeader;

    constructor(generateType: string) {
        this.header = new BaseNativeHeader();
        this.body = new CheckContentsBody(generateType);
    }

}
