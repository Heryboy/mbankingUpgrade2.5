export class GetPushKeyParam {
}
