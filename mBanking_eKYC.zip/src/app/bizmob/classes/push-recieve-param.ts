import { environment } from 'src/environments/environment';

export class PushRecieveBody {
    public url: string = environment.bizPushServer.pushDomain;
    public path: string = environment.bizPushServer.pathReceiptNotification;
    public user_id: string = '';
    public message_id: string = '';

    constructor(userId: string, messageId: string) {
        this.user_id = userId;
        this.message_id = messageId;
    }
}

//We need to pass parameter <header> to plugin but it is not used
//So, we don't need to careful about parameters in <header>
export class BaseNativeHeader {
    public result = false;
    public apiName = 'PUSH_RECIEVE';
    public language = '';
    public osType = '';
    public displayType = '';
    public errorCode = '';
    public errorText = '';
}

export class PushRecieveParam {
    body: PushRecieveBody;
    header: BaseNativeHeader;

    constructor(userId: string, messageId: string) {
        this.header = new BaseNativeHeader();
        this.body = new PushRecieveBody(userId, messageId);
    }
}
