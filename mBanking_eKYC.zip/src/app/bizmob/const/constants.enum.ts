
export enum AppIronErrorMsg {

    ERR_1100 = "Network Error",
    ERR_1101 = "CURL Library Init Error",
	ERR_1102 = "08",
    ERR_1103 = "09"

    // if (code.equals("1100")) {
    //     message = "";
    // } else if (code.equals("")) {
    //     message = "";
    // } else if (code.equals("1102")) {
    //     message = "Couldn’t Resolve Host";
    // } else if (code.equals("1103")) {
    //     message = "Couldn’t Connect to Server";
    // } else if (code.equals("2001")) {
    //     message = "Client Key Init Error.";
    // } else if (code.equals("2004")) {
    //     message = "Server Response SESSION ID is Empty";
    // } else if (code.equals("2005")) {
    //     message = "Server Response PROTOCOL Error(BASE64 DECODE)";
    // } else if (code.equals("2006")) {
    //     message = "Server Response SESSION ID is Empty";
    // } else if (code.equals("2007")) {
    //     message = "Key Final Error";
    // } else if (code.equals("3002")) {
    //     message = "Server Response PROTOCOL Error(Decrypt)";
    // } else if (code.equals("3003")) {
    //     message = "Server Response Nonce is Empty";
    // } else if (code.equals("3004")) {
    //     message = "Server Response ENC ID is Empty";
    // } else if (code.equals("3005")) {
    //     message = "Server Response ENC ID value is not supported";
    // } else if (code.equals("3006")) {
    //     message = "Server Response authType is Empty";
    // } else if (code.equals("3007")) {
    //     message = "Server Response authType value is not supported";
    // } else if (code.equals("3008")) {
    //     message = "Server Response skipYn is Empty";
    // } else if (code.equals("3009")) {
    //     message = "Server Response skipYn value is not supported";
    // } else if (code.equals("3010")) {
    //     message = "Server Response hashTarget is Empty";
    // } else if (code.equals("3011")) {
    //     message = "Server Response hashTarget value is not supported";
    // } else if (code.equals("3012")) {
    //     message = "Server Response abendYn is Empty";
    // } else if (code.equals("3013")) {
    //     message = "Server Response abendYn value is not supported";
    // } else if (code.equals("5003")) {
    //     message = "Server Response Token is Empty";
    // } else if (code.equals("5101")) {
    //     message = "authValue is null.(AppMac)";
    // } else if (code.equals("6000")) {
    //     message = "request parameter Error.";
    // } else if (code.equals("6001")) {
    //     message = "request pattern Error.";
    // } else if (code.equals("6002")) {
    //     message = "opcode Error.";
    // } else if (code.equals("6500")) {
    //     message = "data pattern Error.";
    // } else if (code.equals("6600")) {
    //     message = "not found session id Error";
    // } else if (code.equals("6601")) {
    //     message = "session expired Error";
    // } else if (code.equals("6602")) {
    //     message = "castoff session id Error";
    // } else if (code.equals("6900")) {
    //     message = "Core Library Error";
    // } else if (code.equals("7000")) {
    //     message = "Server keyinit Error.";
    // } else if (code.equals("7001")) { 
    //     message = "not found session";
    // } else if (code.equals("7002")) { 
    //     message = "session timeover";
    // } else if (code.equals("7003")) { 
    //     message = "missmatch token";
    // } else if (code.equals("8000")) {
    //     message = "not found app";
    // } else if (code.equals("8001")) {
    //     message = "missmatched app Error";
    // } else if (code.equals("9000")) {
    //     message = "Detect simulator device";
    // } else if (code.equals("9001")) {
    //     message = "Detect faked app";
    // } else if (code.equals("9002")) {
    //     message = "Detect rooting device";
    // } else if (code.equals("9003")) {
    //     message = "Detect faked lib";
    // } else if (code.equals("9004")) {
    //     message = "Detect black app";
    // } else if (code.equals("9998")) {
    //     message = "not supported method.";
    // } else if (code.equals("9999")) {
    //     message = "Unknown Error.";
    // } else if (code.equals("90000")) { 
    //     message = "replace auth value";
    // } else if (code.equals("90001")) { 
    //     message = "expired authkey";
    // } else if (code.equals("90002")) { 
    //     message = "device already exist";
    // } else if (code.equals("90003")) { 
    //     message = "not found authkey";
    // } else {
    //     message = "";
    // }
}
