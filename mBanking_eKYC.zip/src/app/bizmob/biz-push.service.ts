import { Injectable } from '@angular/core';
import { BizWavePush } from '@ionic-native/bizwave-plugin-bizpush/ngx';
import { BizWaveDeviceInfo } from '@ionic-native/bizwave-plugin-deviceinfo/ngx';
import { Platform } from '@ionic/angular';
import { Util } from '../shared/util';
import { DeviceInfoParam } from './classes/device-info-param';
import { PushRecieveParam } from './classes/push-recieve-param';
import { PushRegistParam } from './classes/push-regist-param';


@Injectable({
  providedIn: 'root'
})
export class BizPushService {

  util = new Util();
  private responseObj = {
    body : {},
    header : {
      result : true,
      apiName : 'REGIST_USER',
      language : '',
      osType : '',
      displayType : '',
      errorCode : '',
      errorText : ''
    }
  };

  constructor(
    private bizpush: BizWavePush,
    private platform: Platform,
    private deviceInfo: BizWaveDeviceInfo
  ) { }

  registUser(userID: string): Promise<any> {

    const promiseReturn = new Promise((resolve, reject) => {

        const isPushRegistration = JSON.parse(localStorage.getItem('BIZMOB_PUSH_REGISTRAION'));
        if ( isPushRegistration ) {
          // const pushKeyParam =  new PushRegistParam(userID);
          // this.bizpush.updatePushAgreementInfo(pushKeyParam).then((res)=>{
          //   console.log(res);
          // });

          resolve(this.responseObj);

        } else {

          if (!this.platform.is('mobile')) {
            resolve(this.responseObj);
          } else {
            const param = new DeviceInfoParam();

            this.deviceInfo.getDeviceInfo(param).then(
              res => {
                const deviceId = res.body.deviceId;
                const pushKeyParam =  new PushRegistParam(userID, deviceId);
                console.log('pushKeyParam', JSON.stringify(pushKeyParam));

                this.bizpush.pushRegistration(pushKeyParam).then(
                  res1 => {
                    console.log('push registration is success : ' + JSON.stringify(res) );
                    localStorage.setItem('BIZMOB_PUSH_REGISTRAION', JSON.stringify(true));
                    localStorage.setItem('PUSH_REGISTER_USER', JSON.stringify(userID));
                    resolve(this.responseObj);
                  },
                  err => {
                    console.log('push registration is fail : ' + JSON.stringify(err) );
                    reject(err);
                  }
                );
              },
              err => {
                console.log('Error deviceInfo: ' + JSON.stringify(err));
                reject(err);
              });
          }
        }
    });

    return promiseReturn;
  }

  /*
  * getPayLoad
  * @param      {string} userId
  *             {string} messageId
  * @return     {Promisie|any}
  * @usage      used to get data from notification
  */
  getPayLoad(userId: string, messageId: string): Promise<any> {
    const promiseReturn = new Promise((resolve, reject) => {
      const param =  new PushRecieveParam(userId, messageId);
      console.log('@@@param', JSON.stringify(param));

      this.bizpush.pushReceivedCheck(param).then(result => {
          console.log('get payload is success : ' + JSON.stringify(result));
          resolve( result.body.body.messagePayload);
        }, error => {
          console.log('get payload is fail : ' + JSON.stringify(error));
          reject(error);
        }
      );
    });

    return promiseReturn;
  }

}
