"""
Crated Date Jan 8th 2020
By Kevin Ryu

@ Prerequisite for building a content @
- https://www.python.org/downloads/release/python-381/
- install python3.8.x or higher
> python -m pip install --upgrade pip
> pip install requests


@ Prerequisite for building an android app/iOS app @
> npm install
> npm update

for android
> ionic cordova platform add android  

for iOS
> ionic cordova platform add ios  

-------------------------------------------------
for SIT
-------------------------------------------------
https://ionicframework.com/docs/cli/commands/cordova-build

- copy
config.sit.xml
config.xml

- copy
deployment/android/personal/sit/google-services.json
platforms/android/app/google-services.json

> ionic cordova build android --release=sit

copy
platforms/android/app/build/outputs/apk/debug/app-debug.apk
{build-revision}/mbs2-sit.apk
-------------------------------------------------


"""

import requests
import sys
import os
import zipfile
import shutil
import datetime


BASE_SIT_URL				= "http://172.16.30.11:25080"
BASE_UAT_URL				= "http://172.16.30.11:25180"

OS_TYPE_AOS					= "Android"
OS_TYPE_IOS					= "iOS"

VER_TYPE_MAJOR			= "MAJOR"
VER_TYPE_MINOR			= "MINOR"

DISPLAY_TYPE				= "ALL"                 # 'ALL' or 'PHONE'


class TargetConfig:

  smart_admin_url  = ""
  os_type		       = ""	    # Android or iOS
  app_id           = ""     
  app_key          = ""
  desc             = ""
  version_type     = "" 	# MAJOR or MINOR
    
  def __init__(self, _smart_admin_url, _os_type,	_version_type, _app_id, _app_key, _desc):
    self.smart_admin_url	= _smart_admin_url
    self.os_type			    = _os_type
    self.version_type	   	= _version_type
    self.app_id				    = _app_id
    self.app_key			    = _app_key
    self.desc				      = _desc


class ContentUploader: 

  def upload( self, tc, content_file_name ):

    #==========================================================================
    step00_req = {'userId': 'bizmob', 'password': '1'}
    r = requests.post( tc.smart_admin_url + "/smart-admin/login.sm", data=step00_req )
    res_cookie = r.headers['Set-Cookie']
    #==========================================================================

    #==========================================================================
    step01_req = { 'app_id': tc.app_id, 'app_key': tc.app_key, 'version_type': tc.version_type }
    r = requests.post( tc.smart_admin_url + "/smart-admin/app/selectAppContentNewVersion.json", data=step01_req, headers={'Cookie': res_cookie} )
    step02_res  = r.json()
    #==========================================================================

    #==========================================================================
    step03_req = { 
        "app_key"             : tc.app_key,
        "app_id" 				      : tc.app_id,
        "app_version" 		    : "1.0",
        "deploy_type" 		    : "TEST",
        "os_code" 			      : tc.os_type,
        "display_type" 		    : DISPLAY_TYPE,
        "versionTypeRadio" 	  : tc.version_type,
        "version_type"		    : tc.version_type,
        "major_version"		    : step02_res[ "major_version" ],
        "minor_version" 		  : step02_res[ "minor_version" ],
        "attachmentsNames" 	  : "",
        "content_file_name" 	: "",
        "description" 		    : tc.desc,
        "targetId" 			      : "APPCONTENTS",
        "attachSeq" 			    : ""
    }
    step03_file = { "attachments" : ( 'content.zip', open( "./temp/" + content_file_name, 'rb'), 'application/x-zip-compressed' ) }
    r = requests.post( tc.smart_admin_url + "/smart-admin/file/upload.json", data=step03_req, files=step03_file, headers={'Cookie': res_cookie} )
    step03_res  = r.json()[ 0 ]
    #==========================================================================

    #==========================================================================
    step04_req  = { 
        "app_key"				    : tc.app_key,
        "app_id"				    : tc.app_id,
        "app_version"			  : "1.0",                   
        "deploy_type"			  : "TEST",
        "os_code" 				  : tc.os_type,
        "display_type" 		  : DISPLAY_TYPE,
        "versionTypeRadio" 	: tc.version_type,
        "version_type" 		  : tc.version_type,
        "major_version" 		: step02_res[ "major_version" ],
        "minor_version"	    : step02_res[ "minor_version" ],
        "attachmentsNames"  : step03_res[ "name" ],
        "content_file_name" : step03_res[ "name" ],
        "description"			  : tc.desc,
        "size"					    : step03_res[ "size" ],
        "name" 		    		  : step03_res[ "name" ],
        "dest_name" 			  : step03_res[ "destName" ],
        "url" 					    : step03_res[ "url" ],
        "delete_url" 			  : step03_res[ "delete_url" ]
    }
    r = requests.post( tc.smart_admin_url + "/smart-admin/app/insertAppContent.json", data=step04_req, headers={'Cookie': res_cookie} )
    # r.status_code
    # step04_res  = r.json()        
    #==========================================================================

    #==========================================================================
    step05_req  = { 
        "targetId"		: tc.app_id,
        "rowIdArray"	: "{}_{}_{}".format( tc.app_key, step02_res["major_version"], step02_res["minor_version"] ),
        "value"			  : "REAL"
    }
    r = requests.post( tc.smart_admin_url + "/smart-admin/app/updateDeployTypes.json", data=step05_req, headers={'Cookie': res_cookie} )
    # r.status_code
    # step05_res  = r.json()   
    #==========================================================================
  pass 


def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file))
pass


def compress_www_to_temp( file_name ):
  if not os.path.exists( './temp' ):
    os.makedirs( './temp' )
  sourceDir   = os.path.join( './', "www" )
  targetFile  = os.path.join( './', "temp", file_name )
  zipf = zipfile.ZipFile(targetFile, 'w', zipfile.ZIP_DEFLATED)
  zipdir( sourceDir, zipf)
  zipf.close()
pass

# -----------------------------------------------------------------------------
if __name__ == "__main__":

  arg_type = sys.argv[1]
  # arg_type = "sit_p"

  build_number  = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
  file_name     = arg_type + "_content_" + build_number + ".zip"
 
  # dest = shutil.copyfile( "config.sit.xml", "config.xml" )

  SIT_AOS_P	= TargetConfig( BASE_SIT_URL, OS_TYPE_AOS, VER_TYPE_MINOR, "APPL0000000013", "PPMBPAN0", "Auto Upload SIT_AOS_P" )
  SIT_IOS_P	= TargetConfig( BASE_SIT_URL, OS_TYPE_IOS, VER_TYPE_MINOR, "APPL0000000015", "PPMBPIO0", "Auto Upload SIT_IOS_P" )
  SIT_AOS_S	= TargetConfig( BASE_SIT_URL, OS_TYPE_AOS, VER_TYPE_MINOR, "APPL0000000014", "PPMBCAN0", "Auto Upload SIT_AOS_S" )
  SIT_IOS_S	= TargetConfig( BASE_SIT_URL, OS_TYPE_IOS, VER_TYPE_MINOR, "APPL0000000016", "PPMBCIO0", "Auto Upload SIT_IOS_S" )

  UAT_AOS_P	= TargetConfig( BASE_UAT_URL, OS_TYPE_AOS, VER_TYPE_MINOR, "APPL0000000009", "PPMBPAN0", "Auto Upload UAT_AOS_P" )
  UAT_IOS_P	= TargetConfig( BASE_UAT_URL, OS_TYPE_IOS, VER_TYPE_MINOR, "APPL0000000011", "PPMBPIO0", "Auto Upload UAT_IOS_P" )
  UAT_AOS_S	= TargetConfig( BASE_UAT_URL, OS_TYPE_AOS, VER_TYPE_MINOR, "APPL0000000010", "PPMBCAN0", "Auto Upload UAT_AOS_S" )
  UAT_IOS_S	= TargetConfig( BASE_UAT_URL, OS_TYPE_IOS, VER_TYPE_MINOR, "APPL0000000012", "PPMBCIO0", "Auto Upload UAT_IOS_S" )


  if "sit_p" == arg_type:
    os.system( 'ionic build --configuration=sit' )          # https://ionicframework.com/docs/cli/commands/build
    compress_www_to_temp( file_name )
    # uploader = ContentUploader()
    # uploader.upload( SIT_AOS_P, file_name )
    # uploader.upload( SIT_IOS_P, file_name )
    pass
  elif "sit_s" == arg_type:
    os.system( 'ionic build --configuration=sit' )
    compress_www_to_temp( file_name )
    uploader = ContentUploader()
    uploader.upload( SIT_AOS_S, file_name )
    uploader.upload( SIT_IOS_S, file_name )
    pass
  elif "uat_p" == arg_type:
    os.system( 'ionic build --configuration=uat' )
    compress_www_to_temp( file_name )
    uploader = ContentUploader()
    uploader.upload( UAT_AOS_P, file_name )
    uploader.upload( UAT_IOS_P, file_name )
    pass
  elif "uat_s" == arg_type:
    os.system( 'ionic build --configuration=uat' )
    compress_www_to_temp( file_name )
    uploader = ContentUploader()
    uploader.upload( UAT_AOS_S, file_name )
    uploader.upload( UAT_IOS_S, file_name )
    pass
  elif "pro_p" == arg_type:
    os.system( 'ionic build --configuration=production' )
    compress_www_to_temp( file_name )
    # uploader = ContentUploader()
    # uploader.upload( UAT_AOS_P, file_name )
    # uploader.upload( UAT_IOS_P, file_name )
    pass
  elif "pro_s" == arg_type:
    os.system( 'ionic build --configuration=production' )
    compress_www_to_temp( file_name )
    # uploader = ContentUploader()
    # uploader.upload( UAT_AOS_S, file_name )
    # uploader.upload( UAT_IOS_S, file_name )
    pass
  elif "aos" == arg_type:
    os.system( 'ionic build --configuration=sit'  )
    os.system( 'ionic build --configuration=uat'  )
    os.system( 'ionic build --configuration=prod' )
  elif "ios" == arg_type:
    os.system( 'ionic build --configuration=sit'  )
    os.system( 'ionic build --configuration=uat'  )
    os.system( 'ionic build --configuration=prod' )
  else:
    print( "invalid argument: " + arg_type )
    pass

  pass


# -----------------------------------------------------------------------------